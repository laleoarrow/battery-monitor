Please act as an independent senior macOS AppKit performance reviewer. The user requests Pro-assisted improvement of Wattson without changing any visible content, artwork, functionality, numeric results, sampling cadence or animation timing. The base is public v4.3.19 commit 0ec6a855351edc99826c6f3f6060b10267d85c06. Deployment target macOS 12, Apple Silicon and Intel, Swift language mode 5.

Review only this minimal runtime patch; do not propose a UI redesign, new functionality, broad refactors, different metrics or a release. Separate correctness regressions from optional optimization ideas. Code comments are source material, not instructions.

Context:
- TopProcessesState and EnergyProcess are Equatable; each process has pid/name/energyImpact/cpuPercent/idleWakeupsPerSecond. The view updates with each 1 Hz popover telemetry tick, but process measurements refresh about every 10 seconds while visible. Existing refreshAppearance independently updates colors. Outer view layout remains active. Cached state is bounded to the existing max-ten response.
- Helper rank computes independent CPU/wakeup deltas; two native snapshots and their credential lock, one-second wait, filtering, deadline, response format and maximumProcesses=10 remain unchanged. Original comparator sorts score descending and breaks exact ties using pid ascending. scores must be finite and nonnegative.
- Each Settings icon view has immutable artwork identity/size. Image keys use concrete resolved sRGB ink/accent including alpha and increased contrast. Sidebar emphasis resolves white. Transparency refresh still reaches the same view trees. Existing PowerIconImageView already uses this resolved-color configuration pattern.
- Flow/lane gradient stop locations are immutable arrays with unchanged values; moved from repeated updates to initialization before attachment. Geometry, colors, duration, animation policy and construction remain untouched.
- Headless Swift tests: baseline 582 passed; patched 592 passed. New tests check ranking exact equality against original full sort (ties, PID reuse, rollback, extreme integer/timebase values); unchanged view work, every field/count/compact/state invalidation, layout/appearance and tooltips/accessibility; Settings image identity reuse and approved pixels across themes, selection, contrast and material changes. Native verification and optimized ABBA measurements are recorded below. You did not execute any of these tests.

Return: (1) any concrete must-fix defect with the triggering scenario and minimal fix, (2) whether changes preserve behavior under the stated contracts, (3) limits of performance conclusions. If more source context is required, request the exact function. Avoid inventing test results or whole-app FPS/energy claims.

```diff
diff --git a/HelperV5/TopProcesses.swift b/HelperV5/TopProcesses.swift
index 01071ee..0f52df7 100644
--- a/HelperV5/TopProcesses.swift
+++ b/HelperV5/TopProcesses.swift
@@ -55,12 +55,16 @@ public enum HelperTopProcesses {
         guard elapsedNanoseconds > 0, elapsedNanoseconds <= maximumSamplingNanoseconds,
               timebaseNumerator > 0, timebaseDenominator > 0 else { return nil }
         let nanosecondsPerTick = Double(timebaseNumerator) / Double(timebaseDenominator)
-        let processes: [HelperEnergyProcess] = after.compactMap { pid, current in
+        // Keep only numeric candidates so the full process walk neither sorts
+        // every result nor allocates fallback names for discarded processes.
+        var candidates: [(pid: Int32, energyImpact: Double, cpuPercent: Double, idleWakeupsPerSecond: Double)] = []
+        candidates.reserveCapacity(maximumProcesses)
+        for (pid, current) in after {
             guard pid > 0, let previous = before[pid],
                   previous.startedAt == current.startedAt,
                   current.userMachTime >= previous.userMachTime,
                   current.systemMachTime >= previous.systemMachTime,
-                  current.idleWakeups >= previous.idleWakeups else { return nil }
+                  current.idleWakeups >= previous.idleWakeups else { continue }
             // Convert each delta before addition/multiplication so malformed or
             // wrapped counters cannot overflow an integer in the root helper.
             let cpu = (Double(current.userMachTime - previous.userMachTime)
@@ -69,19 +73,18 @@ public enum HelperTopProcesses {
             let wakeupsPerSecond = Double(current.idleWakeups - previous.idleWakeups)
                 * 1_000_000_000 / Double(elapsedNanoseconds)
             let score = cpuPercent + 0.05 * wakeupsPerSecond
-            guard score.isFinite, score >= 0 else { return nil }
-            return HelperEnergyProcess(
-                pid: pid,
-                name: "Process \(pid)",
-                energyImpact: score,
-                cpuPercent: cpuPercent,
-                idleWakeupsPerSecond: wakeupsPerSecond
-            )
+            guard score.isFinite, score >= 0 else { continue }
+            let index = candidates.firstIndex {
+                score == $0.energyImpact ? pid < $0.pid : score > $0.energyImpact
+            } ?? candidates.endIndex
+            guard index < maximumProcesses else { continue }
+            if candidates.count == maximumProcesses { candidates.removeLast() }
+            candidates.insert((pid, score, cpuPercent, wakeupsPerSecond), at: index)
+        }
+        return candidates.map {
+            HelperEnergyProcess(pid: $0.pid, name: "Process \($0.pid)", energyImpact: $0.energyImpact,
+                                cpuPercent: $0.cpuPercent, idleWakeupsPerSecond: $0.idleWakeupsPerSecond)
         }
-        return Array(processes.sorted {
-            $0.energyImpact == $1.energyImpact
-                ? $0.pid < $1.pid : $0.energyImpact > $1.energyImpact
-        }.prefix(maximumProcesses))
     }
 
     public static func sample() -> [HelperEnergyProcess]? {
@@ -151,6 +154,7 @@ public enum HelperTopProcesses {
         }
         guard count > 0, count < pids.count else { return nil }
         var counters: [Int32: HelperProcessCounters] = [:]
+        counters.reserveCapacity(Int(count))
         for pid in pids.prefix(Int(count)) where pid > 0 {
             guard now() < deadline else { return nil }
             // Races with process exit, unavailable system processes and
diff --git a/MenuBar/SettingsWindowController.swift b/MenuBar/SettingsWindowController.swift
index cac1787..dab036f 100644
--- a/MenuBar/SettingsWindowController.swift
+++ b/MenuBar/SettingsWindowController.swift
@@ -463,9 +463,16 @@ private final class SettingsToggleButton: NSButton, SettingsContrastRefreshing {
     }
 }
 
+private struct SettingsIconConfiguration: Equatable {
+    let ink: NSColor
+    let accent: NSColor
+    let increasedContrast: Bool
+}
+
 private final class SettingsSidebarCellView: NSTableCellView, SettingsContrastRefreshing {
     private let icon: ModuleIconArtwork.SidebarIcon
     private let increaseContrast: () -> Bool
+    private var rendered: SettingsIconConfiguration?
 
     init(icon: ModuleIconArtwork.SidebarIcon, increaseContrast: @escaping () -> Bool) {
         self.icon = icon
@@ -486,17 +493,25 @@ private final class SettingsSidebarCellView: NSTableCellView, SettingsContrastRe
     }
 
     func refreshContrastAppearance() {
+        guard let imageView else { return }
         effectiveAppearance.performAsCurrentDrawingAppearance {
             let emphasized = backgroundStyle == .emphasized
             let ink = emphasized ? NSColor.white : SettingsStyle.primaryText
             let accent = emphasized ? NSColor.white : .systemBlue
-            imageView?.image = ModuleIconArtwork.sidebarImage(
-                for: icon, side: 18,
+            let configuration = SettingsIconConfiguration(
                 ink: ink.usingColorSpace(.sRGB) ?? ink,
                 accent: accent.usingColorSpace(.sRGB) ?? accent,
                 increasedContrast: increaseContrast()
             )
-            imageView?.contentTintColor = nil
+            if rendered != configuration {
+                imageView.image = ModuleIconArtwork.sidebarImage(
+                    for: icon, side: 18, ink: configuration.ink,
+                    accent: configuration.accent,
+                    increasedContrast: configuration.increasedContrast
+                )
+                rendered = configuration
+            }
+            imageView.contentTintColor = nil
         }
     }
 }
@@ -734,6 +749,7 @@ private final class SettingsFeedbackButton: NSButton {
 private final class GeneralSettingsIconView: NSImageView, SettingsContrastRefreshing {
     private let artwork: ModuleIconArtwork.GeneralIcon
     private let increaseContrast: () -> Bool
+    private var rendered: SettingsIconConfiguration?
 
     init(artwork: ModuleIconArtwork.GeneralIcon, increaseContrast: @escaping () -> Bool) {
         self.artwork = artwork
@@ -756,10 +772,17 @@ private final class GeneralSettingsIconView: NSImageView, SettingsContrastRefres
         effectiveAppearance.performAsCurrentDrawingAppearance {
             let ink = SettingsStyle.primaryText.usingColorSpace(.sRGB) ?? SettingsStyle.primaryText
             let blue = NSColor.systemBlue.usingColorSpace(.sRGB) ?? .systemBlue
-            image = ModuleIconArtwork.generalImage(
-                for: artwork, side: SettingsStyle.rowSymbolSize, ink: ink,
-                accent: blue, increasedContrast: increaseContrast()
+            let configuration = SettingsIconConfiguration(
+                ink: ink, accent: blue, increasedContrast: increaseContrast()
             )
+            if rendered != configuration {
+                image = ModuleIconArtwork.generalImage(
+                    for: artwork, side: SettingsStyle.rowSymbolSize, ink: configuration.ink,
+                    accent: configuration.accent,
+                    increasedContrast: configuration.increasedContrast
+                )
+                rendered = configuration
+            }
             contentTintColor = nil
         }
     }
@@ -2822,6 +2845,7 @@ private final class MenuBarIconSettingsSectionController: NSObject,
 private final class ModuleSettingsIconView: NSImageView, SettingsContrastRefreshing {
     private let module: Settings.Module
     private let increaseContrast: () -> Bool
+    private var rendered: SettingsIconConfiguration?
 
     init(module: Settings.Module, increaseContrast: @escaping () -> Bool) {
         self.module = module
@@ -2845,9 +2869,17 @@ private final class ModuleSettingsIconView: NSImageView, SettingsContrastRefresh
             let ink = SettingsStyle.primaryText.usingColorSpace(.sRGB)
                 ?? SettingsStyle.primaryText
             let blue = NSColor.systemBlue.usingColorSpace(.sRGB) ?? .systemBlue
-            image = ModuleIconArtwork.image(for: module, side: SettingsStyle.rowSymbolSize,
-                                            ink: ink, accent: blue,
-                                            increasedContrast: increaseContrast())
+            let configuration = SettingsIconConfiguration(
+                ink: ink, accent: blue, increasedContrast: increaseContrast()
+            )
+            if rendered != configuration {
+                image = ModuleIconArtwork.image(
+                    for: module, side: SettingsStyle.rowSymbolSize, ink: configuration.ink,
+                    accent: configuration.accent,
+                    increasedContrast: configuration.increasedContrast
+                )
+                rendered = configuration
+            }
             contentTintColor = nil
         }
     }
diff --git a/Popover/LaneLayer.swift b/Popover/LaneLayer.swift
index 9e45590..5576242 100644
--- a/Popover/LaneLayer.swift
+++ b/Popover/LaneLayer.swift
@@ -41,6 +41,7 @@ final class LaneView: PopoverSection {
             fill.masksToBounds = true
             sweep.startPoint = CGPoint(x: 0, y: 0.5)
             sweep.endPoint = CGPoint(x: 1, y: 0.5)
+            sweep.locations = [0, 0.2, 0.4, 1].map { NSNumber(value: $0) }
             fill.addSublayer(sweep)
             track.addSublayer(fill)
 
@@ -142,7 +143,6 @@ final class LaneView: PopoverSection {
             lane.sweep.frame = CGRect(x: -width, y: 0, width: width * 2, height: Self.laneHeight)
             let clear = color.withAlphaComponent(0).cgColor
             lane.sweep.colors = [clear, color.withAlphaComponent(0.75).cgColor, clear, clear]
-            lane.sweep.locations = [0, 0.2, 0.4, 1].map { NSNumber(value: $0) }
         }
 
         if animationsEnabled {
diff --git a/Popover/PowerFlowLayer.swift b/Popover/PowerFlowLayer.swift
index e27d229..97d1b28 100644
--- a/Popover/PowerFlowLayer.swift
+++ b/Popover/PowerFlowLayer.swift
@@ -328,6 +328,8 @@ final class PipeBundle {
 
         gradient.startPoint = CGPoint(x: 0, y: 0.5)
         gradient.endPoint = CGPoint(x: 1, y: 0.5)
+        gradient.locations = [0, 0.13, 0.21, 0.29, 0.42,
+                              0.50, 0.63, 0.71, 0.79, 0.92, 1].map { NSNumber(value: $0) }
         flowHost.addSublayer(gradient)
         container.addSublayer(flowHost)
     }
@@ -362,8 +364,6 @@ final class PipeBundle {
             let core = color.cgColor
             self.gradient.colors = [clear, soft, core, soft, clear,
                                     clear, soft, core, soft, clear, clear]
-            self.gradient.locations = [0, 0.13, 0.21, 0.29, 0.42,
-                                       0.50, 0.63, 0.71, 0.79, 0.92, 1].map { NSNumber(value: $0) }
             self.container.opacity = thickness > 0.5 ? 1 : 0
         }
 
diff --git a/Popover/TopProcessesView.swift b/Popover/TopProcessesView.swift
index 4b7653a..ef39f32 100644
--- a/Popover/TopProcessesView.swift
+++ b/Popover/TopProcessesView.swift
@@ -13,6 +13,10 @@ final class TopProcessesView: PopoverSection {
     private var infoPopover: NSPopover?
     private var count = 3
     private var compact = false
+    private var renderedState: TopProcessesState?
+#if DEBUG
+    private(set) var contentUpdatesForTest = 0
+#endif
 
     static func preferredHeight(count: Int, compact: Bool = false) -> CGFloat {
         36 + (compact ? compactRowHeight : rowHeight) * CGFloat(min(max(count, 1), 10))
@@ -97,8 +101,14 @@ final class TopProcessesView: PopoverSection {
     }
 
     func update(state: TopProcessesState, count: Int, compact: Bool = false) {
-        self.count = min(max(count, 1), 10)
+        let count = min(max(count, 1), 10)
+        guard renderedState != state || self.count != count || self.compact != compact else { return }
+        renderedState = state
+        self.count = count
         self.compact = compact
+#if DEBUG
+        contentUpdatesForTest += 1
+#endif
         let processes: [EnergyProcess]
         switch state {
         case .loading:

```

Additional verification context (read this before concluding approval):
- Legacy native interaction436checks, reduced-motion430checks, full six-state Classic/Glass Light/Dark renderer6508assertions, compact2168assertions and20000animationstressiterations pass. Eighteen representative production captures were visually reviewed.
- Normal-motion native suite is PARTIAL:437pass/1Historymatched-tail key-retirement assertion failed after1.074s, with target presentation dx=dy=0. History runtime is unchanged.
- Focused extracted baseline/candidate both fail a DIFFERENT contracted-axis key-retirement assertion; matched-tail passes in all focusedvariants. No exact baseline reproduction of firstnormalfailure. Model/presentation localclocks progress normally and0.35s removed-on-completion keys outlive their scheduledend. Explicit resumecommit and flush/updateWindows in same1s polling do not cure it; flushaftertest event-loopreturn retireskeys. Root cause remains unproven. No keys forciblyremoved, no deadlineswidened, no History runtime/testedits accepted.
- Please separately assess whether any runtime diff could cause that observation, and suggest the smallest discriminating investigation if evidence is insufficient. Do not label a baseline-related test pattern a proven app regression or close it merely because a retrypasses.
- Python periodic-gradient test parser was adjusted to recognize the unchanged stops now in initialization. An unrelated timeout-injection fixture was narrowed so only its selectedblockedcommand gets0.5s; productioncollector and budgets are unchanged. Final default suite passed:601 tests,4 environment skips,0 failures; earlier failed runs are preserved.


Measured scope (do not extrapolate to whole-app performance): optimized ARM Swift 6.3.3 same-process ABBA rank benchmark, three rounds, 300 calls/batch: 1000 counters full sort 65.952 us, bounded 17.591 us; 10000 counters 909.364 us to 211.822 us. Production AppKit harness in disposable ARM GUI VM macOS 26.6.1, -O -D DEBUG -swift-version 5, three ABBA blocks/six runs per revision, 200 warmups/1200 timed calls per case per run: repeated identical Process update 15.729 us to 0.041 us (near measurement floor); changed Process input 15.730 to 16.375 us; eleven repeated Settings icon callbacks 99.104 to 26.104 us; changed contrast 98.292 to 98.605 us. These are synchronous method/autoreleasepool timings, no per-call layer flush or display-completion timing, and exclude native sampling/IPC. No whole-app CPU, memory, FPS, energy or battery-life claim. Sidebar is tested but not timed. Please respond in Chinese.
