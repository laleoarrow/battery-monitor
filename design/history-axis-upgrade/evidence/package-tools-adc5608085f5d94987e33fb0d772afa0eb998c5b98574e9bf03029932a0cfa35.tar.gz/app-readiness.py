import json,subprocess,sys,time
from pathlib import Path
app=sys.argv[1]; output=Path(sys.argv[2]); exe=app+'/Contents/MacOS/Wattson'
samples=[]; passed=False; deadline=time.monotonic()+10
while time.monotonic()<deadline:
    listing=subprocess.check_output(['/bin/ps','-axo','pid=,comm='],text=True)
    pids=[int(p[0]) for line in listing.splitlines() if len(p:=line.strip().split(None,1))==2 and p[1]==exe]
    samples.append({'atEpoch':time.time(),'atSystemMonotonic':time.clock_gettime(time.CLOCK_MONOTONIC),'pids':pids})
    if len(samples)>=4 and all(len(item['pids'])==1 for item in samples[-4:]) and len({item['pids'][0] for item in samples[-4:]})==1 and samples[-1]['atSystemMonotonic']-samples[-4]['atSystemMonotonic']>=3:
        passed=True; break
    time.sleep(1)
with output.open('x') as f: json.dump({'executable':exe,'launcher':'direct open inside outer package owner; exact-path app stop in owner EXIT','samples':samples,'staysRunning':passed,'singletonPID':samples[-1]['pids'][0] if passed else None,'stableSeconds':samples[-1]['atSystemMonotonic']-samples[-4]['atSystemMonotonic'] if passed else None},f,indent=2)
if not passed: raise SystemExit('Installed app did not remain running')
