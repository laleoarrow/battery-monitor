#!/bin/bash
# Fresh installation exists only inside the explicitly owned History ARM clone.
set -euo pipefail
[[ $# == 4 && "$2" =~ ^[a-f0-9]{64}$ ]] || exit 64
incoming="$1"; expected_sha="$2"; results="$3"; expected_version="$4"
[[ "$expected_version" =~ ^[0-9]+\.[0-9]+\.[0-9]+$ ]] || exit 64
project="$HOME/Project/Wattson-HistoryAxis-QA"
[[ "$incoming" == '/Volumes/My Shared Files/repo/dist/'* && "$results" == '/Volumes/My Shared Files/history/'* ]] || exit 65
[[ "$(/usr/sbin/sysctl -n hw.model)" == VirtualMac* && "$(/usr/bin/uname -m)" == arm64 && -d "$project" ]] || exit 65
[[ ! -e "$results" && ! -L "$results" ]] || exit 65
app='/Applications/Wattson.app'; helper='/Library/PrivilegedHelperTools/com.leoarrow.wattson.helper'; plist='/Library/LaunchDaemons/com.leoarrow.wattson.helper.plist'
label='com.leoarrow.wattson.helper'; receipt='com.leoarrow.wattson.pkg'
for path in "$app" "$helper" "$plist" "$HOME/Library/Preferences/com.leoarrow.wattson.plist" "$HOME/Library/Containers/com.leoarrow.wattson" "$HOME/Library/Application Scripts/com.leoarrow.wattson" "$HOME/Library/Application Support/Wattson" "$HOME/Library/LaunchAgents/com.leoarrow.wattson.login.plist"; do [[ ! -e "$path" && ! -L "$path" ]] || exit 65; done
! /usr/sbin/pkgutil --pkg-info "$receipt" >/dev/null 2>&1 || exit 65
WATTSON_PACKAGE_QA_TOOLS_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$WATTSON_PACKAGE_QA_TOOLS_DIR/lib/local_cleanup.sh"
wattson_cleanup_init
mkdir "$results"
mkdir -p "$project/.build/packages.noindex"
scratch="$(mktemp -d "$project/.build/packages.noindex/run.XXXXXX")"
wattson_cleanup_add_dir "$scratch"
owned_install=0
return_status() { return "$1"; }
finish() {
 local status=$?
 trap - EXIT
 trap '' HUP INT TERM
 set +e
 if [[ -n "${_WATTSON_RUNNER_PID:-}" ]]; then kill -TERM "$_WATTSON_RUNNER_PID" 2>/dev/null; wait "$_WATTSON_RUNNER_PID" 2>/dev/null; _WATTSON_RUNNER_PID=''; fi
 if [[ "$owned_install" == 1 ]]; then
  wattson_stop_executable "$app/Contents/MacOS/Wattson" || status=1
  wattson_unregister_app "$app" || status=1
  /usr/bin/sudo -n /bin/launchctl bootout "system/$label" > "$results/helper-bootout.log" 2>&1 || true
  /usr/bin/sudo -n /bin/launchctl enable "system/$label" || status=1
  /usr/bin/sudo -n /usr/bin/python3 - "$app" "$helper" "$plist" <<'PY'
from pathlib import Path
import shutil,sys
assert sys.argv[1:]==['/Applications/Wattson.app','/Library/PrivilegedHelperTools/com.leoarrow.wattson.helper','/Library/LaunchDaemons/com.leoarrow.wattson.helper.plist']
for s in sys.argv[1:]:
 p=Path(s)
 if p.is_symlink() or p.is_file(): p.unlink()
 elif p.is_dir(): shutil.rmtree(p)
p=Path('/var/run/wattson-helper.sock')
if p.exists(): p.unlink()
PY
  /usr/bin/sudo -n /usr/sbin/pkgutil --forget "$receipt" > "$results/receipt-forget.log" 2>&1 || status=1
 fi
 (return_status "$status"; _wattson_cleanup) > "$results/scratch-cleanup.log" 2>&1 || status=1
 printf '%s\n' "$status" > "$results/exit-code.txt"
 exit "$status"
}
trap finish EXIT
wattson_cleanup_add_container com.leoarrow.wattson
wattson_cleanup_add_defaults com.leoarrow.wattson
wattson_cleanup_add_dir "$HOME/Library/Application Support/Wattson"
cp "$incoming" "$scratch/candidate.pkg"
[[ "$(/usr/bin/shasum -a 256 "$scratch/candidate.pkg" | /usr/bin/awk '{print $1}')" == "$expected_sha" ]] || exit 65
wattson_run_timeout 120 /usr/sbin/pkgutil --expand-full "$scratch/candidate.pkg" "$scratch/expanded"
payload_app="$(/usr/bin/find "$scratch/expanded" -type d -path '*/Payload/Applications/Wattson.app' -print)"
payload_helper="$(/usr/bin/find "$scratch/expanded" -type f -path '*/Payload/Library/PrivilegedHelperTools/com.leoarrow.wattson.helper' -print)"
payload_plist="$(/usr/bin/find "$scratch/expanded" -type f -path '*/Payload/Library/LaunchDaemons/com.leoarrow.wattson.helper.plist' -print)"
[[ -d "$payload_app" && -f "$payload_helper" && -f "$payload_plist" ]]
/usr/bin/sudo -n /usr/bin/true
owned_install=1
for mode in fresh reinstall disabled-service-reinstall; do
 if [[ "$mode" == disabled-service-reinstall ]]; then
  wattson_run_timeout 20 /usr/bin/sudo -n /bin/launchctl bootout "system/$label"
  wattson_run_timeout 20 /usr/bin/sudo -n /bin/launchctl disable "system/$label"
 fi
 wattson_run_timeout 180 /usr/bin/sudo -n /usr/sbin/installer -pkg "$scratch/candidate.pkg" -target / > "$results/$mode-installer.log" 2>&1
 [[ "$(/usr/libexec/PlistBuddy -c 'Print :CFBundleShortVersionString' "$app/Contents/Info.plist")" == "$expected_version" ]]
 [[ "$(/usr/libexec/PlistBuddy -c 'Print :CFBundleVersion' "$app/Contents/Info.plist")" == "$expected_version" ]]
 /usr/sbin/pkgutil --pkg-info "$receipt" > "$results/$mode-receipt.log"
 /usr/bin/grep -Fxq "version: $expected_version" "$results/$mode-receipt.log"
 wattson_run_timeout 20 /usr/bin/codesign --verify --deep --strict "$app" > "$results/$mode-signature.log" 2>&1
 wattson_run_timeout 20 "$app/Contents/MacOS/Wattson" --helper-health-probe > "$results/$mode-health.log" 2>&1
 wattson_run_timeout 20 "$app/Contents/MacOS/Wattson" --helper-v5-observation-probe > "$results/$mode-v5.log" 2>&1
 /usr/bin/grep -Fxq 'helperV5=v5' "$results/$mode-v5.log"
 /usr/bin/diff -rq "$payload_app" "$app" > "$results/$mode-payload-app.log"
 /usr/bin/cmp -s "$payload_helper" "$helper"
 /usr/bin/cmp -s "$payload_plist" "$plist"
 /usr/bin/sudo -n /bin/launchctl print "system/$label" > "$results/$mode-launchd.log"
 /usr/bin/open -n "$app"
 wattson_run_timeout 15 /usr/bin/python3 "$WATTSON_PACKAGE_QA_TOOLS_DIR/app-readiness.py" "$app" "$results/$mode-app-readiness.json"
 wattson_stop_executable "$app/Contents/MacOS/Wattson"
 echo "PASS $mode"
done
/usr/bin/shasum -a 256 "$scratch/candidate.pkg" "$app/Contents/MacOS/Wattson" "$helper" "$plist" > "$results/installed.sha256"
echo HISTORY_PACKAGE_INSTALL_REINSTALL_HEALTH_PASSED
