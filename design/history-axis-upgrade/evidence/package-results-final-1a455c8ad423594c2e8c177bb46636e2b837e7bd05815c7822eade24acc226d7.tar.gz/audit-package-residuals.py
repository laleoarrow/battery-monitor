from pathlib import Path
import json,os,subprocess,sys,time
assert os.getuid()!=0
assert subprocess.check_output(['/usr/sbin/sysctl','-n','hw.model'],text=True).strip().startswith('VirtualMac')
share=Path('/Volumes/My Shared Files/history')
output=share/sys.argv[1]
assert output.parent==share and not output.exists() and output.suffix=='.json'
paths=[Path('/Applications/Wattson.app'),Path('/Library/PrivilegedHelperTools/com.leoarrow.wattson.helper'),Path('/Library/LaunchDaemons/com.leoarrow.wattson.helper.plist'),Path('/var/run/wattson-helper.sock')]+[Path.home()/p for p in ['Library/Containers/com.leoarrow.wattson','Library/Application Scripts/com.leoarrow.wattson','Library/Preferences/com.leoarrow.wattson.plist','Library/Application Support/Wattson','Library/LaunchAgents/com.leoarrow.wattson.login.plist']]
residuals=[str(p) for p in paths if p.exists() or p.is_symlink()]
receipt=subprocess.run(['/usr/sbin/pkgutil','--pkg-info','com.leoarrow.wattson.pkg'],capture_output=True,text=True,timeout=20)
job=subprocess.run(['/usr/bin/sudo','-n','/bin/launchctl','print','system/com.leoarrow.wattson.helper'],capture_output=True,text=True,timeout=20)
commands=subprocess.check_output(['/bin/ps','-axo','pid=,comm='],text=True)
processes=[l.strip() for l in commands.splitlines() if any(s in l for s in ['/Applications/Wattson.app/Contents/MacOS/Wattson','/Library/PrivilegedHelperTools/com.leoarrow.wattson.helper'])]
registrar='/System/Library/Frameworks/CoreServices.framework/Frameworks/LaunchServices.framework/Support/lsregister'
registrations=[l.strip() for l in subprocess.check_output([registrar,'-dump'],text=True).splitlines() if '/Applications/Wattson.app' in l]
checks={'ownedInstallationPathsRemoved':not residuals,'ownedReceiptRemoved':receipt.returncode!=0,'ownedHelperJobRemoved':job.returncode!=0,'ownedAppHelperProcessesRemoved':not processes,'canonicalRegistrationRemoved':not registrations}
record={'schema':1,'checks':checks,'allPassed':all(checks.values()),'residualPaths':residuals,'residualProcesses':processes,'residualRegistrations':registrations,'auditedMonotonic':time.clock_gettime(time.CLOCK_MONOTONIC),'deletedAnything':False,'TCCAccessed':False}
output.write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record))
sys.exit(0 if record['allPassed'] else 1)
