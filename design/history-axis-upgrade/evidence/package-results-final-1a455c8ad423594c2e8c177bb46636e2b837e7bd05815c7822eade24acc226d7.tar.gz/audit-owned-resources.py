#!/usr/bin/env python3
"""Guest read-only residual audit using one exact host-frozen ownership manifest."""
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

PROJECT = Path("/Users/admin/Project/Wattson-HistoryAxis-QA")
SHARE = Path("/Volumes/My Shared Files/history")
UUID = r"[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}"
DOMAIN = re.compile(r"(?:com\.leoarrow\.wattson\.(?:historyaxisqa|interactiontests)\." + UUID
    + r"|Wattson\.SettingsCommandInteraction\." + UUID.replace("a-f", "A-Fa-f")
    + r"|Wattson\.TestRuntime\.[a-f0-9]{32}(?:\.second|\.app)?)")


def require(value, message):
    if not value:
        raise ValueError(message)


def command(args):
    result = subprocess.run(args, capture_output=True, text=True, timeout=30)
    require(result.returncode == 0, "Read-only audit command failed: " + args[0])
    return result.stdout


def lexists(path):
    return path.exists() or path.is_symlink()


def main():
    require(len(sys.argv) == 4, "Expected MANIFEST_BASENAME EXPECTED_SHA256 OUTPUT_BASENAME")
    manifest_name, expected_sha, output_name = sys.argv[1:]
    require(all(re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]+\.json", name) for name in [manifest_name, output_name])
            and re.fullmatch(r"[a-f0-9]{64}", expected_sha), "Invalid manifest/output/hash")
    require(str(Path.home()) == "/Users/admin" and os.getuid() != 0
            and PROJECT.is_dir() and not PROJECT.is_symlink()
            and SHARE.is_dir() and not SHARE.is_symlink(), "Wrong non-root owned guest paths")
    manifest_path, output_path = SHARE / manifest_name, SHARE / output_name
    require(manifest_path.is_file() and not manifest_path.is_symlink(), "Missing regular ownership manifest")
    require(not lexists(output_path), "Never overwrite cleanup evidence")
    data = manifest_path.read_bytes()
    require(hashlib.sha256(data).hexdigest() == expected_sha, "Ownership manifest hash changed")
    manifest = json.loads(data)
    require(manifest.get("schema") == 1 and manifest.get("ownedVM") == "Wattson-HistoryAxis-20261016"
            and manifest.get("ownedNativeProject") == str(PROJECT) and manifest.get("evidenceShare") == str(SHARE)
            and manifest.get("nativeProjectContentsOwnedByThisTask") is True
            and manifest.get("nativeScratchBasenamePrefix") == "run."
            and manifest.get("TCCDatabaseAccessRequired") is False, "Ownership scope mismatch")
    require(command(["/usr/sbin/sysctl", "-n", "hw.model"]).strip().startswith("VirtualMac")
            and command(["/usr/bin/uname", "-m"]).strip() == "arm64"
            and command(["/bin/hostname"]).strip() == manifest["expectedHostname"], "Wrong ARM VM or hostname")
    domains = [item["domain"] for item in manifest["domains"]]
    require(bool(domains) and len(set(domains)) == len(domains)
            and all(DOMAIN.fullmatch(domain) for domain in domains), "Manifest includes non-owned domains")
    evidence_paths = {item["path"] for item in manifest["sourceEvidence"]}
    require(all(item.get("sourceEvidence") and set(item["sourceEvidence"]) <= evidence_paths for item in manifest["domains"]), "Domain lacks recorded provenance")
    for item in manifest["sourceEvidence"]:
        relative = Path(item["path"])
        require(not relative.is_absolute() and ".." not in relative.parts, "Unsafe provenance path")
        path = SHARE / relative
        require(path.is_file() and not path.is_symlink() and path.resolve().is_relative_to(SHARE), "Missing exact ownership source")
        raw = path.read_bytes()
        require(len(raw) == item["bytes"] and hashlib.sha256(raw).hexdigest() == item["sha256"],
                "Ownership log changed; create a new manifest after all runs finish")
    explicit_apps = [Path(value) for value in manifest["explicitOwnedApps"]]
    explicit_workspaces = [Path(value) for value in manifest["explicitOwnedSettingsWorkspaces"]]
    require(all(path.is_absolute() and ".." not in path.parts and path.is_relative_to(PROJECT / ".build")
                for path in explicit_apps + explicit_workspaces), "Manifest native resource escaped owned project")
    # Only the manifest's uniquely owned native project is enumerated. No
    # wildcard preference/container ownership is inferred from a naming prefix.
    native_runs = {str(path) for path in (PROJECT / ".build").rglob("run.*") if path.is_dir() or path.is_symlink()}
    native_runs.update(str(path) for path in explicit_workspaces if lexists(path))
    apps = {str(path) for path in PROJECT.rglob("*.app") if path.is_dir() or path.is_symlink()}
    apps.update(str(path) for path in explicit_apps if lexists(path))
    home = Path.home()
    containers = [str(home / "Library/Containers" / domain) for domain in domains if lexists(home / "Library/Containers" / domain)]
    scripts = [str(home / "Library/Application Scripts" / domain) for domain in domains if lexists(home / "Library/Application Scripts" / domain)]
    preferences = []
    for domain in domains:
        path = home / "Library/Preferences" / (domain + ".plist")
        if lexists(path):
            preferences.append(str(path))
        # Host-scoped files still require this exact manifest-listed domain.
        preferences.extend(str(path) for path in (home / "Library/Preferences/ByHost").glob(domain + ".*.plist"))
    processes, ignored_audit = [], []
    for line in command(["/bin/ps", "-axo", "pid=,args="]).splitlines():
        parts = line.strip().split(None, 1)
        if len(parts) != 2 or str(PROJECT) not in parts[1]:
            continue
        if int(parts[0]) == os.getpid() or str(Path(__file__).resolve()) in parts[1]:
            ignored_audit.append(line.strip())
        else:
            processes.append(line.strip())
    domain_pattern = re.compile(r"(?<![A-Za-z0-9_.-])(?:" + "|".join(re.escape(domain) for domain in domains) + r")(?![A-Za-z0-9_.-])")
    lsregister = "/System/Library/Frameworks/CoreServices.framework/Frameworks/LaunchServices.framework/Support/lsregister"
    registrations = [line.strip() for line in command([lsregister, "-dump"]).splitlines()
                     if str(PROJECT) in line or domain_pattern.search(line)]
    mounts = [line for line in command(["/sbin/mount"]).splitlines() if str(PROJECT) in line]
    residuals = {"nativeRuns": sorted(native_runs), "apps": sorted(apps), "containers": containers,
        "applicationScripts": scripts, "preferences": sorted(set(preferences)), "processes": processes,
        "registrations": registrations, "mounts": mounts}
    checks = {name + "Removed": not items for name, items in residuals.items()}
    report = {"schema": 1, "ownershipManifest": manifest_name, "ownershipManifestSHA256": expected_sha,
        "checks": checks, "checkCount": len(checks), "allPassed": all(checks.values()), "residuals": residuals,
        "exactDomainsAudited": domains, "ignoredReadOnlyAuditCommands": ignored_audit,
        "auditedAtEpoch": time.time(), "ownedVMRetained": True, "deletedAnything": False,
        "TCCDatabaseRead": False, "TCCDatabaseWritten": False,
        "scope": "Read-only exact-domain and explicitly owned native-project residual audit. Canonical installation audit and >=90-second quiet-window timing are separate caller evidence."}
    with output_path.open("x") as stream:
        stream.write(json.dumps(report, sort_keys=True, indent=2) + "\n")
    print(json.dumps({"checks": checks, "allPassed": report["allPassed"], "checkCount": len(checks),
        "output": output_name, "sha256": hashlib.sha256(output_path.read_bytes()).hexdigest()}, sort_keys=True))
    return 0 if report["allPassed"] else 1


if __name__ == "__main__":
    sys.exit(main())
