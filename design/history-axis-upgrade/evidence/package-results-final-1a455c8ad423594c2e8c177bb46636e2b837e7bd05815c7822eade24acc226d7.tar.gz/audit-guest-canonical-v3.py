#!/usr/bin/env python3
import datetime,hashlib,json,os,pathlib,subprocess,sys,time
share=pathlib.Path('/Volumes/My Shared Files/history')
assert len(sys.argv)==2 and sys.argv[1] in ('before-v3','immediate-v3','delayed-v3')
mode=sys.argv[1]; target=share/('guest-canonical-'+mode+'.json')
assert not target.exists() and os.getuid()!=0
assert subprocess.check_output(['/usr/sbin/sysctl','-n','hw.model'],text=True).strip().startswith('VirtualMac')
paths=[pathlib.Path('/Applications/Wattson.app'),pathlib.Path('/Library/PrivilegedHelperTools/com.leoarrow.wattson.helper'),pathlib.Path('/Library/LaunchDaemons/com.leoarrow.wattson.helper.plist'),pathlib.Path.home()/'Library/Preferences/com.leoarrow.Wattson.plist',pathlib.Path.home()/'Library/Preferences/com.leoarrow.wattson.plist']
state={}
for root in paths:
    items=[root]+sorted(root.rglob('*')) if root.is_dir() and not root.is_symlink() else [root]
    entries=[]
    for p in items:
        if not p.exists() and not p.is_symlink(): entries.append({'path':str(p),'missing':True});continue
        value={'path':str(p),'mode':p.lstat().st_mode,'uid':p.lstat().st_uid,'gid':p.lstat().st_gid}
        if p.is_symlink(): value['link']=os.readlink(p)
        elif p.is_file(): value['sha256']=hashlib.sha256(p.read_bytes()).hexdigest()
        entries.append(value)
    state[str(root)]=entries
r=subprocess.run(['/usr/sbin/pkgutil','--pkg-info','com.leoarrow.wattson.pkg'],capture_output=True,text=True,timeout=20)
state['receipt']={'code':r.returncode,'stdout':r.stdout,'stderr':r.stderr}
record={'schema':1,'mode':mode,'epoch':time.time(),'systemMonotonic':time.clock_gettime(time.CLOCK_MONOTONIC),'state':state,'TCCAccessed':False,'networkSettingsModified':False,'canonicalMutated':False}
if mode!='before-v3':
    before=json.loads((share/'guest-canonical-before-v3.json').read_text());record['canonicalUnchanged']=before['state']==state
    assert record['canonicalUnchanged']
    if mode=='delayed-v3':
        earlier=json.loads((share/'guest-canonical-immediate-v3.json').read_text());record['quietSeconds']=record['systemMonotonic']-earlier['systemMonotonic'];assert record['quietSeconds']>=90
with target.open('x') as f: json.dump(record,f,indent=2)
print(json.dumps({'mode':mode,'canonicalUnchanged':record.get('canonicalUnchanged'),'quietSeconds':record.get('quietSeconds'),'output':target.name}))
