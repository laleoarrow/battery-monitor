from pathlib import Path
import gzip,hashlib,json,shutil,tarfile

repo=Path('/Users/leoarrow/Project/mypackage/agents/电池功率')
b=repo/'.build/history-axis-smoothness.noindex';out=repo/'design/history-axis-smoothness'
def copy(source,target):
    p=out/target;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(b/source,p)
for label in ['native-paired-full','release-a2','paired-b1','paired-b2','paired-a2','counts-baseline','counts-paired']:
    receipt=json.loads((b/f'result-{label}.json').read_text())
    assert receipt['commandExitCode']==receipt['stageExitCode']==0
    archive=receipt['archive'];assert hashlib.sha256((b/archive).read_bytes()).hexdigest()==receipt['sha256']
    folder='native' if label=='native-paired-full' else 'benchmark'
    copy(f'result-{label}.json',f'{folder}/result-{label}.json');copy(archive,f'{folder}/{archive}')
for name in ['native-analysis-v4.json','head-trajectory-analysis-v4.json']:
    copy('native-paired-full-result/results/'+name,'native/'+name)
copy('visual-review.json','native/visual-review.json')
copy('sdk-path-contract.json','inputs/sdk-path-contract.json')
for name in ['paired-abba-comparison.json','paired-abba-order.json','construction-counts.json','tools-freeze.json']:
    copy(name,'benchmark/'+name)
for name in ['manifest-paired-native.json','manifest-paired.json','manifest-baseline.json']:
    copy(name,'inputs/'+name)
    manifest=json.loads((b/name).read_text())
    for field in ['source','tools']:
        item=manifest[field];archive=item['archive'];assert hashlib.sha256((b/archive).read_bytes()).hexdigest()==item['archiveSHA256']
        copy(archive,'inputs/'+archive)
for name in ['analyze-native-v4.py','analyze-head-trajectory-v4.py','head-inverse-regression.swift']:
    copy('qa/'+name,'tools/'+name)
for name in ['old.json','new.json','old-inputs.sha256','new-inputs.sha256']:
    copy('host/inverse-red-green/'+name,'regression/'+name)
copy('qa/run-inverse-red-green.sh','regression/run-inverse-red-green.sh')
for name in ['native-correction','closeout']:
    copy('qa/pro-'+name+'.md','pro/'+name+'.md')
    path=out/('pro/'+name+'.md')
    path.write_text('\n'.join(line.rstrip() for line in path.read_text().splitlines())+'\n')
for name in ['paired-full.log','paired-full.exit','python-paired.log','release-4.3.16-paired.log']:
    copy('host/'+name,'host/'+name)
for name in ['before.json','installed.json','complete.json','installer.log','installer.exit','expand.log','verify.log']:
    copy('host-installed-4.3.16/'+name,'host/'+name)
for name in ['installer.log','verify.log']:
    copy('guest-install-first-no-battery/'+name,'package/initial-vm-'+name)
initial=out/'package/initial-vm-installer.log'
with gzip.GzipFile(filename=str(initial)+'.gz',mode='wb',mtime=0) as archive:
    archive.write(initial.read_bytes())
initial.unlink()
for name in ['installed.json','verify.log','expand.log']:
    copy('guest-installed-verify-4.3.16/'+name,'package/guest-'+name)
copy('artifacts-paired.json','package/artifacts.json')
for name in ['host-postflight.json','host-resource-audit.json','worktree-cleanup.json']:
    copy(name,'resources/'+name)
for name in ['inventory-final.json','audit-before-stop-final.json']:
    copy('vm-owner-final/'+name,'resources/'+name)
for name,prefix in [('vm-owner/session.fPN6Sd','first'),('vm-owner-final/session.RgmICl','second'),('vm-owner-final/session.66U6jZ','final')]:
    for item in ['vm-cleanup-summary.json','exit-code.txt','vms-after-cleanup.json','vms-before.json']:
        copy(name+'/'+item,'resources/'+prefix+'-'+item)
with tarfile.open(out/'inputs/qa-snapshot.tar.gz','w:gz') as archive:
    for p in sorted((b/'qa').rglob('*')):
        if p.is_file() and '__pycache__' not in p.parts:archive.add(p,arcname=str(p.relative_to(b)),recursive=False)
    for folder in ['vm-owner','vm-owner-final']:
        for p in sorted((b/folder).glob('*.py')):archive.add(p,arcname=folder+'/'+p.name)
        for p in sorted((b/folder).glob('*.sh')):archive.add(p,arcname=folder+'/'+p.name)
files=[p for p in sorted(out.rglob('*')) if p.is_file() and p.name!='SHA256SUMS.txt']
(out/'SHA256SUMS.txt').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+str(p.relative_to(out))+'\n' for p in files))
print(json.dumps({'files':len(files),'bytes':sum(p.stat().st_size for p in files),'output':str(out)}))
