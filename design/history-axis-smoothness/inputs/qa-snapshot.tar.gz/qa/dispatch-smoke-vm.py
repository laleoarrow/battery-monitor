import hashlib, json, subprocess
from pathlib import Path

base = Path(__file__).resolve().parent.parent
artifact = json.loads((base/'artifacts-paired.json').read_text())
name = 'Wattson-v4.3.16-macos-universal.pkg'
pkg = Path(artifact['path'])/name
assert hashlib.sha256(pkg.read_bytes()).hexdigest() == artifact['sha256'][name]
code = (base/'qa/smoke-vm.sh').read_text()
(base/'dispatch-smoke-vm.json').write_text(json.dumps({'packageSHA256':artifact['sha256'][name],
    'scriptSHA256':hashlib.sha256(code.encode()).hexdigest(),'sourceCommit':artifact['sourceCommit'],
    'VM':'Wattson-HistoryFinal-20261017'},indent=2)+'\n')
share='/Volumes/My Shared Files/historysmooth'
repo='/Volumes/My Shared Files/repo'
raise SystemExit(subprocess.call(['/opt/homebrew/bin/tart','exec','Wattson-HistoryFinal-20261017',
    '/bin/bash','-c',code,'smoke-vm',repo,share+'/qa',
    repo+'/dist/history-axis-smoothness-v4.3.16/'+name,artifact['sha256'][name],share+'/guest-install-4.3.16']))
