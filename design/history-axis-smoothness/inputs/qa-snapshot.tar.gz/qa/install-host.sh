#!/bin/bash
set -euo pipefail
repo='/Users/leoarrow/Project/mypackage/agents/电池功率'
base="$repo/.build/history-axis-smoothness.noindex"
pkg="$repo/dist/history-axis-smoothness-v4.3.16/Wattson-v4.3.16-macos-universal.pkg"
results="$base/host-installed-4.3.16"
source "$repo/scripts/lib/local_cleanup.sh"
wattson_cleanup_init
mkdir -p "$results"
/usr/bin/python3 - "$pkg" "$results/before.json" <<'PY'
from pathlib import Path
import hashlib,json,plistlib,subprocess,sys
pkg,output=map(Path,sys.argv[1:])
assert hashlib.sha256(pkg.read_bytes()).hexdigest()=='06996376449ee6fe7c68f976bb1211543f8ad6d15d05827012f9fbcd1255f44b'
info=plistlib.loads(Path('/Applications/Wattson.app/Contents/Info.plist').read_bytes())
assert info['CFBundleShortVersionString']=='4.3.15'
binary='/Applications/Wattson.app/Contents/MacOS/Wattson'
lines=subprocess.check_output(['/bin/ps','-axo','pid=,comm='],text=True,timeout=10).splitlines()
pids=[int(line.split(None,1)[0]) for line in lines if line.strip().split(None,1)[-1]==binary]
assert len(pids)==1,pids
output.write_text(json.dumps({'version':info['CFBundleShortVersionString'],'pids':pids,'packageSHA256':hashlib.sha256(pkg.read_bytes()).hexdigest()},indent=2)+'\n')
PY
wattson_run_timeout 900 /usr/bin/osascript "$base/qa/authorize-install.applescript" "$pkg" > "$results/installer.log" 2>&1
printf '0\n' > "$results/installer.exit"
wattson_run_timeout 160 /bin/bash "$base/qa/verify-installed.sh" "$repo" "$pkg" "$base/qa" "$results"
/usr/bin/python3 - "$results" <<'PY'
from pathlib import Path
import json,subprocess,sys
r=Path(sys.argv[1]);before=json.loads((r/'before.json').read_text());after=json.loads((r/'installed.json').read_text())
assert after['canonicalPID'] not in before['pids']
for pid in before['pids']:
 output=subprocess.run(['/bin/ps','-p',str(pid),'-o','comm='],capture_output=True,text=True,timeout=10)
 assert output.stdout.strip()!='/Applications/Wattson.app/Contents/MacOS/Wattson'
print(json.dumps(after))
(r/'complete.json').write_text(json.dumps({'installerExitCode':0,'verificationExitCode':0,'oldCanonicalAppStopped':True,'sourceCommit':'f818ae3e06c1fcbd69d506d7631d905a37228ce2','packageSHA256':before['packageSHA256']},indent=2)+'\n')
PY
