**未见这段q映射或keyTimes引入具体错误，没有据此新增的发布阻断。**

设 `L=last.x`、`I=initialLastX`、`S=startX`。原来两条X轨迹终点相同，因此：

\[
visibleX(q)=(1-q)\min(S,I)+qL
\]

扣除 `geometry.value` 中的位移 `(I-L)(1-q)` 后，查询坐标正是：

\[
x_{\mathrm{data}}(q)=sourceX+(L-sourceX)q
\]

所以 `(p.x-sourceX)/(L-sourceX)` 正确对应head经过sample连接点的进度。**keyTimes直接使用这些未缓动q即可**，不能再额外ease或反解时间；共同timingFunction负责整体时间映射。

正分母guard、开区间筛选、去重及排序保持了合法顺序和0／1端点；按steps生成positions，数量对应也正确。首值继续使用实际presentation，末值使用model终态，不改变原有取消语义。

补入连接点避免了一个较大的位置插值区间跨越两段曲线，但**段内仍是线性位置近似，不是解析精确贴线**。因此不能预先认定0.494pt偏差已消除，仍以正在进行的320个非knots原生测试及既定误差门槛放行。此修改不要求增加C1状态。
