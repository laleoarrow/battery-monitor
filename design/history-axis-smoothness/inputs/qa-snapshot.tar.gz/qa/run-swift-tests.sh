#!/bin/bash
set -euo pipefail
review='/Users/leoarrow/Project/mypackage/agents/电池功率/.build/history-axis-smoothness.noindex'
repo="$review/checkout"
source "$repo/scripts/lib/local_cleanup.sh"
wattson_cleanup_init
mkdir -p "$repo/.build/history-axis-tests.noindex" "$review/host"
run="$(mktemp -d "$repo/.build/history-axis-tests.noindex/run.XXXXXX")"
wattson_cleanup_add_dir "$run"
label="${1:?test label}"
[[ "$label" =~ ^[a-z0-9-]+$ ]]
shift
status=0
wattson_run_timeout 900 /usr/bin/nice -n 10 /usr/bin/swift test --package-path "$repo" \
    --scratch-path "$run/build" --jobs 2 -Xswiftc -module-cache-path -Xswiftc "$run/module-cache" \
    -Xcc "-fmodules-cache-path=$run/clang-cache" "$@" > "$review/host/$label.log" 2>&1 || status=$?
printf '%s\n' "$status" > "$review/host/$label.exit"
tail -n 14 "$review/host/$label.log"
exit "$status"
