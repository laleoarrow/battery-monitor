import hashlib, json, subprocess
from pathlib import Path

base = Path(__file__).resolve().parent.parent
manifest = json.loads((base / 'manifest-bounded-full.json').read_text())
label = 'native-bounded-full'
assert not (base / ('result-' + label + '.json')).exists()
code = (base / 'qa/native-stage.py').read_text()
# Content-addressed non-motion runner; its frozen archive is verified in the guest.
(base / ('dispatch-' + label + '.json')).write_text(json.dumps({'manifest': manifest, 'bootstrapSHA256': hashlib.sha256(code.encode()).hexdigest(), 'label': label}, indent=2) + '\n')
raise SystemExit(subprocess.call(['/opt/homebrew/bin/tart', 'exec', 'Wattson-HistoryFinal-20261017', '/usr/bin/python3', '-c', code, json.dumps(manifest), label]))
