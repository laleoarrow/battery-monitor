#!/bin/bash
set -euo pipefail
repo="${1:?}"; tools="${2:?}"; input="${3:?}"; expected="${4:?}"; results="${5:?}"
[[ "$(/usr/sbin/sysctl -n hw.model)" == VirtualMac* ]]
[[ ! -e /Applications/Wattson.app && ! -e /Library/PrivilegedHelperTools/com.leoarrow.wattson.helper ]]
source "$repo/scripts/lib/local_cleanup.sh"
wattson_cleanup_init
project="$HOME/Project/Wattson-History-PKG.noindex"
[[ ! -e "$project" && ! -L "$project" ]]
if [[ ! -d "$HOME/Project" ]]; then wattson_cleanup_add_dir "$HOME/Project"; mkdir "$HOME/Project"; fi
wattson_cleanup_add_dir "$project"
mkdir "$project"
cp "$input" "$project/candidate.pkg"
digest="$(/usr/bin/shasum -a 256 "$project/candidate.pkg")"
[[ "${digest%% *}" == "$expected" ]]
mkdir -p "$results"
wattson_run_timeout 120 /usr/bin/sudo -n /usr/sbin/installer -pkg "$project/candidate.pkg" -target / > "$results/installer.log" 2>&1
wattson_run_timeout 120 /bin/bash "$tools/verify-installed.sh" "$repo" "$project/candidate.pkg" "$tools" "$results" "$project/.scratch.noindex"
printf '%s\n' 'The installed guest app, helper, receipt, preferences and registrations belong to the enclosing disposable VM lease and are removed when its owner deletes this clone.' > "$results/cleanup-owner.txt"
