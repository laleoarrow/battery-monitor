set -euo pipefail
repo='/Volumes/My Shared Files/repo'
tools='/Volumes/My Shared Files/historysmooth/qa'
results='/Volumes/My Shared Files/historysmooth/guest-installed-verify-4.3.16'
[[ "$(/usr/sbin/sysctl -n hw.model)" == VirtualMac* ]]
source "$repo/scripts/lib/local_cleanup.sh"
wattson_cleanup_init
project="$HOME/Project/Wattson-History-PKG-verify.noindex"
[[ ! -e "$project" ]]
if [[ ! -d "$HOME/Project" ]]; then wattson_cleanup_add_dir "$HOME/Project"; mkdir "$HOME/Project"; fi
wattson_cleanup_add_dir "$project"; mkdir "$project"
cp "$repo/dist/history-axis-smoothness-v4.3.16/Wattson-v4.3.16-macos-universal.pkg" "$project/candidate.pkg"
mkdir -p "$results"
wattson_run_timeout 120 /bin/bash "$tools/verify-installed.sh" "$repo" "$project/candidate.pkg" "$tools" "$results" "$project/.scratch.noindex" --vm
