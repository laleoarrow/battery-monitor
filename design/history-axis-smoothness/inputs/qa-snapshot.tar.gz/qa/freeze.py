import hashlib, io, json, re, subprocess, sys, tarfile
from pathlib import Path

base = Path(__file__).resolve().parent.parent
repo = base.parent.parent
label, ref = sys.argv[1:]
assert label.isalnum()
assert re.fullmatch(r"[0-9a-f]{40}", ref), "source freeze requires an explicit immutable commit SHA"
commit = subprocess.check_output(['git', 'rev-parse', ref], cwd=repo, text=True).strip()
names = subprocess.check_output(['git', 'ls-tree', '-r', '--name-only', commit], cwd=repo, text=True).splitlines()
tree = names
names = [n for n in tree if n.startswith(('Core/', 'MenuBar/', 'Popover/')) and n.endswith('.swift')]
names += ['VERSION', 'scripts/lib/local_cleanup.sh', 'scripts/lib/run_owned.py']
names += [n for n in tree if n.startswith('design/icon/in-app-logo/') and n.endswith('.png')]
def seal(name, contents):
    archive = base / (name + '.tar.gz')
    assert not archive.exists()
    with tarfile.open(archive, 'w:gz') as target:
        for member, data in sorted(contents.items()):
            info = tarfile.TarInfo(member); info.size = len(data); info.mode = 0o644
            target.addfile(info, io.BytesIO(data))
    return {'archive': archive.name, 'archiveSHA256': hashlib.sha256(archive.read_bytes()).hexdigest(),
            'files': {n: hashlib.sha256(d).hexdigest() for n, d in contents.items()}}
source = seal('source-' + label, {n: subprocess.check_output(['git', 'show', commit + ':' + n], cwd=repo) for n in names})
source['commit'] = commit
tools_manifest = base / 'tools-freeze.json'
if tools_manifest.exists():
    tools = json.loads(tools_manifest.read_text())
    assert tools['files'] == {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in (base / 'qa/tools').iterdir() if p.is_file()}
else:
    tools = seal('tools', {p.name: p.read_bytes() for p in (base / 'qa/tools').iterdir() if p.is_file()})
    tools_manifest.write_text(json.dumps(tools, indent=2) + '\n')
manifest = {'source': source, 'tools': tools}
(base / ('manifest-' + label + '.json')).write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps({'label': label, 'commit': commit, 'sourceFiles': len(names), 'sourceSHA256': source['archiveSHA256'], 'toolsSHA256': tools['archiveSHA256']}))
