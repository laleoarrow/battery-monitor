import hashlib, json, subprocess, sys
from pathlib import Path

base = Path(__file__).resolve().parent.parent
source, label, count, mode = sys.argv[1:]
manifest = json.loads((base / ('manifest-' + source + '.json')).read_text())
assert not (base / ('result-' + label + '.json')).exists()
code = (base / 'qa/stage.py').read_text()
(base / ('dispatch-' + label + '.json')).write_text(json.dumps({'manifest': manifest, 'bootstrapSHA256': hashlib.sha256(code.encode()).hexdigest(), 'label': label, 'count': int(count), 'mode': mode}, indent=2) + '\n')
raise SystemExit(subprocess.call(['/opt/homebrew/bin/tart', 'exec', 'Wattson-HistorySmooth-20261017', '/usr/bin/python3', '-c', code, json.dumps(manifest), label, count, mode]))
