import json, subprocess, sys, time
from pathlib import Path

base = Path(__file__).resolve().parent.parent
repo = base.parent.parent
deadline = time.monotonic() + 1100
receipt = base/'result-paired-a2.json'
while not receipt.exists():
    if time.monotonic() >= deadline: raise SystemExit('Final timing batch did not complete')
    time.sleep(5)
record = json.loads(receipt.read_text())
assert record['stageExitCode'] == 0 and record['projectRemoved'] and not record['cleanupErrors']
commands = [
    [sys.executable,str(base/'qa/dispatch-native-paired-full.py')],
    [sys.executable,str(base/'qa/dispatch-optimized.py'),'baseline','counts-baseline','1','counted'],
    [sys.executable,str(base/'qa/dispatch-optimized.py'),'paired','counts-paired','1','counted'],
]
for command in commands:
    result = subprocess.run([sys.executable,str(repo/'scripts/lib/run_owned.py'),'--grace','180','--timeout','1600','--']+command,cwd=repo)
    if result.returncode: raise SystemExit(result.returncode)
    print('POSTCHECK_STAGE_COMPLETED '+Path(command[1]).name,flush=True)
