import hashlib, json, os, re, shutil, signal, subprocess, sys, tarfile
from pathlib import Path

manifest = json.loads(sys.argv[1]); label = sys.argv[2]; count = '1'; mode = 'motion'
assert re.fullmatch(r'[a-z0-9-]+', label) and count.isdigit() and mode == 'motion'
assert Path.home() == Path('/Users/admin')
assert subprocess.check_output(['/usr/sbin/sysctl', '-n', 'hw.model'], text=True).strip().startswith('VirtualMac')
share = Path('/Volumes/My Shared Files/historysmooth')
project = Path.home() / 'Project' / ('Wattson-HistorySmooth-' + label + '-QA')
assert not project.exists() and not project.is_symlink() and not project.parent.is_symlink()
signals = {signal.SIGHUP, signal.SIGINT, signal.SIGTERM}
def interrupted(number, frame): raise SystemExit(128 + number)
for number in signals: signal.signal(number, interrupted)
owned = False; parent_created = False; child = None; status = 1; errors = []; failure = None
try:
    previous = signal.pthread_sigmask(signal.SIG_BLOCK, signals)
    try:
        if not project.parent.exists():
            project.parent.mkdir(); parent_created = True
        project.mkdir(); owned = True
    finally:
        signal.pthread_sigmask(signal.SIG_SETMASK, previous)
    for kind in ('source', 'tools'):
        entry = manifest[kind]; archive = project / (kind + '.tar.gz')
        shutil.copyfile(share / entry['archive'], archive)
        assert hashlib.sha256(archive.read_bytes()).hexdigest() == entry['archiveSHA256']
        target = project / kind; target.mkdir()
        with tarfile.open(archive, 'r:gz') as source:
            members = source.getmembers()
            assert len(members) == len(entry['files']) and {m.name for m in members} == set(entry['files'])
            for member in members:
                assert member.isfile() and not Path(member.name).is_absolute() and '..' not in Path(member.name).parts
                path = target / member.name; path.parent.mkdir(parents=True, exist_ok=True)
                path.write_bytes(source.extractfile(member).read())
        assert {n: hashlib.sha256((target/n).read_bytes()).hexdigest() for n in entry['files']} == entry['files']
    results = project / 'results'; results.mkdir()
    (results / 'provenance.json').write_text(json.dumps({'manifest': manifest, 'guestProject': str(project), 'verifiedGuestLocalBeforeExecution': True, 'label': label, 'count': int(count), 'mode': mode}, indent=2) + '\n')
    with (results / 'stage.log').open('wb') as log:
        previous = signal.pthread_sigmask(signal.SIG_BLOCK, signals)
        try:
            child = subprocess.Popen(['/usr/bin/python3', str(project/'source/scripts/lib/run_owned.py'), '--grace', '90', '--timeout', '1600', '--', '/bin/bash', str(project/'tools/run-native.sh'), str(project/'source'), str(project/'tools'), str(results), count, mode], stdout=log, stderr=subprocess.STDOUT, start_new_session=True, preexec_fn=lambda: signal.pthread_sigmask(signal.SIG_SETMASK, previous))
        finally:
            signal.pthread_sigmask(signal.SIG_SETMASK, previous)
        status = child.wait(timeout=1850)
        if status < 0: status = 128 - status
except SystemExit as error:
    status = int(error.code)
except subprocess.TimeoutExpired:
    status = 124; failure = 'stage deadline'
except Exception as error:
    status = 1; failure = type(error).__name__ + ': ' + str(error)
finally:
    for number in signals: signal.signal(number, signal.SIG_IGN)
    if child is not None:
        try:
            if child.poll() is None:
                child.send_signal(signal.SIGTERM)
                try: child.wait(timeout=110)
                except subprocess.TimeoutExpired:
                    os.killpg(child.pid, signal.SIGKILL); child.wait(timeout=10)
            try: os.killpg(child.pid, signal.SIGKILL)
            except ProcessLookupError: pass
        except Exception as error: errors.append('child: ' + repr(error))
    try:
        if (project / 'results').is_dir():
            archive = project / 'results.tar.gz'
            with tarfile.open(archive, 'w:gz') as target: target.add(project/'results', arcname='results')
            digest = hashlib.sha256(archive.read_bytes()).hexdigest()
            destination = share / ('results-' + label + '-' + digest + '.tar.gz')
            assert not destination.exists(); shutil.copyfile(archive, destination)
            record = {'label': label, 'archive': destination.name, 'sha256': digest, 'commandExitCode': status}
    except Exception as error: errors.append('export: ' + repr(error))
    if owned:
        try: shutil.rmtree(project)
        except Exception as error: errors.append('scratch: ' + repr(error))
    if parent_created:
        try: project.parent.rmdir()
        except Exception as error: errors.append('new project parent: ' + repr(error))
    record = locals().get('record', {'label': label, 'commandExitCode': status})
    record.update(stageExitCode=status if not errors or status else 1, projectRemoved=not project.exists(), cleanupErrors=errors, failure=failure)
    (share / ('result-' + label + '.json')).write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps(record), flush=True)
raise SystemExit(record['stageExitCode'])
