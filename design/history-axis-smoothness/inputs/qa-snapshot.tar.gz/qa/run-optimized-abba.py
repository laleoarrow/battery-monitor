import json, subprocess, sys, time
from pathlib import Path

base = Path(__file__).resolve().parent.parent
repo = base.parent.parent
order = [('baseline','optimized-a1'),('optimized','optimized-b1'),('optimized','optimized-b2'),('baseline','optimized-a2')]
records = []
for source, label in order:
    started = time.time()
    result = subprocess.run([sys.executable, str(repo/'scripts/lib/run_owned.py'), '--grace','180','--timeout','1000','--',sys.executable,str(base/'qa/dispatch-optimized.py'),source,label,'32','original'],cwd=repo)
    record = {'label':label,'source':source,'startedEpoch':started,'endedEpoch':time.time(),'exitCode':result.returncode}
    records.append(record)
    (base/'optimized-abba-order.json').write_text(json.dumps(records,indent=2)+'\n')
    if result.returncode: raise SystemExit(result.returncode)
    receipt = json.loads((base/('result-'+label+'.json')).read_text())
    assert receipt['stageExitCode'] == 0 and receipt['projectRemoved'] and not receipt['cleanupErrors']
