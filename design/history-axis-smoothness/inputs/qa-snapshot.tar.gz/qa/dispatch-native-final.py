import hashlib, json, subprocess
from pathlib import Path

base = Path(__file__).resolve().parent.parent
manifest = json.loads((base / 'manifest-native-integrated.json').read_text())
label = 'native-final'
assert not (base / ('result-' + label + '.json')).exists()
code = (base / 'qa/native-stage.py').read_text()
assert manifest['tools']['files'] == {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in (base / 'qa/native-tools').iterdir() if p.is_file()}
(base / ('dispatch-' + label + '.json')).write_text(json.dumps({'manifest': manifest, 'bootstrapSHA256': hashlib.sha256(code.encode()).hexdigest(), 'label': label}, indent=2) + '\n')
raise SystemExit(subprocess.call(['/opt/homebrew/bin/tart', 'exec', 'Wattson-HistorySmooth-20261017', '/usr/bin/python3', '-c', code, json.dumps(manifest), label]))
