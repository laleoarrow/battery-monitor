import json, os, subprocess, sys
from pathlib import Path

inventory, output = map(Path, sys.argv[1:])
owned=json.loads(inventory.read_text());home=Path.home()
domains=owned['domains'];apps=owned['apps']
remaining=[]
for domain in domains:
    for relative in ('Library/Preferences/'+domain+'.plist','Library/Containers/'+domain,
                     'Library/Group Containers/'+domain,'Library/Saved Application State/'+domain+'.savedState',
                     'Library/Caches/'+domain):
        p=home/relative
        if p.exists() or p.is_symlink():remaining.append(str(p))
ls=subprocess.check_output(['/System/Library/Frameworks/CoreServices.framework/Frameworks/LaunchServices.framework/Support/lsregister','-dump'],text=True,timeout=25)
registrations=[d for d in domains if d in ls]
listing=subprocess.check_output(['/bin/ps','-axo','pid=,comm='],text=True,timeout=10)
processes=[line.strip() for line in listing.splitlines() if any(a+'/Contents/MacOS/' in line for a in apps)]
projects=[str(p) for p in (home/'Project').glob('Wattson-History*')]
record={'domainCount':len(domains),'appCount':len(apps),'remainingOwnedPaths':remaining,
        'remainingRegistrations':registrations,'remainingExecutables':processes,'remainingProjects':projects,
        'canonicalGuestFixture':'Wattson 4.3.16 app/helper/receipt are owned by enclosing disposable VM; clone deletion removes them.',
        'passed':not (remaining or registrations or processes or projects)}
output.write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))
assert record['passed']
