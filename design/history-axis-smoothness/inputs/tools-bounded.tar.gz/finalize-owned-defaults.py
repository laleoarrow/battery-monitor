import json
import pathlib
import re
import sys
import time

domain = sys.argv[1]
if not re.fullmatch(r"com\.leoarrow\.wattson\.historyaxisqa\.[a-f0-9-]{36}", domain):
    raise SystemExit("Only an explicitly owned capture UUID domain is accepted")
path = pathlib.Path.home() / "Library/Preferences" / (domain + ".plist")
deadline = time.monotonic() + 20
stable_since = time.monotonic()
removed = []
while time.monotonic() < deadline:
    if path.is_symlink() or (path.exists() and not path.is_file()):
        raise SystemExit("Owned capture preference path changed type")
    if path.exists():
        removed.append({"size": path.stat().st_size, "atEpoch": time.time()})
        path.unlink()
        stable_since = time.monotonic()
    if time.monotonic() - stable_since >= 3:
        print(json.dumps({"ownedDomain": domain, "postFoundationProcessExit": True,
                          "removedLatePlists": removed, "stableSeconds": 3,
                          "fileRemoved": not path.exists()}))
        break
    time.sleep(0.1)
else:
    raise SystemExit("Owned capture preferences did not settle after Foundation exited")
