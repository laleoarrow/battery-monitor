#!/usr/bin/env python3
"""Derive a fixture-only release probe from the frozen production-host harness."""
import pathlib,sys
source=pathlib.Path(sys.argv[1]).read_text()
old="""        let sample = PowerSnapshot(percent: 72, plugged: true, adapterW: 68,
            batteryW: 22.2, systemW: 45.8, temperatureC: 34.2, cycleCount: 282,
            lowPowerMode: false, batteryTimeEstimate: .charging(42))"""
new="""        let fixtureScenario = ProcessInfo.processInfo.environment["WATTSON_CAPTURE_SCENARIO"] ?? "gallery"
        let sample: PowerSnapshot
        switch fixtureScenario {
        case "gallery", "charging":
            sample = PowerSnapshot(percent: 72, plugged: true, adapterW: 68,
                batteryW: 22.2, systemW: 45.8, temperatureC: 34.2, cycleCount: 282,
                lowPowerMode: false, batteryTimeEstimate: .charging(42))
        case "full":
            sample = PowerSnapshot(percent: 100, plugged: true, adapterW: 35.5,
                batteryW: 0, systemW: 35.5, temperatureC: 30.2, cycleCount: 282,
                lowPowerMode: false, batteryTimeEstimate: .full)
        case "on-battery":
            sample = PowerSnapshot(percent: 67, plugged: false, adapterW: 0,
                batteryW: -22.4, systemW: 22.4, temperatureC: 33.1, cycleCount: 282,
                lowPowerMode: false, batteryTimeEstimate: .remaining(265))
        case "mixed-supply":
            sample = PowerSnapshot(percent: 72, plugged: true, adapterW: 30,
                batteryW: -10, systemW: 40, temperatureC: 35.2, cycleCount: 282,
                lowPowerMode: false, batteryTimeEstimate: .notCharging)
        case "low-battery":
            sample = PowerSnapshot(percent: 8, plugged: false, adapterW: 0,
                batteryW: -18, systemW: 18, temperatureC: 31.2, cycleCount: 282,
                lowPowerMode: false, batteryTimeEstimate: .remaining(22))
        case "low-power":
            sample = PowerSnapshot(percent: 41, plugged: false, adapterW: 0,
                batteryW: -8, systemW: 8, temperatureC: 29.8, cycleCount: 282,
                lowPowerMode: true, batteryTimeEstimate: .remaining(210))
        default: throw failure("Unknown capture scenario")
        }"""
replacements=[(old,new),('footer.update(mode: .auto, helperInstalled: true','footer.update(mode: sample.lowPowerMode ? .low : .auto, helperInstalled: true'),('"name": name, "margin": margin, "window": panel.windowNumber,','"name": name, "fixtureScenario": fixtureScenario, "fixtureValues": true, "margin": margin, "window": panel.windowNumber,')]

for before,after in replacements:
    if source.count(before)!=1: raise SystemExit('Frozen production probe source did not match expected section: '+before[:70])
    source=source.replace(before,after)
pathlib.Path(sys.argv[2]).write_text(source)
