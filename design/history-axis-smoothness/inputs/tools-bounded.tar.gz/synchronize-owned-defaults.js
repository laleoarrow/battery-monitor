ObjC.import("Foundation");
function run(args) {
  if (args.length !== 1 || !/^com\.leoarrow\.wattson\.historyaxisqa\.[a-f0-9-]{36}$/.test(args[0])) {
    throw new Error("Only the current uniquely identified owned release capture domain is accepted");
  }
  const domain = args[0];
  const defaults = $.NSUserDefaults.alloc.initWithSuiteName(domain);
  const path = $.NSHomeDirectory().js + "/Library/Preferences/" + domain + ".plist";
  const manager = $.NSFileManager.defaultManager;
  // NSStatusItem's preferences daemon can flush a late queued write after
  // its owning GUI process exited. Clear only this exact owned UUID domain,
  // and require two seconds without a reappearing file before returning.
  let stable = 0;
  let attempts = 0;
  while (attempts < 40 && stable < 10) {
    attempts += 1;
    defaults.removePersistentDomainForName(domain);
    if (!defaults.synchronize) throw new Error("Owned capture domain synchronization failed");
    if (manager.fileExistsAtPath(path) && !manager.removeItemAtPathError(path, null)) {
      throw new Error("Could not delete the exact owned capture preference file");
    }
    $.NSThread.sleepForTimeInterval(0.2);
    stable = manager.fileExistsAtPath(path) ? 0 : stable + 1;
  }
  if (stable < 10 || manager.fileExistsAtPath(path)) throw new Error("Owned capture preferences did not settle");
  return JSON.stringify({ownedDomain: domain, synchronized: true, fileRemoved: true, stableSeconds: stable * 0.2, attempts: attempts});
}
