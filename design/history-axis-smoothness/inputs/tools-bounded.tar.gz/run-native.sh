#!/bin/bash
set -euo pipefail
repo="${1:?}"; tools="${2:?}"; results="${3:?}"
source "$repo/scripts/lib/local_cleanup.sh"
wattson_cleanup_init
cd "$repo"
mkdir -p "$results" "$repo/.build/history-native.noindex"
run_dir="$(mktemp -d "$repo/.build/history-native.noindex/run.XXXXXX")"
wattson_cleanup_add_dir "$run_dir"
owned_domains=()
return_status() { return "$1"; }
finish() {
  local status=$?
  trap - EXIT
  trap '' HUP INT TERM
  set +e
  if [[ -n "${_WATTSON_RUNNER_PID:-}" ]]; then kill -TERM "$_WATTSON_RUNNER_PID" 2>/dev/null; wait "$_WATTSON_RUNNER_PID" 2>/dev/null; _WATTSON_RUNNER_PID=''; fi
  for domain in "${owned_domains[@]+"${owned_domains[@]}"}"; do
    wattson_run_timeout 20 /usr/bin/osascript -l JavaScript "$tools/synchronize-owned-defaults.js" "$domain" >> "$results/defaults-synchronized.log" 2>&1 || { [[ "$status" != 0 ]] || status=1; }
    wattson_run_timeout 25 /usr/bin/python3 "$tools/finalize-owned-defaults.py" "$domain" >> "$results/defaults-finalized.jsonl" 2>&1 || { [[ "$status" != 0 ]] || status=1; }
  done
  printf '%s\n' "$status" > "$results/native-exit.txt"
  return_status "$status"
  _wattson_cleanup
}
trap finish EXIT
/usr/bin/sw_vers > "$results/system.txt"
mkdir -p "$run_dir/isolated-home"
wattson_run /usr/bin/xcrun clang -mmacosx-version-min=12.0 -Wno-deprecated-declarations -c tests/visual/capture_glass_shadow.c -o "$run_dir/capture.o" > "$results/build.log" 2>&1
kinds=(interaction stress motion gallery)
[[ "${5:-}" != motion ]] || kinds=(motion)
for kind in "${kinds[@]}"; do
  app="$run_dir/$kind.app"
  domain="com.leoarrow.wattson.historyaxisqa.$(/usr/bin/uuidgen | /usr/bin/tr '[:upper:]' '[:lower:]')"
  owned_domains+=("$domain")
  wattson_cleanup_add_app "$app"
  wattson_cleanup_add_container "$domain"
  wattson_cleanup_add_defaults "$domain"
  wattson_cleanup_add_executable "$app/Contents/MacOS/HistoryQA"
  printf '%s\t%s\n' "$domain" "$app" >> "$results/owned-bundles.tsv"
  mkdir -p "$app/Contents/MacOS" "$app/Contents/Resources" "$results/$kind"
  cp design/icon/in-app-logo/*.png "$app/Contents/Resources/"
  case "$kind" in
    interaction) main=tests/interaction/main.swift ;;
    stress) main=tests/animation_stress/main.swift ;;
    motion) main="$tools/capture-axis-motion.swift" ;;
    gallery)
      main="$run_dir/gallery.swift"
      wattson_run /usr/bin/python3 "$tools/prepare-gallery.py" tests/visual/capture_production_glass.swift "$main" "$tools/prepare-sixstate-harness.py"
      ;;
  esac
  cp "$main" "$results/$kind/harness.swift"
  /usr/bin/shasum -a 256 "$main" Core/HistoryChart.swift Popover/HistoryLayer.swift >> "$results/inputs.sha256"
  wattson_run /usr/bin/xcrun swiftc Core/*.swift MenuBar/*.swift Popover/*.swift "$main" "$run_dir/capture.o" -D DEBUG -swift-version 5 -warnings-as-errors -module-cache-path "$run_dir/module-cache" -import-objc-header tests/visual/capture_glass_shadow.h -framework AppKit -framework CoreGraphics -framework IOKit -o "$app/Contents/MacOS/HistoryQA" >> "$results/build.log" 2>&1
  cat > "$app/Contents/Info.plist" <<EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
<key>CFBundleIdentifier</key><string>$domain</string>
<key>CFBundleName</key><string>HistoryQA</string>
<key>CFBundleExecutable</key><string>HistoryQA</string>
<key>CFBundlePackageType</key><string>APPL</string>
<key>LSUIElement</key><true/>
</dict></plist>
EOF
  if [[ "$kind" == interaction ]]; then
    wattson_run /usr/bin/codesign --force --sign - --entitlements BatteryPowerApp.entitlements "$app" >> "$results/build.log" 2>&1
    suite="com.leoarrow.wattson.historyaxisqa.$(/usr/bin/uuidgen | /usr/bin/tr '[:upper:]' '[:lower:]')"
    owned_domains+=("$suite"); wattson_cleanup_add_defaults "$suite"
    printf '%s\n' "$suite" >> "$results/owned-suites.txt"
    power_mode="$(/usr/bin/pmset -g live | awk 'tolower($1) == "powermode" { print $2; exit }')"
    wattson_run_timeout 300 /usr/bin/open -n -W -o "$results/$kind/run.log" --stderr "$results/$kind/run.err" --env CFFIXED_USER_HOME="$run_dir/isolated-home" --env WATTSON_TEST_DEFAULTS_SUITE="$suite" --env WATTSON_EXPECTED_POWER_MODE="$power_mode" "$app"
    /usr/bin/grep -q '^ALL_INTERACTION_CHECKS_PASSED$' "$results/$kind/run.log"
    ! /usr/bin/grep -q 'SOME_CHECKS_FAILED\|SOME_SKIPPED' "$results/$kind/run.log"
  else
    wattson_run /usr/bin/codesign --force --sign - "$app" >> "$results/build.log" 2>&1
    if [[ "$kind" == stress ]]; then
      wattson_run_timeout 150 "$app/Contents/MacOS/HistoryQA" 20000 > "$results/$kind/run.log" 2> "$results/$kind/run.err"
      /usr/bin/grep -q 'ANIMATION_STRESS_PASSED iterations=20000' "$results/$kind/run.log"
    else
      if [[ "$kind" == motion ]]; then modes=(scalar controlled frames); else modes=(charging full on-battery mixed-supply low-battery low-power); fi
      for mode in "${modes[@]}"; do
        output="$results/$kind/$mode"; mkdir -p "$output"
        args=("$output"); [[ "$kind" != motion ]] || args+=("$mode")
        wattson_run_timeout 120 /usr/bin/open -n -W -o "$output/run.log" --stderr "$output/run.err" --env WATTSON_FORCE_REDUCE_MOTION=0 --env WATTSON_FORCE_REDUCE_TRANSPARENCY=0 --env WATTSON_FORCE_INCREASE_CONTRAST=0 --env WATTSON_CAPTURE_SCENARIO="$mode" --env WATTSON_CAPTURE_POPOVER_ARROW=1 --env WATTSON_CAPTURE_GLASS_TRANSPARENCY=1 "$app" --args "${args[@]}"
        if [[ "$kind" == motion ]]; then [[ -s "$output/axis-motion.json" ]]; else [[ -s "$output/complete.json" ]]; fi
        printf 'PASS %s %s\n' "$kind" "$mode"
      done
    fi
  fi
  printf 'PASS native %s\n' "$kind"
done
echo HISTORY_NATIVE_COMPLETED_ANALYSIS_PENDING
