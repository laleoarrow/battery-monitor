from pathlib import Path
import subprocess,sys
subprocess.run(['/usr/bin/python3',sys.argv[3],sys.argv[1],sys.argv[2]],check=True)
p=Path(sys.argv[2]); s=p.read_text()
changes=[
('for style in [Settings.LiquidGlassStyle.regular, .clear]', 'for style in [Settings.LiquidGlassStyle.regular]'),
('let history = (0..<32).map { sample.totalInputW * (0.88 + 0.08 * sin(Double($0) * 0.4)) }', '''let history = (0..<60).map { sample.totalInputW * (0.68 + 0.25 * abs(sin(Double($0) * 0.42))) }
        let fixtureTime: TimeInterval = 1000
        let historyTimes = (0..<60).map { fixtureTime - Double(59 - $0) * 2 }'''),
('popover.update(snapshot: sample, history: history, peak: sample.totalInputW, degraded: false)', 'popover.update(snapshot: sample, history: history, peak: history.max() ?? 0, degraded: false, historyTiming: HistoryChartTiming(sampledAt: historyTimes, referenceTime: fixtureTime))')]
for a,b in changes:
 if s.count(a)!=1: raise ValueError('Frozen production probe section changed: '+a[:70])
 s=s.replace(a,b)
p.write_text(s)
