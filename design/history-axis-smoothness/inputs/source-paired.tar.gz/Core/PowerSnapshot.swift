import Foundation

enum PowerState {
    case charging
    case pluggedIdle
    case onBattery
    case mixedSupply
}

enum BatteryTimeEstimate: Equatable {
    case remaining(Int?)
    case charging(Int?)
    case full
    case notCharging
}

enum BatteryTimeEstimateSource: String {
    case system
    case batteryGauge
    case observedDischarge
}

struct PowerSnapshot {
    static let epsilon: Double = 0.3

    var percent: Int = 0
    var plugged: Bool = false
    /// Adapter output. Always non-negative.
    var adapterW: Double = 0
    /// Signed: positive flows into the battery, negative flows out of it.
    var batteryW: Double = 0
    /// System consumption. Always non-negative.
    var systemW: Double = 0
    /// Available measured power delivered to attached devices, summed across ports.
    /// `nil` means this hardware sample did not publish a usable measurement.
    /// A partial sum must not be subtracted to derive an exact Mac-only load.
    /// This is an auxiliary breakdown of `systemW`, not another power sink.
    var deviceOutputW: Double? = nil
    var deviceOutputIsComplete: Bool = true
    var temperatureC: Double? = nil
    var cycleCount: Int = 0
    var lowPowerMode: Bool = false
    /// Internal-battery state and time from IOPS, the gauge, or observed discharge.
    /// `nil` means no trustworthy state or estimate is available for this sample.
    var batteryTimeEstimate: BatteryTimeEstimate? = nil
    var batteryTimeEstimateSource: BatteryTimeEstimateSource? = nil

    /// Everything the sources are putting out right now. Drives the visual
    /// encoding curve and the popover's headline number.
    var totalInputW: Double {
        adapterW + max(-batteryW, 0)
    }

    /// Sources minus sinks. Should be ~0; anything larger means a field was
    /// parsed wrong.
    var conservationError: Double {
        (adapterW + max(-batteryW, 0)) - (systemW + max(batteryW, 0))
    }

    /// A device reading can outlive the independently sampled system total.
    /// Keep the raw auxiliary measurement above, but only use it to derive a
    /// Mac-load breakdown while it fits inside the current system total.
    var coherentDeviceOutputW: Double? {
        guard deviceOutputIsComplete,
              let deviceOutputW,
              deviceOutputW.isFinite,
              systemW.isFinite,
              deviceOutputW >= 0,
              deviceOutputW <= systemW else { return nil }
        return deviceOutputW
    }

    var state: PowerState {
        guard plugged else { return .onBattery }
        if batteryW > Self.epsilon { return .charging }
        if batteryW < -Self.epsilon { return .mixedSupply }
        return .pluggedIdle
    }
}
