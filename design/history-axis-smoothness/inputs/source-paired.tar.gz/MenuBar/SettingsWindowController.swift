import AppKit
import UniformTypeIdentifiers

protocol SettingsSectionController: AnyObject {
    var identifier: String { get }
    var title: String { get }
    var sidebarIcon: ModuleIconArtwork.SidebarIcon { get }
    var view: NSView { get }
    func refresh()
}

struct SettingsWindowDependencies {
    let loginItemState: () -> LoginItemState
    let refreshLoginItem: (_ completion: @escaping (LoginItemState) -> Void) -> Void
    let setLoginItemEnabled: (
        _ enabled: Bool,
        _ completion: @escaping (Result<LoginItemState, Error>) -> Void
    ) -> Void
    let systemBatteryIconHidden: () -> Bool?
    let helperAvailable: () -> Bool
    let refreshSystemBatteryIcon: (_ completion: @escaping (Bool?) -> Void) -> Void
    let setSystemBatteryIconHidden: (
        _ hidden: Bool,
        _ completion: @escaping (Bool) -> Void
    ) -> Void
    let systemBatteryIconDidChange: Notification.Name
    let currentVersion: () -> String
    let checkForUpdates: (
        _ completion: @escaping (Result<UpdateCheckOutcome, Error>) -> Void
    ) -> Void
    let openUpdateURL: (_ url: URL) -> Bool
    let increaseContrast: () -> Bool
    let announceAccessibility: (_ message: String) -> Void
    var feedbackSnapshot: () -> PowerSnapshot? = { nil }
    var feedbackReadingIsStale: () -> Bool = { false }
    var systemBatteryIconReadStatus: () -> SystemBatteryIconReadStatus = { .ready }

    static let live = SettingsWindowDependencies(
        loginItemState: { LoginItemController.state },
        refreshLoginItem: { completion in
            LoginItemController.refresh(completion: completion)
        },
        setLoginItemEnabled: { enabled, completion in
            LoginItemController.setEnabled(enabled, completion: completion)
        },
        systemBatteryIconHidden: { SystemBatteryIconController.cachedHidden },
        helperAvailable: { HelperClient.isInstalled },
        refreshSystemBatteryIcon: { completion in
            SystemBatteryIconController.refreshHidden(completion)
        },
        setSystemBatteryIconHidden: { hidden, completion in
            SystemBatteryIconController.setHidden(hidden, completion: completion)
        },
        systemBatteryIconDidChange: SystemBatteryIconController.didChange,
        currentVersion: {
            Bundle.main.object(
                forInfoDictionaryKey: "CFBundleShortVersionString"
            ) as? String ?? "Unknown"
        },
        checkForUpdates: { completion in
            UpdateChecker.shared.check(completion: completion)
        },
        openUpdateURL: { NSWorkspace.shared.open($0) },
        increaseContrast: {
            NSWorkspace.shared.accessibilityDisplayShouldIncreaseContrast
        },
        announceAccessibility: { message in
            NSAccessibility.post(
                element: NSApp as Any,
                notification: .announcementRequested,
                userInfo: [
                    .announcement: message,
                    .priority: NSAccessibilityPriorityLevel.high.rawValue,
                ]
            )
        },
        systemBatteryIconReadStatus: { SystemBatteryIconController.readStatus }
    )
}

private enum SettingsStyle {
    static let contentSize = NSSize(width: 720, height: 520)
    static let sidebarWidth: CGFloat = 176
    static let contentHorizontalInset: CGFloat = 20
    static let contentTopInset: CGFloat = 56
    static let contentBottomInset: CGFloat = 20

    static let trafficLightSafeHeight: CGFloat = 52
    static let identityHeight: CGFloat = 56
    static let identityTileSize: CGFloat = 32
    static let navigationInset: CGFloat = 12
    static let navigationTopGap: CGFloat = 12
    static let navigationRowHeight: CGFloat = 32
    static let navigationRowGap: CGFloat = 4
    static let navigationHeight: CGFloat = 124

    static let headingFont = NSFont.systemFont(ofSize: 18, weight: .semibold)
    static let primaryFont = NSFont.systemFont(ofSize: 13, weight: .regular)
    static let detailFont = NSFont.systemFont(ofSize: 11, weight: .regular)
    static let sidebarFont = NSFont.systemFont(ofSize: 13, weight: .regular)

    static let toggleSize = NSSize(width: 38, height: 22)
    static let generalListHeight: CGFloat = 136
    static let generalRowHeight: CGFloat = 68
    static let rowIconSize: CGFloat = 28
    static let rowSymbolSize: CGFloat = 20
    static let generalActionSize = NSSize(width: 88, height: 28)
    static let moduleRowHeight: CGFloat = 72
    static let iconCardGap: CGFloat = 8
    static let iconCardHeight: CGFloat = 80
    static let iconCardGroupHeight: CGFloat = 344
    static let iconStateHeight: CGFloat = 38
    static let iconStateGap: CGFloat = 5
    static let iconStateCornerRadius: CGFloat = 7
    static let surfaceCornerRadius: CGFloat = 14
    static let glassGroupCornerRadius: CGFloat = 20
    static let groupOpticalInset: CGFloat = contentHorizontalInset

    static let contentBackground = adaptive(0x151618, .windowBackgroundColor, light: 0xF4F4F6)
    static let canvasBackground = adaptive(0x151618, GlassBackgroundView.fillColor, light: 0xF4F4F6)
    static let sidebarBackground = adaptive(0x1E1F21, .clear, light: 0xE9EAEC)
    static let surfaceBackground = adaptive(0x191A1C, GlassBackgroundView.fillColor, light: 0xFFFFFF)
    static let previewBackground = adaptive(0x1A1B1C, .clear, light: 0xE5E6E8)
    static let selection = adaptive(0x2B362F, .controlAccentColor.withAlphaComponent(0.10), light: 0xDBEBDD)
    static let green = adaptive(0x68C367, .controlAccentColor, light: 0x25813B)
    static let surfaceBorder = adaptive(0x363838, .clear, light: 0xCCD0D3)
    static let border = adaptive(0x363838, .separatorColor, light: 0xCCD0D3)
    static let divider = adaptive(0x363838, .separatorColor, light: 0xCCD0D3)
    static let toggleOff = adaptive(0x2E3032, .quaternaryLabelColor, light: 0xBCBEC3)
    static let increasedContrastSelection = adaptive(0x3B5944, .selectedContentBackgroundColor, light: 0xCBDDCA)
    static let increasedContrastSelectionBorder = adaptive(0x8AD88E, .controlAccentColor, light: 0x216A2C)
    static let increasedContrastBorder = adaptive(0x8D949A, .labelColor, light: 0x5E6268)
    static let increasedContrastToggleOff = adaptive(0x575B5F, .tertiaryLabelColor, light: 0x8C9096)
    static let increasedContrastToggleBorder = adaptive(0xB9C0C6, .labelColor, light: 0x484C52)
    static let headingText = adaptive(0xF4F4F4, .labelColor, light: 0x1C1C1E)
    static let primaryText = adaptive(0xE9E9E9, .labelColor, light: 0x242426)
    static let secondaryText = adaptive(0xA0A0A2, .secondaryLabelColor, light: 0x63636A)

    private static func adaptive(_ baseline: UInt32, _ system: NSColor, light: UInt32) -> NSColor {
        NSColor(name: nil) { appearance in
            guard Settings.usesLiquidGlass else {
                let isDark = appearance.bestMatch(from: [.aqua, .darkAqua]) == .darkAqua
                return color(hex: isDark ? baseline : light)
            }
            var resolved = system
            appearance.performAsCurrentDrawingAppearance {
                resolved = system.usingColorSpace(.deviceRGB) ?? system
            }
            return resolved
        }
    }

    private static func color(hex: UInt32, alpha: CGFloat = 1) -> NSColor {
        NSColor(
            srgbRed: CGFloat((hex >> 16) & 0xff) / 255,
            green: CGFloat((hex >> 8) & 0xff) / 255,
            blue: CGFloat(hex & 0xff) / 255,
            alpha: alpha
        )
    }
}

private final class SettingsFillView: NSView {
    private let fillColor: NSColor

    init(color: NSColor) {
        fillColor = color
        super.init(frame: .zero)
        wantsLayer = true
    }

    @available(*, unavailable)
    required init?(coder: NSCoder) {
        fatalError("init(coder:) is unavailable")
    }

    override var wantsUpdateLayer: Bool { true }

    override func updateLayer() {
        effectiveAppearance.performAsCurrentDrawingAppearance {
            layer?.backgroundColor = fillColor.cgColor
        }
    }

    override func viewDidChangeEffectiveAppearance() {
        super.viewDidChangeEffectiveAppearance()
        needsDisplay = true
    }
}

private protocol SettingsContrastRefreshing: AnyObject {
    func refreshContrastAppearance()
}

/// Glass pages use the window toolbar for their title; Classic keeps it inline.
private final class SettingsPageHeading: NSTextField, SettingsContrastRefreshing {
    var titleSpace: CGFloat = 40
    var contentTopConstraint: NSLayoutConstraint? {
        didSet {
            classicTopInset = contentTopConstraint?.constant ?? 0
            refreshContrastAppearance()
        }
    }
    private var classicTopInset: CGFloat = 0

    func refreshContrastAppearance() {
        isHidden = Settings.usesLiquidGlass
        contentTopConstraint?.constant = classicTopInset - (Settings.usesLiquidGlass ? titleSpace : 0)
    }
}

/// One system glass surface for a functional group, retaining its controls.
private final class SettingsGlassSurface: NSView, SettingsContrastRefreshing {
    private let controls: NSView
    private var effect: NSView?
    private var placement: [NSLayoutConstraint] = []

    init(controls: NSView) {
        self.controls = controls
        super.init(frame: .zero)
        translatesAutoresizingMaskIntoConstraints = false
        refreshContrastAppearance()
    }

    @available(*, unavailable)
    required init?(coder: NSCoder) {
        fatalError("init(coder:) is unavailable")
    }

    func refreshContrastAppearance() {
        let enabled = Settings.usesLiquidGlass
        (controls as? NSBox)?.cornerRadius = enabled
            ? SettingsStyle.glassGroupCornerRadius : SettingsStyle.surfaceCornerRadius
        guard controls.superview == nil || enabled != (effect != nil) else { return }
        NSLayoutConstraint.deactivate(placement)
        controls.removeFromSuperview()
        effect?.removeFromSuperview()
        effect = nil

        let host: NSView
        if #available(macOS 26, *), enabled {
            let glass = NSGlassEffectView()
            glass.identifier = NSUserInterfaceItemIdentifier("settings.control-group.glass")
            glass.style = .regular
            glass.cornerRadius = SettingsStyle.glassGroupCornerRadius
            glass.contentView = controls
            glass.translatesAutoresizingMaskIntoConstraints = false
            addSubview(glass)
            effect = glass
            host = glass
        } else {
            addSubview(controls)
            host = self
        }
        controls.translatesAutoresizingMaskIntoConstraints = false
        placement = [
            controls.leadingAnchor.constraint(equalTo: host.leadingAnchor),
            controls.trailingAnchor.constraint(equalTo: host.trailingAnchor),
            controls.topAnchor.constraint(equalTo: host.topAnchor),
            controls.bottomAnchor.constraint(equalTo: host.bottomAnchor),
        ]
        if let effect {
            placement += [
                effect.leadingAnchor.constraint(equalTo: leadingAnchor),
                effect.trailingAnchor.constraint(equalTo: trailingAnchor),
                effect.topAnchor.constraint(equalTo: topAnchor),
                effect.bottomAnchor.constraint(equalTo: bottomAnchor),
            ]
        }
        NSLayoutConstraint.activate(placement)
    }
}

private final class SettingsAdaptiveBorderBox: NSBox, SettingsContrastRefreshing {
    private let increaseContrast: () -> Bool

    init(increaseContrast: @escaping () -> Bool) {
        self.increaseContrast = increaseContrast
        super.init(frame: .zero)
        refreshContrastAppearance()
    }

    @available(*, unavailable)
    required init?(coder: NSCoder) {
        fatalError("init(coder:) is unavailable")
    }

    func refreshContrastAppearance() {
        borderWidth = increaseContrast() ? 2 : 1
        borderColor = increaseContrast()
            ? SettingsStyle.increasedContrastBorder
            : SettingsStyle.surfaceBorder
        needsDisplay = true
    }
}

private final class SettingsToggleButton: NSButton, SettingsContrastRefreshing {
    private let increaseContrast: () -> Bool
    let nativeSwitch = NSSwitch()

    init(
        accessibilityLabel: String,
        increaseContrast: @escaping () -> Bool,
        target: AnyObject? = nil,
        action: Selector? = nil
    ) {
        self.increaseContrast = increaseContrast
        super.init(frame: NSRect(origin: .zero, size: SettingsStyle.toggleSize))
        title = ""
        isBordered = false
        bezelStyle = .regularSquare
        setButtonType(.pushOnPushOff)
        imagePosition = .noImage
        focusRingType = .none
        self.target = target
        self.action = action
        setAccessibilityLabel(accessibilityLabel)
        setAccessibilityRole(.checkBox)
        translatesAutoresizingMaskIntoConstraints = false
        nativeSwitch.target = self
        nativeSwitch.action = #selector(toggleNativeSwitch(_:))
        nativeSwitch.setAccessibilityLabel(accessibilityLabel)
        nativeSwitch.translatesAutoresizingMaskIntoConstraints = false
        addSubview(nativeSwitch)
        NSLayoutConstraint.activate([
            nativeSwitch.centerXAnchor.constraint(equalTo: centerXAnchor),
            nativeSwitch.centerYAnchor.constraint(equalTo: centerYAnchor),
        ])
        refreshContrastAppearance()
    }

    @available(*, unavailable)
    required init?(coder: NSCoder) {
        fatalError("init(coder:) is unavailable")
    }

    override var intrinsicContentSize: NSSize { SettingsStyle.toggleSize }

    override var state: NSControl.StateValue {
        didSet { refreshNativeState() }
    }

    override var isEnabled: Bool {
        didSet { refreshNativeState() }
    }

    override var acceptsFirstResponder: Bool {
        Settings.usesLiquidGlass ? false : super.acceptsFirstResponder
    }

    override func setAccessibilityHelp(_ help: String?) {
        super.setAccessibilityHelp(help)
        nativeSwitch.setAccessibilityHelp(help)
    }

    @objc private func toggleNativeSwitch(_ sender: NSSwitch) {
        guard isEnabled, state != .mixed else {
            refreshNativeState()
            return
        }
        state = sender.state
        if let action { sendAction(action, to: target) }
    }

    private func refreshNativeState() {
        // NSSwitch interprets .mixed as .on. Unknown helper state must not
        // claim an enabled setting; the row detail and AX description explain it.
        nativeSwitch.state = state == .on ? .on : .off
        nativeSwitch.isEnabled = isEnabled && state != .mixed
        nativeSwitch.setAccessibilityValueDescription(state == .mixed ? "Unknown" : nil)
    }

    var trackColor: NSColor {
        guard state != .on else { return SettingsStyle.green }
        return increaseContrast()
            ? SettingsStyle.increasedContrastToggleOff
            : SettingsStyle.toggleOff
    }

    var trackStrokeColor: NSColor {
        guard state != .on, increaseContrast() else { return SettingsStyle.border }
        return SettingsStyle.increasedContrastToggleBorder
    }

    var trackStrokeWidth: CGFloat {
        state != .on && increaseContrast() ? 2 : 1
    }

    func refreshContrastAppearance() {
        nativeSwitch.isHidden = !Settings.usesLiquidGlass
        refreshNativeState()
        setAccessibilityElement(!Settings.usesLiquidGlass)
        needsDisplay = true
    }

    override func viewDidChangeEffectiveAppearance() {
        super.viewDidChangeEffectiveAppearance()
        needsDisplay = true
    }

    override func draw(_ dirtyRect: NSRect) {
        guard !Settings.usesLiquidGlass else { return }
        let trackRect = bounds.insetBy(dx: 1, dy: 1)
        let track = NSBezierPath(
            roundedRect: trackRect,
            xRadius: trackRect.height / 2,
            yRadius: trackRect.height / 2
        )
        let opacity: CGFloat = isEnabled ? 1 : 0.48
        trackColor.withAlphaComponent(opacity).setFill()
        track.fill()

        trackStrokeColor.withAlphaComponent(opacity).setStroke()
        track.lineWidth = trackStrokeWidth
        track.stroke()

        let knobSide = trackRect.height - 4
        let knobX: CGFloat
        switch state {
        case .on:
            knobX = trackRect.maxX - knobSide - 2
        case .mixed:
            knobX = trackRect.midX - knobSide / 2
        default:
            knobX = trackRect.minX + 2
        }
        let knobRect = NSRect(
            x: knobX,
            y: trackRect.midY - knobSide / 2,
            width: knobSide,
            height: knobSide
        )
        NSColor.white.withAlphaComponent(0.98 * opacity).setFill()
        NSBezierPath(ovalIn: knobRect).fill()

        NSColor.black.withAlphaComponent(0.22 * opacity).setStroke()
        let knobBorder = NSBezierPath(ovalIn: knobRect.insetBy(dx: 0.5, dy: 0.5))
        knobBorder.lineWidth = 0.75
        knobBorder.stroke()

        if window?.firstResponder === self {
            NSColor.keyboardFocusIndicatorColor.withAlphaComponent(0.85).setStroke()
            let focus = NSBezierPath(
                roundedRect: bounds.insetBy(dx: 0.5, dy: 0.5),
                xRadius: bounds.height / 2,
                yRadius: bounds.height / 2
            )
            focus.lineWidth = 2
            focus.stroke()
        }
    }
}

private final class SettingsSidebarCellView: NSTableCellView, SettingsContrastRefreshing {
    private let icon: ModuleIconArtwork.SidebarIcon
    private let increaseContrast: () -> Bool

    init(icon: ModuleIconArtwork.SidebarIcon, increaseContrast: @escaping () -> Bool) {
        self.icon = icon
        self.increaseContrast = increaseContrast
        super.init(frame: .zero)
    }

    @available(*, unavailable)
    required init?(coder: NSCoder) { fatalError("init(coder:) is unavailable") }

    override var backgroundStyle: NSView.BackgroundStyle {
        didSet { refreshContrastAppearance() }
    }

    override func viewDidChangeEffectiveAppearance() {
        super.viewDidChangeEffectiveAppearance()
        refreshContrastAppearance()
    }

    func refreshContrastAppearance() {
        effectiveAppearance.performAsCurrentDrawingAppearance {
            let emphasized = backgroundStyle == .emphasized
            let ink = emphasized ? NSColor.white : SettingsStyle.primaryText
            let accent = emphasized ? NSColor.white : .systemBlue
            imageView?.image = ModuleIconArtwork.sidebarImage(
                for: icon, side: 18,
                ink: ink.usingColorSpace(.sRGB) ?? ink,
                accent: accent.usingColorSpace(.sRGB) ?? accent,
                increasedContrast: increaseContrast()
            )
            imageView?.contentTintColor = nil
        }
    }
}

private final class SettingsSidebarRowView: NSTableRowView, SettingsContrastRefreshing {
    private let increaseContrast: () -> Bool

    init(increaseContrast: @escaping () -> Bool) {
        self.increaseContrast = increaseContrast
        super.init(frame: .zero)
    }

    @available(*, unavailable)
    required init?(coder: NSCoder) {
        fatalError("init(coder:) is unavailable")
    }

    var selectionFillColor: NSColor {
        .labelColor.withAlphaComponent(increaseContrast() ? 0.14 : 0.07)
    }

    var selectionStrokeColor: NSColor? {
        increaseContrast() ? .labelColor : nil
    }

    var selectionStrokeWidth: CGFloat { increaseContrast() ? 2 : 0 }

    override var isSelected: Bool {
        didSet { needsDisplay = true }
    }

    func refreshContrastAppearance() {
        needsDisplay = true
    }

    override func drawBackground(in dirtyRect: NSRect) {
        super.drawBackground(in: dirtyRect)
        guard !Settings.usesLiquidGlass else { return }
        guard isSelected else { return }
        selectionFillColor.setFill()
        let selection = NSBezierPath(
            roundedRect: bounds.insetBy(dx: 0, dy: 3),
            xRadius: 9,
            yRadius: 9
        )
        selection.fill()

        guard let selectionStrokeColor else { return }
        selectionStrokeColor.setStroke()
        let outline = NSBezierPath(
            roundedRect: bounds.insetBy(dx: 1, dy: 4),
            xRadius: 8,
            yRadius: 8
        )
        outline.lineWidth = selectionStrokeWidth
        outline.stroke()
    }

    override func drawSelection(in dirtyRect: NSRect) {
        if Settings.usesLiquidGlass { super.drawSelection(in: dirtyRect) }
    }
}

private final class DynamicSeparatorView: NSView, SettingsContrastRefreshing {
    private let increaseContrast: () -> Bool
    private let increasedContrastStroke = CALayer()

    init(increaseContrast: @escaping () -> Bool) {
        self.increaseContrast = increaseContrast
        super.init(frame: .zero)
        wantsLayer = true
        layer?.masksToBounds = false
        layer?.addSublayer(increasedContrastStroke)
        refreshContrastAppearance()
    }

    @available(*, unavailable)
    required init?(coder: NSCoder) {
        fatalError("init(coder:) is unavailable")
    }

    var strokeColor: NSColor {
        increaseContrast() ? SettingsStyle.increasedContrastBorder : SettingsStyle.divider
    }

    var visualStrokeWidth: CGFloat { increaseContrast() ? 2 : 1 }
    var renderedStrokeWidth: CGFloat {
        increaseContrast() ? increasedContrastStroke.frame.width : bounds.width
    }

    override var wantsUpdateLayer: Bool { true }

    override func layout() {
        super.layout()
        updateStrokeLayers()
    }

    override func updateLayer() {
        updateStrokeLayers()
    }

    func refreshContrastAppearance() {
        updateStrokeLayers()
        needsLayout = true
        needsDisplay = true
    }

    private func updateStrokeLayers() {
        let increased = increaseContrast()
        layer?.masksToBounds = false
        effectiveAppearance.performAsCurrentDrawingAppearance {
            layer?.backgroundColor = increased ? NSColor.clear.cgColor : SettingsStyle.divider.cgColor
            increasedContrastStroke.backgroundColor = strokeColor.cgColor
        }
        increasedContrastStroke.isHidden = !increased
        increasedContrastStroke.frame = NSRect(
            x: (bounds.width - visualStrokeWidth) / 2,
            y: 0,
            width: visualStrokeWidth,
            height: bounds.height
        )
    }
}

private final class SettingsFormStackView: NSStackView {
    override var isFlipped: Bool { true }
}

private func settingsGroup(title: String, identifier: String, content: NSView) -> NSStackView {
    let heading = NSTextField(labelWithString: title)
    heading.identifier = NSUserInterfaceItemIdentifier("\(identifier).heading")
    heading.font = .systemFont(ofSize: 12, weight: .semibold)
    heading.textColor = SettingsStyle.primaryText
    let group = NSStackView(views: [heading, content])
    group.identifier = NSUserInterfaceItemIdentifier(identifier)
    group.setAccessibilityElement(true)
    group.setAccessibilityRole(.group)
    group.setAccessibilityLabel(title)
    group.orientation = .vertical
    group.alignment = .leading
    group.spacing = 8
    content.widthAnchor.constraint(equalTo: group.widthAnchor).isActive = true
    return group
}

@available(macOS 26, *)
private final class SettingsGlassFormContainerView: NSGlassEffectContainerView {
    override var isFlipped: Bool { true }
}

private enum SettingsLogoArtwork {
    static func image(style: Settings.InAppLogoStyle, appearance: NSAppearance) -> NSImage? {
        let resource: String
        switch style {
        case .color:
            resource = "AppLogoColor"
        case .clear:
            resource = appearance.bestMatch(from: [.aqua, .darkAqua]) == .darkAqua
                ? "AppLogoClearDark" : "AppLogoClearLight"
        }
        return NSImage(named: resource)
            ?? NSImage(named: "AppIconSettings")
            ?? NSWorkspace.shared.icon(forFile: Bundle.main.bundlePath)
    }
}

private final class SettingsLogoImageView: NSImageView {
    func refreshLogo() {
        image = SettingsLogoArtwork.image(style: Settings.inAppLogoStyle, appearance: effectiveAppearance)
    }

    override func viewDidChangeEffectiveAppearance() {
        super.viewDidChangeEffectiveAppearance()
        refreshLogo()
    }
}

private final class SettingsTransparencySlider: NSSlider {
    override func becomeFirstResponder() -> Bool {
        let accepted = super.becomeFirstResponder()
        if accepted, let row = superview { row.scrollToVisible(row.bounds) }
        return accepted
    }
}

private final class SettingsPopoverArrowSwitch: NSSwitch {
    override func becomeFirstResponder() -> Bool {
        let accepted = super.becomeFirstResponder()
        if accepted, let row = superview { row.scrollToVisible(row.bounds) }
        return accepted
    }
}

private final class SettingsAppearancePopupButton: NSPopUpButton {
    weak var focusScrollView: NSView?

    override func becomeFirstResponder() -> Bool {
        let accepted = super.becomeFirstResponder()
        if accepted {
            let target = focusScrollView ?? self
            target.scrollToVisible(target.bounds)
        }
        return accepted
    }

    func refreshPreviews() {
        for item in itemArray {
            guard let value = item.representedObject as? String,
                  let style = Settings.InAppLogoStyle(rawValue: value) else { continue }
            let preview = SettingsLogoArtwork.image(style: style, appearance: effectiveAppearance)?.copy() as? NSImage
            preview?.size = NSSize(width: 24, height: 24)
            item.image = preview
        }
    }

    override func viewDidChangeEffectiveAppearance() {
        super.viewDidChangeEffectiveAppearance()
        refreshPreviews()
    }
}

private final class SettingsFeedbackButton: NSButton {
    override func becomeFirstResponder() -> Bool {
        let accepted = super.becomeFirstResponder()
        if accepted, let row = superview {
            let inset = Settings.usesLiquidGlass ? SettingsStyle.groupOpticalInset : 0
            row.scrollToVisible(row.bounds.insetBy(dx: -inset, dy: -inset))
        }
        return accepted
    }
}

private final class GeneralSettingsIconView: NSImageView, SettingsContrastRefreshing {
    private let artwork: ModuleIconArtwork.GeneralIcon
    private let increaseContrast: () -> Bool

    init(artwork: ModuleIconArtwork.GeneralIcon, increaseContrast: @escaping () -> Bool) {
        self.artwork = artwork
        self.increaseContrast = increaseContrast
        super.init(frame: .zero)
        isEditable = false
        allowsCutCopyPaste = false
        refreshContrastAppearance()
    }

    @available(*, unavailable)
    required init?(coder: NSCoder) { fatalError("init(coder:) is unavailable") }

    override func viewDidChangeEffectiveAppearance() {
        super.viewDidChangeEffectiveAppearance()
        refreshContrastAppearance()
    }

    func refreshContrastAppearance() {
        effectiveAppearance.performAsCurrentDrawingAppearance {
            let ink = SettingsStyle.primaryText.usingColorSpace(.sRGB) ?? SettingsStyle.primaryText
            let blue = NSColor.systemBlue.usingColorSpace(.sRGB) ?? .systemBlue
            image = ModuleIconArtwork.generalImage(
                for: artwork, side: SettingsStyle.rowSymbolSize, ink: ink,
                accent: blue, increasedContrast: increaseContrast()
            )
            contentTintColor = nil
        }
    }
}

private final class GeneralSettingsSectionController: NSObject, SettingsSectionController {
    private static let controlsInstallerURL = URL(
        string: "https://github.com/laleoarrow/battery-monitor/releases/latest"
    )!

    let identifier = "general"
    let title = "General"
    let sidebarIcon: ModuleIconArtwork.SidebarIcon = .general
    let view = NSView()

    private let dependencies: SettingsWindowDependencies
    private let loginButton: SettingsToggleButton
    private let batteryButton: SettingsToggleButton
    private let updateButton = NSButton()
    private let automaticUpdateButton: SettingsToggleButton
    private let feedbackButton = SettingsFeedbackButton()
    private let feedbackDetail = NSTextField(labelWithString: "Save diagnostics and review a report on GitHub")
    private let feedbackError = NSTextField(labelWithString: "")
    private let liquidGlassSwitch = NSSwitch()
    private let liquidGlassStylePopup = NSPopUpButton(frame: .zero, pullsDown: false)
    private let popoverArrowSwitch = SettingsPopoverArrowSwitch()
    private let transparencySlider = SettingsTransparencySlider()
    private let transparencyValue = NSTextField(labelWithString: "100%")
    private var displayOptionsObserver: NSObjectProtocol?
    private let colorSchemePopup = SettingsAppearancePopupButton(frame: .zero, pullsDown: false)
    private let logoPopup = SettingsAppearancePopupButton(frame: .zero, pullsDown: false)
    private let dockPopup = SettingsAppearancePopupButton(frame: .zero, pullsDown: false)
    private var appearanceObserver: NSObjectProtocol?
    private let loginDetail = NSTextField(labelWithString: "")
    private let loginError = NSTextField(labelWithString: "")
    private let batteryDetail = NSTextField(labelWithString: "")
    private let batteryError = NSTextField(labelWithString: "")
    private let updateDetail = NSTextField(labelWithString: "")
    private let updateError = NSTextField(labelWithString: "")
    private let automaticUpdateDetail = NSTextField(labelWithString: "")
    private let controlsRecovery = NSStackView()
    private let controlsRecoveryDetail = NSTextField(wrappingLabelWithString:
        "Monitoring continues using battery telemetry. The full PKG adds system controls and live SMC power. You can cancel installation and keep monitoring."
    )
    private let controlsRecoveryButton = NSButton()

    private let loginAccessibilityPurpose =
        "Open Wattson automatically after you sign in to this Mac."
    private let batteryAccessibilityPurpose =
        "Hide Apple’s battery icon while keeping Wattson in the menu bar."
    private let updateAccessibilityPurpose =
        "Check GitHub for the latest stable Wattson release."
    private let automaticUpdateAccessibilityPurpose =
        "Check for a newer stable Wattson release whenever Wattson opens."
    private let feedbackAccessibilityPurpose =
        "Save a diagnostic report and open a GitHub issue draft. Review and attach the report yourself; GitHub issues are public."

    private var batteryObserver: NSObjectProtocol?
    private var loginGeneration = 0
    private var batteryGeneration = 0
    private var loginMutationInFlight = false
    private var batteryMutationInFlight = false
    private var lastAuthoritativeLoginState: LoginItemState?
    private var lastAuthoritativeBatteryState: Bool?
    private var updateCheckInFlight = false
    private var availableRelease: UpdateRelease?
    private var loginNeedsRecovery = false
    private var batteryNeedsRecovery = false

    init(dependencies: SettingsWindowDependencies) {
        self.dependencies = dependencies
        loginButton = SettingsToggleButton(
            accessibilityLabel: "Launch at Login",
            increaseContrast: dependencies.increaseContrast
        )
        batteryButton = SettingsToggleButton(
            accessibilityLabel: "Hide System Battery Icon",
            increaseContrast: dependencies.increaseContrast
        )
        automaticUpdateButton = SettingsToggleButton(
            accessibilityLabel: "Check for Updates on Launch",
            increaseContrast: dependencies.increaseContrast
        )
        super.init()

        configureControls()
        buildView()
        installObservers()
    }

    deinit {
        if let batteryObserver {
            NotificationCenter.default.removeObserver(batteryObserver)
        }
        if let appearanceObserver {
            NotificationCenter.default.removeObserver(appearanceObserver)
        }
        if let displayOptionsObserver {
            NSWorkspace.shared.notificationCenter.removeObserver(displayOptionsObserver)
        }
    }

    func refresh() {
        guard Thread.isMainThread else {
            DispatchQueue.main.async { [weak self] in self?.refresh() }
            return
        }

        refreshLoginItem()
        refreshBatteryIcon()
        renderAutomaticUpdates()
        if !updateCheckInFlight, availableRelease == nil,
           updateError.isHidden, updateDetail.stringValue.isEmpty {
            renderCurrentVersion()
        }
    }

    private func configureControls() {
        configureSwitch(loginButton)
        loginButton.target = self
        loginButton.action = #selector(toggleLoginItem(_:))
        loginButton.allowsMixedState = true
        loginButton.setAccessibilityLabel("Launch at Login")
        loginButton.setAccessibilityHelp(
            loginAccessibilityPurpose
        )

        configureSwitch(batteryButton)
        batteryButton.target = self
        batteryButton.action = #selector(toggleBatteryIcon(_:))
        batteryButton.allowsMixedState = true
        batteryButton.setAccessibilityLabel("Hide System Battery Icon")
        batteryButton.setAccessibilityHelp(
            batteryAccessibilityPurpose
        )

        updateButton.title = "Check Now"
        updateButton.bezelStyle = .rounded
        updateButton.controlSize = .regular
        updateButton.font = .systemFont(ofSize: 12, weight: .medium)
        updateButton.target = self
        updateButton.action = #selector(checkForUpdates(_:))
        updateButton.setAccessibilityLabel("Check for Updates")
        updateButton.setAccessibilityHelp(updateAccessibilityPurpose)
        updateButton.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            updateButton.widthAnchor.constraint(
                equalToConstant: SettingsStyle.generalActionSize.width
            ),
            updateButton.heightAnchor.constraint(
                equalToConstant: SettingsStyle.generalActionSize.height
            ),
        ])

        configureSwitch(automaticUpdateButton)
        automaticUpdateButton.target = self
        automaticUpdateButton.action = #selector(toggleAutomaticUpdates(_:))
        automaticUpdateButton.setAccessibilityLabel("Check for Updates on Launch")
        automaticUpdateButton.setAccessibilityHelp(
            automaticUpdateAccessibilityPurpose
        )

        feedbackButton.title = "Report…"
        feedbackButton.bezelStyle = .rounded
        feedbackButton.controlSize = .regular
        feedbackButton.font = .systemFont(ofSize: 12, weight: .medium)
        feedbackButton.target = self
        feedbackButton.action = #selector(sendFeedback(_:))
        feedbackButton.setAccessibilityIdentifier("settings.general.feedback.button")
        feedbackButton.setAccessibilityLabel("Send Feedback")
        feedbackButton.setAccessibilityHelp(feedbackAccessibilityPurpose)
        feedbackButton.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            feedbackButton.widthAnchor.constraint(equalToConstant: SettingsStyle.generalActionSize.width),
            feedbackButton.heightAnchor.constraint(equalToConstant: SettingsStyle.generalActionSize.height),
        ])
        configureDetailLabel(feedbackDetail, identifier: "settings.general.feedback.detail")
        configureErrorLabel(feedbackError, identifier: "settings.general.feedback.error")

        configureDetailLabel(
            loginDetail,
            identifier: "settings.general.login.detail"
        )
        configureErrorLabel(
            loginError,
            identifier: "settings.general.login.error"
        )
        configureDetailLabel(
            batteryDetail,
            identifier: "settings.general.battery.detail"
        )
        configureErrorLabel(
            batteryError,
            identifier: "settings.general.battery.error"
        )
        configureDetailLabel(
            updateDetail,
            identifier: "settings.general.update.detail"
        )
        configureErrorLabel(
            updateError,
            identifier: "settings.general.update.error"
        )
        configureDetailLabel(
            automaticUpdateDetail,
            identifier: "settings.general.automatic-updates.detail"
        )
        controlsRecoveryDetail.font = SettingsStyle.detailFont
        controlsRecoveryDetail.textColor = .secondaryLabelColor
        controlsRecoveryDetail.setAccessibilityIdentifier("settings.general.controls-recovery.detail")
        controlsRecoveryButton.title = "Enable Controls…"
        controlsRecoveryButton.bezelStyle = .rounded
        controlsRecoveryButton.controlSize = .regular
        controlsRecoveryButton.font = .systemFont(ofSize: 12, weight: .medium)
        controlsRecoveryButton.image = NSImage(
            systemSymbolName: "arrow.up.right.square", accessibilityDescription: nil
        )
        controlsRecoveryButton.imagePosition = .imageLeading
        controlsRecoveryButton.target = self
        controlsRecoveryButton.action = #selector(openControlsInstaller(_:))
        controlsRecoveryButton.setAccessibilityIdentifier("settings.general.controls-recovery.button")
        controlsRecoveryButton.setAccessibilityHelp(
            "Open Wattson’s official GitHub release for the optional full PKG installer. No download or authorization starts automatically."
        )
    }

    private func configureSwitch(_ button: NSButton) {
        button.controlSize = .regular
        button.cell?.lineBreakMode = .byClipping
        button.title = ""
        button.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            button.widthAnchor.constraint(equalToConstant: SettingsStyle.toggleSize.width),
            button.heightAnchor.constraint(equalToConstant: SettingsStyle.toggleSize.height),
        ])
    }

    private func configureDetailLabel(
        _ label: NSTextField,
        identifier: String
    ) {
        label.font = SettingsStyle.detailFont
        label.textColor = SettingsStyle.secondaryText
        label.lineBreakMode = .byTruncatingTail
        label.maximumNumberOfLines = 1
        label.setAccessibilityIdentifier(identifier)
    }

    private func configureErrorLabel(
        _ label: NSTextField,
        identifier: String
    ) {
        configureDetailLabel(label, identifier: identifier)
        label.textColor = .systemRed
        label.isHidden = true
    }

    private func buildView() {
        view.identifier = NSUserInterfaceItemIdentifier("settings.section.general")
        let startupRows = [
            row(
                identifier: "login",
                artwork: .login,
                visibleTitle: "Launch at Login",
                button: loginButton,
                detail: loginDetail,
                error: loginError,
                hasSeparator: true
            ),
            row(
                identifier: "battery",
                artwork: .battery,
                visibleTitle: "Hide System Battery Icon",
                button: batteryButton,
                detail: batteryDetail,
                error: batteryError,
                hasSeparator: false
            ),
        ]
        let updateRows = [
            row(
                identifier: "update",
                artwork: .update,
                visibleTitle: "Check for Updates",
                button: updateButton,
                detail: updateDetail,
                error: updateError,
                hasSeparator: true
            ),
            row(
                identifier: "automatic-updates",
                artwork: .automatic,
                visibleTitle: "Check for Updates on Launch",
                button: automaticUpdateButton,
                detail: automaticUpdateDetail,
                error: nil,
                hasSeparator: false
            ),
        ]
        func makeList(_ views: [NSView], identifier: String) -> NSView {
            let rows = NSStackView(views: views)
            rows.orientation = .vertical
            rows.alignment = .width
            rows.distribution = .fillEqually
            rows.spacing = 0
            rows.translatesAutoresizingMaskIntoConstraints = false
            let list = SettingsAdaptiveBorderBox(increaseContrast: dependencies.increaseContrast)
            list.boxType = .custom
            list.identifier = NSUserInterfaceItemIdentifier(identifier)
            list.titlePosition = .noTitle
            list.cornerRadius = SettingsStyle.surfaceCornerRadius
            list.fillColor = SettingsStyle.surfaceBackground
            list.translatesAutoresizingMaskIntoConstraints = false
            list.addSubview(rows)
            let surface = SettingsGlassSurface(controls: list)
            NSLayoutConstraint.activate([
                surface.heightAnchor.constraint(equalToConstant: SettingsStyle.generalListHeight),
                rows.leadingAnchor.constraint(equalTo: list.leadingAnchor),
                rows.trailingAnchor.constraint(equalTo: list.trailingAnchor),
                rows.topAnchor.constraint(equalTo: list.topAnchor),
                rows.bottomAnchor.constraint(equalTo: list.bottomAnchor),
            ])
            return surface
        }
        let startup = settingsGroup(title: "Startup & Menu Bar", identifier: "settings.general.startup",
                                    content: makeList(startupRows, identifier: "settings.general.list"))
        let updates = settingsGroup(title: "Updates", identifier: "settings.general.updates",
                                    content: makeList(updateRows, identifier: "settings.general.updates.list"))

        let heading = SettingsPageHeading(labelWithString: title)
        heading.identifier = NSUserInterfaceItemIdentifier("settings.general.heading")
        heading.font = SettingsStyle.headingFont
        heading.textColor = SettingsStyle.headingText
        heading.setAccessibilityLabel(title)
        heading.translatesAutoresizingMaskIntoConstraints = false

        view.addSubview(heading)
        controlsRecovery.orientation = .vertical
        controlsRecovery.alignment = .leading
        controlsRecovery.spacing = 8
        controlsRecovery.translatesAutoresizingMaskIntoConstraints = false
        controlsRecovery.identifier = NSUserInterfaceItemIdentifier("settings.general.controls-recovery")
        controlsRecovery.addArrangedSubview(controlsRecoveryDetail)
        controlsRecovery.addArrangedSubview(controlsRecoveryButton)
        controlsRecovery.isHidden = true

        let appearance = makeAppearanceSection()
        let feedback = settingsGroup(title: "Support", identifier: "settings.general.support",
                                     content: makeFeedbackSection())
        let document = SettingsFormStackView(views: [startup, controlsRecovery, updates, appearance, feedback])
        document.orientation = .vertical
        document.alignment = .leading
        document.spacing = 16
        let opticalInset = SettingsStyle.groupOpticalInset
        document.edgeInsets = NSEdgeInsets(
            top: opticalInset, left: opticalInset, bottom: opticalInset, right: opticalInset
        )
        document.translatesAutoresizingMaskIntoConstraints = false
        let scrollDocument: NSView
        if #available(macOS 26, *) {
            // A container lifts its glass descendants above its content view.
            // Keep that rendering boundary inside the clip view, below the
            // fixed page heading. In Classic there are no glass descendants.
            let container = SettingsGlassFormContainerView()
            container.identifier = NSUserInterfaceItemIdentifier("settings.glass-container")
            container.spacing = 0
            container.contentView = document
            container.translatesAutoresizingMaskIntoConstraints = false
            NSLayoutConstraint.activate([
                document.leadingAnchor.constraint(equalTo: container.leadingAnchor),
                document.trailingAnchor.constraint(equalTo: container.trailingAnchor),
                document.topAnchor.constraint(equalTo: container.topAnchor),
                document.bottomAnchor.constraint(equalTo: container.bottomAnchor),
            ])
            scrollDocument = container
        } else {
            scrollDocument = document
        }
        let scroll = NSScrollView()
        scroll.identifier = NSUserInterfaceItemIdentifier("settings.general.scroll")
        scroll.backgroundColor = .clear
        scroll.drawsBackground = false
        scroll.borderType = .noBorder
        scroll.hasVerticalScroller = true
        scroll.autohidesScrollers = true
        scroll.scrollerStyle = .overlay
        scroll.automaticallyAdjustsContentInsets = false
        scroll.documentView = scrollDocument
        scroll.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(scroll)
        let contentTop = scroll.topAnchor.constraint(equalTo: view.topAnchor, constant: 40 - opticalInset)
        heading.contentTopConstraint = contentTop

        NSLayoutConstraint.activate([
            heading.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 2),
            heading.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            heading.topAnchor.constraint(equalTo: view.topAnchor, constant: -2),

            // Native group edges extend outside their rounded content. Expand
            // the clip and inset the document equally, retaining control frames.
            scroll.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: -opticalInset),
            scroll.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: opticalInset),
            contentTop,
            scroll.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: opticalInset),
            scrollDocument.leadingAnchor.constraint(equalTo: scroll.contentView.leadingAnchor),
            scrollDocument.topAnchor.constraint(equalTo: scroll.contentView.topAnchor),
            scrollDocument.widthAnchor.constraint(equalTo: scroll.contentView.widthAnchor),
            startup.widthAnchor.constraint(equalTo: document.widthAnchor, constant: -2 * opticalInset),
            updates.widthAnchor.constraint(equalTo: document.widthAnchor, constant: -2 * opticalInset),
            controlsRecovery.widthAnchor.constraint(equalTo: document.widthAnchor, constant: -2 * opticalInset),
            appearance.widthAnchor.constraint(equalTo: document.widthAnchor, constant: -2 * opticalInset),
            feedback.widthAnchor.constraint(equalTo: document.widthAnchor, constant: -2 * opticalInset),
            controlsRecoveryDetail.widthAnchor.constraint(equalTo: controlsRecovery.widthAnchor),
        ])
    }

    private func makeFeedbackSection() -> NSView {
        let feedbackRow = row(
            identifier: "feedback", artwork: .feedback,
            visibleTitle: "Send Feedback", button: feedbackButton,
            detail: feedbackDetail, error: feedbackError, hasSeparator: false
        )
        feedbackRow.translatesAutoresizingMaskIntoConstraints = false
        let box = SettingsAdaptiveBorderBox(increaseContrast: dependencies.increaseContrast)
        box.boxType = .custom
        box.titlePosition = .noTitle
        box.cornerRadius = SettingsStyle.surfaceCornerRadius
        box.fillColor = SettingsStyle.surfaceBackground
        box.translatesAutoresizingMaskIntoConstraints = false
        box.addSubview(feedbackRow)
        let surface = SettingsGlassSurface(controls: box)
        surface.identifier = NSUserInterfaceItemIdentifier("settings.general.feedback")
        NSLayoutConstraint.activate([
            feedbackRow.leadingAnchor.constraint(equalTo: box.leadingAnchor),
            feedbackRow.trailingAnchor.constraint(equalTo: box.trailingAnchor),
            feedbackRow.topAnchor.constraint(equalTo: box.topAnchor),
            feedbackRow.bottomAnchor.constraint(equalTo: box.bottomAnchor),
            surface.heightAnchor.constraint(equalToConstant: SettingsStyle.generalRowHeight),
        ])
        return surface
    }

    private func makeAppearanceSection() -> NSView {
        colorSchemePopup.identifier = NSUserInterfaceItemIdentifier("settings.appearance.color-scheme")
        colorSchemePopup.setAccessibilityLabel("Theme")
        colorSchemePopup.setAccessibilityHelp("Choose Light or Dark for Wattson, or System to follow macOS. Applies immediately.")
        colorSchemePopup.font = .systemFont(ofSize: 12)
        colorSchemePopup.controlSize = .small
        colorSchemePopup.target = self
        colorSchemePopup.action = #selector(selectColorScheme(_:))
        colorSchemePopup.translatesAutoresizingMaskIntoConstraints = false
        for scheme in Settings.ColorScheme.allCases {
            colorSchemePopup.addItem(withTitle: scheme.title)
            colorSchemePopup.lastItem?.representedObject = scheme.rawValue
        }
        let themeLabel = NSTextField(labelWithString: "Theme")
        themeLabel.font = SettingsStyle.primaryFont
        themeLabel.textColor = SettingsStyle.primaryText
        themeLabel.translatesAutoresizingMaskIntoConstraints = false
        let themeRow = NSView()
        themeRow.translatesAutoresizingMaskIntoConstraints = false
        themeRow.addSubview(themeLabel)
        themeRow.addSubview(colorSchemePopup)
        colorSchemePopup.focusScrollView = themeRow
        liquidGlassSwitch.identifier = NSUserInterfaceItemIdentifier("settings.appearance.liquid-glass")
        liquidGlassSwitch.setAccessibilityLabel("Global Liquid Glass")
        liquidGlassSwitch.target = self
        liquidGlassSwitch.action = #selector(toggleLiquidGlass(_:))
        liquidGlassSwitch.state = Settings.liquidGlassEnabled ? .on : .off
        liquidGlassSwitch.translatesAutoresizingMaskIntoConstraints = false
        let available: Bool
        if #available(macOS 26, *) { available = true } else { available = false }
        liquidGlassSwitch.isEnabled = available
        liquidGlassSwitch.setAccessibilityHelp(available
            ? "Use system glass throughout Wattson. Off keeps the classic appearance."
            : "Requires macOS 26 or later. Classic appearance is available on this Mac.")
        let detail = NSTextField(labelWithString: available
            ? "Standard is softly frosted; Clear is more transparent."
            : "Requires macOS 26 or later.")
        detail.font = SettingsStyle.detailFont
        detail.textColor = SettingsStyle.secondaryText
        let switchSlot = NSControl()
        switchSlot.setAccessibilityElement(false)
        switchSlot.translatesAutoresizingMaskIntoConstraints = false
        switchSlot.addSubview(liquidGlassSwitch)
        let option = row(identifier: "appearance", artwork: nil,
                         visibleTitle: "Liquid Glass", button: switchSlot,
                         detail: detail, error: nil, hasSeparator: false)

        liquidGlassStylePopup.identifier = NSUserInterfaceItemIdentifier(
            "settings.appearance.liquid-glass-style"
        )
        liquidGlassStylePopup.setAccessibilityLabel("Popup glass background")
        liquidGlassStylePopup.setAccessibilityHelp(
            "Choose Standard Glass for a softly frosted popup or Clear Glass for more transparency. Requires Liquid Glass to be on."
        )
        liquidGlassStylePopup.font = .systemFont(ofSize: 12)
        liquidGlassStylePopup.controlSize = .small
        liquidGlassStylePopup.target = self
        liquidGlassStylePopup.action = #selector(selectLiquidGlassStyle(_:))
        liquidGlassStylePopup.translatesAutoresizingMaskIntoConstraints = false
        for style in Settings.LiquidGlassStyle.allCases {
            liquidGlassStylePopup.addItem(withTitle: style == .regular ? "Standard Glass" : "Clear Glass")
            liquidGlassStylePopup.lastItem?.representedObject = style.rawValue
        }
        let styleLabel = NSTextField(labelWithString: "Popup background")
        styleLabel.identifier = NSUserInterfaceItemIdentifier("settings.appearance.background.label")
        styleLabel.font = .systemFont(ofSize: 12)
        styleLabel.textColor = SettingsStyle.secondaryText
        styleLabel.translatesAutoresizingMaskIntoConstraints = false
        let styleRow = NSView()
        styleRow.translatesAutoresizingMaskIntoConstraints = false
        styleRow.addSubview(styleLabel)
        styleRow.addSubview(liquidGlassStylePopup)

        popoverArrowSwitch.identifier = NSUserInterfaceItemIdentifier("settings.appearance.popover-arrow")
        popoverArrowSwitch.setAccessibilityLabel("Show Popover Arrow")
        popoverArrowSwitch.setAccessibilityHelp(
            "Show the arrow connecting the popup to its menu-bar icon. Turn off to move the popup body closer to the menu bar. Requires Liquid Glass to be on."
        )
        popoverArrowSwitch.target = self
        popoverArrowSwitch.action = #selector(togglePopoverArrow(_:))
        popoverArrowSwitch.translatesAutoresizingMaskIntoConstraints = false
        let arrowLabel = NSTextField(labelWithString: "Show Popover Arrow")
        arrowLabel.identifier = NSUserInterfaceItemIdentifier("settings.appearance.popover-arrow.label")
        arrowLabel.font = .systemFont(ofSize: 12)
        arrowLabel.textColor = SettingsStyle.secondaryText
        arrowLabel.translatesAutoresizingMaskIntoConstraints = false
        let arrowRow = NSView()
        arrowRow.translatesAutoresizingMaskIntoConstraints = false
        arrowRow.addSubview(arrowLabel)
        arrowRow.addSubview(popoverArrowSwitch)

        transparencySlider.identifier = NSUserInterfaceItemIdentifier("settings.appearance.glass-transparency")
        transparencySlider.cell?.setAccessibilityLabel("Glass transparency")
        transparencySlider.toolTip = "Adjust popup and Settings content backgrounds. 0% is solid; 100% keeps native glass. Text and controls stay opaque. macOS accessibility settings take priority."
        transparencySlider.cell?.setAccessibilityHelp(transparencySlider.toolTip)
        transparencySlider.minValue = 0
        transparencySlider.maxValue = 100
        transparencySlider.controlSize = .small
        transparencySlider.isContinuous = true
        transparencySlider.target = self
        transparencySlider.action = #selector(changeGlassTransparency(_:))
        transparencySlider.translatesAutoresizingMaskIntoConstraints = false
        transparencyValue.font = .monospacedDigitSystemFont(ofSize: 12, weight: .regular)
        transparencyValue.textColor = SettingsStyle.secondaryText
        transparencyValue.alignment = .right
        transparencyValue.setAccessibilityElement(false)
        transparencyValue.translatesAutoresizingMaskIntoConstraints = false
        let transparencyLabel = NSTextField(labelWithString: "Transparency")
        transparencyLabel.identifier = NSUserInterfaceItemIdentifier("settings.appearance.transparency.label")
        transparencyLabel.font = .systemFont(ofSize: 12)
        transparencyLabel.textColor = SettingsStyle.secondaryText
        transparencyLabel.translatesAutoresizingMaskIntoConstraints = false
        let transparencyRow = NSView()
        transparencyRow.translatesAutoresizingMaskIntoConstraints = false
        transparencyRow.addSubview(transparencyLabel)
        transparencyRow.addSubview(transparencySlider)
        transparencyRow.addSubview(transparencyValue)
        refreshAppearanceControls()
        logoPopup.identifier = NSUserInterfaceItemIdentifier("settings.appearance.in-app-logo")
        logoPopup.setAccessibilityLabel("In-App Logo")
        logoPopup.setAccessibilityHelp("Finder and menu bar icons stay unchanged. Previews are static artwork.")
        logoPopup.font = .systemFont(ofSize: 12)
        logoPopup.controlSize = .small
        logoPopup.target = self
        logoPopup.action = #selector(selectInAppLogo(_:))
        logoPopup.translatesAutoresizingMaskIntoConstraints = false
        for style in Settings.InAppLogoStyle.allCases {
            logoPopup.addItem(withTitle: style == .color ? "Color" : "Clear")
            logoPopup.lastItem?.representedObject = style.rawValue
        }
        refreshLogoControls()
        let logoLabel = NSTextField(labelWithString: "In-App Logo")
        logoLabel.font = SettingsStyle.primaryFont
        logoLabel.textColor = SettingsStyle.primaryText
        logoLabel.translatesAutoresizingMaskIntoConstraints = false
        let logoRow = NSView()
        logoRow.translatesAutoresizingMaskIntoConstraints = false
        logoRow.addSubview(logoLabel)
        logoRow.addSubview(logoPopup)
        dockPopup.identifier = NSUserInterfaceItemIdentifier("settings.appearance.dock-icon")
        dockPopup.setAccessibilityLabel("Dock Icon")
        dockPopup.setAccessibilityHelp(
            "Restart Wattson to apply. Finder icon stays unchanged. Hidden keeps Wattson menu-bar-only."
        )
        dockPopup.font = .systemFont(ofSize: 12)
        dockPopup.controlSize = .small
        dockPopup.target = self
        dockPopup.action = #selector(selectDockIcon(_:))
        dockPopup.translatesAutoresizingMaskIntoConstraints = false
        for style in Settings.DockIconStyle.allCases {
            dockPopup.addItem(withTitle: style.title)
            dockPopup.lastItem?.representedObject = style.rawValue
        }
        refreshDockControls()
        let dockLabel = NSTextField(labelWithString: "Dock Icon")
        dockLabel.font = SettingsStyle.primaryFont
        dockLabel.textColor = SettingsStyle.primaryText
        dockLabel.translatesAutoresizingMaskIntoConstraints = false
        let dockHelp = NSTextField(wrappingLabelWithString:
            "Restart Wattson to apply."
        )
        dockHelp.identifier = NSUserInterfaceItemIdentifier("settings.appearance.dock-icon.help")
        dockHelp.font = SettingsStyle.detailFont
        dockHelp.textColor = SettingsStyle.secondaryText
        dockHelp.translatesAutoresizingMaskIntoConstraints = false
        let dockRow = NSView()
        dockRow.translatesAutoresizingMaskIntoConstraints = false
        dockRow.addSubview(dockLabel)
        dockRow.addSubview(dockPopup)
        dockRow.addSubview(dockHelp)
        dockPopup.focusScrollView = dockRow
        let box = SettingsAdaptiveBorderBox(increaseContrast: dependencies.increaseContrast)
        box.boxType = .custom
        box.titlePosition = .noTitle
        box.cornerRadius = SettingsStyle.surfaceCornerRadius
        box.fillColor = SettingsStyle.surfaceBackground
        box.addSubview(themeRow)
        box.addSubview(option)
        box.addSubview(styleRow)
        box.addSubview(arrowRow)
        box.addSubview(transparencyRow)
        box.addSubview(logoRow)
        box.addSubview(dockRow)
        option.translatesAutoresizingMaskIntoConstraints = false
        let surface = SettingsGlassSurface(controls: box)
        let section = settingsGroup(title: "Appearance", identifier: "settings.general.appearance",
                                    content: surface)
        for peerRow in [themeRow, logoRow] {
            let separator = NSBox()
            separator.boxType = .separator
            separator.translatesAutoresizingMaskIntoConstraints = false
            peerRow.addSubview(separator)
            NSLayoutConstraint.activate([
                separator.leadingAnchor.constraint(equalTo: peerRow.leadingAnchor, constant: 16),
                separator.trailingAnchor.constraint(equalTo: peerRow.trailingAnchor, constant: -16),
                separator.bottomAnchor.constraint(equalTo: peerRow.bottomAnchor),
            ])
        }
        let glassSeparator = NSBox()
        glassSeparator.boxType = .separator
        glassSeparator.translatesAutoresizingMaskIntoConstraints = false
        transparencyRow.addSubview(glassSeparator)
        NSLayoutConstraint.activate([
            switchSlot.widthAnchor.constraint(equalToConstant: SettingsStyle.toggleSize.width),
            switchSlot.heightAnchor.constraint(equalToConstant: SettingsStyle.toggleSize.height),
            liquidGlassSwitch.centerXAnchor.constraint(equalTo: switchSlot.centerXAnchor),
            liquidGlassSwitch.centerYAnchor.constraint(equalTo: switchSlot.centerYAnchor),
            surface.heightAnchor.constraint(equalToConstant: 44 + SettingsStyle.generalRowHeight + 32 + 32 + 36 + 44 + 60),
            themeRow.leadingAnchor.constraint(equalTo: box.leadingAnchor),
            themeRow.trailingAnchor.constraint(equalTo: box.trailingAnchor),
            themeRow.topAnchor.constraint(equalTo: box.topAnchor),
            themeRow.heightAnchor.constraint(equalToConstant: 44),
            themeLabel.leadingAnchor.constraint(equalTo: themeRow.leadingAnchor, constant: 16),
            themeLabel.centerYAnchor.constraint(equalTo: themeRow.centerYAnchor),
            themeLabel.trailingAnchor.constraint(lessThanOrEqualTo: colorSchemePopup.leadingAnchor, constant: -12),
            colorSchemePopup.trailingAnchor.constraint(equalTo: liquidGlassStylePopup.trailingAnchor),
            colorSchemePopup.centerYAnchor.constraint(equalTo: themeRow.centerYAnchor),
            colorSchemePopup.widthAnchor.constraint(equalTo: liquidGlassStylePopup.widthAnchor),
            option.leadingAnchor.constraint(equalTo: box.leadingAnchor),
            option.trailingAnchor.constraint(equalTo: box.trailingAnchor),
            option.topAnchor.constraint(equalTo: themeRow.bottomAnchor),
            option.heightAnchor.constraint(equalToConstant: SettingsStyle.generalRowHeight),
            styleRow.leadingAnchor.constraint(equalTo: box.leadingAnchor),
            styleRow.trailingAnchor.constraint(equalTo: box.trailingAnchor),
            styleRow.topAnchor.constraint(equalTo: option.bottomAnchor),
            styleRow.heightAnchor.constraint(equalToConstant: 32),
            styleLabel.leadingAnchor.constraint(equalTo: styleRow.leadingAnchor,
                                                constant: 32),
            styleLabel.centerYAnchor.constraint(equalTo: styleRow.centerYAnchor, constant: -4),
            styleLabel.trailingAnchor.constraint(lessThanOrEqualTo: liquidGlassStylePopup.leadingAnchor,
                                                 constant: -12),
            liquidGlassStylePopup.trailingAnchor.constraint(equalTo: styleRow.trailingAnchor, constant: -16),
            liquidGlassStylePopup.centerYAnchor.constraint(equalTo: styleLabel.centerYAnchor),
            liquidGlassStylePopup.widthAnchor.constraint(equalToConstant: 162),
            arrowRow.leadingAnchor.constraint(equalTo: box.leadingAnchor),
            arrowRow.trailingAnchor.constraint(equalTo: box.trailingAnchor),
            arrowRow.topAnchor.constraint(equalTo: styleRow.bottomAnchor),
            arrowRow.heightAnchor.constraint(equalToConstant: 32),
            arrowLabel.leadingAnchor.constraint(equalTo: styleLabel.leadingAnchor),
            arrowLabel.centerYAnchor.constraint(equalTo: arrowRow.centerYAnchor, constant: -4),
            arrowLabel.trailingAnchor.constraint(lessThanOrEqualTo: popoverArrowSwitch.leadingAnchor, constant: -12),
            popoverArrowSwitch.trailingAnchor.constraint(equalTo: liquidGlassSwitch.trailingAnchor),
            popoverArrowSwitch.centerYAnchor.constraint(equalTo: arrowLabel.centerYAnchor),
            transparencyRow.leadingAnchor.constraint(equalTo: box.leadingAnchor),
            transparencyRow.trailingAnchor.constraint(equalTo: box.trailingAnchor),
            transparencyRow.topAnchor.constraint(equalTo: arrowRow.bottomAnchor),
            transparencyRow.heightAnchor.constraint(equalToConstant: 36),
            transparencyLabel.leadingAnchor.constraint(equalTo: styleLabel.leadingAnchor),
            transparencyLabel.centerYAnchor.constraint(equalTo: transparencyRow.centerYAnchor, constant: -4),
            transparencyLabel.trailingAnchor.constraint(lessThanOrEqualTo: transparencySlider.leadingAnchor, constant: -12),
            transparencySlider.leadingAnchor.constraint(equalTo: liquidGlassStylePopup.leadingAnchor),
            transparencySlider.trailingAnchor.constraint(equalTo: transparencyValue.leadingAnchor, constant: -6),
            transparencySlider.centerYAnchor.constraint(equalTo: transparencyLabel.centerYAnchor),
            transparencyValue.trailingAnchor.constraint(equalTo: liquidGlassStylePopup.trailingAnchor),
            transparencyValue.widthAnchor.constraint(equalToConstant: 34),
            transparencyValue.centerYAnchor.constraint(equalTo: transparencyLabel.centerYAnchor),
            glassSeparator.leadingAnchor.constraint(equalTo: transparencyRow.leadingAnchor, constant: 16),
            glassSeparator.trailingAnchor.constraint(equalTo: transparencyRow.trailingAnchor, constant: -16),
            glassSeparator.bottomAnchor.constraint(equalTo: transparencyRow.bottomAnchor),
            logoRow.leadingAnchor.constraint(equalTo: box.leadingAnchor),
            logoRow.trailingAnchor.constraint(equalTo: box.trailingAnchor),
            logoRow.topAnchor.constraint(equalTo: transparencyRow.bottomAnchor),
            logoRow.heightAnchor.constraint(equalToConstant: 44),
            logoLabel.leadingAnchor.constraint(equalTo: themeLabel.leadingAnchor),
            logoLabel.centerYAnchor.constraint(equalTo: logoRow.centerYAnchor),
            logoLabel.trailingAnchor.constraint(lessThanOrEqualTo: logoPopup.leadingAnchor, constant: -12),
            logoPopup.trailingAnchor.constraint(equalTo: liquidGlassStylePopup.trailingAnchor),
            logoPopup.centerYAnchor.constraint(equalTo: logoLabel.centerYAnchor),
            logoPopup.widthAnchor.constraint(equalTo: liquidGlassStylePopup.widthAnchor),
            dockRow.leadingAnchor.constraint(equalTo: box.leadingAnchor),
            dockRow.trailingAnchor.constraint(equalTo: box.trailingAnchor),
            dockRow.topAnchor.constraint(equalTo: logoRow.bottomAnchor),
            dockRow.bottomAnchor.constraint(equalTo: box.bottomAnchor),
            dockLabel.leadingAnchor.constraint(equalTo: themeLabel.leadingAnchor),
            dockLabel.centerYAnchor.constraint(equalTo: dockRow.topAnchor, constant: 22),
            dockLabel.trailingAnchor.constraint(lessThanOrEqualTo: dockPopup.leadingAnchor, constant: -12),
            dockPopup.trailingAnchor.constraint(equalTo: liquidGlassStylePopup.trailingAnchor),
            dockPopup.centerYAnchor.constraint(equalTo: dockLabel.centerYAnchor),
            dockPopup.widthAnchor.constraint(equalTo: liquidGlassStylePopup.widthAnchor),
            dockHelp.leadingAnchor.constraint(equalTo: dockLabel.leadingAnchor),
            dockHelp.trailingAnchor.constraint(equalTo: dockRow.trailingAnchor, constant: -16),
            dockHelp.topAnchor.constraint(equalTo: dockRow.topAnchor, constant: 40),
            dockHelp.bottomAnchor.constraint(lessThanOrEqualTo: dockRow.bottomAnchor, constant: -6),
        ])
        return section
    }

    @objc private func selectColorScheme(_ sender: NSPopUpButton) {
        guard let value = sender.selectedItem?.representedObject as? String,
              let scheme = Settings.ColorScheme(rawValue: value) else { return }
        Settings.colorScheme = scheme
    }

    @objc private func toggleLiquidGlass(_ sender: NSSwitch) {
        Settings.liquidGlassEnabled = sender.state == .on
    }

    @objc private func selectLiquidGlassStyle(_ sender: NSPopUpButton) {
        guard Settings.usesLiquidGlass,
              let value = sender.selectedItem?.representedObject as? String,
              let style = Settings.LiquidGlassStyle(rawValue: value) else { return }
        Settings.liquidGlassStyle = style
    }

    @objc private func changeGlassTransparency(_ sender: NSSlider) {
        guard Settings.usesLiquidGlass,
              !GlassBackgroundView.accessibilityRequiresSolidBackground else { return }
        Settings.liquidGlassTransparency = sender.doubleValue.rounded() / 100
    }

    @objc private func togglePopoverArrow(_ sender: NSSwitch) {
        guard Settings.usesLiquidGlass else { return }
        Settings.showPopoverArrow = sender.state == .on
    }

    @objc private func selectInAppLogo(_ sender: NSPopUpButton) {
        guard let value = sender.selectedItem?.representedObject as? String,
              let style = Settings.InAppLogoStyle(rawValue: value) else { return }
        Settings.inAppLogoStyle = style
    }

    @objc private func selectDockIcon(_ sender: NSPopUpButton) {
        guard let value = sender.selectedItem?.representedObject as? String,
              let style = Settings.DockIconStyle(rawValue: value) else { return }
        Settings.dockIconStyle = style
    }

    private func refreshDockControls() {
        if let item = dockPopup.itemArray.first(where: {
            $0.representedObject as? String == Settings.dockIconStyle.rawValue
        }) {
            dockPopup.select(item)
        }
        dockPopup.refreshPreviews()
    }

    private func refreshLogoControls() {
        if let item = logoPopup.itemArray.first(where: {
            $0.representedObject as? String == Settings.inAppLogoStyle.rawValue
        }) {
            logoPopup.select(item)
        }
        logoPopup.refreshPreviews()
    }

    private func refreshAppearanceControls() {
        if let item = colorSchemePopup.itemArray.first(where: {
            $0.representedObject as? String == Settings.colorScheme.rawValue
        }) {
            colorSchemePopup.select(item)
        }
        liquidGlassSwitch.state = Settings.liquidGlassEnabled ? .on : .off
        if !Settings.usesLiquidGlass,
           popoverArrowSwitch.window?.firstResponder === popoverArrowSwitch {
            popoverArrowSwitch.window?.makeFirstResponder(liquidGlassSwitch)
        }
        popoverArrowSwitch.isEnabled = Settings.usesLiquidGlass
        popoverArrowSwitch.state = Settings.showPopoverArrow ? .on : .off
        let adjustable = Settings.usesLiquidGlass && !GlassBackgroundView.accessibilityRequiresSolidBackground
        if !adjustable, transparencySlider.window?.firstResponder === transparencySlider {
            transparencySlider.window?.makeFirstResponder(liquidGlassSwitch)
        }
        transparencySlider.isEnabled = adjustable
        transparencySlider.doubleValue = Settings.liquidGlassTransparency * 100
        transparencyValue.stringValue = "\(Int(transparencySlider.doubleValue.rounded()))%"
        transparencySlider.cell?.setAccessibilityValueDescription(GlassBackgroundView.accessibilityRequiresSolidBackground
            ? "Controlled by macOS accessibility settings"
            : "\(transparencyValue.stringValue), higher is more transparent")
        if !Settings.usesLiquidGlass,
           liquidGlassStylePopup.window?.firstResponder === liquidGlassStylePopup {
            liquidGlassStylePopup.window?.makeFirstResponder(liquidGlassSwitch)
        }
        liquidGlassStylePopup.isEnabled = Settings.usesLiquidGlass
        if let item = liquidGlassStylePopup.itemArray.first(where: {
            $0.representedObject as? String == Settings.liquidGlassStyle.rawValue
        }) {
            liquidGlassStylePopup.select(item)
        }
    }

    private func row(
        identifier: String,
        artwork: ModuleIconArtwork.GeneralIcon?,
        visibleTitle: String,
        button: NSControl,
        detail: NSTextField,
        error: NSTextField?,
        hasSeparator: Bool
    ) -> NSView {
        let row = NSView()
        row.identifier = NSUserInterfaceItemIdentifier("settings.general.row.\(identifier)")

        let primary = NSTextField(
            labelWithString: visibleTitle
        )
        primary.font = SettingsStyle.primaryFont
        primary.textColor = SettingsStyle.primaryText
        primary.lineBreakMode = .byTruncatingTail
        primary.translatesAutoresizingMaskIntoConstraints = false

        var textViews: [NSView] = [primary, detail]
        if let error { textViews.append(error) }
        let text = NSStackView(views: textViews)
        text.orientation = .vertical
        text.alignment = .leading
        text.distribution = .fill
        text.spacing = 2
        text.translatesAutoresizingMaskIntoConstraints = false

        row.addSubview(text)
        row.addSubview(button)
        if let artwork {
            let icon = GeneralSettingsIconView(artwork: artwork,
                                               increaseContrast: dependencies.increaseContrast)
            icon.identifier = NSUserInterfaceItemIdentifier("settings.general.icon.\(identifier)")
            icon.imageScaling = .scaleProportionallyDown
            icon.setAccessibilityElement(false)
            icon.translatesAutoresizingMaskIntoConstraints = false
            row.addSubview(icon)
            NSLayoutConstraint.activate([
                icon.leadingAnchor.constraint(equalTo: row.leadingAnchor, constant: 16),
                icon.centerYAnchor.constraint(equalTo: row.centerYAnchor),
                icon.widthAnchor.constraint(equalToConstant: SettingsStyle.rowIconSize),
                icon.heightAnchor.constraint(equalToConstant: SettingsStyle.rowIconSize),
                text.leadingAnchor.constraint(equalTo: icon.trailingAnchor, constant: 12),
            ])
        } else {
            text.leadingAnchor.constraint(equalTo: row.leadingAnchor, constant: 16).isActive = true
        }
        NSLayoutConstraint.activate([
            text.centerYAnchor.constraint(equalTo: row.centerYAnchor, constant: 0.5),
            text.trailingAnchor.constraint(lessThanOrEqualTo: button.leadingAnchor, constant: -12),

            button.trailingAnchor.constraint(equalTo: row.trailingAnchor, constant: -16),
            button.centerYAnchor.constraint(equalTo: row.centerYAnchor),
        ])

        if hasSeparator {
            let separator = NSBox()
            separator.boxType = .separator
            separator.translatesAutoresizingMaskIntoConstraints = false
            row.addSubview(separator)
            NSLayoutConstraint.activate([
                separator.leadingAnchor.constraint(equalTo: text.leadingAnchor),
                separator.trailingAnchor.constraint(equalTo: row.trailingAnchor, constant: -16),
                separator.bottomAnchor.constraint(equalTo: row.bottomAnchor),
            ])
        }
        return row
    }

    private func installObservers() {
        appearanceObserver = NotificationCenter.default.addObserver(
            forName: Settings.didChange, object: nil, queue: .main
        ) { [weak self] notification in
            let change = notification.userInfo?[Settings.changeUserInfoKey] as? Settings.Change
            if change == .liquidGlassAppearance || change == .liquidGlassTransparency || change == .popoverArrow || change == .colorScheme { self?.refreshAppearanceControls() }
            if change == .inAppLogoStyle { self?.refreshLogoControls() }
            if change == nil || change == .dockIconStyle { self?.refreshDockControls() }
        }
        displayOptionsObserver = NSWorkspace.shared.notificationCenter.addObserver(
            forName: NSWorkspace.accessibilityDisplayOptionsDidChangeNotification,
            object: nil, queue: .main
        ) { [weak self] _ in self?.refreshAppearanceControls() }
        batteryObserver = NotificationCenter.default.addObserver(
            forName: dependencies.systemBatteryIconDidChange,
            object: nil,
            queue: .main
        ) { [weak self] _ in
            guard let self, !self.batteryMutationInFlight else { return }
            let hidden = self.dependencies.systemBatteryIconHidden()
            self.renderObservedBatteryIcon(hidden)
        }
    }

    private func refreshLoginItem() {
        guard !loginMutationInFlight else { return }
        rememberAuthoritativeLoginState(dependencies.loginItemState())
        loginGeneration += 1
        let generation = loginGeneration
        clearError(loginError)
        renderLoginItem(.checking)
        dependencies.refreshLoginItem { [weak self] state in
            self?.onMain { [weak self] in
                guard let self,
                      generation == self.loginGeneration,
                      !self.loginMutationInFlight else { return }
                self.rememberAuthoritativeLoginState(state)
                self.renderLoginItem(state)
            }
        }
    }

    private func refreshBatteryIcon() {
        guard !batteryMutationInFlight else { return }
        lastAuthoritativeBatteryState = dependencies.systemBatteryIconHidden()
        batteryGeneration += 1
        let generation = batteryGeneration
        clearError(batteryError)
        renderBatteryIconChecking()
        dependencies.refreshSystemBatteryIcon { [weak self] hidden in
            self?.onMain { [weak self] in
                guard let self,
                      generation == self.batteryGeneration,
                      !self.batteryMutationInFlight else { return }
                self.renderObservedBatteryIcon(hidden)
            }
        }
    }

    @objc private func toggleLoginItem(_ sender: NSButton) {
        guard !loginMutationInFlight else { return }
        let restoration = lastAuthoritativeLoginState
            ?? authoritativeLoginState(dependencies.loginItemState())
        guard let restoration else {
            renderLoginItem(.readFailed)
            return
        }
        // `.mixed` is a display-only unknown state, not a third user choice.
        // Invert the last authoritative value so mouse, keyboard, and
        // VoiceOver agree.
        let requested = restoration != .enabled

        loginMutationInFlight = true
        loginGeneration += 1
        clearError(loginError)
        loginButton.isEnabled = false
        loginDetail.stringValue = "Updating…"
        updateAccessibilityHelp(
            for: loginButton,
            purpose: loginAccessibilityPurpose,
            status: loginDetail.stringValue
        )

        dependencies.setLoginItemEnabled(requested) { [weak self] result in
            self?.onMain { [weak self] in
                guard let self else { return }
                self.loginMutationInFlight = false
                switch result {
                case let .success(state):
                    self.rememberAuthoritativeLoginState(state)
                    self.renderLoginItem(state)
                case let .failure(error):
                    let current = self.dependencies.loginItemState()
                    if current == .checking {
                        self.renderLoginItem(restoration)
                    } else {
                        self.rememberAuthoritativeLoginState(current)
                        self.renderLoginItem(current)
                    }
                    self.showError(
                        error.localizedDescription,
                        in: self.loginError,
                        for: self.loginButton,
                        purpose: self.loginAccessibilityPurpose
                    )
                }
            }
        }
    }

    @objc private func toggleBatteryIcon(_ sender: NSButton) {
        guard !batteryMutationInFlight else { return }
        guard let restoration = lastAuthoritativeBatteryState else {
            renderBatteryIcon(nil)
            return
        }
        let requested = !restoration

        batteryMutationInFlight = true
        batteryGeneration += 1
        clearError(batteryError)
        batteryButton.isEnabled = false
        batteryDetail.stringValue = "Updating…"
        updateAccessibilityHelp(
            for: batteryButton,
            purpose: batteryAccessibilityPurpose,
            status: batteryDetail.stringValue
        )

        dependencies.setSystemBatteryIconHidden(requested) { [weak self] succeeded in
            self?.onMain { [weak self] in
                guard let self else { return }
                self.batteryMutationInFlight = false
                self.renderObservedBatteryIcon(self.dependencies.systemBatteryIconHidden())
                if !succeeded {
                    self.showError(
                        "macOS couldn’t update the system battery icon. Try again later.",
                        in: self.batteryError,
                        for: self.batteryButton,
                        purpose: self.batteryAccessibilityPurpose
                    )
                }
            }
        }
    }

    @objc private func checkForUpdates(_ sender: NSButton) {
        if let availableRelease {
            guard dependencies.openUpdateURL(availableRelease.pageURL) else {
                showError(
                    "macOS couldn’t open the GitHub release. Try again later.",
                    in: updateError,
                    for: updateButton,
                    purpose: updateAccessibilityPurpose
                )
                return
            }
            clearError(updateError)
            return
        }
        guard !updateCheckInFlight else { return }

        updateCheckInFlight = true
        clearError(updateError)
        updateButton.isEnabled = false
        updateButton.title = "Checking…"
        updateDetail.stringValue = "Contacting GitHub…"
        updateAccessibilityHelp(
            for: updateButton,
            purpose: updateAccessibilityPurpose,
            status: updateDetail.stringValue
        )

        dependencies.checkForUpdates { [weak self] result in
            self?.onMain { [weak self] in
                guard let self else { return }
                self.updateCheckInFlight = false
                self.updateButton.isEnabled = true
                switch result {
                case let .success(.upToDate(currentVersion)):
                    self.availableRelease = nil
                    self.updateButton.title = "Check Now"
                    self.updateDetail.stringValue =
                        "Wattson \(currentVersion) is up to date"
                    self.clearError(self.updateError)
                    self.updateAccessibilityHelp(
                        for: self.updateButton,
                        purpose: self.updateAccessibilityPurpose,
                        status: self.updateDetail.stringValue
                    )
                    self.dependencies.announceAccessibility(
                        self.updateDetail.stringValue
                    )
                case let .success(.updateAvailable(release)):
                    self.availableRelease = release
                    self.updateButton.title = "View Update"
                    self.updateDetail.stringValue =
                        "Wattson \(release.version) is available"
                    self.clearError(self.updateError)
                    self.updateAccessibilityHelp(
                        for: self.updateButton,
                        purpose: self.updateAccessibilityPurpose,
                        status: self.updateDetail.stringValue
                    )
                    self.dependencies.announceAccessibility(
                        self.updateDetail.stringValue
                    )
                case let .failure(error):
                    self.availableRelease = nil
                    self.updateButton.title = "Try Again"
                    self.renderCurrentVersion()
                    self.showError(
                        error.localizedDescription,
                        in: self.updateError,
                        for: self.updateButton,
                        purpose: self.updateAccessibilityPurpose
                    )
                }
            }
        }
    }

    @objc private func toggleAutomaticUpdates(_ sender: NSButton) {
        Settings.checksForUpdatesOnLaunch = sender.state == .on
        renderAutomaticUpdates()
    }

    private func renderCurrentVersion() {
        updateDetail.stringValue = "Current version \(dependencies.currentVersion())"
        updateAccessibilityHelp(
            for: updateButton,
            purpose: updateAccessibilityPurpose,
            status: updateDetail.stringValue
        )
    }

    private func renderAutomaticUpdates() {
        automaticUpdateButton.state = Settings.checksForUpdatesOnLaunch ? .on : .off
        automaticUpdateButton.isEnabled = true
        automaticUpdateDetail.stringValue = "Check GitHub when Wattson opens"
        updateAccessibilityHelp(
            for: automaticUpdateButton,
            purpose: automaticUpdateAccessibilityPurpose,
            status: automaticUpdateDetail.stringValue
        )
    }

    private func renderLoginItem(_ state: LoginItemState) {
        switch state {
        case .enabled:
            loginNeedsRecovery = false
            loginButton.state = .on
            loginButton.isEnabled = true
            loginDetail.stringValue = "Open Wattson when you sign in"
        case .notRegistered:
            loginNeedsRecovery = false
            loginButton.state = .off
            loginButton.isEnabled = true
            loginDetail.stringValue = "Open Wattson when you sign in"
        case .checking:
            loginButton.state = .mixed
            loginButton.isEnabled = false
            loginDetail.stringValue = "Checking…"
        case .unavailable:
            loginNeedsRecovery = true
            loginButton.state = .mixed
            loginButton.isEnabled = false
            loginDetail.stringValue = "Full installer required"
        case .readFailed:
            loginNeedsRecovery = true
            loginButton.state = .mixed
            loginButton.isEnabled = false
            loginDetail.stringValue = "Status unavailable"
        }
        updateAccessibilityHelp(
            for: loginButton,
            purpose: loginAccessibilityPurpose,
            status: loginDetail.stringValue
        )
        renderControlsRecovery()
    }

    private func renderObservedBatteryIcon(_ hidden: Bool?) {
        switch dependencies.systemBatteryIconReadStatus() {
        case .notRequested, .checking:
            if dependencies.helperAvailable() {
                renderBatteryIconChecking()
                return
            }
        case .failed:
            lastAuthoritativeBatteryState = nil
            clearError(batteryError)
            renderBatteryIcon(nil)
            return
        case .ready: break
        }
        lastAuthoritativeBatteryState = hidden
        clearError(batteryError)
        renderBatteryIcon(hidden)
    }

    private func renderBatteryIconChecking() {
        batteryNeedsRecovery = false
        renderControlsRecovery()
        batteryButton.state = .mixed
        batteryButton.isEnabled = false
        batteryDetail.stringValue = "Checking…"
        updateAccessibilityHelp(
            for: batteryButton,
            purpose: batteryAccessibilityPurpose,
            status: batteryDetail.stringValue
        )
    }

    private func renderBatteryIcon(_ hidden: Bool?) {
        batteryNeedsRecovery = hidden == nil
        renderControlsRecovery()
        guard let hidden else {
            batteryButton.state = .mixed
            batteryButton.isEnabled = false
            batteryDetail.stringValue = dependencies.helperAvailable()
                ? "Status unavailable"
                : "Full installer required"
            updateAccessibilityHelp(
                for: batteryButton,
                purpose: batteryAccessibilityPurpose,
                status: batteryDetail.stringValue
            )
            return
        }
        batteryButton.state = hidden ? .on : .off
        batteryButton.isEnabled = true
        batteryDetail.stringValue = "Reduce duplicate battery indicators"
        updateAccessibilityHelp(
            for: batteryButton,
            purpose: batteryAccessibilityPurpose,
            status: batteryDetail.stringValue
        )
    }

    private func renderControlsRecovery() {
        let helperAvailable = dependencies.helperAvailable()
        controlsRecovery.isHidden = helperAvailable && !loginNeedsRecovery && !batteryNeedsRecovery
        controlsRecoveryButton.title = helperAvailable ? "Repair Controls…" : "Enable Controls…"
        // Keep the optional recovery action in the existing explicit Tab loop
        // only while it is visible; no window rebuild or extra status poll.
        let precedingControl: NSView = Settings.usesLiquidGlass
            ? batteryButton.nativeSwitch : batteryButton
        if controlsRecovery.isHidden {
            if precedingControl.nextKeyView === controlsRecoveryButton {
                precedingControl.nextKeyView = controlsRecoveryButton.nextKeyView
                controlsRecoveryButton.nextKeyView = nil
            }
        } else if precedingControl.nextKeyView !== controlsRecoveryButton {
            controlsRecoveryButton.nextKeyView = precedingControl.nextKeyView
            precedingControl.nextKeyView = controlsRecoveryButton
        }
    }

    @objc private func openControlsInstaller(_ sender: NSButton) {
        guard !controlsRecovery.isHidden else { return }
        guard dependencies.openUpdateURL(Self.controlsInstallerURL) else {
            controlsRecoveryDetail.stringValue =
                "Couldn’t open GitHub. Monitoring is still available. Try again later for the full PKG with system controls and live SMC power."
            dependencies.announceAccessibility(controlsRecoveryDetail.stringValue)
            return
        }
    }

    @objc private func sendFeedback(_ sender: NSButton) {
        guard let window = view.window else { return }
        let panel = NSSavePanel()
        panel.title = "Send Feedback"
        panel.prompt = "Save & Open Issue"
        panel.nameFieldStringValue = FeedbackDiagnostics.filename
        panel.allowedContentTypes = [.plainText]
        panel.message =
            "Save macOS, Mac model, Wattson settings, helper status and battery readings. Review the file before attaching it to a public GitHub issue."
        panel.beginSheetModal(for: window) { [weak self] response in
            guard let self, response == .OK, let destination = panel.url else { return }
            let context = FeedbackDiagnostics.context(
                currentVersion: self.dependencies.currentVersion(),
                displayedSnapshot: self.dependencies.feedbackSnapshot(),
                displayedReadingIsStale: self.dependencies.feedbackReadingIsStale(),
                effectiveAppearance: self.view.effectiveAppearance.name.rawValue
            )
            self.clearError(self.feedbackError)
            self.feedbackButton.isEnabled = false
            self.feedbackDetail.stringValue = "Collecting diagnostics…"
            self.updateAccessibilityHelp(
                for: self.feedbackButton, purpose: self.feedbackAccessibilityPurpose,
                status: self.feedbackDetail.stringValue
            )
            DispatchQueue.global(qos: .utility).async {
                let report = FeedbackDiagnostics.collect(context)
                let result: Result<Void, Error> = Result {
                    try report.text.write(to: destination, atomically: true, encoding: .utf8)
                }
                DispatchQueue.main.async { [weak self] in
                    guard let self else { return }
                    self.feedbackButton.isEnabled = true
                    switch result {
                    case .success:
                        self.feedbackDetail.stringValue = "Report saved; attach it to your GitHub issue"
                        self.updateAccessibilityHelp(
                            for: self.feedbackButton, purpose: self.feedbackAccessibilityPurpose,
                            status: self.feedbackDetail.stringValue
                        )
                        NSWorkspace.shared.activateFileViewerSelecting([destination])
                        if !self.dependencies.openUpdateURL(report.issueURL) {
                            self.showError(
                                "Couldn’t open GitHub. The report is saved.",
                                in: self.feedbackError, for: self.feedbackButton,
                                purpose: self.feedbackAccessibilityPurpose
                            )
                        }
                    case .failure:
                        self.feedbackDetail.stringValue = "Save diagnostics and review a report on GitHub"
                        self.showError(
                            "Couldn’t save the report. Choose another location.",
                            in: self.feedbackError, for: self.feedbackButton,
                            purpose: self.feedbackAccessibilityPurpose
                        )
                    }
                }
            }
        }
    }

    private func rememberAuthoritativeLoginState(_ state: LoginItemState) {
        if let state = authoritativeLoginState(state) {
            lastAuthoritativeLoginState = state
        }
    }

    private func authoritativeLoginState(_ state: LoginItemState) -> LoginItemState? {
        switch state {
        case .enabled, .notRegistered: return state
        case .checking, .unavailable, .readFailed: return nil
        }
    }

    private func clearError(_ label: NSTextField) {
        label.stringValue = ""
        label.isHidden = true
    }

    private func showError(
        _ message: String,
        in label: NSTextField,
        for button: NSButton,
        purpose: String
    ) {
        label.stringValue = message
        label.isHidden = false
        updateAccessibilityHelp(for: button, purpose: purpose, status: message)
        dependencies.announceAccessibility(message)
    }

    private func updateAccessibilityHelp(
        for button: NSButton,
        purpose: String,
        status: String
    ) {
        button.setAccessibilityHelp("\(purpose) \(status)")
    }

    private func onMain(_ operation: @escaping () -> Void) {
        if Thread.isMainThread {
            operation()
        } else {
            DispatchQueue.main.async(execute: operation)
        }
    }
}

private enum MenuBarIconAppearance: Int, CaseIterable {
    case wattsonIconOnly
    case wattsonWithPercentage
    case macOSIconOnly
    case macOSWithPercentage

    var iconStyle: Settings.MenuBarIconStyle {
        switch self {
        case .wattsonIconOnly, .wattsonWithPercentage: return .wattson
        case .macOSIconOnly, .macOSWithPercentage: return .native
        }
    }

    var showsPercentage: Bool {
        switch self {
        case .wattsonIconOnly, .macOSIconOnly: return false
        case .wattsonWithPercentage, .macOSWithPercentage: return true
        }
    }

    var accessibilityLabel: String {
        switch self {
        case .wattsonIconOnly: return "Wattson icon only"
        case .wattsonWithPercentage: return "Wattson with percentage"
        case .macOSIconOnly: return "macOS 26 icon only"
        case .macOSWithPercentage: return "macOS 26 with percentage"
        }
    }

    var visibleTitle: String {
        switch iconStyle {
        case .wattson: return "Wattson"
        case .native: return "macOS 26"
        }
    }

    var visibleDetail: String { showsPercentage ? "With percentage" : "Icon only" }

    var accessibilityHelp: String {
        let artwork = iconStyle == .wattson
            ? "Wattson’s live status battery glyph"
            : "The battery artwork used by the macOS 26 menu bar"
        return showsPercentage
            ? "\(artwork), with the battery percentage on its left."
            : "\(artwork), without a percentage."
    }

    var identifierSuffix: String {
        switch self {
        case .wattsonIconOnly: return "wattson-icon-only"
        case .wattsonWithPercentage: return "wattson-percentage"
        case .macOSIconOnly: return "macos-icon-only"
        case .macOSWithPercentage: return "macos-percentage"
        }
    }

    init(iconStyle: Settings.MenuBarIconStyle, showsPercentage: Bool) {
        switch (iconStyle, showsPercentage) {
        case (.wattson, false): self = .wattsonIconOnly
        case (.wattson, true): self = .wattsonWithPercentage
        case (.native, false): self = .macOSIconOnly
        case (.native, true): self = .macOSWithPercentage
        }
    }
}

private enum MenuBarIconCardKeyCommand {
    case previous
    case next
    case first
    case last
}

enum MenuBarIconPreviewState: CaseIterable {
    case onBattery
    case pluggedFull
    case charging
    case lowBattery
    case lowBatteryPlugged
    case lowPower
    case lowPowerPlugged

    var identifierSuffix: String {
        switch self {
        case .onBattery: return "battery"
        case .pluggedFull: return "full"
        case .charging: return "charging"
        case .lowBattery: return "low"
        case .lowBatteryPlugged: return "low-ac"
        case .lowPower: return "saver"
        case .lowPowerPlugged: return "saver-ac"
        }
    }

    var visibleLabel: String {
        switch self {
        case .onBattery: return "Battery"
        case .pluggedFull: return "Full"
        case .charging: return "Charging"
        case .lowBattery: return "Low"
        case .lowBatteryPlugged: return "Low + AC"
        case .lowPower: return "Saver"
        case .lowPowerPlugged: return "Saver + AC"
        }
    }

    var accessibilityDescription: String {
        switch self {
        case .onBattery: return "75 percent on battery"
        case .pluggedFull: return "100 percent full and connected to power"
        case .charging: return "72 percent charging"
        case .lowBattery: return "10 percent low battery"
        case .lowBatteryPlugged: return "20 percent low battery connected to power"
        case .lowPower: return "42 percent in Low Power Mode"
        case .lowPowerPlugged: return "42 percent in Low Power Mode connected to power"
        }
    }

    var mode: EnergyMode {
        switch self {
        case .lowPower, .lowPowerPlugged: return .low
        default: return .auto
        }
    }

    var fixture: (
        percent: Int,
        plugged: Bool,
        adapterW: Double,
        batteryW: Double,
        systemW: Double,
        lowPowerMode: Bool
    ) {
        switch self {
        case .onBattery:
            return (percent: 75, plugged: false, adapterW: 0, batteryW: -18,
                    systemW: 18, lowPowerMode: false)
        case .pluggedFull:
            return (percent: 100, plugged: true, adapterW: 42, batteryW: 0,
                    systemW: 42, lowPowerMode: false)
        case .charging:
            return (percent: 72, plugged: true, adapterW: 60, batteryW: 18,
                    systemW: 42, lowPowerMode: false)
        case .lowBattery:
            return (percent: 10, plugged: false, adapterW: 0, batteryW: -12,
                    systemW: 12, lowPowerMode: false)
        case .lowBatteryPlugged:
            return (percent: 20, plugged: true, adapterW: 42, batteryW: 0,
                    systemW: 42, lowPowerMode: false)
        case .lowPower:
            return (percent: 42, plugged: false, adapterW: 0, batteryW: -18,
                    systemW: 18, lowPowerMode: true)
        case .lowPowerPlugged:
            return (percent: 42, plugged: true, adapterW: 42, batteryW: 0,
                    systemW: 42, lowPowerMode: true)
        }
    }

    var snapshot: PowerSnapshot {
        let fixture = fixture
        return PowerSnapshot(
            percent: fixture.percent,
            plugged: fixture.plugged,
            adapterW: fixture.adapterW,
            batteryW: fixture.batteryW,
            systemW: fixture.systemW,
            temperatureC: nil,
            cycleCount: 0,
            lowPowerMode: fixture.lowPowerMode
        )
    }
}

private final class MenuBarIconCardButton: NSButton, SettingsContrastRefreshing {
    let menuBarAppearance: MenuBarIconAppearance
    var onKeyboardCommand: ((MenuBarIconCardKeyCommand) -> Void)?

#if DEBUG
    private(set) var drawCountForTest = 0
#endif

    private let increaseContrast: () -> Bool
    private var stateBoxes: [NSBox] = []

    /// Keeps the menu-bar font family and tabular digit spacing at a compact
    /// preview size, leaving safe insets around three-digit percentages.
    private static let previewMenuBarFont: NSFont = {
        let base = NSFont.menuBarFont(ofSize: 11)
        let descriptor = base.fontDescriptor.addingAttributes([
            .featureSettings: [[
                NSFontDescriptor.FeatureKey.typeIdentifier: kNumberSpacingType,
                NSFontDescriptor.FeatureKey.selectorIdentifier:
                    kMonospacedNumbersSelector,
            ]],
        ])
        return NSFont(descriptor: descriptor, size: 11) ?? base
    }()

    init(
        appearance: MenuBarIconAppearance,
        previews: [(state: MenuBarIconPreviewState, image: NSImage)],
        increaseContrast: @escaping () -> Bool
    ) {
        menuBarAppearance = appearance
        self.increaseContrast = increaseContrast
        super.init(frame: .zero)

        let identifierSuffix = appearance.identifierSuffix
        identifier = NSUserInterfaceItemIdentifier(
            "settings.menu-bar-icon.card.\(identifierSuffix)"
        )
        title = ""
        isBordered = false
        bezelStyle = .regularSquare
        imagePosition = .noImage
        focusRingType = .none
        setButtonType(.radio)
        setAccessibilityRole(.radioButton)
        setAccessibilityLabel(appearance.accessibilityLabel)
        let stateDescriptions = previews.map(\.state.accessibilityDescription).joined(
            separator: ", "
        )
        setAccessibilityHelp("\(appearance.accessibilityHelp) Previews: \(stateDescriptions).")

        let stateViews = previews.map { preview -> NSView in
            let stateSuffix = "\(identifierSuffix).\(preview.state.identifierSuffix)"

            let stateBox = NSBox()
            stateBox.identifier = NSUserInterfaceItemIdentifier(
                "settings.menu-bar-icon.state.\(stateSuffix)"
            )
            let increased = increaseContrast()
            stateBox.boxType = .custom
            stateBox.titlePosition = .noTitle
            stateBox.cornerRadius = SettingsStyle.iconStateCornerRadius
            stateBox.borderWidth = increased ? 2 : 1
            stateBox.borderColor = increased
                ? SettingsStyle.increasedContrastBorder
                : SettingsStyle.surfaceBorder
            stateBox.fillColor = SettingsStyle.previewBackground
            stateBox.setAccessibilityElement(false)
            stateBox.translatesAutoresizingMaskIntoConstraints = false
            stateBoxes.append(stateBox)

            let stateLabel = NSTextField(labelWithString: preview.state.visibleLabel)
            stateLabel.identifier = NSUserInterfaceItemIdentifier(
                "settings.menu-bar-icon.state-label.\(stateSuffix)"
            )
            stateLabel.font = .systemFont(ofSize: 9, weight: .medium)
            stateLabel.textColor = SettingsStyle.secondaryText
            stateLabel.alignment = .center
            stateLabel.lineBreakMode = .byClipping
            stateLabel.maximumNumberOfLines = 1
            stateLabel.setAccessibilityElement(false)
            stateLabel.translatesAutoresizingMaskIntoConstraints = false

            let imageView = NSImageView()
            imageView.identifier = NSUserInterfaceItemIdentifier(
                "settings.menu-bar-icon.preview.\(stateSuffix)"
            )
            imageView.image = preview.image
            imageView.imageScaling = .scaleProportionallyUpOrDown
            imageView.contentTintColor = .labelColor
            imageView.setAccessibilityElement(false)
            imageView.translatesAutoresizingMaskIntoConstraints = false

            var presentationViews: [NSView] = []
            if appearance.showsPercentage {
                let percentage = NSTextField(
                    labelWithString: "\(preview.state.fixture.percent)%"
                )
                percentage.identifier = NSUserInterfaceItemIdentifier(
                    "settings.menu-bar-icon.percentage.\(stateSuffix)"
                )
                percentage.font = Self.previewMenuBarFont
                percentage.textColor = .labelColor
                percentage.lineBreakMode = .byClipping
                percentage.setAccessibilityElement(false)
                presentationViews.append(percentage)
            }
            presentationViews.append(imageView)
            let presentation = NSStackView(views: presentationViews)
            presentation.orientation = .horizontal
            presentation.alignment = .centerY
            presentation.distribution = .fill
            presentation.spacing = 2
            presentation.setAccessibilityElement(false)
            presentation.translatesAutoresizingMaskIntoConstraints = false

            stateBox.addSubview(stateLabel)
            stateBox.addSubview(presentation)
            NSLayoutConstraint.activate([
                stateLabel.leadingAnchor.constraint(equalTo: stateBox.leadingAnchor, constant: 2),
                stateLabel.trailingAnchor.constraint(equalTo: stateBox.trailingAnchor, constant: -2),
                stateLabel.topAnchor.constraint(equalTo: stateBox.topAnchor, constant: 3),

                presentation.centerXAnchor.constraint(equalTo: stateBox.centerXAnchor),
                presentation.bottomAnchor.constraint(equalTo: stateBox.bottomAnchor, constant: -3),
                imageView.widthAnchor.constraint(equalToConstant: preview.image.size.width),
                imageView.heightAnchor.constraint(equalToConstant: preview.image.size.height),
                stateLabel.bottomAnchor.constraint(
                    lessThanOrEqualTo: presentation.topAnchor,
                    constant: -1
                ),
            ])
            return stateBox
        }
        let stateRow = NSStackView(views: stateViews)
        stateRow.orientation = .horizontal
        stateRow.alignment = .height
        stateRow.distribution = .fillEqually
        stateRow.spacing = SettingsStyle.iconStateGap
        stateRow.setAccessibilityElement(false)
        stateRow.translatesAutoresizingMaskIntoConstraints = false

        let primary = NSTextField(labelWithString: appearance.visibleTitle)
        primary.identifier = NSUserInterfaceItemIdentifier(
            "settings.menu-bar-icon.title.\(identifierSuffix)"
        )
        primary.font = .systemFont(ofSize: 12, weight: .medium)
        primary.textColor = SettingsStyle.primaryText
        primary.alignment = .left
        primary.lineBreakMode = .byClipping
        primary.setAccessibilityElement(false)
        primary.translatesAutoresizingMaskIntoConstraints = false

        let secondary = NSTextField(labelWithString: appearance.visibleDetail)
        secondary.identifier = NSUserInterfaceItemIdentifier(
            "settings.menu-bar-icon.detail.\(identifierSuffix)"
        )
        secondary.setAccessibilityIdentifier(
            "settings.menu-bar-icon.detail.\(identifierSuffix)"
        )
        secondary.font = SettingsStyle.detailFont
        secondary.textColor = SettingsStyle.secondaryText
        secondary.alignment = .left
        secondary.lineBreakMode = .byClipping
        secondary.maximumNumberOfLines = 1
        secondary.setAccessibilityElement(false)
        secondary.translatesAutoresizingMaskIntoConstraints = false

        addSubview(primary)
        addSubview(secondary)
        addSubview(stateRow)
        NSLayoutConstraint.activate([
            primary.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 12),
            primary.topAnchor.constraint(equalTo: topAnchor, constant: 8),

            secondary.leadingAnchor.constraint(equalTo: primary.trailingAnchor, constant: 8),
            secondary.firstBaselineAnchor.constraint(equalTo: primary.firstBaselineAnchor),
            secondary.trailingAnchor.constraint(lessThanOrEqualTo: trailingAnchor, constant: -44),

            stateRow.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 12),
            stateRow.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -12),
            stateRow.bottomAnchor.constraint(equalTo: bottomAnchor, constant: -8),
            stateRow.heightAnchor.constraint(equalToConstant: SettingsStyle.iconStateHeight),
        ])
    }

    @available(*, unavailable)
    required init?(coder: NSCoder) {
        fatalError("init(coder:) is unavailable")
    }

    override var acceptsFirstResponder: Bool { true }

    override func becomeFirstResponder() -> Bool {
        let becameFirstResponder = super.becomeFirstResponder()
        if becameFirstResponder {
            DispatchQueue.main.async { [weak self] in
                self?.needsDisplay = true
            }
        }
        return becameFirstResponder
    }

    override func resignFirstResponder() -> Bool {
        let resignedFirstResponder = super.resignFirstResponder()
        if resignedFirstResponder {
            DispatchQueue.main.async { [weak self] in
                self?.needsDisplay = true
            }
        }
        return resignedFirstResponder
    }

    override func accessibilityValue() -> Any? {
        NSNumber(value: state == .on)
    }

    var cardFillColor: NSColor {
        guard state == .on else { return SettingsStyle.surfaceBackground }
        return increaseContrast()
            ? SettingsStyle.increasedContrastSelection
            : SettingsStyle.selection
    }

    var cardBorderColor: NSColor {
        if state == .on {
            return increaseContrast()
                ? SettingsStyle.increasedContrastSelectionBorder
                : SettingsStyle.green
        }
        return increaseContrast()
            ? SettingsStyle.increasedContrastBorder
            : SettingsStyle.surfaceBorder
    }

    var cardBorderWidth: CGFloat {
        if state == .on { return increaseContrast() ? 3 : 2 }
        return increaseContrast() ? 2 : 1
    }

    func refreshContrastAppearance() {
        let increased = increaseContrast()
        stateBoxes.forEach {
            $0.borderWidth = increased ? 2 : 1
            $0.borderColor = increased
                ? SettingsStyle.increasedContrastBorder
                : SettingsStyle.surfaceBorder
        }
        needsDisplay = true
    }

    override func viewDidChangeEffectiveAppearance() {
        super.viewDidChangeEffectiveAppearance()
        needsDisplay = true
    }

    override func hitTest(_ point: NSPoint) -> NSView? {
        guard !isHidden, frame.contains(point) else { return nil }
        return self
    }

    override func keyDown(with event: NSEvent) {
        switch event.keyCode {
        case 123, 126:
            onKeyboardCommand?(.previous)
        case 124, 125:
            onKeyboardCommand?(.next)
        case 115:
            onKeyboardCommand?(.first)
        case 119:
            onKeyboardCommand?(.last)
        case 49:
            performClick(nil)
        default:
            super.keyDown(with: event)
        }
    }

    override func draw(_ dirtyRect: NSRect) {
#if DEBUG
        drawCountForTest += 1
#endif
        let inset = max(cardBorderWidth / 2, 1)
        let card = NSBezierPath(
            roundedRect: bounds.insetBy(dx: inset, dy: inset),
            xRadius: SettingsStyle.surfaceCornerRadius,
            yRadius: SettingsStyle.surfaceCornerRadius
        )
        cardFillColor.setFill()
        card.fill()
        cardBorderColor.setStroke()
        card.lineWidth = cardBorderWidth
        card.stroke()

        let radioY = isFlipped ? 15 : bounds.maxY - 29
        let radioRect = NSRect(
            x: bounds.maxX - 29,
            y: radioY,
            width: 14,
            height: 14
        )
        let radio = NSBezierPath(ovalIn: radioRect)
        let radioColor = state == .on ? SettingsStyle.green : SettingsStyle.secondaryText
        radioColor.setStroke()
        radio.lineWidth = state == .on ? 2 : 1.5
        radio.stroke()
        if state == .on {
            radioColor.setFill()
            NSBezierPath(ovalIn: radioRect.insetBy(dx: 4, dy: 4)).fill()
        }

        if window?.firstResponder === self {
            NSColor.keyboardFocusIndicatorColor.setStroke()
            let focus = NSBezierPath(
                roundedRect: bounds.insetBy(dx: 4, dy: 4),
                xRadius: SettingsStyle.surfaceCornerRadius - 2,
                yRadius: SettingsStyle.surfaceCornerRadius - 2
            )
            focus.lineWidth = 2
            focus.stroke()
        }
    }
}

private final class MenuBarIconSettingsSectionController: NSObject,
    SettingsSectionController
{
    let identifier = "menu-bar-icon"
    let title = "Display"
    let sidebarIcon: ModuleIconArtwork.SidebarIcon = .display
    let view = NSView()

    private let increaseContrast: () -> Bool
    private var buttons: [MenuBarIconAppearance: MenuBarIconCardButton] = [:]
    private var settingsObserver: NSObjectProtocol?

    init(increaseContrast: @escaping () -> Bool) {
        self.increaseContrast = increaseContrast
        super.init()
        buildView()
        installObserver()
        refreshSelection()
    }

    deinit {
        if let settingsObserver {
            NotificationCenter.default.removeObserver(settingsObserver)
        }
    }

    func refresh() {
        guard Thread.isMainThread else {
            DispatchQueue.main.async { [weak self] in self?.refresh() }
            return
        }
        refreshSelection()
    }

    private func buildView() {
        view.identifier = NSUserInterfaceItemIdentifier("settings.section.menu-bar-icon")

        let heading = SettingsPageHeading(labelWithString: title)
        heading.identifier = NSUserInterfaceItemIdentifier("settings.menu-bar-icon.heading")
        heading.font = SettingsStyle.headingFont
        heading.textColor = SettingsStyle.headingText
        heading.setAccessibilityLabel(title)
        heading.translatesAutoresizingMaskIntoConstraints = false

        let subtitle = NSTextField(
            labelWithString: "Choose how Wattson appears in the menu bar."
        )
        subtitle.identifier = NSUserInterfaceItemIdentifier("settings.menu-bar-icon.subtitle")
        subtitle.font = SettingsStyle.detailFont
        subtitle.textColor = SettingsStyle.secondaryText
        subtitle.translatesAutoresizingMaskIntoConstraints = false

        let orderedButtons = MenuBarIconAppearance.allCases.map { appearance in
            let previews = MenuBarIconPreviewState.allCases.map { previewState in
                let snapshot = previewState.snapshot
                let image = BatteryIcon.image(
                    for: snapshot,
                    mode: previewState.mode,
                    pressed: false,
                    style: appearance.iconStyle
                )
                return (state: previewState, image: image)
            }
            let button = MenuBarIconCardButton(
                appearance: appearance,
                previews: previews,
                increaseContrast: increaseContrast
            )
            button.target = self
            button.action = #selector(selectAppearance(_:))
            button.onKeyboardCommand = { [weak self] command in
                self?.handleKeyboard(command, from: appearance)
            }
            button.translatesAutoresizingMaskIntoConstraints = false
            buttons[appearance] = button
            return button
        }

        let group = NSStackView(views: orderedButtons)
        group.identifier = NSUserInterfaceItemIdentifier("settings.menu-bar-icon.group")
        group.orientation = .vertical
        group.alignment = .leading
        group.distribution = .fillEqually
        group.spacing = SettingsStyle.iconCardGap
        group.setAccessibilityElement(true)
        group.setAccessibilityRole(.radioGroup)
        group.setAccessibilityLabel(title)
        group.setAccessibilityHelp(
            "Choose a complete Wattson or macOS menu-bar battery presentation."
        )
        group.setAccessibilityChildren(orderedButtons)
        group.translatesAutoresizingMaskIntoConstraints = false
        let surface = SettingsGlassSurface(controls: group)
        let contentTop = subtitle.topAnchor.constraint(equalTo: heading.bottomAnchor, constant: 8)
        heading.titleSpace = heading.intrinsicContentSize.height + 5
        heading.contentTopConstraint = contentTop

        view.addSubview(heading)
        view.addSubview(subtitle)
        view.addSubview(surface)
        NSLayoutConstraint.activate([
            heading.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 2),
            heading.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            heading.topAnchor.constraint(equalTo: view.topAnchor, constant: -3),

            subtitle.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 2),
            subtitle.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            contentTop,

            surface.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            surface.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            surface.topAnchor.constraint(equalTo: subtitle.bottomAnchor, constant: 14),
            surface.heightAnchor.constraint(equalToConstant: SettingsStyle.iconCardGroupHeight),
        ])
        orderedButtons.forEach {
            $0.widthAnchor.constraint(equalTo: group.widthAnchor).isActive = true
            $0.heightAnchor.constraint(
                equalToConstant: SettingsStyle.iconCardHeight
            ).isActive = true
        }
    }

    private func installObserver() {
        settingsObserver = NotificationCenter.default.addObserver(
            forName: Settings.didChange,
            object: nil,
            queue: .main
        ) { [weak self] notification in
            guard let self else { return }
            guard let change = notification.userInfo?[Settings.changeUserInfoKey]
                    as? Settings.Change else {
                self.refreshSelection()
                return
            }
            switch change {
            case .menuBarIconStyle, .menuBarPercentage:
                self.refreshSelection()
            case .checkForUpdatesOnLaunch, .module, .moduleOrder, .liquidGlassAppearance, .liquidGlassTransparency, .popoverArrow, .colorScheme, .inAppLogoStyle, .dockIconStyle:
                break
            }
        }
    }

    private func refreshSelection() {
        let selected = MenuBarIconAppearance(
            iconStyle: Settings.menuBarIconStyle,
            showsPercentage: Settings.showsMenuBarPercentage
        )
        for (appearance, button) in buttons {
            button.state = appearance == selected ? .on : .off
            button.needsDisplay = true
        }
    }

    @objc private func selectAppearance(_ sender: MenuBarIconCardButton) {
        select(sender.menuBarAppearance, movingFocus: false)
    }

    private func handleKeyboard(
        _ command: MenuBarIconCardKeyCommand,
        from current: MenuBarIconAppearance
    ) {
        let appearances = MenuBarIconAppearance.allCases
        guard let currentIndex = appearances.firstIndex(of: current) else { return }
        let targetIndex: Int
        switch command {
        case .previous:
            targetIndex = (currentIndex - 1 + appearances.count) % appearances.count
        case .next:
            targetIndex = (currentIndex + 1) % appearances.count
        case .first:
            targetIndex = appearances.startIndex
        case .last:
            targetIndex = appearances.index(before: appearances.endIndex)
        }
        select(appearances[targetIndex], movingFocus: true)
    }

    private func select(
        _ appearance: MenuBarIconAppearance,
        movingFocus: Bool
    ) {
        Settings.setMenuBarAppearance(
            iconStyle: appearance.iconStyle,
            showsPercentage: appearance.showsPercentage
        )
        refreshSelection()
        if movingFocus, let button = buttons[appearance] {
            button.window?.makeFirstResponder(button)
        }
    }
}

private final class ModuleSettingsIconView: NSImageView, SettingsContrastRefreshing {
    private let module: Settings.Module
    private let increaseContrast: () -> Bool

    init(module: Settings.Module, increaseContrast: @escaping () -> Bool) {
        self.module = module
        self.increaseContrast = increaseContrast
        super.init(frame: .zero)
        isEditable = false
        allowsCutCopyPaste = false
        refreshContrastAppearance()
    }

    @available(*, unavailable)
    required init?(coder: NSCoder) { fatalError("init(coder:) is unavailable") }

    override func viewDidChangeEffectiveAppearance() {
        super.viewDidChangeEffectiveAppearance()
        refreshContrastAppearance()
    }

    func refreshContrastAppearance() {
        effectiveAppearance.performAsCurrentDrawingAppearance {
            let ink = SettingsStyle.primaryText.usingColorSpace(.sRGB)
                ?? SettingsStyle.primaryText
            let blue = NSColor.systemBlue.usingColorSpace(.sRGB) ?? .systemBlue
            image = ModuleIconArtwork.image(for: module, side: SettingsStyle.rowSymbolSize,
                                            ink: ink, accent: blue,
                                            increasedContrast: increaseContrast())
            contentTintColor = nil
        }
    }
}

private final class ModuleReorderHandle: NSButton, SettingsContrastRefreshing {
    let module: Settings.Module
    weak var reorderList: ModuleReorderList?
    private let increaseContrast: () -> Bool
    private var pressEvent: NSEvent?
    private var keyboardFocusVisible = false
#if DEBUG
    var dragStartObserverForTest: ((NSEvent) -> Void)?
#endif

    init(module: Settings.Module, increaseContrast: @escaping () -> Bool) {
        self.module = module
        self.increaseContrast = increaseContrast
        super.init(frame: .zero)
        identifier = NSUserInterfaceItemIdentifier("settings.modules.reorder.\(module.rawValue)")
        title = ""
        isBordered = false
        focusRingType = .none
        imagePosition = .imageOnly
        image = NSImage(systemSymbolName: "line.3.horizontal", accessibilityDescription: nil)?
            .withSymbolConfiguration(.init(pointSize: 12, weight: .regular))
        target = self
        action = #selector(showMoveMenu(_:))
        translatesAutoresizingMaskIntoConstraints = false
        setAccessibilityLabel("Reorder \(module.title)")
        setAccessibilityHelp("Drag to change the module order, or use the Up and Down arrow keys.")
        toolTip = "Drag to reorder"
        refreshContrastAppearance()
    }

    @available(*, unavailable)
    required init?(coder: NSCoder) { fatalError("init(coder:) is unavailable") }

    override var acceptsFirstResponder: Bool { true }
    override var mouseDownCanMoveWindow: Bool { false }

    override func mouseDown(with event: NSEvent) {
        guard isEnabled else { return }
        window?.makeFirstResponder(self)
        keyboardFocusVisible = false
        needsDisplay = true
        pressEvent = event
    }

    override func mouseDragged(with event: NSEvent) {
        guard let mouseDown = pressEvent else { return }
        let start = mouseDown.locationInWindow
        guard hypot(event.locationInWindow.x - start.x, event.locationInWindow.y - start.y) >= 4 else { return }
        pressEvent = nil
#if DEBUG
        if let dragStartObserverForTest {
            dragStartObserverForTest(mouseDown)
            return
        }
#endif
        // AppKit requires the original mouse-down event, including its location.
        reorderList?.beginReordering(module, event: mouseDown)
    }

    override func mouseUp(with event: NSEvent) {
        let wasPressed = pressEvent != nil
        pressEvent = nil
        if wasPressed && window?.isVisible == true && bounds.contains(convert(event.locationInWindow, from: nil)) {
            performClick(nil)
        }
    }

    override func viewWillMove(toWindow newWindow: NSWindow?) {
        pressEvent = nil
        super.viewWillMove(toWindow: newWindow)
    }

    override func keyDown(with event: NSEvent) {
        keyboardFocusVisible = true
        needsDisplay = true
        switch event.keyCode {
        case 126: _ = reorderList?.move(module, by: -1)
        case 125: _ = reorderList?.move(module, by: 1)
        default: super.keyDown(with: event)
        }
    }

    func refreshPosition(_ index: Int, count: Int) {
        setAccessibilityValueDescription("\(index + 1) of \(count)")
        var actions: [NSAccessibilityCustomAction] = []
        if index > 0 {
            actions.append(NSAccessibilityCustomAction(name: "Move Up") { [weak self] in
                guard let self else { return false }
                return self.reorderList?.move(self.module, by: -1) ?? false
            })
        }
        if index + 1 < count {
            actions.append(NSAccessibilityCustomAction(name: "Move Down") { [weak self] in
                guard let self else { return false }
                return self.reorderList?.move(self.module, by: 1) ?? false
            })
        }
        setAccessibilityCustomActions(actions)
    }

    @objc private func showMoveMenu(_ sender: NSButton) {
        guard let index = Settings.moduleOrder.firstIndex(of: module) else { return }
        let menu = NSMenu(title: "Reorder \(module.title)")
        menu.autoenablesItems = false
        for (title, delta) in [("Move Up", -1), ("Move Down", 1)] {
            let item = NSMenuItem(title: title, action: #selector(moveFromMenu(_:)), keyEquivalent: "")
            item.target = self
            item.tag = delta
            item.isEnabled = Settings.moduleOrder.indices.contains(index + delta)
            menu.addItem(item)
        }
        menu.popUp(positioning: nil, at: NSPoint(x: bounds.maxX, y: bounds.minY), in: self)
    }

    @objc private func moveFromMenu(_ sender: NSMenuItem) { _ = reorderList?.move(module, by: sender.tag) }

    func refreshContrastAppearance() {
        contentTintColor = increaseContrast() ? SettingsStyle.primaryText : SettingsStyle.secondaryText.withAlphaComponent(0.65)
        needsDisplay = true
    }

    override func becomeFirstResponder() -> Bool {
        let accepted = super.becomeFirstResponder()
        if accepted { keyboardFocusVisible = true }
        needsDisplay = true
        return accepted
    }

    override func resignFirstResponder() -> Bool {
        let accepted = super.resignFirstResponder()
        if accepted { keyboardFocusVisible = false }
        needsDisplay = true
        return accepted
    }

    var showsKeyboardFocus: Bool { keyboardFocusVisible && window?.firstResponder === self }

    override func draw(_ dirtyRect: NSRect) {
        super.draw(dirtyRect)
        if showsKeyboardFocus {
            NSColor.keyboardFocusIndicatorColor.setStroke()
            let outline = NSBezierPath(roundedRect: bounds.insetBy(dx: 1, dy: 1), xRadius: 5, yRadius: 5)
            outline.lineWidth = 2
            outline.stroke()
        }
    }
}

/// The system owns drag tracking and cancellation. Only a successful local drop
/// changes Settings; the retained rows may move temporarily to preview the gap.
private final class ModuleReorderList: NSStackView, NSDraggingSource, SettingsContrastRefreshing {
    private static let dragType = NSPasteboard.PasteboardType("com.leoarrow.wattson.module-order")
    var rows: [Settings.Module: NSView] = [:]
    var orderDidChange: (() -> Void)?
    private var draggedModule: Settings.Module?
    private var originalOrder: [Settings.Module] = []
    private weak var dragSession: NSDraggingSession?
    private let insertionLine = NSBox()
    private var windowObservers: [NSObjectProtocol] = []
#if DEBUG
    var pressedMouseButtonsForTest: (() -> Int)?
    var nativeDragStartObserverForTest: ((NSEvent) -> Void)?
    var dragStateIsClearForTest: Bool {
        draggedModule == nil && originalOrder.isEmpty && dragSession == nil && insertionLine.isHidden
    }
#endif

    init() {
        super.init(frame: .zero)
        orientation = .vertical
        alignment = .width
        distribution = .fillEqually
        spacing = 0
        wantsLayer = true
        translatesAutoresizingMaskIntoConstraints = false
        registerForDraggedTypes([Self.dragType])
        insertionLine.boxType = .custom
        insertionLine.borderWidth = 0
        insertionLine.fillColor = .separatorColor
        insertionLine.isHidden = true
        insertionLine.setAccessibilityElement(false)
        addSubview(insertionLine)
    }

    @available(*, unavailable)
    required init?(coder: NSCoder) { fatalError("init(coder:) is unavailable") }

    deinit { windowObservers.forEach(NotificationCenter.default.removeObserver) }

    var displayedOrder: [Settings.Module] {
        arrangedSubviews.compactMap { row in rows.first { $0.value === row }?.key }
    }

    private var reducesMotion: Bool {
#if DEBUG
        if let value = ProcessInfo.processInfo.environment["WATTSON_FORCE_REDUCE_MOTION"] { return value == "1" }
#endif
        return NSWorkspace.shared.accessibilityDisplayShouldReduceMotion
    }

    func applySavedOrder() {
        cancelReordering()
        arrange(Settings.moduleOrder, animated: false)
    }

    private func arrange(_ order: [Settings.Module], animated: Bool) {
        guard order != displayedOrder else { return }
        layoutSubtreeIfNeeded()
        NSAnimationContext.runAnimationGroup { context in
            context.duration = animated && !reducesMotion ? 0.14 : 0
            context.allowsImplicitAnimation = animated && !reducesMotion
            for (index, module) in order.enumerated() {
                if let row = rows[module] { insertArrangedSubview(row, at: index) }
            }
            layoutSubtreeIfNeeded()
        }
        addSubview(insertionLine, positioned: .above, relativeTo: nil)
        setAccessibilityChildrenInNavigationOrder(arrangedSubviews)
        orderDidChange?()
    }

    private var leftMouseButtonIsDown: Bool {
#if DEBUG
        if let pressedMouseButtonsForTest { return pressedMouseButtonsForTest() & 1 != 0 }
#endif
        return NSEvent.pressedMouseButtons & 1 != 0
    }

    func beginReordering(_ module: Settings.Module, event: NSEvent) {
        guard leftMouseButtonIsDown, draggedModule == nil, window?.isVisible == true, let row = rows[module],
              let bitmap = row.bitmapImageRepForCachingDisplay(in: row.bounds) else { return }
        row.cacheDisplay(in: row.bounds, to: bitmap)
        let image = NSImage(size: row.bounds.size)
        image.addRepresentation(bitmap)
        let pasteboardItem = NSPasteboardItem()
        pasteboardItem.setString(module.rawValue, forType: Self.dragType)
        let item = NSDraggingItem(pasteboardWriter: pasteboardItem)
        item.setDraggingFrame(row.frame.offsetBy(dx: 0, dy: reducesMotion ? 0 : 2), contents: image)
        // A queued drag event can arrive after release, including while the
        // row snapshot is being prepared. Do not start a session in that case.
        guard leftMouseButtonIsDown else { return }
#if DEBUG
        if let nativeDragStartObserverForTest {
            nativeDragStartObserverForTest(event)
            return
        }
#endif
        originalOrder = Settings.moduleOrder
        draggedModule = module
        let session = beginDraggingSession(with: [item], event: event, source: self)
        session.animatesToStartingPositionsOnCancelOrFail = !reducesMotion
        dragSession = session
    }

    func draggingSession(_ session: NSDraggingSession, sourceOperationMaskFor context: NSDraggingContext) -> NSDragOperation {
        context == .withinApplication && draggedModule != nil ? .move : []
    }

    func ignoreModifierKeys(for session: NSDraggingSession) -> Bool { true }

    func draggingSession(_ session: NSDraggingSession, willBeginAt screenPoint: NSPoint) {
        if let module = draggedModule { rows[module]?.alphaValue = 0.25 }
    }

    func draggingSession(_ session: NSDraggingSession, endedAt screenPoint: NSPoint, operation: NSDragOperation) {
        cancelReordering()
    }

    private func accepts(_ sender: NSDraggingInfo) -> Bool {
        guard (sender.draggingSource as AnyObject?) === self, let module = draggedModule,
              sender.draggingPasteboard.pasteboardItems?.count == 1,
              sender.draggingPasteboard.string(forType: Self.dragType) == module.rawValue,
              originalOrder == Settings.moduleOrder, window?.isVisible == true,
              window?.isMiniaturized == false else { return false }
        return bounds.contains(convert(sender.draggingLocation, from: nil))
    }

    override func draggingEntered(_ sender: NSDraggingInfo) -> NSDragOperation { draggingUpdated(sender) }

    override func draggingUpdated(_ sender: NSDraggingInfo) -> NSDragOperation {
        guard accepts(sender), let module = draggedModule else { return [] }
        let point = convert(sender.draggingLocation, from: nil)
        var proposed = displayedOrder.filter { $0 != module }
        let index = proposed.filter { other in
            guard let row = rows[other] else { return false }
            return isFlipped ? point.y > row.frame.midY : point.y < row.frame.midY
        }.count
        proposed.insert(module, at: index)
        arrange(proposed, animated: true)
        insertionLine.isHidden = false
        updateInsertionLine()
        return .move
    }

    override func wantsPeriodicDraggingUpdates() -> Bool { false }

    override func draggingExited(_ sender: NSDraggingInfo?) {
        guard draggedModule != nil else { return }
        insertionLine.isHidden = true
        arrange(originalOrder, animated: !reducesMotion)
    }

    override func prepareForDragOperation(_ sender: NSDraggingInfo) -> Bool { accepts(sender) }

    override func performDragOperation(_ sender: NSDraggingInfo) -> Bool {
        guard accepts(sender), draggingUpdated(sender) == .move else { return false }
        let order = displayedOrder
        clearDragFeedback()
        if order != Settings.moduleOrder {
            Settings.moduleOrder = order
            NSAccessibility.post(element: self, notification: .layoutChanged)
        }
        return true
    }

    private func clearDragFeedback() {
        draggedModule = nil
        originalOrder = []
        dragSession = nil
        insertionLine.isHidden = true
        rows.values.forEach { $0.alphaValue = 1; $0.layer?.removeAllAnimations() }
    }

    func cancelReordering() {
        let wasDragging = draggedModule != nil
        dragSession?.animatesToStartingPositionsOnCancelOrFail = !reducesMotion
        clearDragFeedback()
        if wasDragging { arrange(Settings.moduleOrder, animated: false) }
    }

    override func layout() { super.layout(); updateInsertionLine() }

    private func updateInsertionLine() {
        guard !insertionLine.isHidden, let module = draggedModule, let row = rows[module] else { return }
        let y = isFlipped ? row.frame.minY : row.frame.maxY - 1
        insertionLine.frame = NSRect(x: 56, y: y, width: max(0, bounds.width - 72), height: 1)
    }

    override func viewWillMove(toWindow newWindow: NSWindow?) {
        if newWindow !== window { cancelReordering() }
        super.viewWillMove(toWindow: newWindow)
    }

    override func viewDidMoveToWindow() {
        super.viewDidMoveToWindow()
        windowObservers.forEach(NotificationCenter.default.removeObserver)
        windowObservers.removeAll()
        guard let window else { return }
        for name in [NSWindow.willCloseNotification, NSWindow.didMiniaturizeNotification, NSWindow.didResignKeyNotification] {
            windowObservers.append(NotificationCenter.default.addObserver(forName: name, object: nil, queue: .main) { [weak self, weak window] notification in
                guard let window, notification.object as? NSWindow === window else { return }
                self?.cancelReordering()
            })
        }
    }

    override func viewDidHide() { super.viewDidHide(); cancelReordering() }

    func refreshContrastAppearance() {
        if reducesMotion { rows.values.forEach { $0.layer?.removeAllAnimations() } }
        dragSession?.animatesToStartingPositionsOnCancelOrFail = !reducesMotion
        insertionLine.fillColor = NSWorkspace.shared.accessibilityDisplayShouldIncreaseContrast ? .labelColor : .separatorColor
    }

    @discardableResult func move(_ module: Settings.Module, by delta: Int) -> Bool {
        guard draggedModule == nil, window != nil, let index = Settings.moduleOrder.firstIndex(of: module),
              Settings.moduleOrder.indices.contains(index + delta) else { return false }
        var order = Settings.moduleOrder
        order.remove(at: index)
        order.insert(module, at: index + delta)
        Settings.moduleOrder = order
        NSAccessibility.post(element: self, notification: .layoutChanged)
        return true
    }
}

private final class ModuleSettingsSectionController: NSObject, SettingsSectionController {
    let identifier = "modules"
    let title = "Modules"
    let sidebarIcon: ModuleIconArtwork.SidebarIcon = .modules
    let view = NSView()

    private let increaseContrast: () -> Bool
    private var buttons: [Settings.Module: NSButton] = [:]
    private var handles: [Settings.Module: ModuleReorderHandle] = [:]
    private var separators: [Settings.Module: NSBox] = [:]
    private let rows = ModuleReorderList()
    var orderDidChange: (() -> Void)?
    private var settingsObserver: NSObjectProtocol?

    init(increaseContrast: @escaping () -> Bool) {
        self.increaseContrast = increaseContrast
        super.init()
        buildView()
        installObserver()
    }

    deinit {
        if let settingsObserver {
            NotificationCenter.default.removeObserver(settingsObserver)
        }
    }

    func refresh() {
        guard Thread.isMainThread else {
            DispatchQueue.main.async { [weak self] in self?.refresh() }
            return
        }
        for module in Settings.Module.allCases { refresh(module) }
        rows.applySavedOrder()
    }

    private func buildView() {
        view.identifier = NSUserInterfaceItemIdentifier("settings.section.modules")

        let heading = SettingsPageHeading(labelWithString: title)
        heading.identifier = NSUserInterfaceItemIdentifier("settings.modules.heading")
        heading.font = SettingsStyle.headingFont
        heading.textColor = SettingsStyle.headingText
        heading.setAccessibilityLabel(title)
        heading.translatesAutoresizingMaskIntoConstraints = false

        let subtitle = NSTextField(labelWithString: "Choose what appears in the power popover.")
        subtitle.identifier = NSUserInterfaceItemIdentifier("settings.modules.subtitle")
        subtitle.font = SettingsStyle.detailFont
        subtitle.textColor = SettingsStyle.secondaryText
        subtitle.translatesAutoresizingMaskIntoConstraints = false

        let restoreOrder = NSButton(title: "Restore Default Order", target: self,
                                    action: #selector(restoreDefaultOrder(_:)))
        restoreOrder.identifier = NSUserInterfaceItemIdentifier("settings.modules.restore-default-order")
        restoreOrder.setAccessibilityIdentifier("settings.modules.restore-default-order")
        restoreOrder.setAccessibilityLabel("Restore Default Order")
        restoreOrder.setAccessibilityHelp("Restore the original module order without changing which modules are shown.")
        restoreOrder.bezelStyle = .rounded
        restoreOrder.controlSize = .small
        restoreOrder.font = .systemFont(ofSize: NSFont.smallSystemFontSize)
        restoreOrder.translatesAutoresizingMaskIntoConstraints = false

        for (index, module) in Settings.Module.allCases.enumerated() {
            rows.rows[module] = makeRow(for: module, index: index)
        }
        rows.orderDidChange = { [weak self] in
            self?.refreshRowOrder()
            self?.orderDidChange?()
        }
        rows.applySavedOrder()

        let list = SettingsAdaptiveBorderBox(increaseContrast: increaseContrast)
        list.identifier = NSUserInterfaceItemIdentifier("settings.modules.list")
        list.boxType = .custom
        list.titlePosition = .noTitle
        list.cornerRadius = SettingsStyle.surfaceCornerRadius
        list.fillColor = SettingsStyle.surfaceBackground
        list.translatesAutoresizingMaskIntoConstraints = false
        list.addSubview(rows)
        let surface = SettingsGlassSurface(controls: list)

        view.addSubview(heading)
        view.addSubview(subtitle)
        view.addSubview(surface)
        view.addSubview(restoreOrder)
        let contentTop = surface.topAnchor.constraint(equalTo: view.topAnchor, constant: 70)
        heading.contentTopConstraint = contentTop
        NSLayoutConstraint.activate([
            heading.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 2),
            heading.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            heading.topAnchor.constraint(equalTo: view.topAnchor, constant: -3),
            subtitle.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 2),
            subtitle.trailingAnchor.constraint(lessThanOrEqualTo: restoreOrder.leadingAnchor, constant: -12),
            subtitle.bottomAnchor.constraint(equalTo: surface.topAnchor, constant: -10),
            restoreOrder.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            restoreOrder.centerYAnchor.constraint(equalTo: subtitle.centerYAnchor),
            restoreOrder.heightAnchor.constraint(equalToConstant: 22),
            surface.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            surface.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            contentTop,
            surface.bottomAnchor.constraint(lessThanOrEqualTo: view.bottomAnchor),
            surface.heightAnchor.constraint(equalToConstant:
                SettingsStyle.moduleRowHeight * CGFloat(Settings.Module.allCases.count)),
            rows.leadingAnchor.constraint(equalTo: list.leadingAnchor),
            rows.trailingAnchor.constraint(equalTo: list.trailingAnchor),
            rows.topAnchor.constraint(equalTo: list.topAnchor),
            rows.bottomAnchor.constraint(equalTo: list.bottomAnchor),
        ])
    }

    private func makeRow(for module: Settings.Module, index: Int) -> NSView {
        let row = NSView()
        row.wantsLayer = true
        row.identifier = NSUserInterfaceItemIdentifier("settings.modules.row.\(module.rawValue)")

        let icon = ModuleSettingsIconView(module: module, increaseContrast: increaseContrast)
        icon.identifier = NSUserInterfaceItemIdentifier("settings.modules.icon.\(module.rawValue)")
        icon.imageScaling = .scaleProportionallyDown
        icon.setAccessibilityElement(false)
        icon.translatesAutoresizingMaskIntoConstraints = false

        let primary = NSTextField(labelWithString: module.title)
        primary.font = SettingsStyle.primaryFont
        primary.textColor = SettingsStyle.primaryText

        let detail = NSTextField(labelWithString: description(for: module))
        detail.font = SettingsStyle.detailFont
        detail.textColor = SettingsStyle.secondaryText
        detail.lineBreakMode = .byTruncatingTail
        let text = NSStackView(views: [primary, detail])
        text.orientation = .vertical
        text.alignment = .leading
        text.spacing = 5
        text.translatesAutoresizingMaskIntoConstraints = false

        let button = SettingsToggleButton(
            accessibilityLabel: module.title,
            increaseContrast: increaseContrast,
            target: self,
            action: #selector(toggleModule(_:))
        )
        button.tag = index
        button.setAccessibilityHelp("Show or hide the \(module.title) module in Wattson.")
        buttons[module] = button
        let handle = ModuleReorderHandle(module: module, increaseContrast: increaseContrast)
        handle.reorderList = rows
        handles[module] = handle

        row.addSubview(icon)
        row.addSubview(text)
        row.addSubview(button)
        row.addSubview(handle)
        NSLayoutConstraint.activate([
            icon.leadingAnchor.constraint(equalTo: row.leadingAnchor, constant: 16),
            icon.centerYAnchor.constraint(equalTo: row.centerYAnchor),
            icon.widthAnchor.constraint(equalToConstant: SettingsStyle.rowIconSize),
            icon.heightAnchor.constraint(equalToConstant: SettingsStyle.rowIconSize),
            text.leadingAnchor.constraint(equalTo: icon.trailingAnchor, constant: 12),
            text.centerYAnchor.constraint(equalTo: row.centerYAnchor),
            text.trailingAnchor.constraint(lessThanOrEqualTo: button.leadingAnchor, constant: -8),
            button.trailingAnchor.constraint(equalTo: handle.leadingAnchor, constant: -6),
            button.centerYAnchor.constraint(equalTo: row.centerYAnchor),
            button.widthAnchor.constraint(equalToConstant: SettingsStyle.toggleSize.width),
            button.heightAnchor.constraint(equalToConstant: SettingsStyle.toggleSize.height),
            handle.trailingAnchor.constraint(equalTo: row.trailingAnchor, constant: -8),
            handle.centerYAnchor.constraint(equalTo: row.centerYAnchor),
            handle.widthAnchor.constraint(equalToConstant: 24),
            handle.heightAnchor.constraint(equalToConstant: 28),
            row.heightAnchor.constraint(equalToConstant: SettingsStyle.moduleRowHeight),
        ])

        let separator = NSBox()
        separators[module] = separator
        separator.boxType = .separator
        separator.translatesAutoresizingMaskIntoConstraints = false
        row.addSubview(separator)
        NSLayoutConstraint.activate([
            separator.leadingAnchor.constraint(equalTo: text.leadingAnchor),
            separator.trailingAnchor.constraint(equalTo: row.trailingAnchor, constant: -16),
            separator.bottomAnchor.constraint(equalTo: row.bottomAnchor),
        ])
        return row
    }

    private func description(for module: Settings.Module) -> String {
        switch module {
        case .flow: return "See where power comes from and goes."
        case .ring: return "Battery charge and power at a glance."
        case .lanes: return "Compare system and battery power."
        case .history: return "See recent power use over time."
        case .runtime: return "See time to full charge or remaining battery time."
        }
    }

    private func installObserver() {
        settingsObserver = NotificationCenter.default.addObserver(
            forName: Settings.didChange,
            object: nil,
            queue: .main
        ) { [weak self] notification in
            guard let self else { return }
            guard let change = notification.userInfo?[Settings.changeUserInfoKey]
                    as? Settings.Change else {
                self.refresh()
                return
            }
            if case let .module(module) = change { self.refresh(module) }
            if change == .moduleOrder { self.rows.applySavedOrder() }
        }
    }

    private func refreshRowOrder() {
        let order = rows.displayedOrder
        for (index, module) in order.enumerated() {
            separators[module]?.isHidden = index == order.count - 1
            handles[module]?.refreshPosition(index, count: order.count)
        }
    }

    private func refresh(_ module: Settings.Module) {
        buttons[module]?.state = Settings.isModuleVisible(module) ? .on : .off
    }

    @objc private func restoreDefaultOrder(_ sender: NSButton) {
        Settings.moduleOrder = Settings.Module.allCases
    }

    @objc private func toggleModule(_ sender: NSButton) {
        guard Settings.Module.allCases.indices.contains(sender.tag) else { return }
        let module = Settings.Module.allCases[sender.tag]
        Settings.setModule(module, visible: sender.state == .on)
    }
}

final class SettingsWindowController: NSWindowController, NSTableViewDataSource,
    NSTableViewDelegate, NSToolbarDelegate
{
    private static let frameAutosaveName = "WattsonSettingsWindow"
    private static let sectionTitleItem = NSToolbarItem.Identifier("settings.section-title")

    private let sections: [SettingsSectionController]
    private let increaseContrast: () -> Bool
    private let sidebar = NSTableView()
    private let root = SettingsFillView(color: SettingsStyle.canvasBackground)
    private let windowBackdrop = NSVisualEffectView()
    private let sidebarContainer = SettingsFillView(color: SettingsStyle.sidebarBackground)
    private let trafficSafeArea = NSView()
    private let toolbarTitle = NSTextField(labelWithString: "")
    private var splitController: NSSplitViewController?
    private var classicLayout: [NSLayoutConstraint] = []
    private var glassLayout: [NSLayoutConstraint] = []
    private let identityIcon = SettingsLogoImageView()
    private let contentHost = NSView()
    private let divider: DynamicSeparatorView
    private var accessibilityDisplayObserver: NSObjectProtocol?
    private var appearanceObserver: NSObjectProtocol?
    private var selectedSectionIndex = 0

    static func defaultSections(
        dependencies: SettingsWindowDependencies = .live
    ) -> [SettingsSectionController] {
        [
            GeneralSettingsSectionController(dependencies: dependencies),
            MenuBarIconSettingsSectionController(
                increaseContrast: dependencies.increaseContrast
            ),
            ModuleSettingsSectionController(
                increaseContrast: dependencies.increaseContrast
            ),
        ]
    }

    init(
        sections: [SettingsSectionController]? = nil,
        dependencies: SettingsWindowDependencies = .live,
        frameAutosaveName: String? = SettingsWindowController.frameAutosaveName
    ) {
        let resolvedSections = sections ?? Self.defaultSections(dependencies: dependencies)
        precondition(
            Set(resolvedSections.map(\.identifier)).count == resolvedSections.count,
            "Settings section identifiers must be unique."
        )
        precondition(!resolvedSections.isEmpty, "Settings needs at least one section.")
        self.sections = resolvedSections
        increaseContrast = dependencies.increaseContrast
        divider = DynamicSeparatorView(
            increaseContrast: dependencies.increaseContrast
        )

        let window = NSWindow(
            contentRect: NSRect(origin: .zero, size: SettingsStyle.contentSize),
            styleMask: [
                .titled,
                .closable,
                .miniaturizable,
                .fullSizeContentView,
            ],
            backing: .buffered,
            defer: false
        )
        window.appearance = Settings.colorScheme.appearance
        window.backgroundColor = SettingsStyle.contentBackground
        window.title = "Wattson Settings"
        window.titleVisibility = .hidden
        window.titlebarAppearsTransparent = true
        window.titlebarSeparatorStyle = .none
        window.isReleasedWhenClosed = false
        window.isRestorable = false
        window.tabbingMode = .disallowed
        // This utility window has one intentionally compact composition.
        // Omitting `.resizable` keeps AppKit's native zoom control disabled.
        window.contentMinSize = SettingsStyle.contentSize
        window.contentMaxSize = SettingsStyle.contentSize
        window.isMovableByWindowBackground = true
        window.autorecalculatesKeyViewLoop = false

        let hadSavedFrame = frameAutosaveName.flatMap {
            UserDefaults.standard.string(forKey: "NSWindow Frame \($0)")
        } != nil
        super.init(window: window)

        for case let moduleSection as ModuleSettingsSectionController in resolvedSections {
            moduleSection.orderDidChange = { [weak self] in self?.updateVisibleSwitchKeyLoop() }
        }

        configureContent()
        installAccessibilityDisplayObserver()
        appearanceObserver = NotificationCenter.default.addObserver(
            forName: Settings.didChange, object: nil, queue: .main
        ) { [weak self] notification in
            let change = notification.userInfo?[Settings.changeUserInfoKey] as? Settings.Change
            if change == .liquidGlassAppearance { self?.refreshLiquidGlassAppearance() }
            if change == .liquidGlassTransparency { self?.refreshContrastAppearance() }
            if change == .colorScheme { self?.refreshColorScheme() }
            if change == .inAppLogoStyle { self?.identityIcon.refreshLogo() }
        }
        refreshLiquidGlassAppearance()
        if let frameAutosaveName {
            // NSWindowController initialization clears a name assigned before
            // it takes ownership, so install autosave after `super.init`.
            window.setFrameAutosaveName(frameAutosaveName)
            if !hadSavedFrame { window.center() }
        }
    }

    deinit {
        if let appearanceObserver {
            NotificationCenter.default.removeObserver(appearanceObserver)
        }
        if let accessibilityDisplayObserver {
            NSWorkspace.shared.notificationCenter.removeObserver(
                accessibilityDisplayObserver
            )
        }
    }

    private func installAccessibilityDisplayObserver() {
        accessibilityDisplayObserver = NSWorkspace.shared.notificationCenter.addObserver(
            forName: NSWorkspace.accessibilityDisplayOptionsDidChangeNotification,
            object: nil,
            queue: .main
        ) { [weak self] _ in
            self?.refreshContrastAppearance()
        }
    }

    private func refreshContrastAppearance() {
        guard Thread.isMainThread else {
            DispatchQueue.main.async { [weak self] in
                self?.refreshContrastAppearance()
            }
            return
        }

        sections.forEach { refreshContrastAppearance(in: $0.view) }
        sidebar.enumerateAvailableRowViews { rowView, _ in
            self.refreshContrastAppearance(in: rowView)
        }
        divider.refreshContrastAppearance()
        updateVisibleSwitchKeyLoop()
    }

    private func refreshContrastAppearance(in view: NSView) {
        (view as? SettingsContrastRefreshing)?.refreshContrastAppearance()
        view.needsDisplay = true
        view.subviews.forEach { refreshContrastAppearance(in: $0) }
    }

    private func refreshColorScheme() {
        window?.appearance = Settings.colorScheme.appearance
        if let content = window?.contentView { refreshContrastAppearance(in: content) }
        refreshContrastAppearance()
        identityIcon.refreshLogo()
    }

    private func refreshLiquidGlassAppearance() {
        guard let window else { return }
        let enabled = Settings.usesLiquidGlass
        // Keep the section controllers and their in-flight operations intact.
        // Appearance is never a reason to re-query the privileged helper.
        let focusedToggle = window.firstResponder as? SettingsToggleButton
            ?? (window.firstResponder as? NSSwitch)?.superview as? SettingsToggleButton
        let focusedView = window.firstResponder as? NSView
        window.appearance = Settings.colorScheme.appearance
        window.isOpaque = !enabled
        window.backgroundColor = enabled ? .clear : SettingsStyle.contentBackground
        windowBackdrop.isHidden = !enabled
        configureNativeSidebar(enabled: enabled)
        sidebar.selectionHighlightStyle = enabled ? .regular : .none
        identityIcon.refreshLogo()
        for section in sections {
            for button in switchButtons(in: section.view)
                where type(of: button) == NSButton.self || button is SettingsFeedbackButton {
                if #available(macOS 26, *) {
                    button.bezelStyle = enabled ? .glass : .rounded
                }
            }
        }
        if let content = window.contentView { refreshContrastAppearance(in: content) }
        // Non-visible sections remain owned but are not children of the window.
        refreshContrastAppearance()
        updateVisibleSwitchKeyLoop()
        if let focusedToggle {
            window.makeFirstResponder(enabled ? focusedToggle.nativeSwitch : focusedToggle)
        } else if let focusedView, focusedView.window === window {
            window.makeFirstResponder(focusedView)
        }
    }

    @available(*, unavailable)
    required init?(coder: NSCoder) {
        fatalError("init(coder:) is unavailable")
    }

    func show(activateApp: Bool = true) {
        guard Thread.isMainThread else {
            DispatchQueue.main.async { [weak self] in
                self?.show(activateApp: activateApp)
            }
            return
        }

        refreshSections()
        guard let window else { return }
        if window.isMiniaturized { window.deminiaturize(nil) }
        window.initialFirstResponder = sidebar
        if activateApp {
            window.makeKeyAndOrderFront(nil)
            if #available(macOS 14, *) {
                NSRunningApplication.current.activate(options: [.activateAllWindows])
            } else {
                NSRunningApplication.current.activate(
                    options: [.activateIgnoringOtherApps, .activateAllWindows]
                )
            }
            NSApp.activate(ignoringOtherApps: true)
            DispatchQueue.main.async { [weak window] in
                guard let window, window.isVisible else { return }
                window.makeKeyAndOrderFront(nil)
            }
        } else {
            window.orderFront(nil)
        }
    }

    private func configureContent() {
        guard let window else { return }
        let viewport = NSView(frame: NSRect(origin: .zero, size: SettingsStyle.contentSize))
        viewport.identifier = NSUserInterfaceItemIdentifier("settings.viewport")
        viewport.autoresizingMask = [.width, .height]
        windowBackdrop.identifier = NSUserInterfaceItemIdentifier("settings.window.backdrop")
        windowBackdrop.frame = viewport.bounds
        windowBackdrop.autoresizingMask = [.width, .height]
        windowBackdrop.material = .underWindowBackground
        windowBackdrop.blendingMode = .behindWindow
        windowBackdrop.state = .followsWindowActiveState
        viewport.addSubview(windowBackdrop)
        root.frame = NSRect(origin: .zero, size: SettingsStyle.contentSize)
        root.identifier = NSUserInterfaceItemIdentifier("settings.root")
        root.autoresizingMask = []

        sidebarContainer.identifier = NSUserInterfaceItemIdentifier("settings.sidebar")
        sidebarContainer.translatesAutoresizingMaskIntoConstraints = false

        let identity = makeIdentityView()
        trafficSafeArea.identifier = NSUserInterfaceItemIdentifier(
            "settings.sidebar.traffic-safe-area"
        )
        trafficSafeArea.translatesAutoresizingMaskIntoConstraints = false
        let navigation = makeNavigationView()
        divider.identifier = NSUserInterfaceItemIdentifier("settings.sidebar.divider")
        divider.translatesAutoresizingMaskIntoConstraints = false

        contentHost.identifier = NSUserInterfaceItemIdentifier("settings.content.host")
        contentHost.translatesAutoresizingMaskIntoConstraints = false

        root.addSubview(sidebarContainer)
        root.addSubview(divider)
        root.addSubview(contentHost)
        sidebarContainer.addSubview(identity)
        sidebarContainer.addSubview(trafficSafeArea)
        sidebarContainer.addSubview(navigation)

        let layoutConstraints = [
            sidebarContainer.leadingAnchor.constraint(equalTo: root.leadingAnchor),
            sidebarContainer.topAnchor.constraint(equalTo: root.topAnchor),
            sidebarContainer.bottomAnchor.constraint(equalTo: root.bottomAnchor),
            sidebarContainer.widthAnchor.constraint(equalToConstant: SettingsStyle.sidebarWidth),

            trafficSafeArea.leadingAnchor.constraint(equalTo: sidebarContainer.leadingAnchor),
            trafficSafeArea.trailingAnchor.constraint(equalTo: sidebarContainer.trailingAnchor),
            trafficSafeArea.topAnchor.constraint(equalTo: sidebarContainer.topAnchor),
            trafficSafeArea.heightAnchor.constraint(
                equalToConstant: SettingsStyle.trafficLightSafeHeight
            ),

            identity.leadingAnchor.constraint(equalTo: sidebarContainer.leadingAnchor),
            identity.trailingAnchor.constraint(equalTo: sidebarContainer.trailingAnchor),
            identity.topAnchor.constraint(equalTo: trafficSafeArea.bottomAnchor),
            identity.heightAnchor.constraint(equalToConstant: SettingsStyle.identityHeight),

            navigation.leadingAnchor.constraint(
                equalTo: sidebarContainer.leadingAnchor,
                constant: SettingsStyle.navigationInset
            ),
            navigation.trailingAnchor.constraint(
                equalTo: sidebarContainer.trailingAnchor,
                constant: -SettingsStyle.navigationInset
            ),
            navigation.topAnchor.constraint(
                equalTo: identity.bottomAnchor,
                constant: SettingsStyle.navigationTopGap
            ),
            navigation.heightAnchor.constraint(
                equalToConstant: SettingsStyle.navigationHeight
            ),

            divider.leadingAnchor.constraint(equalTo: sidebarContainer.trailingAnchor),
            divider.topAnchor.constraint(equalTo: root.topAnchor),
            divider.bottomAnchor.constraint(equalTo: root.bottomAnchor),
            divider.widthAnchor.constraint(equalToConstant: 1),

            contentHost.leadingAnchor.constraint(
                equalTo: divider.trailingAnchor,
                constant: SettingsStyle.contentHorizontalInset
            ),
            contentHost.trailingAnchor.constraint(
                equalTo: root.trailingAnchor,
                constant: -SettingsStyle.contentHorizontalInset
            ),
            contentHost.topAnchor.constraint(
                equalTo: root.topAnchor,
                constant: SettingsStyle.contentTopInset
            ),
            contentHost.bottomAnchor.constraint(
                equalTo: root.bottomAnchor,
                constant: -SettingsStyle.contentBottomInset
            ),
        ]
        // Only the outer placement changes when AppKit takes over the sidebar.
        // The identity, navigation, controls and section instances stay alive.
        classicLayout = layoutConstraints.filter {
            ($0.firstItem as? NSView) === sidebarContainer
                || ($0.firstItem as? NSView) === divider
                || ($0.firstItem as? NSView) === contentHost
                || (($0.firstItem as? NSView) === trafficSafeArea && $0.firstAttribute == .height)
        }
        NSLayoutConstraint.activate(layoutConstraints)

        viewport.addSubview(root)
        let viewportController = NSViewController()
        viewportController.view = viewport
        window.contentViewController = viewportController
        sidebar.selectRowIndexes(IndexSet(integer: 0), byExtendingSelection: false)
        // Row zero may already be selected before the delegate is installed.
        // Ensure the initial page even when there is no selection change.
        showSection(at: 0)
        configureKeyViewLoop()
        root.layoutSubtreeIfNeeded()
    }

    private func configureNativeSidebar(enabled: Bool) {
        guard enabled != (splitController != nil) else { return }
        if enabled {
            guard #available(macOS 26, *) else { return }
            NSLayoutConstraint.deactivate(classicLayout)
            sidebarContainer.removeFromSuperview()
            contentHost.removeFromSuperview()

            let navigation = NSViewController()
            navigation.view = sidebarContainer
            let detail = NSViewController()
            detail.view = NSView()
            // Continue the background beneath AppKit's floating sidebar so
            // its rounded edges never expose a separate window backing fill.
            windowBackdrop.removeFromSuperview()
            windowBackdrop.translatesAutoresizingMaskIntoConstraints = false
            detail.view.addSubview(windowBackdrop)
            detail.view.addSubview(contentHost)
            let split = NSSplitViewController()
            split.view.identifier = NSUserInterfaceItemIdentifier("settings.native-split")
            split.splitView.isVertical = true
            let navigationItem = NSSplitViewItem(sidebarWithViewController: navigation)
            navigationItem.canCollapse = false
            navigationItem.minimumThickness = SettingsStyle.sidebarWidth
            navigationItem.maximumThickness = SettingsStyle.sidebarWidth
            let detailItem = NSSplitViewItem(viewController: detail)
            detailItem.automaticallyAdjustsSafeAreaInsets = true
            split.addSplitViewItem(navigationItem)
            split.addSplitViewItem(detailItem)
            window?.contentViewController?.addChild(split)
            split.view.translatesAutoresizingMaskIntoConstraints = false
            root.addSubview(split.view)
            glassLayout = [
                split.view.leadingAnchor.constraint(equalTo: root.leadingAnchor),
                split.view.trailingAnchor.constraint(equalTo: root.trailingAnchor),
                split.view.topAnchor.constraint(equalTo: root.topAnchor),
                split.view.bottomAnchor.constraint(equalTo: root.bottomAnchor),
                windowBackdrop.leadingAnchor.constraint(equalTo: detail.view.leadingAnchor),
                windowBackdrop.trailingAnchor.constraint(equalTo: detail.view.trailingAnchor),
                windowBackdrop.topAnchor.constraint(equalTo: detail.view.topAnchor),
                windowBackdrop.bottomAnchor.constraint(equalTo: detail.view.bottomAnchor),
                contentHost.leadingAnchor.constraint(equalTo: detail.view.safeAreaLayoutGuide.leadingAnchor,
                                                   constant: SettingsStyle.contentHorizontalInset),
                contentHost.trailingAnchor.constraint(equalTo: detail.view.trailingAnchor,
                                                    constant: -SettingsStyle.contentHorizontalInset),
                contentHost.topAnchor.constraint(equalTo: detail.view.safeAreaLayoutGuide.topAnchor,
                                              constant: 16),
                contentHost.bottomAnchor.constraint(equalTo: detail.view.bottomAnchor,
                                                 constant: -SettingsStyle.contentBottomInset),
                trafficSafeArea.bottomAnchor.constraint(equalTo: sidebarContainer.safeAreaLayoutGuide.topAnchor),
            ]
            NSLayoutConstraint.activate(glassLayout)
            splitController = split
            let toolbar = NSToolbar(identifier: "WattsonSettingsToolbar")
            toolbar.delegate = self
            toolbar.displayMode = .iconOnly
            window?.toolbarStyle = .unified
            window?.toolbar = toolbar
        } else if let split = splitController {
            window?.toolbar = nil
            window?.toolbarStyle = .automatic
            NSLayoutConstraint.deactivate(glassLayout)
            glassLayout.removeAll()
            windowBackdrop.removeFromSuperview()
            windowBackdrop.translatesAutoresizingMaskIntoConstraints = true
            if let viewport = window?.contentView {
                windowBackdrop.frame = viewport.bounds
                viewport.addSubview(windowBackdrop, positioned: .below, relativeTo: root)
            }
            sidebarContainer.removeFromSuperview()
            contentHost.removeFromSuperview()
            split.view.removeFromSuperview()
            split.removeFromParent()
            splitController = nil
            root.addSubview(sidebarContainer)
            root.addSubview(contentHost)
            NSLayoutConstraint.activate(classicLayout)
        }
        divider.isHidden = enabled
        root.layoutSubtreeIfNeeded()
    }

    func toolbarDefaultItemIdentifiers(_ toolbar: NSToolbar) -> [NSToolbarItem.Identifier] {
        [.sidebarTrackingSeparator, Self.sectionTitleItem, .flexibleSpace]
    }

    func toolbarAllowedItemIdentifiers(_ toolbar: NSToolbar) -> [NSToolbarItem.Identifier] {
        toolbarDefaultItemIdentifiers(toolbar)
    }

    func toolbar(_ toolbar: NSToolbar, itemForItemIdentifier identifier: NSToolbarItem.Identifier,
                 willBeInsertedIntoToolbar flag: Bool) -> NSToolbarItem? {
        if identifier == .sidebarTrackingSeparator, let split = splitController {
            return NSTrackingSeparatorToolbarItem(identifier: identifier,
                splitView: split.splitView, dividerIndex: 0)
        }
        guard identifier == Self.sectionTitleItem else { return nil }
        toolbarTitle.identifier = NSUserInterfaceItemIdentifier("settings.toolbar.title")
        toolbarTitle.stringValue = sections[selectedSectionIndex].title
        toolbarTitle.font = .systemFont(ofSize: 15, weight: .medium)
        toolbarTitle.textColor = .labelColor
        let item = NSToolbarItem(itemIdentifier: identifier)
        item.isBordered = false
        item.view = toolbarTitle
        item.label = sections[selectedSectionIndex].title
        return item
    }

    private func makeIdentityView() -> NSView {
        let identity = NSView()
        identity.identifier = NSUserInterfaceItemIdentifier("settings.sidebar.identity")
        identity.translatesAutoresizingMaskIntoConstraints = false

        let iconTile = identityIcon
        iconTile.identifier = NSUserInterfaceItemIdentifier("settings.sidebar.identity.tile")
        iconTile.refreshLogo()
        iconTile.imageScaling = .scaleProportionallyDown
        iconTile.imageAlignment = .alignCenter
        iconTile.setAccessibilityElement(false)
        iconTile.translatesAutoresizingMaskIntoConstraints = false

        let name = NSTextField(labelWithString: "Wattson")
        name.font = .systemFont(ofSize: 14, weight: .medium)
        name.textColor = SettingsStyle.headingText
        name.translatesAutoresizingMaskIntoConstraints = false

        identity.addSubview(iconTile)
        identity.addSubview(name)
        NSLayoutConstraint.activate([
            iconTile.leadingAnchor.constraint(equalTo: identity.leadingAnchor, constant: 16),
            iconTile.centerYAnchor.constraint(equalTo: identity.centerYAnchor),
            iconTile.widthAnchor.constraint(equalToConstant: SettingsStyle.identityTileSize),
            iconTile.heightAnchor.constraint(equalToConstant: SettingsStyle.identityTileSize),
            name.leadingAnchor.constraint(equalTo: iconTile.trailingAnchor, constant: 10),
            name.centerYAnchor.constraint(equalTo: iconTile.centerYAnchor),
        ])
        return identity
    }

    private func makeNavigationView() -> NSView {
        let scroll = NSScrollView()
        scroll.identifier = NSUserInterfaceItemIdentifier("settings.sidebar.navigation")
        scroll.drawsBackground = false
        scroll.hasVerticalScroller = false
        scroll.hasHorizontalScroller = false
        scroll.borderType = .noBorder
        scroll.translatesAutoresizingMaskIntoConstraints = false

        let column = NSTableColumn(identifier: NSUserInterfaceItemIdentifier("settings.sidebar.column"))
        column.resizingMask = .autoresizingMask
        sidebar.addTableColumn(column)
        sidebar.headerView = nil
        sidebar.style = .sourceList
        sidebar.rowHeight = SettingsStyle.navigationRowHeight
        sidebar.intercellSpacing = NSSize(width: 0, height: SettingsStyle.navigationRowGap)
        sidebar.selectionHighlightStyle = .none
        sidebar.allowsEmptySelection = false
        sidebar.allowsMultipleSelection = false
        sidebar.focusRingType = .default
        sidebar.backgroundColor = .clear
        sidebar.dataSource = self
        sidebar.delegate = self
        scroll.documentView = sidebar
        return scroll
    }

    private func configureKeyViewLoop() {
        updateVisibleSwitchKeyLoop()
    }

    private func updateVisibleSwitchKeyLoop() {
        let controls = keyControls(in: sections[selectedSectionIndex].view)
        sidebar.nextKeyView = controls.first ?? sidebar
        for (current, next) in zip(controls, controls.dropFirst()) {
            current.nextKeyView = next
        }
        controls.last?.nextKeyView = sidebar
    }

    private func keyControls(in view: NSView) -> [NSView] {
        guard !view.isHidden else { return [] }
        if let toggle = view as? SettingsToggleButton {
            return [Settings.usesLiquidGlass ? toggle.nativeSwitch : toggle]
        }
        if let control = view as? NSSwitch { return control.isEnabled ? [control] : [] }
        if let popup = view as? NSPopUpButton { return popup.isEnabled ? [popup] : [] }
        if let slider = view as? NSSlider { return slider.isEnabled ? [slider] : [] }
        if view is NSButton { return [view] }
        if let rows = view as? ModuleReorderList { return rows.arrangedSubviews.flatMap { keyControls(in: $0) } }
        return view.subviews.flatMap { keyControls(in: $0) }
    }

    private func switchButtons(in view: NSView) -> [NSButton] {
        guard !view.isHidden else { return [] }
        var buttons: [NSButton] = []
        if let button = view as? NSButton, !(button is NSPopUpButton) {
            buttons.append(button)
        }
        let children = (view as? ModuleReorderList)?.arrangedSubviews ?? view.subviews
        for subview in children { buttons.append(contentsOf: switchButtons(in: subview)) }
        return buttons
    }

    private func refreshSections() {
        sections.forEach { $0.refresh() }
    }

    private func showSection(at index: Int) {
        guard sections.indices.contains(index) else { return }
        selectedSectionIndex = index
        toolbarTitle.stringValue = sections[index].title
        window?.toolbar?.items.first { $0.itemIdentifier == Self.sectionTitleItem }?.label = sections[index].title
        let sectionView = sections[index].view
        guard sectionView.superview !== contentHost else { return }
        contentHost.subviews.forEach { $0.removeFromSuperview() }
        sectionView.translatesAutoresizingMaskIntoConstraints = false
        contentHost.addSubview(sectionView)
        NSLayoutConstraint.activate([
            sectionView.leadingAnchor.constraint(equalTo: contentHost.leadingAnchor),
            sectionView.trailingAnchor.constraint(equalTo: contentHost.trailingAnchor),
            sectionView.topAnchor.constraint(equalTo: contentHost.topAnchor),
            sectionView.bottomAnchor.constraint(equalTo: contentHost.bottomAnchor),
        ])
        updateVisibleSwitchKeyLoop()
    }

    func tableViewSelectionDidChange(_ notification: Notification) {
        guard let tableView = notification.object as? NSTableView,
              tableView === sidebar else { return }
        let row = sidebar.selectedRow
        guard sections.indices.contains(row) else {
            sidebar.selectRowIndexes(
                IndexSet(integer: selectedSectionIndex),
                byExtendingSelection: false
            )
            return
        }
        showSection(at: row)
    }

    func numberOfRows(in tableView: NSTableView) -> Int { sections.count }

    func tableView(_ tableView: NSTableView, heightOfRow row: Int) -> CGFloat {
        SettingsStyle.navigationRowHeight
    }

    func tableView(_ tableView: NSTableView, rowViewForRow row: Int) -> NSTableRowView? {
        SettingsSidebarRowView(increaseContrast: increaseContrast)
    }

    func tableView(
        _ tableView: NSTableView,
        viewFor tableColumn: NSTableColumn?,
        row: Int
    ) -> NSView? {
        guard sections.indices.contains(row) else { return nil }
        let section = sections[row]
        let cell = SettingsSidebarCellView(icon: section.sidebarIcon,
                                           increaseContrast: increaseContrast)

        let icon = NSImageView()
        icon.identifier = NSUserInterfaceItemIdentifier("settings.sidebar.icon.\(section.identifier)")
        icon.translatesAutoresizingMaskIntoConstraints = false
        icon.imageScaling = .scaleProportionallyDown
        icon.setAccessibilityElement(false)

        let title = NSTextField(labelWithString: section.title)
        title.font = SettingsStyle.sidebarFont
        title.textColor = SettingsStyle.primaryText
        title.lineBreakMode = .byTruncatingTail
        title.translatesAutoresizingMaskIntoConstraints = false

        cell.addSubview(icon)
        cell.addSubview(title)
        cell.imageView = icon
        cell.textField = title
        cell.refreshContrastAppearance()
        NSLayoutConstraint.activate([
            icon.leadingAnchor.constraint(equalTo: cell.leadingAnchor),
            icon.centerYAnchor.constraint(equalTo: cell.centerYAnchor),
            icon.widthAnchor.constraint(equalToConstant: 24),
            icon.heightAnchor.constraint(equalToConstant: 24),
            title.leadingAnchor.constraint(equalTo: icon.trailingAnchor, constant: 9),
            title.trailingAnchor.constraint(equalTo: cell.trailingAnchor),
            title.centerYAnchor.constraint(equalTo: cell.centerYAnchor),
        ])
        cell.setAccessibilityLabel(section.title)
        cell.setAccessibilityHelp("Show the \(section.title) settings page.")
        return cell
    }

#if DEBUG
    var windowForTest: NSWindow? { window }
    var trafficLightButtonsForTest: [NSButton] {
        guard let window else { return [] }
        return [
            window.standardWindowButton(.closeButton),
            window.standardWindowButton(.miniaturizeButton),
            window.standardWindowButton(.zoomButton),
        ].compactMap { $0 }
    }
    var selectedRowStrokeWidthForTest: CGFloat {
        selectedSidebarRowForTest?.selectionStrokeWidth ?? -1
    }
    var selectedRowFillColorForTest: NSColor? {
        selectedSidebarRowForTest?.selectionFillColor
    }
    var selectedRowStrokeColorForTest: NSColor? {
        selectedSidebarRowForTest?.selectionStrokeColor
    }
    var dividerVisualStrokeWidthForTest: CGFloat { divider.renderedStrokeWidth }
    var dividerColorForTest: NSColor { divider.strokeColor }

    func toggleTrackStrokeWidthForTest(_ accessibilityLabel: String) -> CGFloat {
        settingsToggleForTest(accessibilityLabel)?.trackStrokeWidth ?? -1
    }

    func toggleTrackColorForTest(_ accessibilityLabel: String) -> NSColor? {
        settingsToggleForTest(accessibilityLabel)?.trackColor
    }

    func toggleTrackStrokeColorForTest(_ accessibilityLabel: String) -> NSColor? {
        settingsToggleForTest(accessibilityLabel)?.trackStrokeColor
    }

    func iconCardBorderWidthForTest(_ accessibilityLabel: String) -> CGFloat {
        iconCardForTest(accessibilityLabel)?.cardBorderWidth ?? -1
    }

    func iconCardFillColorForTest(_ accessibilityLabel: String) -> NSColor? {
        iconCardForTest(accessibilityLabel)?.cardFillColor
    }

    func iconCardBorderColorForTest(_ accessibilityLabel: String) -> NSColor? {
        iconCardForTest(accessibilityLabel)?.cardBorderColor
    }

    func iconCardDrawCountForTest(_ accessibilityLabel: String) -> Int {
        iconCardForTest(accessibilityLabel)?.drawCountForTest ?? -1
    }

    private var selectedSidebarRowForTest: SettingsSidebarRowView? {
        guard sidebar.selectedRow >= 0 else { return nil }
        return sidebar.rowView(
            atRow: sidebar.selectedRow,
            makeIfNecessary: true
        ) as? SettingsSidebarRowView
    }

    private func settingsToggleForTest(
        _ accessibilityLabel: String
    ) -> SettingsToggleButton? {
        for section in sections {
            if let match = switchButtons(in: section.view)
                .compactMap({ $0 as? SettingsToggleButton })
                .first(where: { $0.accessibilityLabel() == accessibilityLabel }) {
                return match
            }
        }
        return nil
    }

    private func iconCardForTest(
        _ accessibilityLabel: String
    ) -> MenuBarIconCardButton? {
        for section in sections {
            if let match = switchButtons(in: section.view)
                .compactMap({ $0 as? MenuBarIconCardButton })
                .first(where: { $0.accessibilityLabel() == accessibilityLabel }) {
                return match
            }
        }
        return nil
    }

    var sectionIdentifiersForTest: [String] { sections.map(\.identifier) }
    var selectedSectionIdentifierForTest: String { sections[selectedSectionIndex].identifier }
    var visibleSectionIdentifierForTest: String? {
        sections.first(where: { $0.view.superview === contentHost })?.identifier
    }
    var contentHostSubviewCountForTest: Int { contentHost.subviews.count }
    var sectionViewIdentitiesForTest: [ObjectIdentifier] {
        sections.map { ObjectIdentifier($0.view) }
    }
    var contentHostFrameForTest: NSRect { contentHost.frame }
    var sidebarStyleForTest: NSTableView.Style { sidebar.style }
    var sidebarAllowsEmptySelectionForTest: Bool { sidebar.allowsEmptySelection }
    var sidebarRowHeightForTest: CGFloat { sidebar.rowHeight }
    var sidebarRowGapForTest: CGFloat { sidebar.intercellSpacing.height }
    var sidebarVisibleRectForTest: NSRect { sidebar.visibleRect }
    func sidebarRectForRowForTest(_ row: Int) -> NSRect { sidebar.rect(ofRow: row) }
    var sidebarForTest: NSTableView { sidebar }
    var sidebarNextKeyViewForTest: NSView? { sidebar.nextKeyView }

    private func moduleReorderHandleForTest(_ module: Settings.Module) -> ModuleReorderHandle? {
        sections.flatMap { keyControls(in: $0.view) }
            .compactMap { $0 as? ModuleReorderHandle }.first { $0.module == module }
    }

    func observeModuleReorderDragStartForTest(_ module: Settings.Module, handler: ((NSEvent) -> Void)?) {
        moduleReorderHandleForTest(module)?.dragStartObserverForTest = handler
    }

    func moduleReorderShowsKeyboardFocusForTest(_ module: Settings.Module) -> Bool {
        moduleReorderHandleForTest(module)?.showsKeyboardFocus ?? false
    }

    func configureModuleDragPreflightForTest(
        buttons: (() -> Int)?, onStart: ((NSEvent) -> Void)?
    ) {
        let list = moduleReorderHandleForTest(.flow)?.reorderList
        list?.pressedMouseButtonsForTest = buttons
        list?.nativeDragStartObserverForTest = onStart
    }

    var moduleDragStateIsClearForTest: Bool {
        moduleReorderHandleForTest(.flow)?.reorderList?.dragStateIsClearForTest ?? false
    }

    var lastVisibleSwitchNextKeyViewForTest: NSView? {
        switchButtons(in: sections[selectedSectionIndex].view).last?.nextKeyView
    }

    func selectSectionForTest(identifier: String) {
        guard let index = sections.firstIndex(where: { $0.identifier == identifier }) else { return }
        sidebar.selectRowIndexes(IndexSet(integer: index), byExtendingSelection: false)
    }

    func selectSidebarRowForTest(_ row: Int) {
        sidebar.selectRowIndexes(IndexSet(integer: row), byExtendingSelection: false)
    }

    func refreshSectionsForTest() { refreshSections() }
#endif
}
