// Generated from design/settings/*-icons-vector and design/popover/power-icons-vector. Edit SVG masters.
// Regenerate with: python3 design/settings/module-icons-vector/generate-swift.py
import AppKit

enum ModuleIconArtwork {
    enum SidebarIcon: CaseIterable { case general, display, modules }

    enum GeneralIcon: CaseIterable { case login, battery, update, automatic, feedback }

    enum PowerIcon: CaseIterable { case adapter, disconnected, system, battery, charging }

    static func image(for module: Settings.Module, side: CGFloat, ink: NSColor,
                      accent: NSColor, increasedContrast: Bool) -> NSImage {
        let image = NSImage(size: NSSize(width: side, height: side), flipped: false) { rect in
            NSGraphicsContext.saveGraphicsState()
            defer { NSGraphicsContext.restoreGraphicsState() }
            let transform = NSAffineTransform()
            transform.translateX(by: rect.minX, yBy: rect.maxY)
            transform.scaleX(by: rect.width / 24, yBy: -rect.height / 24)
            transform.concat()
            let contrastScale: CGFloat = increasedContrast ? 1.2 : 1
            switch module {
            case .flow:
                do {
                    let path = CGMutablePath()
                    path.move(to: NSPoint(x: 2.2, y: 4))
                    path.addLine(to: NSPoint(x: 2.2, y: 7.6))
                    path.addCurve(to: NSPoint(x: 13.1, y: 21), control1: NSPoint(x: 9.4, y: 7.6), control2: NSPoint(x: 13.1, y: 12.9))
                    drawGradient(path, strokeWidth: 1.65 * contrastScale,
                                 colors: [accent.withAlphaComponent((increasedContrast ? 1 : 0)).cgColor, accent.withAlphaComponent((increasedContrast ? 1 : 0.3)).cgColor, accent.withAlphaComponent((increasedContrast ? 1 : 1)).cgColor],
                                 locations: [0, 0.32, 1], start: NSPoint(x: 2.2, y: 4), end: NSPoint(x: 2.2, y: 8.4))
                }
                do {
                    let path = NSBezierPath()
                    path.move(to: NSPoint(x: 7.3, y: 13.1))
                    path.line(to: NSPoint(x: 7.3, y: 20.1))
                    path.move(to: NSPoint(x: 4.8, y: 17.6))
                    path.line(to: NSPoint(x: 7.3, y: 20.1))
                    path.line(to: NSPoint(x: 9.8, y: 17.6))
                    accent.setStroke()
                    path.lineWidth = 1.75 * contrastScale
                    path.lineCapStyle = .round
                    path.lineJoinStyle = .round
                    path.stroke()
                }
                do {
                    let path = NSBezierPath()
                    path.move(to: NSPoint(x: 18.7, y: 15))
                    path.line(to: NSPoint(x: 18.7, y: 2.8))
                    path.move(to: NSPoint(x: 15.9, y: 5.7))
                    path.line(to: NSPoint(x: 18.7, y: 2.8))
                    path.line(to: NSPoint(x: 21.5, y: 5.7))
                    ink.setStroke()
                    path.lineWidth = 1.5 * contrastScale
                    path.lineCapStyle = .round
                    path.lineJoinStyle = .round
                    path.stroke()
                }
            case .ring:
                do {
                    let path = NSBezierPath(ovalIn: NSRect(x: 1.65, y: 1.65, width: 20.7, height: 20.7))
                    ink.setStroke()
                    path.lineWidth = 1.35 * contrastScale
                    path.lineCapStyle = .round
                    path.lineJoinStyle = .round
                    path.stroke()
                }
                do {
                    if !increasedContrast {
                        let path = CGMutablePath()
                        path.move(to: NSPoint(x: 3.03664, y: 6.825))
                        path.addCurve(to: NSPoint(x: 10.64905, y: 1.73855), control1: NSPoint(x: 4.64549, y: 4.03838), control2: NSPoint(x: 7.45887, y: 2.15854))
                        path.addCurve(to: NSPoint(x: 19.31856, y: 4.68144), control1: NSPoint(x: 13.83923, y: 1.31855), control2: NSPoint(x: 17.04329, y: 2.40618))
                        drawGradient(path, strokeWidth: 1.35 * contrastScale,
                                     colors: [accent.withAlphaComponent((increasedContrast ? 1 : 0.12)).cgColor, accent.withAlphaComponent((increasedContrast ? 1 : 1)).cgColor],
                                     locations: [0, 1], start: NSPoint(x: 3.0366, y: 6.825), end: NSPoint(x: 19.31856, y: 4.68144))
                    }
                }
                do {
                    let path = NSBezierPath()
                    path.move(to: NSPoint(x: 5.44, y: 8.8))
                    path.line(to: NSPoint(x: 6.03, y: 9.09))
                    path.move(to: NSPoint(x: 7.71, y: 6.12))
                    path.line(to: NSPoint(x: 8.1, y: 6.65))
                    path.move(to: NSPoint(x: 11, y: 4.78))
                    path.line(to: NSPoint(x: 11.09, y: 5.43))
                    path.move(to: NSPoint(x: 14.5, y: 5.14))
                    path.line(to: NSPoint(x: 14.27, y: 5.76))
                    path.move(to: NSPoint(x: 17.42, y: 7.12))
                    path.line(to: NSPoint(x: 16.93, y: 7.56))
                    path.move(to: NSPoint(x: 19.08, y: 10.23))
                    path.line(to: NSPoint(x: 18.44, y: 10.39))
                    ink.setStroke()
                    path.lineWidth = 1.25 * contrastScale
                    path.lineCapStyle = .round
                    path.lineJoinStyle = .round
                    path.stroke()
                }
                do {
                    let path = NSBezierPath()
                    path.move(to: NSPoint(x: 10.9, y: 10.7))
                    path.curve(to: NSPoint(x: 17.15, y: 6.85), controlPoint1: NSPoint(x: 12.4, y: 9.89), controlPoint2: NSPoint(x: 14.8, y: 8.24))
                    path.curve(to: NSPoint(x: 13.3, y: 13.1), controlPoint1: NSPoint(x: 15.76, y: 9.2), controlPoint2: NSPoint(x: 14.11, y: 11.6))
                    path.close()
                    accent.setFill()
                    path.fill()
                }
                do {
                    let path = NSBezierPath(ovalIn: NSRect(x: 10.12, y: 10.12, width: 3.76, height: 3.76))
                    accent.setFill()
                    path.fill()
                }
            case .lanes:
                do {
                    let path = NSBezierPath(roundedRect: NSRect(x: 2.2, y: 12.2, width: 4.2, height: 9.8), xRadius: 0.85, yRadius: 0.85)
                    ink.setStroke()
                    path.lineWidth = 1.15 * contrastScale
                    path.lineCapStyle = .round
                    path.lineJoinStyle = .round
                    path.stroke()
                }
                do {
                    let path = CGMutablePath()
                    path.addRoundedRect(in: CGRect(x: 9.6, y: 8.2, width: 4.2, height: 13.8), cornerWidth: 0.85, cornerHeight: 0.85)
                    drawGradient(path, strokeWidth: nil,
                                 colors: [accent.withAlphaComponent((increasedContrast ? 1 : 1)).cgColor, accent.withAlphaComponent((increasedContrast ? 1 : 0.38)).cgColor],
                                 locations: [0, 1], start: NSPoint(x: 0, y: 8.2), end: NSPoint(x: 0, y: 22))
                    stroke(path, color: ink, width: 1.15 * contrastScale)
                }
                do {
                    let path = CGMutablePath()
                    path.addRoundedRect(in: CGRect(x: 17, y: 3.2, width: 4.2, height: 18.8), cornerWidth: 0.85, cornerHeight: 0.85)
                    drawGradient(path, strokeWidth: nil,
                                 colors: [accent.withAlphaComponent((increasedContrast ? 1 : 1)).cgColor, accent.withAlphaComponent((increasedContrast ? 1 : 0.38)).cgColor],
                                 locations: [0, 1], start: NSPoint(x: 0, y: 3.2), end: NSPoint(x: 0, y: 22))
                    stroke(path, color: ink, width: 1.15 * contrastScale)
                }
            case .history:
                do {
                    let path = CGMutablePath()
                    path.move(to: NSPoint(x: 3.1, y: 16.2))
                    path.addLine(to: NSPoint(x: 9, y: 11.1))
                    path.addLine(to: NSPoint(x: 14.4, y: 14.6))
                    path.addLine(to: NSPoint(x: 21, y: 7.2))
                    path.addLine(to: NSPoint(x: 22, y: 7.2))
                    path.addLine(to: NSPoint(x: 22, y: 21.5))
                    path.addLine(to: NSPoint(x: 3.1, y: 21.5))
                    path.closeSubpath()
                    drawGradient(path, strokeWidth: nil,
                                 colors: [accent.withAlphaComponent(0.24).cgColor, accent.withAlphaComponent(0.1).cgColor, accent.withAlphaComponent(0).cgColor],
                                 locations: [0, 0.55, 1], start: NSPoint(x: 0, y: 7.2), end: NSPoint(x: 0, y: 21.5))
                }
                do {
                    let path = NSBezierPath()
                    path.move(to: NSPoint(x: 2, y: 2.5))
                    path.line(to: NSPoint(x: 2, y: 21.5))
                    path.line(to: NSPoint(x: 22, y: 21.5))
                    ink.setStroke()
                    path.lineWidth = 1.4 * contrastScale
                    path.lineCapStyle = .round
                    path.lineJoinStyle = .round
                    path.stroke()
                }
                do {
                    let path = NSBezierPath()
                    path.move(to: NSPoint(x: 3.1, y: 16.2))
                    path.line(to: NSPoint(x: 9, y: 11.1))
                    path.line(to: NSPoint(x: 14.4, y: 14.6))
                    path.line(to: NSPoint(x: 21, y: 7.2))
                    accent.setStroke()
                    path.lineWidth = 1.55 * contrastScale
                    path.lineCapStyle = .round
                    path.lineJoinStyle = .round
                    path.stroke()
                }
                do {
                    let path = NSBezierPath(ovalIn: NSRect(x: 7.1, y: 9.2, width: 3.8, height: 3.8))
                    accent.setFill()
                    path.fill()
                }
                do {
                    let path = NSBezierPath(ovalIn: NSRect(x: 8.2, y: 10.3, width: 1.6, height: 1.6))
                    ink.setFill()
                    path.fill()
                }
                do {
                    let path = NSBezierPath(ovalIn: NSRect(x: 12.5, y: 12.7, width: 3.8, height: 3.8))
                    accent.setFill()
                    path.fill()
                }
                do {
                    let path = NSBezierPath(ovalIn: NSRect(x: 13.6, y: 13.8, width: 1.6, height: 1.6))
                    ink.setFill()
                    path.fill()
                }
                do {
                    let path = NSBezierPath(ovalIn: NSRect(x: 19.1, y: 5.3, width: 3.8, height: 3.8))
                    accent.setFill()
                    path.fill()
                }
                do {
                    let path = NSBezierPath(ovalIn: NSRect(x: 20.2, y: 6.4, width: 1.6, height: 1.6))
                    ink.setFill()
                    path.fill()
                }
            case .runtime:
                do {
                    let path = NSBezierPath(ovalIn: NSRect(x: 1.65, y: 1.65, width: 20.7, height: 20.7))
                    ink.setStroke()
                    path.lineWidth = 1.35 * contrastScale
                    path.lineCapStyle = .round
                    path.lineJoinStyle = .round
                    path.stroke()
                }
                do {
                    if !increasedContrast {
                        let path = CGMutablePath()
                        path.move(to: NSPoint(x: 12, y: 12.3))
                        path.addLine(to: NSPoint(x: 12, y: 5.6))
                        path.addCurve(to: NSPoint(x: 18.7, y: 12.3), control1: NSPoint(x: 15.70031, y: 5.6), control2: NSPoint(x: 18.7, y: 8.59969))
                        path.closeSubpath()
                        drawGradient(path, strokeWidth: nil,
                                     colors: [accent.withAlphaComponent(0).cgColor, accent.withAlphaComponent(0.1).cgColor, accent.withAlphaComponent(0.22).cgColor],
                                     locations: [0, 0.55, 1], start: NSPoint(x: 12, y: 5.6), end: NSPoint(x: 18.7, y: 12.3))
                    }
                }
                do {
                    let path = NSBezierPath()
                    path.move(to: NSPoint(x: 12, y: 5.6))
                    path.line(to: NSPoint(x: 12, y: 12.3))
                    path.line(to: NSPoint(x: 18, y: 12.3))
                    accent.setStroke()
                    path.lineWidth = 1.95 * contrastScale
                    path.lineCapStyle = .round
                    path.lineJoinStyle = .round
                    path.stroke()
                }
            }
            return true
        }
        image.isTemplate = false
        return image
    }

    static func sidebarImage(for icon: SidebarIcon, side: CGFloat, ink: NSColor,
                             accent: NSColor, increasedContrast: Bool) -> NSImage {
        let image = NSImage(size: NSSize(width: side, height: side), flipped: false) { rect in
            NSGraphicsContext.saveGraphicsState()
            defer { NSGraphicsContext.restoreGraphicsState() }
            let transform = NSAffineTransform()
            transform.translateX(by: rect.minX, yBy: rect.maxY)
            transform.scaleX(by: rect.width / 24, yBy: -rect.height / 24)
            transform.concat()
            let contrastScale: CGFloat = increasedContrast ? 1.2 : 1
            switch icon {
            case .general:
                do {
                    let path = NSBezierPath()
                    path.move(to: NSPoint(x: 2.8, y: 5))
                    path.line(to: NSPoint(x: 21.2, y: 5))
                    path.move(to: NSPoint(x: 2.8, y: 12))
                    path.line(to: NSPoint(x: 21.2, y: 12))
                    path.move(to: NSPoint(x: 2.8, y: 19))
                    path.line(to: NSPoint(x: 21.2, y: 19))
                    ink.setStroke()
                    path.lineWidth = 1.35 * contrastScale
                    path.lineCapStyle = .round
                    path.lineJoinStyle = .round
                    path.stroke()
                }
                do {
                    let path = CGMutablePath()
                    path.move(to: NSPoint(x: 2.8, y: 5))
                    path.addLine(to: NSPoint(x: 7.2, y: 5))
                    path.move(to: NSPoint(x: 2.8, y: 12))
                    path.addLine(to: NSPoint(x: 16.8, y: 12))
                    path.move(to: NSPoint(x: 2.8, y: 19))
                    path.addLine(to: NSPoint(x: 11.4, y: 19))
                    drawGradient(path, strokeWidth: 1.45 * contrastScale,
                                 colors: [accent.withAlphaComponent((increasedContrast ? 1 : 0.12)).cgColor, accent.withAlphaComponent((increasedContrast ? 1 : 1)).cgColor],
                                 locations: [0, 1], start: NSPoint(x: 2.8, y: 0), end: NSPoint(x: 18, y: 0))
                }
                do {
                    let path = NSBezierPath(ovalIn: NSRect(x: 4.95, y: 2.75, width: 4.5, height: 4.5))
                    accent.setFill()
                    path.fill()
                    ink.setStroke()
                    path.lineWidth = 1.2 * contrastScale
                    path.lineCapStyle = .round
                    path.lineJoinStyle = .round
                    path.stroke()
                }
                do {
                    let path = NSBezierPath(ovalIn: NSRect(x: 14.55, y: 9.75, width: 4.5, height: 4.5))
                    accent.setFill()
                    path.fill()
                    ink.setStroke()
                    path.lineWidth = 1.2 * contrastScale
                    path.lineCapStyle = .round
                    path.lineJoinStyle = .round
                    path.stroke()
                }
                do {
                    let path = NSBezierPath(ovalIn: NSRect(x: 9.15, y: 16.75, width: 4.5, height: 4.5))
                    accent.setFill()
                    path.fill()
                    ink.setStroke()
                    path.lineWidth = 1.2 * contrastScale
                    path.lineCapStyle = .round
                    path.lineJoinStyle = .round
                    path.stroke()
                }
            case .display:
                do {
                    if !increasedContrast {
                        let path = CGMutablePath()
                        path.addRoundedRect(in: CGRect(x: 3.4, y: 8.3, width: 17.2, height: 11.1), cornerWidth: 1.6, cornerHeight: 1.6)
                        drawGradient(path, strokeWidth: nil,
                                     colors: [accent.withAlphaComponent(0.03).cgColor, accent.withAlphaComponent(0.24).cgColor],
                                     locations: [0, 1], start: NSPoint(x: 0, y: 8.3), end: NSPoint(x: 0, y: 19.4))
                    }
                }
                do {
                    let path = NSBezierPath(roundedRect: NSRect(x: 2.7, y: 3.8, width: 18.6, height: 16.4), xRadius: 2.4, yRadius: 2.4)
                    ink.setStroke()
                    path.lineWidth = 1.35 * contrastScale
                    path.lineCapStyle = .round
                    path.lineJoinStyle = .round
                    path.stroke()
                }
                do {
                    let path = NSBezierPath()
                    path.move(to: NSPoint(x: 3.1, y: 8.3))
                    path.line(to: NSPoint(x: 20.9, y: 8.3))
                    ink.setStroke()
                    path.lineWidth = 1.1 * contrastScale
                    path.lineCapStyle = .round
                    path.lineJoinStyle = .round
                    path.stroke()
                }
                do {
                    let path = NSBezierPath()
                    path.move(to: NSPoint(x: 15.8, y: 6.1))
                    path.line(to: NSPoint(x: 18.6, y: 6.1))
                    accent.setStroke()
                    path.lineWidth = 1.45 * contrastScale
                    path.lineCapStyle = .round
                    path.lineJoinStyle = .round
                    path.stroke()
                }
            case .modules:
                do {
                    let path = NSBezierPath(roundedRect: NSRect(x: 3, y: 3, width: 7, height: 7), xRadius: 1.5, yRadius: 1.5)
                    ink.setStroke()
                    path.lineWidth = 1.35 * contrastScale
                    path.lineCapStyle = .round
                    path.lineJoinStyle = .round
                    path.stroke()
                }
                do {
                    let path = CGMutablePath()
                    path.addRoundedRect(in: CGRect(x: 14, y: 3, width: 7, height: 7), cornerWidth: 1.5, cornerHeight: 1.5)
                    drawGradient(path, strokeWidth: nil,
                                 colors: [accent.withAlphaComponent((increasedContrast ? 1 : 1)).cgColor, accent.withAlphaComponent((increasedContrast ? 1 : 0.38)).cgColor],
                                 locations: [0, 1], start: NSPoint(x: 0, y: 3), end: NSPoint(x: 0, y: 10))
                    stroke(path, color: ink, width: 1.35 * contrastScale)
                }
                do {
                    let path = NSBezierPath(roundedRect: NSRect(x: 3, y: 14, width: 7, height: 7), xRadius: 1.5, yRadius: 1.5)
                    ink.setStroke()
                    path.lineWidth = 1.35 * contrastScale
                    path.lineCapStyle = .round
                    path.lineJoinStyle = .round
                    path.stroke()
                }
                do {
                    let path = NSBezierPath(roundedRect: NSRect(x: 14, y: 14, width: 7, height: 7), xRadius: 1.5, yRadius: 1.5)
                    ink.setStroke()
                    path.lineWidth = 1.35 * contrastScale
                    path.lineCapStyle = .round
                    path.lineJoinStyle = .round
                    path.stroke()
                }
            }
            return true
        }
        image.isTemplate = false
        return image
    }

    static func generalImage(for icon: GeneralIcon, side: CGFloat, ink: NSColor,
                             accent: NSColor, increasedContrast: Bool) -> NSImage {
        let image = NSImage(size: NSSize(width: side, height: side), flipped: false) { rect in
            NSGraphicsContext.saveGraphicsState()
            defer { NSGraphicsContext.restoreGraphicsState() }
            let transform = NSAffineTransform()
            transform.translateX(by: rect.minX, yBy: rect.maxY)
            transform.scaleX(by: rect.width / 24, yBy: -rect.height / 24)
            transform.concat()
            let contrastScale: CGFloat = increasedContrast ? 1.2 : 1
            switch icon {
            case .login:
                do {
                    let path = NSBezierPath()
                    path.move(to: NSPoint(x: 18.2, y: 6.2))
                    path.curve(to: NSPoint(x: 21.2, y: 12.8), controlPoint1: NSPoint(x: 20.2, y: 7.9), controlPoint2: NSPoint(x: 21.2, y: 10.1))
                    path.curve(to: NSPoint(x: 12, y: 22), controlPoint1: NSPoint(x: 21.2, y: 17.9), controlPoint2: NSPoint(x: 17.1, y: 22))
                    path.curve(to: NSPoint(x: 2.8, y: 12.8), controlPoint1: NSPoint(x: 6.9, y: 22), controlPoint2: NSPoint(x: 2.8, y: 17.9))
                    path.curve(to: NSPoint(x: 5.8, y: 6.2), controlPoint1: NSPoint(x: 2.8, y: 10.1), controlPoint2: NSPoint(x: 3.8, y: 7.9))
                    ink.setStroke()
                    path.lineWidth = 1.35 * contrastScale
                    path.lineCapStyle = .round
                    path.lineJoinStyle = .round
                    path.stroke()
                }
                do {
                    if !increasedContrast {
                        let path = CGMutablePath()
                        path.move(to: NSPoint(x: 5.8, y: 6.2))
                        path.addCurve(to: NSPoint(x: 2.8, y: 12.8), control1: NSPoint(x: 3.8, y: 7.9), control2: NSPoint(x: 2.8, y: 10.1))
                        path.addCurve(to: NSPoint(x: 12, y: 22), control1: NSPoint(x: 2.8, y: 17.9), control2: NSPoint(x: 6.9, y: 22))
                        drawGradient(path, strokeWidth: 1.35 * contrastScale,
                                     colors: [accent.withAlphaComponent((increasedContrast ? 1 : 0.12)).cgColor, accent.withAlphaComponent((increasedContrast ? 1 : 0.7)).cgColor],
                                     locations: [0, 1], start: NSPoint(x: 5.8, y: 6.2), end: NSPoint(x: 12, y: 21.2))
                    }
                }
                do {
                    let path = NSBezierPath()
                    path.move(to: NSPoint(x: 12, y: 2.5))
                    path.line(to: NSPoint(x: 12, y: 11.3))
                    accent.setStroke()
                    path.lineWidth = 1.7 * contrastScale
                    path.lineCapStyle = .round
                    path.lineJoinStyle = .round
                    path.stroke()
                }
            case .battery:
                do {
                    if !increasedContrast {
                        let path = CGMutablePath()
                        path.addRoundedRect(in: CGRect(x: 3.4, y: 8.8, width: 17.2, height: 10.6), cornerWidth: 1.6, cornerHeight: 1.6)
                        drawGradient(path, strokeWidth: nil,
                                     colors: [accent.withAlphaComponent(0.02).cgColor, accent.withAlphaComponent(0.17).cgColor],
                                     locations: [0, 1], start: NSPoint(x: 0, y: 8.8), end: NSPoint(x: 0, y: 19.4))
                    }
                }
                do {
                    let path = NSBezierPath(roundedRect: NSRect(x: 2.7, y: 3.8, width: 18.6, height: 16.4), xRadius: 2.4, yRadius: 2.4)
                    ink.setStroke()
                    path.lineWidth = 1.35 * contrastScale
                    path.lineCapStyle = .round
                    path.lineJoinStyle = .round
                    path.stroke()
                }
                do {
                    let path = NSBezierPath()
                    path.move(to: NSPoint(x: 3.1, y: 8.8))
                    path.line(to: NSPoint(x: 20.9, y: 8.8))
                    ink.setStroke()
                    path.lineWidth = 1.1 * contrastScale
                    path.lineCapStyle = .round
                    path.lineJoinStyle = .round
                    path.stroke()
                }
                do {
                    let path = NSBezierPath(roundedRect: NSRect(x: 13.3, y: 5.3, width: 4.9, height: 2), xRadius: 0.5, yRadius: 0.5)
                    accent.setFill()
                    path.fill()
                }
                do {
                    let path = NSBezierPath()
                    path.move(to: NSPoint(x: 19.1, y: 5.9))
                    path.line(to: NSPoint(x: 19.1, y: 6.7))
                    accent.setStroke()
                    path.lineWidth = 0.8 * contrastScale
                    path.lineCapStyle = .round
                    path.lineJoinStyle = .round
                    path.stroke()
                }
            case .update:
                do {
                    if !increasedContrast {
                        let path = CGMutablePath()
                        path.addEllipse(in: CGRect(x: 2.6, y: 2.6, width: 18.8, height: 18.8))
                        drawGradient(path, strokeWidth: nil,
                                     colors: [accent.withAlphaComponent(0).cgColor, accent.withAlphaComponent(0.2).cgColor],
                                     locations: [0, 1], start: NSPoint(x: 0, y: 6), end: NSPoint(x: 0, y: 21.4))
                    }
                }
                do {
                    let path = NSBezierPath(ovalIn: NSRect(x: 2.6, y: 2.6, width: 18.8, height: 18.8))
                    ink.setStroke()
                    path.lineWidth = 1.35 * contrastScale
                    path.lineCapStyle = .round
                    path.lineJoinStyle = .round
                    path.stroke()
                }
                do {
                    let path = NSBezierPath()
                    path.move(to: NSPoint(x: 12, y: 6.6))
                    path.line(to: NSPoint(x: 12, y: 17.1))
                    path.move(to: NSPoint(x: 8.4, y: 13.5))
                    path.line(to: NSPoint(x: 12, y: 17.1))
                    path.line(to: NSPoint(x: 15.6, y: 13.5))
                    accent.setStroke()
                    path.lineWidth = 1.65 * contrastScale
                    path.lineCapStyle = .round
                    path.lineJoinStyle = .round
                    path.stroke()
                }
            case .automatic:
                do {
                    let path = NSBezierPath()
                    path.move(to: NSPoint(x: 18.6, y: 5.9))
                    path.curve(to: NSPoint(x: 17.8, y: 19), controlPoint1: NSPoint(x: 22, y: 9.6), controlPoint2: NSPoint(x: 21.7, y: 15.6))
                    path.curve(to: NSPoint(x: 4.9, y: 17.3), controlPoint1: NSPoint(x: 13.9, y: 22.3), controlPoint2: NSPoint(x: 8, y: 21.3))
                    path.curve(to: NSPoint(x: 6.9, y: 4.8), controlPoint1: NSPoint(x: 1.8, y: 13.2), controlPoint2: NSPoint(x: 2.8, y: 7.7))
                    path.curve(to: NSPoint(x: 18.6, y: 5.9), controlPoint1: NSPoint(x: 10.6, y: 2.2), controlPoint2: NSPoint(x: 15.6, y: 2.9))
                    ink.setStroke()
                    path.lineWidth = 1.35 * contrastScale
                    path.lineCapStyle = .round
                    path.lineJoinStyle = .round
                    path.stroke()
                }
                do {
                    if !increasedContrast {
                        let path = CGMutablePath()
                        path.move(to: NSPoint(x: 6.9, y: 4.8))
                        path.addCurve(to: NSPoint(x: 18.6, y: 5.9), control1: NSPoint(x: 10.6, y: 2.2), control2: NSPoint(x: 15.6, y: 2.9))
                        drawGradient(path, strokeWidth: 1.35 * contrastScale,
                                     colors: [accent.withAlphaComponent((increasedContrast ? 1 : 0.12)).cgColor, accent.withAlphaComponent((increasedContrast ? 1 : 1)).cgColor],
                                     locations: [0, 1], start: NSPoint(x: 6.9, y: 4.8), end: NSPoint(x: 18.6, y: 5.9))
                    }
                }
                do {
                    let path = NSBezierPath()
                    path.move(to: NSPoint(x: 18.4, y: 1.5))
                    path.line(to: NSPoint(x: 18.6, y: 5.9))
                    path.line(to: NSPoint(x: 14.2, y: 5.7))
                    accent.setStroke()
                    path.lineWidth = 1.65 * contrastScale
                    path.lineCapStyle = .round
                    path.lineJoinStyle = .round
                    path.stroke()
                }
            case .feedback:
                do {
                    let path = NSBezierPath()
                    path.move(to: NSPoint(x: 8.4, y: 13.8))
                    path.line(to: NSPoint(x: 7.2, y: 13.8))
                    path.line(to: NSPoint(x: 5, y: 16.2))
                    path.line(to: NSPoint(x: 5, y: 13.8))
                    path.line(to: NSPoint(x: 4.8, y: 13.8))
                    path.curve(to: NSPoint(x: 2.6, y: 11.6), controlPoint1: NSPoint(x: 3.4, y: 13.8), controlPoint2: NSPoint(x: 2.6, y: 13))
                    path.line(to: NSPoint(x: 2.6, y: 5.8))
                    path.curve(to: NSPoint(x: 4.8, y: 3.6), controlPoint1: NSPoint(x: 2.6, y: 4.4), controlPoint2: NSPoint(x: 3.4, y: 3.6))
                    path.line(to: NSPoint(x: 13.6, y: 3.6))
                    path.curve(to: NSPoint(x: 15.8, y: 5.8), controlPoint1: NSPoint(x: 15, y: 3.6), controlPoint2: NSPoint(x: 15.8, y: 4.4))
                    path.line(to: NSPoint(x: 15.8, y: 7.2))
                    ink.setStroke()
                    path.lineWidth = 1.25 * contrastScale
                    path.lineCapStyle = .round
                    path.lineJoinStyle = .round
                    path.stroke()
                }
                do {
                    if !increasedContrast {
                        let path = CGMutablePath()
                        path.move(to: NSPoint(x: 11.2, y: 8))
                        path.addLine(to: NSPoint(x: 19, y: 8))
                        path.addCurve(to: NSPoint(x: 21.2, y: 10.2), control1: NSPoint(x: 20.4, y: 8), control2: NSPoint(x: 21.2, y: 8.8))
                        path.addLine(to: NSPoint(x: 21.2, y: 15.4))
                        path.addCurve(to: NSPoint(x: 19, y: 17.6), control1: NSPoint(x: 21.2, y: 16.8), control2: NSPoint(x: 20.4, y: 17.6))
                        path.addLine(to: NSPoint(x: 18, y: 17.6))
                        path.addLine(to: NSPoint(x: 18, y: 20.3))
                        path.addLine(to: NSPoint(x: 14.6, y: 17.6))
                        path.addLine(to: NSPoint(x: 11.2, y: 17.6))
                        path.addCurve(to: NSPoint(x: 9, y: 15.4), control1: NSPoint(x: 9.8, y: 17.6), control2: NSPoint(x: 9, y: 16.8))
                        path.addLine(to: NSPoint(x: 9, y: 10.2))
                        path.addCurve(to: NSPoint(x: 11.2, y: 8), control1: NSPoint(x: 9, y: 8.8), control2: NSPoint(x: 9.8, y: 8))
                        path.closeSubpath()
                        drawGradient(path, strokeWidth: nil,
                                     colors: [accent.withAlphaComponent(0.04).cgColor, accent.withAlphaComponent(0.26).cgColor],
                                     locations: [0, 1], start: NSPoint(x: 0, y: 8), end: NSPoint(x: 0, y: 20.3))
                    }
                }
                do {
                    let path = NSBezierPath()
                    path.move(to: NSPoint(x: 11.2, y: 8))
                    path.line(to: NSPoint(x: 19, y: 8))
                    path.curve(to: NSPoint(x: 21.2, y: 10.2), controlPoint1: NSPoint(x: 20.4, y: 8), controlPoint2: NSPoint(x: 21.2, y: 8.8))
                    path.line(to: NSPoint(x: 21.2, y: 15.4))
                    path.curve(to: NSPoint(x: 19, y: 17.6), controlPoint1: NSPoint(x: 21.2, y: 16.8), controlPoint2: NSPoint(x: 20.4, y: 17.6))
                    path.line(to: NSPoint(x: 18, y: 17.6))
                    path.line(to: NSPoint(x: 18, y: 20.3))
                    path.line(to: NSPoint(x: 14.6, y: 17.6))
                    path.line(to: NSPoint(x: 11.2, y: 17.6))
                    path.curve(to: NSPoint(x: 9, y: 15.4), controlPoint1: NSPoint(x: 9.8, y: 17.6), controlPoint2: NSPoint(x: 9, y: 16.8))
                    path.line(to: NSPoint(x: 9, y: 10.2))
                    path.curve(to: NSPoint(x: 11.2, y: 8), controlPoint1: NSPoint(x: 9, y: 8.8), controlPoint2: NSPoint(x: 9.8, y: 8))
                    path.close()
                    ink.setStroke()
                    path.lineWidth = 1.25 * contrastScale
                    path.lineCapStyle = .round
                    path.lineJoinStyle = .round
                    path.stroke()
                }
                do {
                    let path = NSBezierPath(ovalIn: NSRect(x: 11.6, y: 12.1, width: 1.2, height: 1.2))
                    accent.setFill()
                    path.fill()
                }
                do {
                    let path = NSBezierPath(ovalIn: NSRect(x: 14.6, y: 12.1, width: 1.2, height: 1.2))
                    accent.setFill()
                    path.fill()
                }
                do {
                    let path = NSBezierPath(ovalIn: NSRect(x: 17.6, y: 12.1, width: 1.2, height: 1.2))
                    accent.setFill()
                    path.fill()
                }
            }
            return true
        }
        image.isTemplate = false
        return image
    }

    static func powerImage(for icon: PowerIcon, side: CGFloat, inset: CGFloat = 0,
                           chargeFraction: CGFloat = 1, ink: NSColor, accent: NSColor,
                           increasedContrast: Bool) -> NSImage {
        let image = NSImage(size: NSSize(width: side, height: side), flipped: false) { rect in
            NSGraphicsContext.saveGraphicsState()
            defer { NSGraphicsContext.restoreGraphicsState() }
            let transform = NSAffineTransform()
            transform.translateX(by: rect.minX + inset, yBy: rect.maxY - inset)
            transform.scaleX(by: (rect.width - 2 * inset) / 24, yBy: -(rect.height - 2 * inset) / 24)
            transform.concat()
            let contrastScale: CGFloat = increasedContrast ? 1.2 : 1
            let fillFraction = min(max(chargeFraction, 0), 1)
            switch icon {
            case .adapter:
                do {
                    let path = NSBezierPath()
                    path.move(to: NSPoint(x: 6.8537169, y: 17.776174))
                    path.line(to: NSPoint(x: 3.7290562, y: 21.5))
                    accent.setStroke()
                    path.lineWidth = 1.5954409 * contrastScale
                    path.lineCapStyle = .round
                    path.lineJoinStyle = .round
                    path.stroke()
                }
                do {
                    let path = NSBezierPath()
                    path.move(to: NSPoint(x: 16.222477, y: 2.5))
                    path.line(to: NSPoint(x: 12.809386, y: 6.5675633))
                    path.move(to: NSPoint(x: 20.270944, y: 5.897067))
                    path.line(to: NSPoint(x: 16.857853, y: 9.9646303))
                    accent.setStroke()
                    path.lineWidth = 1.5954409 * contrastScale
                    path.lineCapStyle = .round
                    path.lineJoinStyle = .round
                    path.stroke()
                }
                do {
                    if !increasedContrast {
                        let path = CGMutablePath()
                        path.move(to: NSPoint(x: 11.256851, y: 6.0133019))
                        path.addLine(to: NSPoint(x: 17.673289, y: 11.397333))
                        path.addCurve(to: NSPoint(x: 17.747032, y: 12.240223), control1: NSPoint(x: 17.926432, y: 11.609745), control2: NSPoint(x: 17.959445, y: 11.987079))
                        path.addLine(to: NSPoint(x: 13.965392, y: 16.747007))
                        path.addCurve(to: NSPoint(x: 7.2222666, y: 17.336954), control1: NSPoint(x: 12.266217, y: 18.772004), control2: NSPoint(x: 9.2472639, y: 19.036128))
                        path.addCurve(to: NSPoint(x: 6.6323196, y: 10.593829), control1: NSPoint(x: 5.1972694, y: 15.63778), control2: NSPoint(x: 4.9331452, y: 12.618826))
                        path.addLine(to: NSPoint(x: 10.41396, y: 6.0870453))
                        path.addCurve(to: NSPoint(x: 11.256851, y: 6.0133019), control1: NSPoint(x: 10.626373, y: 5.8339015), control2: NSPoint(x: 11.003707, y: 5.8008891))
                        path.closeSubpath()
                        drawGradient(path, strokeWidth: nil,
                                     colors: [accent.withAlphaComponent(0.02).cgColor, accent.withAlphaComponent(0.18).cgColor],
                                     locations: [0, 1], start: NSPoint(x: 14.46507, y: 8.7053173), end: NSPoint(x: 7.2222666, y: 17.336954))
                    }
                }
                do {
                    let path = NSBezierPath()
                    path.move(to: NSPoint(x: 11.256851, y: 6.0133019))
                    path.line(to: NSPoint(x: 17.673289, y: 11.397333))
                    path.curve(to: NSPoint(x: 17.747032, y: 12.240223), controlPoint1: NSPoint(x: 17.926432, y: 11.609745), controlPoint2: NSPoint(x: 17.959445, y: 11.987079))
                    path.line(to: NSPoint(x: 13.965392, y: 16.747007))
                    path.curve(to: NSPoint(x: 7.2222666, y: 17.336954), controlPoint1: NSPoint(x: 12.266217, y: 18.772004), controlPoint2: NSPoint(x: 9.2472639, y: 19.036128))
                    path.curve(to: NSPoint(x: 6.6323196, y: 10.593829), controlPoint1: NSPoint(x: 5.1972694, y: 15.63778), controlPoint2: NSPoint(x: 4.9331452, y: 12.618826))
                    path.line(to: NSPoint(x: 10.41396, y: 6.0870453))
                    path.curve(to: NSPoint(x: 11.256851, y: 6.0133019), controlPoint1: NSPoint(x: 10.626373, y: 5.8339015), controlPoint2: NSPoint(x: 11.003707, y: 5.8008891))
                    path.close()
                    ink.setStroke()
                    path.lineWidth = 1.1467232 * contrastScale
                    path.lineCapStyle = .round
                    path.lineJoinStyle = .round
                    path.stroke()
                }
            case .disconnected:
                do {
                    let path = NSBezierPath()
                    path.move(to: NSPoint(x: 6.8537169, y: 17.776174))
                    path.line(to: NSPoint(x: 3.7290562, y: 21.5))
                    ink.setStroke()
                    path.lineWidth = 1.5954409 * contrastScale
                    path.lineCapStyle = .round
                    path.lineJoinStyle = .round
                    path.stroke()
                }
                do {
                    let path = NSBezierPath()
                    path.move(to: NSPoint(x: 16.222477, y: 2.5))
                    path.line(to: NSPoint(x: 12.809386, y: 6.5675633))
                    path.move(to: NSPoint(x: 20.270944, y: 5.897067))
                    path.line(to: NSPoint(x: 16.857853, y: 9.9646303))
                    ink.setStroke()
                    path.lineWidth = 1.5954409 * contrastScale
                    path.lineCapStyle = .round
                    path.lineJoinStyle = .round
                    path.stroke()
                }
                do {
                    if !increasedContrast {
                        let path = CGMutablePath()
                        path.move(to: NSPoint(x: 11.256851, y: 6.0133019))
                        path.addLine(to: NSPoint(x: 17.673289, y: 11.397333))
                        path.addCurve(to: NSPoint(x: 17.747032, y: 12.240223), control1: NSPoint(x: 17.926432, y: 11.609745), control2: NSPoint(x: 17.959445, y: 11.987079))
                        path.addLine(to: NSPoint(x: 13.965392, y: 16.747007))
                        path.addCurve(to: NSPoint(x: 7.2222666, y: 17.336954), control1: NSPoint(x: 12.266217, y: 18.772004), control2: NSPoint(x: 9.2472639, y: 19.036128))
                        path.addCurve(to: NSPoint(x: 6.6323196, y: 10.593829), control1: NSPoint(x: 5.1972694, y: 15.63778), control2: NSPoint(x: 4.9331452, y: 12.618826))
                        path.addLine(to: NSPoint(x: 10.41396, y: 6.0870453))
                        path.addCurve(to: NSPoint(x: 11.256851, y: 6.0133019), control1: NSPoint(x: 10.626373, y: 5.8339015), control2: NSPoint(x: 11.003707, y: 5.8008891))
                        path.closeSubpath()
                        drawGradient(path, strokeWidth: nil,
                                     colors: [ink.withAlphaComponent(0.02).cgColor, ink.withAlphaComponent(0.08).cgColor],
                                     locations: [0, 1], start: NSPoint(x: 14.46507, y: 8.7053173), end: NSPoint(x: 7.2222666, y: 17.336954))
                    }
                }
                do {
                    let path = NSBezierPath()
                    path.move(to: NSPoint(x: 11.256851, y: 6.0133019))
                    path.line(to: NSPoint(x: 17.673289, y: 11.397333))
                    path.curve(to: NSPoint(x: 17.747032, y: 12.240223), controlPoint1: NSPoint(x: 17.926432, y: 11.609745), controlPoint2: NSPoint(x: 17.959445, y: 11.987079))
                    path.line(to: NSPoint(x: 13.965392, y: 16.747007))
                    path.curve(to: NSPoint(x: 7.2222666, y: 17.336954), controlPoint1: NSPoint(x: 12.266217, y: 18.772004), controlPoint2: NSPoint(x: 9.2472639, y: 19.036128))
                    path.curve(to: NSPoint(x: 6.6323196, y: 10.593829), controlPoint1: NSPoint(x: 5.1972694, y: 15.63778), controlPoint2: NSPoint(x: 4.9331452, y: 12.618826))
                    path.line(to: NSPoint(x: 10.41396, y: 6.0870453))
                    path.curve(to: NSPoint(x: 11.256851, y: 6.0133019), controlPoint1: NSPoint(x: 10.626373, y: 5.8339015), controlPoint2: NSPoint(x: 11.003707, y: 5.8008891))
                    path.close()
                    ink.setStroke()
                    path.lineWidth = 1.1467232 * contrastScale
                    path.lineCapStyle = .round
                    path.lineJoinStyle = .round
                    path.stroke()
                }
            case .system:
                do {
                    let path = NSBezierPath()
                    path.move(to: NSPoint(x: 8, y: 3))
                    path.line(to: NSPoint(x: 8, y: 5.5))
                    path.move(to: NSPoint(x: 12, y: 3))
                    path.line(to: NSPoint(x: 12, y: 5.5))
                    path.move(to: NSPoint(x: 16, y: 3))
                    path.line(to: NSPoint(x: 16, y: 5.5))
                    path.move(to: NSPoint(x: 8, y: 18.5))
                    path.line(to: NSPoint(x: 8, y: 21))
                    path.move(to: NSPoint(x: 12, y: 18.5))
                    path.line(to: NSPoint(x: 12, y: 21))
                    path.move(to: NSPoint(x: 16, y: 18.5))
                    path.line(to: NSPoint(x: 16, y: 21))
                    path.move(to: NSPoint(x: 3, y: 8))
                    path.line(to: NSPoint(x: 5.5, y: 8))
                    path.move(to: NSPoint(x: 3, y: 12))
                    path.line(to: NSPoint(x: 5.5, y: 12))
                    path.move(to: NSPoint(x: 3, y: 16))
                    path.line(to: NSPoint(x: 5.5, y: 16))
                    path.move(to: NSPoint(x: 18.5, y: 8))
                    path.line(to: NSPoint(x: 21, y: 8))
                    path.move(to: NSPoint(x: 18.5, y: 12))
                    path.line(to: NSPoint(x: 21, y: 12))
                    path.move(to: NSPoint(x: 18.5, y: 16))
                    path.line(to: NSPoint(x: 21, y: 16))
                    ink.setStroke()
                    path.lineWidth = 1.35 * contrastScale
                    path.lineCapStyle = .round
                    path.lineJoinStyle = .round
                    path.stroke()
                }
                do {
                    let path = NSBezierPath(roundedRect: NSRect(x: 5.5, y: 5.5, width: 13, height: 13), xRadius: 2.6, yRadius: 2.6)
                    ink.setStroke()
                    path.lineWidth = 1.35 * contrastScale
                    path.lineCapStyle = .round
                    path.lineJoinStyle = .round
                    path.stroke()
                }
                do {
                    if !increasedContrast {
                        let path = CGMutablePath()
                        path.addRoundedRect(in: CGRect(x: 8.5, y: 8.5, width: 7, height: 7), cornerWidth: 1.4, cornerHeight: 1.4)
                        drawGradient(path, strokeWidth: nil,
                                     colors: [accent.withAlphaComponent(0.08).cgColor, accent.withAlphaComponent(0.44).cgColor],
                                     locations: [0, 1], start: NSPoint(x: 8.5, y: 8.5), end: NSPoint(x: 15.5, y: 15.5))
                    }
                }
                do {
                    let path = NSBezierPath(roundedRect: NSRect(x: 8.5, y: 8.5, width: 7, height: 7), xRadius: 1.4, yRadius: 1.4)
                    accent.setStroke()
                    path.lineWidth = 1.2 * contrastScale
                    path.lineCapStyle = .round
                    path.lineJoinStyle = .round
                    path.stroke()
                }
            case .battery:
                do {
                    let path = NSBezierPath(roundedRect: NSRect(x: 2.5, y: 6.2, width: 17.2, height: 11.6), xRadius: 2.5, yRadius: 2.5)
                    ink.setStroke()
                    path.lineWidth = 1.3 * contrastScale
                    path.lineCapStyle = .round
                    path.lineJoinStyle = .round
                    path.stroke()
                }
                do {
                    let path = NSBezierPath()
                    path.move(to: NSPoint(x: 21.3, y: 10.4))
                    path.line(to: NSPoint(x: 21.3, y: 13.6))
                    accent.setStroke()
                    path.lineWidth = 1.3 * contrastScale
                    path.lineCapStyle = .round
                    path.lineJoinStyle = .round
                    path.stroke()
                }
                do {
                    let path = CGMutablePath()
                    path.addRoundedRect(in: CGRect(x: 4.5, y: 8.1, width: 13.2 * fillFraction, height: 7.8), cornerWidth: 1.1, cornerHeight: 1.1)
                    drawGradient(path, strokeWidth: nil,
                                 colors: [accent.withAlphaComponent((increasedContrast ? 1 : 0.8)).cgColor, accent.withAlphaComponent((increasedContrast ? 1 : 0.35)).cgColor],
                                 locations: [0, 1], start: NSPoint(x: 4.5, y: 8.1), end: NSPoint(x: 18, y: 15.9))
                }
            case .charging:
                do {
                    let path = NSBezierPath(roundedRect: NSRect(x: 2.5, y: 6.2, width: 17.2, height: 11.6), xRadius: 2.5, yRadius: 2.5)
                    ink.setStroke()
                    path.lineWidth = 1.3 * contrastScale
                    path.lineCapStyle = .round
                    path.lineJoinStyle = .round
                    path.stroke()
                }
                do {
                    let path = NSBezierPath()
                    path.move(to: NSPoint(x: 21.3, y: 10.4))
                    path.line(to: NSPoint(x: 21.3, y: 13.6))
                    accent.setStroke()
                    path.lineWidth = 1.3 * contrastScale
                    path.lineCapStyle = .round
                    path.lineJoinStyle = .round
                    path.stroke()
                }
                do {
                    if !increasedContrast {
                        let path = CGMutablePath()
                        path.addRoundedRect(in: CGRect(x: 4.5, y: 8.1, width: 13.2, height: 7.8), cornerWidth: 1.1, cornerHeight: 1.1)
                        drawGradient(path, strokeWidth: nil,
                                     colors: [accent.withAlphaComponent(0.42).cgColor, accent.withAlphaComponent(0.12).cgColor],
                                     locations: [0, 1], start: NSPoint(x: 4.5, y: 8.1), end: NSPoint(x: 18, y: 15.9))
                    }
                }
                do {
                    let path = NSBezierPath()
                    path.move(to: NSPoint(x: 12.9, y: 6.5))
                    path.line(to: NSPoint(x: 8.9, y: 12.6))
                    path.line(to: NSPoint(x: 11.5, y: 12.6))
                    path.line(to: NSPoint(x: 10.7, y: 17.5))
                    path.line(to: NSPoint(x: 15.6, y: 10.9))
                    path.line(to: NSPoint(x: 12.8, y: 10.9))
                    path.close()
                    accent.setFill()
                    path.fill()
                }
            }
            return true
        }
        image.isTemplate = false
        return image
    }

    private static func drawGradient(_ path: CGPath, strokeWidth: CGFloat?,
                                     colors: [CGColor], locations: [CGFloat],
                                     start: CGPoint, end: CGPoint) {
        guard let context = NSGraphicsContext.current?.cgContext,
              let space = CGColorSpace(name: CGColorSpace.sRGB),
              let gradient = CGGradient(colorsSpace: space, colors: colors as CFArray,
                                        locations: locations) else { return }
        context.saveGState()
        defer { context.restoreGState() }
        context.addPath(path)
        if let strokeWidth {
            context.setLineWidth(strokeWidth)
            context.setLineCap(.round)
            context.setLineJoin(.round)
            context.replacePathWithStrokedPath()
        }
        context.clip()
        context.drawLinearGradient(gradient, start: start, end: end,
                                   options: [.drawsBeforeStartLocation, .drawsAfterEndLocation])
    }

    private static func stroke(_ path: CGPath, color: NSColor, width: CGFloat) {
        guard let context = NSGraphicsContext.current?.cgContext else { return }
        context.saveGState()
        defer { context.restoreGState() }
        context.addPath(path)
        context.setStrokeColor(color.cgColor)
        context.setLineWidth(width)
        context.setLineCap(.round)
        context.setLineJoin(.round)
        context.strokePath()
    }
}
