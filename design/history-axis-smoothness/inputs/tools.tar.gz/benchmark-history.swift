import AppKit

enum HistoryProfiling {
    static var mutablePaths = 0
    static var rectanglePaths = 0
    static var pathsCalls = 0
    static var fillPathCalls = 0
    static var decodedPaths = 0
    static func path() -> CGMutablePath { mutablePaths += 1; return CGMutablePath() }
    static func rectPath(rect: CGRect, transform: UnsafePointer<CGAffineTransform>?) -> CGPath { rectanglePaths += 1; return CGPath(rect: rect, transform: transform) }
    static func reset() { mutablePaths = 0; rectanglePaths = 0; pathsCalls = 0; fillPathCalls = 0; decodedPaths = 0 }
    static var counts: [String: Int] { ["mutablePaths": mutablePaths, "rectanglePaths": rectanglePaths, "pathsCalls": pathsCalls, "fillPathCalls": fillPathCalls, "decodedPaths": decodedPaths] }
}

// Call-boundary timings use unmodified production files, optimized with -O.
// The ordinary application run loop owns presentation between measurements.
@main private enum BenchmarkMain {
    static func main() {
        guard CommandLine.arguments.count == 3, let count = Int(CommandLine.arguments[2]), count > 0 else { exit(64) }
        let app = NSApplication.shared
        app.setActivationPolicy(.accessory)
        let probe = HistoryBenchmark(output: URL(fileURLWithPath: CommandLine.arguments[1]), count: count)
        app.delegate = probe
        withExtendedLifetime(probe) { app.run() }
    }
}

private final class HistoryBenchmark: NSObject, NSApplicationDelegate {
    private let output: URL
    private let count: Int
    private let warmups = 8
    private let names = ["ordinary-scroll", "scale-expansion", "scale-contraction", "interrupted-scale", "same-input-noop"]
    private var scenario = 0
    private var round = 0
    private var stage = 0
    private var phaseAt = 0.0
    private var window: NSWindow!
    private var fixture: HistoryView!
    private var timer: Timer?
    private var activity: NSObjectProtocol?
    private var values: [Double] = []
    private var times: [TimeInterval] = []
    private var records: [[String: Any]] = []
    private var pending: [String: Any] = [:]
    private var noopScaleAfterMeasurement: Double?
    private var finished = false

    init(output: URL, count: Int) { self.output = output; self.count = count }
    func applicationDidFinishLaunching(_ notification: Notification) {
        guard !NSWorkspace.shared.accessibilityDisplayShouldReduceMotion else { fail("Reduce Motion enabled") }
        activity = ProcessInfo.processInfo.beginActivity(options: [.userInitiated, .latencyCritical], reason: "Bounded production History update benchmark")
        NSApp.appearance = NSAppearance(named: .darkAqua)
        let size = NSSize(width: PopoverStyle.contentWidth + 48, height: HistoryView.preferredHeight + 48)
        window = NSWindow(contentRect: NSRect(origin: NSPoint(x: 120, y: 100), size: size), styleMask: [.borderless], backing: .buffered, defer: false)
        window.isReleasedWhenClosed = false
        window.isRestorable = false
        window.backgroundColor = .black
        window.hasShadow = false
        window.contentView = NSView(frame: NSRect(origin: .zero, size: size))
        window.orderFrontRegardless()
        timer = Timer(timeInterval: 1.0 / 120, target: self, selector: #selector(tick), userInfo: nil, repeats: true)
        RunLoop.main.add(timer!, forMode: .common)
        DispatchQueue.main.asyncAfter(deadline: .now() + 300) { [weak self] in self?.fail("GUI watchdog") }
        prepare()
    }
    func applicationWillTerminate(_ notification: Notification) { cleanup() }
    private func cleanup() {
        timer?.invalidate(); timer = nil
        fixture?.setPresentationActive(false)
        window?.close()
        if let activity { ProcessInfo.processInfo.endActivity(activity); self.activity = nil }
    }
    private func fail(_ message: String) -> Never {
        fputs("BENCHMARK_FAILED: \(message)\n", stderr)
        cleanup(); exit(1)
    }
    private func update() {
        fixture.update(samples: values, peak: values.max() ?? 0, color: .systemBlue,
                       timing: HistoryChartTiming(sampledAt: times, referenceTime: times.last!))
    }
    private func append(_ value: Double) {
        if values.count >= 60 { values.removeFirst(); times.removeFirst() }
        values.append(value); times.append(times.last! + 2)
    }
    private func prepare() {
        fixture?.setPresentationActive(false); fixture?.removeFromSuperview()
        fixture = HistoryView()
        fixture.frame = NSRect(x: 24, y: 24, width: PopoverStyle.contentWidth, height: HistoryView.preferredHeight)
        window.contentView!.addSubview(fixture)
        fixture.layoutSubtreeIfNeeded()
        fixture.setPresentationActive(true); fixture.setAnimationsEnabled(false)
        values = (0..<60).map { 28 + 5 * sin(Double($0) * 0.4) }
        times = (0..<60).map { 1000 - Double(59 - $0) * 2 }
        if scenario == 2 { values[0] = 90 }
        update()
        if scenario == 2 {
            for _ in 0..<4 { append(29); update() }
        }
        fixture.setAnimationsEnabled(true)
        CATransaction.flush()
        stage = 0; phaseAt = ProcessInfo.processInfo.systemUptime
    }
    @objc private func tick() {
        guard !finished else { return }
        let now = ProcessInfo.processInfo.systemUptime
        if stage == 0 {
            guard now - phaseAt >= 0.025 else { return }
            guard window.isVisible, !fixture.isHiddenOrHasHiddenAncestor, !fixture.visibleRect.isEmpty else { fail("Fixture is not visibly presented") }
            if scenario == 3 || scenario == 4 {
                append(90); update(); CATransaction.flush()
                guard animationKeys().contains("history.stroke") else { fail("Pre-animation branch missing") }
                stage = 1; phaseAt = now; return
            }
            measure(); return
        }
        if stage == 1 {
            guard now - phaseAt >= 0.10 else { return }
            guard fixture.layer?.presentation() != nil else { fail("Presentation tree missing before retarget/noop") }
            guard animationKeys().contains("history.stroke") else { fail("Animation completed before measured update") }
            measure(); return
        }
        if stage == 2 {
            guard now - phaseAt >= 0.045 else { return }
            let keys = animationKeys()
            guard keys.contains("history.stroke"), keys.contains("history.head"), fixture.layer?.presentation() != nil else { fail("Measured update did not enter visible animation branch") }
            if scenario == 4, let after = noopScaleAfterMeasurement {
                let current = viewportScale()
                guard current <= after + 1e-7, current >= 1 - 1e-7,
                      current < after - 1e-6 else { fail("No-op prevented continuous presentation progress") }
                pending["noopPresentationProgressVerified"] = true
            }
            pending["presentationVerified"] = true
            if round >= warmups { records.append(pending) }
            stage = 3
        }
        guard stage == 3, now - phaseAt >= 0.40 else { return }
        round += 1
        if round >= count + warmups {
            scenario += 1; round = 0
            print("COMPLETED \(names[scenario - 1])"); fflush(stdout)
        }
        guard scenario < names.count else { finish(); return }
        prepare()
    }
    private func measure() {
        if scenario != 4 { append(scenario == 1 ? 90 : (scenario == 3 ? 140 : 29)) }
        let beforeKeys = animationKeys()
        if scenario == 3 || scenario == 4 {
            let current = viewportScale()
            guard let initial = viewportFromScale(), current > 1 + 1e-5,
                  current < initial - 1e-5 else { fail("Pre-existing viewport not demonstrably between endpoints") }
        }
        let beforeState = scenario == 4 ? exactState() : nil
        let beforeScale = scenario == 4 ? viewportScale() : nil
        let loops = scenario == 4 ? 512 : 1
        var durations: [Double] = []
        durations.reserveCapacity(loops)
        let measuredPeak = values.max() ?? 0
        let measuredTiming = HistoryChartTiming(sampledAt: times, referenceTime: times.last!)
        let measuredColor = NSColor.systemBlue
        HistoryProfiling.reset()
        for _ in 0..<loops {
            let started = DispatchTime.now().uptimeNanoseconds
            fixture.update(samples: values, peak: measuredPeak, color: measuredColor, timing: measuredTiming)
            durations.append(Double(DispatchTime.now().uptimeNanoseconds - started) / 1000)
        }
        let afterKeys = animationKeys()
        if scenario == 4 {
            guard beforeKeys == afterKeys, beforeState == exactState() else { fail("No-op changed model geometry or animation payload") }
            let after = viewportScale()
            guard let beforeScale, after <= beforeScale + 1e-7, after > 1 - 1e-7 else { fail("No-op presentation jumped backwards") }
            noopScaleAfterMeasurement = after
        }
        if scenario == 3 {
            let p = strokeEndpoint()
            let h = headLayer().position
            let y = HistoryView.chartHeight * 0.30
            guard abs(p.x - PopoverStyle.contentWidth) < 1e-5, abs(p.y - y) < 1e-5,
                  abs(h.x - PopoverStyle.contentWidth) < 1e-5,
                  abs(h.y - (PopoverStyle.sectionPadding + HistoryView.headerHeight + y)) < 1e-5 else {
                fail("Retarget did not install 140W/200W target stroke and head")
            }
        }
        guard afterKeys.contains("history.stroke"), afterKeys.contains("history.head") else { fail("Measured update has no animation") }
        let initial = firstAnchor(strokeStartPath()), target = firstAnchor(strokeLayer().path!)
        if scenario == 1 || scenario == 2 || scenario == 3 {
            guard let scale = viewportFromScale(), abs(scale - 1) > 1e-5 else { fail("Actual axis transition missing") }
        } else if scenario == 0 {
            guard abs(initial.x - target.x) > 1e-5 else { fail("Actual scrolling transition missing") }
        }
        pending = ["scenario": names[scenario], "round": round - warmups,
                   "durationsMicroseconds": durations, "animationKeys": afterKeys,
                   "animationPayload": animationPayload(), "visible": true,
                   "presentationBeforeUpdate": fixture.layer?.presentation() != nil,
                   "sourceSampleCount": values.count, "instrumentedCounts": HistoryProfiling.counts,
                   "retargetTargetModelVerified": scenario == 3, "noopModelAndAnimationUnchanged": scenario == 4]
        CATransaction.flush()
        stage = 2; phaseAt = ProcessInfo.processInfo.systemUptime
    }
    private func layers() -> [CALayer] {
        func visit(_ layer: CALayer) -> [CALayer] {
            [layer] + (layer.sublayers ?? []).flatMap(visit) + (layer.mask.map(visit) ?? [])
        }
        return fixture.layer.map(visit) ?? []
    }
    private func animationKeys() -> [String] { layers().flatMap { $0.animationKeys() ?? [] }.sorted() }
    private func commandCount(_ path: CGPath) -> Int {
        var n = 0; path.applyWithBlock { _ in n += 1 }; return n
    }
    private func animationPayload(exact: Bool = false) -> [[String: Any]] {
        layers().flatMap { layer in (layer.animationKeys() ?? []).compactMap { key -> [String: Any]? in
            guard let animation = layer.animation(forKey: key) else { return nil }
            var data: [String: Any] = ["key": key, "duration": animation.duration]
            if exact {
                data["beginTime"] = animation.beginTime
                data["speed"] = animation.speed
                data["timeOffset"] = animation.timeOffset
                data["fillMode"] = animation.fillMode.rawValue
                data["removed"] = animation.isRemovedOnCompletion
                data["timing"] = (0...3).map { index -> [Float] in
                    var point = [Float](repeating: 0, count: 2)
                    animation.timingFunction?.getControlPoint(at: index, values: &point)
                    return point
                }
            }
            if let k = animation as? CAKeyframeAnimation {
                data["keyPath"] = k.keyPath ?? ""
                data["valuesCount"] = k.values?.count ?? 0
                if exact {
                    data["values"] = (k.values ?? []).map(valueRecord)
                    data["keyTimes"] = (k.keyTimes ?? []).map(\.doubleValue)
                    data["calculationMode"] = k.calculationMode.rawValue
                }
                if k.keyPath == "path", let values = k.values {
                    data["pathCommandCounts"] = values.map { commandCount($0 as! CGPath) }
                }
            }
            if let b = animation as? CABasicAnimation {
                data["keyPath"] = b.keyPath ?? ""
                if exact {
                    data["from"] = b.fromValue.map(valueRecord) ?? ["absent": true]
                    data["to"] = b.toValue.map(valueRecord) ?? ["absent": true]
                    data["by"] = b.byValue.map(valueRecord) ?? ["absent": true]
                }
                if b.keyPath == "path", let p = b.fromValue, let q = b.toValue {
                    data["pathCommandCounts"] = [commandCount(p as! CGPath), commandCount(q as! CGPath)]
                }
            }
            return data
        }}
    }
    private func firstAnchor(_ path: CGPath) -> CGPoint {
        var first: CGPoint?
        path.applyWithBlock { p in if first == nil, p.pointee.type == .moveToPoint { first = p.pointee.points[0] } }
        guard let first else { fail("Stroke anchor missing") }; return first
    }
    private func strokeStartPath() -> CGPath {
        let animation = strokeLayer().animation(forKey: "history.stroke")
        if let basic = animation as? CABasicAnimation, let value = basic.fromValue { return value as! CGPath }
        if let frames = animation as? CAKeyframeAnimation, let value = frames.values?.first { return value as! CGPath }
        fail("Stroke start path missing")
    }
    private func viewportScale() -> Double {
        let stroke = strokeLayer()
        guard let path = stroke.presentation()?.path else { fail("Stroke presentation missing") }
        return Double((HistoryView.chartHeight - firstAnchor(path).y) / (HistoryView.chartHeight - firstAnchor(stroke.path!).y))
    }
    private func viewportFromScale() -> Double? {
        let finalHeight = HistoryView.chartHeight - firstAnchor(strokeLayer().path!).y
        guard finalHeight > 1e-8 else { return nil }
        return Double((HistoryView.chartHeight - firstAnchor(strokeStartPath()).y) / finalHeight)
    }
    private func headLayer() -> CALayer {
        guard let layer = layers().first(where: { abs($0.cornerRadius - 2.6) < 1e-6 && abs($0.bounds.width - 5.2) < 1e-6 }) else { fail("Head layer missing") }
        return layer
    }
    private func strokeLayer() -> CAShapeLayer {
        guard let layer = layers().compactMap({ $0 as? CAShapeLayer }).first(where: { $0.strokeColor != nil && $0.fillColor == nil && $0.path != nil }) else { fail("Stroke layer missing") }
        return layer
    }
    private func strokeEndpoint() -> CGPoint {
        var endpoint: CGPoint?
        strokeLayer().path!.applyWithBlock { pointer in
            let e = pointer.pointee
            switch e.type {
            case .moveToPoint, .addLineToPoint: endpoint = e.points[0]
            case .addQuadCurveToPoint: endpoint = e.points[1]
            case .addCurveToPoint: endpoint = e.points[2]
            case .closeSubpath: break
            @unknown default: break
            }
        }
        guard let endpoint else { fail("Empty stroke") }; return endpoint
    }
    private func pathRecord(_ path: CGPath) -> [[Double]] {
        var commands: [[Double]] = []
        path.applyWithBlock { pointer in
            let e = pointer.pointee
            let count: Int
            switch e.type {
            case .moveToPoint, .addLineToPoint: count = 1
            case .addQuadCurveToPoint: count = 2
            case .addCurveToPoint: count = 3
            case .closeSubpath: count = 0
            @unknown default: count = 0
            }
            commands.append([Double(e.type.rawValue)] + (0..<count).flatMap { [Double(e.points[$0].x), Double(e.points[$0].y)] })
        }
        return commands
    }
    private func valueRecord(_ value: Any) -> [String: Any] {
        if CFGetTypeID(value as CFTypeRef) == CGPath.typeID { return ["path": pathRecord(value as! CGPath)] }
        if let n = value as? NSNumber { return ["number": n.doubleValue] }
        if let n = value as? NSValue {
            let kind = String(cString: n.objCType)
            if kind.contains("CATransform3D") { return ["transform": transformRecord(n.caTransform3DValue)] }
            if kind.contains("CGPoint") { return ["point": [n.pointValue.x, n.pointValue.y]] }
            if kind.contains("CGSize") { return ["size": [n.sizeValue.width, n.sizeValue.height]] }
            return ["encoding": kind, "description": n.description]
        }
        return ["description": String(describing: value)]
    }
    private func transformRecord(_ t: CATransform3D) -> [CGFloat] {
        [t.m11,t.m12,t.m13,t.m14,t.m21,t.m22,t.m23,t.m24,t.m31,t.m32,t.m33,t.m34,t.m41,t.m42,t.m43,t.m44]
    }
    private func exactState() -> Data {
        let head = headLayer()
        let state: [String: Any] = ["stroke": pathRecord(strokeLayer().path!),
            "headPosition": [head.position.x, head.position.y], "headBounds": [head.bounds.minX,head.bounds.minY,head.bounds.width,head.bounds.height],
            "headTransform": transformRecord(head.transform), "layerTransforms": layers().map { transformRecord($0.transform) },
            "animations": animationPayload(exact: true)]
        do { return try JSONSerialization.data(withJSONObject: state, options: [.sortedKeys]) }
        catch { fail("No-op state serialization: \(error)") }
    }
    private func finish() {
        finished = true
        let payload: [String: Any] = ["schema": 1, "measurement": "Unmodified optimized production HistoryView.update call boundary; no flush/capture/logging in timed interval", "notFPS": true, "countingEnabled": ProcessInfo.processInfo.environment["WATTSON_HISTORY_INSTRUMENTED"] == "1", "warmupsPerScenario": warmups, "countPerScenario": count, "records": records]
        do {
            try FileManager.default.createDirectory(at: output.deletingLastPathComponent(), withIntermediateDirectories: true)
            let data = try JSONSerialization.data(withJSONObject: payload, options: [.prettyPrinted, .sortedKeys])
            try data.write(to: output)
        } catch { fail(String(describing: error)) }
        cleanup(); NSApp.terminate(nil)
    }
}
