import AppKit
import CoreGraphics
import Foundation

let pid = pid_t(CommandLine.arguments[1])!
let app = NSRunningApplication(processIdentifier: pid)!
let screens = NSScreen.screens.map { screen -> [String: Any] in
    ["frame": NSStringFromRect(screen.frame), "visibleFrame": NSStringFromRect(screen.visibleFrame)]
}
let windows = (CGWindowListCopyWindowInfo(.optionAll, kCGNullWindowID) as? [[String: Any]] ?? [])
    .filter { ($0[kCGWindowOwnerPID as String] as? Int) == Int(pid) }
    .map { window -> [String: Any] in
        var result: [String: Any] = [:]
        for key in [kCGWindowNumber, kCGWindowBounds, kCGWindowLayer, kCGWindowAlpha, kCGWindowIsOnscreen] {
            result[key as String] = window[key as String]
        }
        return result
    }
let record: [String: Any] = ["pid": pid, "isHidden": app.isHidden, "isActive": app.isActive,
    "isFinishedLaunching": app.isFinishedLaunching, "activationPolicy": app.activationPolicy.rawValue,
    "bundleIdentifier": app.bundleIdentifier ?? "", "executableURL": app.executableURL?.path ?? "",
    "screens": screens, "windows": windows]
print(String(data: try JSONSerialization.data(withJSONObject: record, options: [.prettyPrinted, .sortedKeys]), encoding: .utf8)!)
