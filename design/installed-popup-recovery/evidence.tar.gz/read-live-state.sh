#!/bin/bash
set -euo pipefail
repo='/Users/leoarrow/Project/mypackage/agents/电池功率'
base="$repo/.build/popup-open-regression.noindex"
source "$repo/scripts/lib/local_cleanup.sh"
wattson_cleanup_init
run="$(mktemp -d "$base/run.XXXXXX")"
wattson_cleanup_add_dir "$run"
wattson_run_timeout 60 /usr/bin/nice -n 15 /usr/bin/xcrun swiftc -module-cache-path "$run/module-cache" "$base/read-live-state.swift" -framework AppKit -framework CoreGraphics -o "$run/read-state"
wattson_run_timeout 15 "$run/read-state" 18025 > "$base/live-state.json"
cat "$base/live-state.json"
