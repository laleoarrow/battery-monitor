from pathlib import Path
import hashlib, json, os, shutil, subprocess, tarfile, datetime

repo=Path('/Users/leoarrow/Project/mypackage/agents/电池功率')
old=repo/'.build/history-axis-smoothness.noindex'
base=repo/'.build/popup-open-regression.noindex'
out=repo/'design/installed-popup-recovery'
def digest(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def allocated(path): return int(subprocess.check_output(['/usr/bin/du','-sk',str(path)],text=True).split()[0])*1024
assert not (out/'evidence.tar.gz').exists()
for line in (repo/'design/history-axis-smoothness/SHA256SUMS.txt').read_text().splitlines():
    checksum,name=line.split('  ',1)
    assert digest(repo/'design/history-axis-smoothness'/name)==checksum,name
for manifest,path in [(old/'artifacts-paired.json',repo/'dist/history-axis-smoothness-v4.3.16'),
                      (base/'artifacts.json',repo/'dist/popup-open-fix-v4.3.17')]:
    record=json.loads(manifest.read_text())
    for name,checksum in record['sha256'].items(): assert digest(path/name)==checksum,name
assert json.loads((base/'host-cleanup-audit.json').read_text())['passed']
assert json.loads((base/'guest-resource-audit.json').read_text())['passed']
assert (base/'vm-owner/session.vaj9Ye/exit-code.txt').read_text().strip()=='0'
worktrees=subprocess.check_output(['git','worktree','list','--porcelain'],cwd=repo,text=True)
assert not any('worktree '+str(p/'checkout') in worktrees for p in [old,base])
prototype_records=[]
prototypes=repo/'dist/history-axis-smoothness-prototypes'
for suffix,name in [('4.3.16-f8c09be','artifacts-4.3.16.json'),('4.3.16-e78fdf4','artifacts-release.json')]:
    path=prototypes/suffix;record=json.loads((old/name).read_text())
    assert {p.name for p in path.iterdir()}==set(record['sha256'])
    for filename,checksum in record['sha256'].items(): assert digest(path/filename)==checksum
    prototype_records.append({'path':str(path),'sourceCommit':record['sourceCommit'],'sha256':record['sha256']})
assert {p.name for p in prototypes.iterdir()}=={'4.3.16-f8c09be','4.3.16-e78fdf4'}
(base/'prototype-cleanup-verification.json').write_text(json.dumps(prototype_records,indent=2)+'\n')

names=['installed-sample.txt','live-state.json','before-popup-events.log','after-popup-events.log',
       'restart.json','live-popup-verification.json','host-final.json',
       'installed-4.3.17-popup-events.log','installed-4.3.17-popup-verification.json',
       'baseline-launch-matrix.json','fixed-launch-matrix.json','probe.swift','run-probe-guest.sh',
       'read-live-state.swift','read-live-state.sh','probe-initial-build.log','popover-contract.log',
       'native-manifest.json','native-source.tar.gz','native-tools.tar.gz','native-stage.py',
       'result-popup-fix-interaction.json','native-command.exit','test-summary.json','release-4.3.17.log',
       'release-command.exit','artifacts.json','install-guest.sh','install-host.sh',
       'audit-guest-owned.py','owned-inventory.json','guest-resource-audit.json','host-cleanup-audit.json',
       'worktree-cleanup.json','prototype-cleanup-verification.json','archive-and-clean.py']
receipt=json.loads((base/'result-popup-fix-interaction.json').read_text())
assert receipt['commandExitCode']==receipt['stageExitCode']==0
assert digest(base/receipt['archive'])==receipt['sha256']
names.append(receipt['archive'])
for folder in ['probe-baseline-results','probe-results','verify-tools','host-installed-4.3.17','guest-install-4.3.17']:
    names.extend(str(p.relative_to(base)) for p in (base/folder).rglob('*') if p.is_file())
for name in ['vm-cleanup-summary.json','exit-code.txt','vms-before.json','vms-after-cleanup.json']:
    names.append('vm-owner/session.vaj9Ye/'+name)
names=sorted(set(names));input_hashes={name:digest(base/name) for name in names}
(base/'evidence-files.json').write_text(json.dumps(input_hashes,indent=2)+'\n');names.append('evidence-files.json')
temporary=base/'evidence.partial.tar.gz'
with tarfile.open(temporary,'w:gz') as archive:
    for name in names: archive.add(base/name,arcname=name,recursive=False)
shutil.copy2(temporary,out/'evidence.tar.gz')
assert digest(temporary)==digest(out/'evidence.tar.gz')
with tarfile.open(out/'evidence.tar.gz') as archive:
    assert len(archive.getmembers())==len(names)
    for name,checksum in input_hashes.items():
        assert hashlib.sha256(archive.extractfile(name).read()).hexdigest()==checksum,name

record={'atUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'userRequestedRedundantLocalFilesRemoved':True,'canonicalInstalledVersion':'4.3.17',
        'canonicalInstallationAndUserPreferencesPreserved':True,
        'finalDistributionDirectoriesPreserved':[str(repo/'dist/history-axis-smoothness-v4.3.16'),str(repo/'dist/popup-open-fix-v4.3.17')],
        'acceptedHistoryEvidenceSHA256VerifiedFiles':76,
        'newEvidenceArchiveSHA256':digest(out/'evidence.tar.gz'),'newEvidenceFileCount':len(names),
        'deleted':[],'alreadyRemovedWorktree':json.loads((base/'worktree-cleanup.json').read_text()),
        'ownedVMDeleted':True,'otherTestVMsStillStopped':True,'hostRegistrationAndMountAuditPassed':True}
for path in [prototypes,old,base]:
    assert path.is_dir() and not path.is_symlink() and path.resolve()==path
    assert path in [repo/'dist/history-axis-smoothness-prototypes',repo/'.build/history-axis-smoothness.noindex',repo/'.build/popup-open-regression.noindex']
    item={'path':str(path),'directoryAllocatedBytesBefore':allocated(path),'removed':False}
    record['deleted'].append(item)
    (out/'cleanup.json').write_text(json.dumps(record,indent=2)+'\n')
    shutil.rmtree(path)
    item['removed']=not path.exists()
    (out/'cleanup.json').write_text(json.dumps(record,indent=2)+'\n')
    assert item['removed']
record['removedDirectoryAllocatedBytes']=sum(item['directoryAllocatedBytesBefore'] for item in record['deleted'])+record['alreadyRemovedWorktree']['directoryAllocatedBytesBefore']
record['passed']=all(item['removed'] for item in record['deleted'])
(out/'cleanup.json').write_text(json.dumps(record,indent=2)+'\n')
files=[p for p in sorted(out.iterdir()) if p.is_file() and p.name!='SHA256SUMS.txt']
(out/'SHA256SUMS.txt').write_text(''.join(digest(p)+'  '+p.name+'\n' for p in files))
print(json.dumps({'passed':record['passed'],'removedDirectoryAllocatedBytes':record['removedDirectoryAllocatedBytes'],'retainedEvidenceBytes':(out/'evidence.tar.gz').stat().st_size,'retainedReviewFiles':len(files)+1}))
