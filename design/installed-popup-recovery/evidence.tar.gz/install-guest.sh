#!/bin/bash
set -euo pipefail
repo='/Volumes/My Shared Files/repo'
share='/Volumes/My Shared Files/historysmooth'
[[ "$(/usr/sbin/sysctl -n hw.model)" == VirtualMac* ]]
[[ ! -e /Applications/Wattson.app && ! -e /Library/PrivilegedHelperTools/com.leoarrow.wattson.helper ]]
source "$repo/scripts/lib/local_cleanup.sh"
wattson_cleanup_init
if [[ ! -d "$HOME/Project" ]]; then wattson_cleanup_add_dir "$HOME/Project"; mkdir "$HOME/Project"; fi
project="$HOME/Project/Wattson-PopupFix-PKG.noindex"
[[ ! -e "$project" ]]
wattson_cleanup_add_dir "$project"
mkdir "$project"
cp "$repo/dist/popup-open-fix-v4.3.17/Wattson-v4.3.17-macos-universal.pkg" "$project/candidate.pkg"
/usr/bin/python3 - "$project/candidate.pkg" "$share/artifacts.json" <<'PY'
from pathlib import Path
import json,hashlib,sys
p,m=map(Path,sys.argv[1:]);j=json.loads(m.read_text())
assert hashlib.sha256(p.read_bytes()).hexdigest()==j['sha256']['Wattson-v4.3.17-macos-universal.pkg']
PY
results="$share/guest-install-4.3.17"
mkdir -p "$results"
wattson_run_timeout 180 /usr/bin/sudo -n /usr/sbin/installer -pkg "$project/candidate.pkg" -target / > "$results/installer.log" 2>&1
# This exact package fixture belongs to the enclosing disposable VM until clone deletion.
wattson_run_timeout 150 /bin/bash "$share/verify-tools/verify-installed.sh" "$repo" "$project/candidate.pkg" "$share/verify-tools" "$results" "$project/.scratch.noindex" --vm
printf '0\n' > "$results/exit-code.txt"
