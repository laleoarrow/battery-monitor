#!/bin/bash
set -euo pipefail
repo="${1:?}"; pkg="${2:?}"; tools="${3:?}"; results="${4:?}"
source "$repo/scripts/lib/local_cleanup.sh"
wattson_cleanup_init
scratch="${5:-$results/.scratch.noindex}"
if [[ ! -d "$scratch" ]]; then wattson_cleanup_add_dir "$scratch"; mkdir -p "$scratch"; fi
run="$(mktemp -d "$scratch/run.XXXXXX")"
wattson_cleanup_add_dir "$run"
wattson_run_timeout 90 /usr/sbin/pkgutil --expand-full "$pkg" "$run/expanded" > "$results/expand.log" 2>&1
while IFS= read -r app; do wattson_cleanup_add_app "$app"; done < <(/usr/bin/find "$run/expanded" -name Wattson.app -type d)
args=("$run/expanded" "$results/installed.json")
[[ "${6:-}" != --vm ]] || args+=(--vm)
wattson_run_timeout 90 /usr/bin/python3 "$tools/verify-installed.py" "${args[@]}" > "$results/verify.log" 2>&1
