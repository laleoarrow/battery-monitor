import hashlib, json, os, plistlib, socket, stat, subprocess, sys, time
from pathlib import Path

expanded, output = map(Path, sys.argv[1:3])
version = '4.3.17'
apps = list(expanded.rglob('Wattson.app'))
helpers = [p for p in expanded.rglob('com.leoarrow.wattson.helper') if p.is_file()]
assert len(apps) == len(helpers) == 1
app = Path('/Applications/Wattson.app')
helper = Path('/Library/PrivilegedHelperTools/com.leoarrow.wattson.helper')
def digest(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def tree(path):
    files = {}
    for p in sorted(path.rglob('*')):
        name = str(p.relative_to(path))
        if p.is_symlink(): files[name] = {'link': os.readlink(p)}
        elif p.is_file(): files[name] = {'sha256': digest(p), 'mode': stat.S_IMODE(p.stat().st_mode)}
    return files
assert tree(apps[0]) == tree(app), 'Installed app differs from verified PKG payload'
assert digest(helper) == digest(helpers[0]), 'Installed helper differs from PKG payload'
info = plistlib.loads((app/'Contents/Info.plist').read_bytes())
assert info['CFBundleShortVersionString'] == info['CFBundleVersion'] == version
receipt = plistlib.loads(subprocess.check_output(['/usr/sbin/pkgutil','--pkg-info-plist','com.leoarrow.wattson.pkg'],timeout=10))
assert receipt['pkg-version'] == version
for p in (app, helper): subprocess.run(['/usr/bin/codesign','--verify','--deep','--strict',str(p)],check=True,timeout=20)
binary = app/'Contents/MacOS'/info['CFBundleExecutable']
architectures = subprocess.check_output(['/usr/bin/lipo','-archs',str(binary)],text=True,timeout=10).split()
assert set(architectures) == {'arm64','x86_64'}
healthy = False
deadline = time.monotonic() + 15
while time.monotonic() < deadline:
    try:
        with socket.socket(socket.AF_UNIX,socket.SOCK_STREAM) as connection:
            connection.settimeout(2);connection.connect('/var/run/wattson-helper.sock')
            connection.sendall(b'{"_wattsonProtocol":4,"op":"health"}\n')
            chunks=[]
            while True:
                block=connection.recv(8192)
                if not block:break
                chunks.append(block)
                if b'\n' in block:break
            response = json.loads(b''.join(chunks))
            healthy = response.get('ok') is True and response.get('health') is True
        if healthy:break
    except (OSError,ValueError,KeyError): pass
    time.sleep(.2)
assert healthy, 'Installed helper did not become healthy'
subprocess.run(['/usr/bin/open','-g',str(app)],check=True,timeout=15)
time.sleep(3)
def pids():
    text=subprocess.check_output(['/bin/ps','-axo','pid=,comm='],text=True,timeout=10)
    return [int(line.split(None,1)[0]) for line in text.splitlines() if line.strip().split(None,1)[-1] == str(binary)]
running = pids()
virtual_no_battery = False
if not running and len(sys.argv) > 3 and sys.argv[3] == '--vm':
    model = subprocess.check_output(['/usr/sbin/sysctl','-n','hw.model'],text=True,timeout=10).strip()
    battery = subprocess.check_output(['/usr/sbin/ioreg','-r','-c','AppleSmartBattery'],text=True,timeout=10)
    logs = subprocess.check_output(['/usr/bin/log','show','--last','90s','--style','compact','--predicate','process == "Wattson"'],text=True,timeout=20)
    virtual_no_battery = model.startswith('VirtualMac') and not battery.strip() and 'no AppleSmartBattery' in logs
assert len(running)==1 or virtual_no_battery, running
if running:
    time.sleep(3);assert pids()==running, 'Canonical app was not launch-stable'
record={'version':version,'receiptVersion':receipt['pkg-version'],'appMatchesPKG':True,'helperMatchesPKG':True,
        'appExecutableSHA256':digest(binary),'helperSHA256':digest(helper),'architectures':architectures,
        'signatureValid':True,'helperHealthy':True,'canonicalPID':running[0] if running else None,
        'launchStableSeconds':3 if running else None,'expectedVirtualNoBatteryExit':virtual_no_battery,
        'installedFixtureCleanupOwner':'Disposable VM owner for guest tests; host installation is the requested persistent result.'}
output.write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))
