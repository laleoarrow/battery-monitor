on run argv
    if (count of argv) is not 1 then error "Expected one verified native PKG path"
    set packagePath to item 1 of argv
    return do shell script "/usr/sbin/installer -pkg " & quoted form of packagePath & " -target /" with administrator privileges
end run
