import AppKit
import Foundation

final class Probe: NSObject, NSApplicationDelegate {
    let suite = ProcessInfo.processInfo.environment["WATTSON_TEST_DEFAULTS_SUITE"]!
    var item: NSStatusItem!
    var controller: PopoverController!
    var record: [String: Any] = [:]
    func applicationDidFinishLaunching(_ notification: Notification) {
        let defaults = UserDefaults(suiteName: suite)!
        defaults.removePersistentDomain(forName: suite)
        Settings.configureForTest(defaults: defaults)
        Settings.liquidGlassEnabled = true
        Settings.showPopoverArrow = false
        Settings.setModule(.lanes, visible: false)
        controller = PopoverController()
        controller.update(snapshot: PowerSnapshot(percent: 72, plugged: true, adapterW: 68,
            batteryW: 22, systemW: 46), history: [30, 42, 28, 35], peak: 42, degraded: false)
        item = NSStatusBar.system.statusItem(withLength: NSStatusItem.variableLength)
        item.button!.title = "72%"
        DispatchQueue.main.asyncAfter(deadline: .now() + 1) { self.run() }
    }
    func run() {
        let button = item.button!, window = button.window!
        let anchor = window.convertToScreen(button.convert(button.bounds, to: nil))
        let natural = controller.contentViewForTest!.frame.size
        let placement = PopoverPlacement.resolve(anchor: anchor, displays: NSScreen.screens.map {
            .init(frame: $0.frame, visibleFrame: $0.visibleFrame)
        }, naturalSize: natural, glassMargin: GlassPopoverPanel.contentInset, showsArrow: false)
        record = ["appHidden": NSApp.isHidden, "anchorVisible": window.isVisible,
            "buttonHidden": button.isHiddenOrHasHiddenAncestor, "windowNumber": window.windowNumber,
            "windowFrame": NSStringFromRect(window.frame), "anchor": NSStringFromRect(anchor),
            "naturalSize": NSStringFromSize(natural), "placementResolved": placement != nil,
            "panelFrameResolved": placement?.glassPanelFrame(margin: GlassPopoverPanel.contentInset) != nil]
        controller.toggle(relativeTo: button)
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
            self.record["open"] = self.controller.isOpen
            self.record["shown"] = self.controller.isShownForTest
            self.record["appHiddenAfter"] = NSApp.isHidden
            let data = try! JSONSerialization.data(withJSONObject: self.record, options: [.prettyPrinted, .sortedKeys])
            print("POPUP_PROBE " + String(data: data, encoding: .utf8)!.replacingOccurrences(of: "\n", with: ""))
            fflush(stdout)
            self.controller.handleOutsideClick()
            NSStatusBar.system.removeStatusItem(self.item)
            NSApp.terminate(nil)
        }
    }
}

@main enum Entry {
    static func main() {
        let app = NSApplication.shared
        let delegate = Probe()
        app.delegate = delegate
        app.setActivationPolicy(.accessory)
        app.run()
        withExtendedLifetime(delegate) {}
    }
}
