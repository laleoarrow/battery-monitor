#!/bin/bash
set -euo pipefail
repo='/Volumes/My Shared Files/repo'
share='/Volumes/My Shared Files/historysmooth'
[[ "$(/usr/sbin/sysctl -n hw.model)" == VirtualMac* ]]
source "$repo/scripts/lib/local_cleanup.sh"
wattson_cleanup_init
if [[ ! -d "$HOME/Project" ]]; then wattson_cleanup_add_dir "$HOME/Project"; mkdir "$HOME/Project"; fi
project="$HOME/Project/Wattson-PopupOpen-QA"
[[ ! -e "$project" ]]
wattson_cleanup_add_dir "$project"
mkdir "$project"
cp -R "$repo/Core" "$repo/MenuBar" "$repo/Popover" "$project/"
cp "$share/probe.swift" "$project/main.swift"
app="$project/Probe.app"
bundle_id="com.leoarrow.wattson.popupopenqa.$(/usr/bin/uuidgen | /usr/bin/tr '[:upper:]' '[:lower:]')"
wattson_cleanup_add_app "$app"
wattson_cleanup_add_container "$bundle_id"
wattson_cleanup_add_defaults "$bundle_id"
wattson_cleanup_add_executable "$app/Contents/MacOS/Probe"
mkdir -p "$app/Contents/MacOS" "$share/probe-results"
printf '%s\t%s\n' "$bundle_id" "$app" > "$share/probe-results/owned-bundle.tsv"
cd "$project"
/usr/bin/shasum -a 256 Core/*.swift MenuBar/*.swift Popover/*.swift main.swift > "$share/probe-results/inputs.sha256"
wattson_run_timeout 150 /usr/bin/nice -n 15 /usr/bin/xcrun swiftc -Onone -D DEBUG -module-cache-path "$project/module-cache" -parse-as-library -swift-version 5 -warnings-as-errors -target arm64-apple-macos12.0 Core/*.swift MenuBar/*.swift Popover/*.swift main.swift -framework AppKit -framework CoreGraphics -framework IOKit -o "$app/Contents/MacOS/Probe" > "$share/probe-results/build.log" 2>&1
cat > "$app/Contents/Info.plist" <<EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict><key>CFBundleIdentifier</key><string>$bundle_id</string><key>CFBundleExecutable</key><string>Probe</string><key>CFBundleName</key><string>PopupProbe</string><key>CFBundlePackageType</key><string>APPL</string><key>LSUIElement</key><true/></dict></plist>
EOF
wattson_run /usr/bin/codesign --force --sign - --entitlements "$repo/BatteryPowerApp.entitlements" "$app" >> "$share/probe-results/build.log" 2>&1
for mode in normal background hidden; do
    suite="com.leoarrow.wattson.popupopenqa.$(/usr/bin/uuidgen | /usr/bin/tr '[:upper:]' '[:lower:]')"
    wattson_cleanup_add_defaults "$suite"
    printf '%s\n' "$suite" >> "$share/probe-results/owned-suites.txt"
    command=(/usr/bin/open -n -W)
    [[ "$mode" == normal ]] || command+=(-g)
    [[ "$mode" != hidden ]] || command+=(-j)
    wattson_run_timeout 40 "${command[@]}" -o "$share/probe-results/$mode.log" --stderr "$share/probe-results/$mode.err" --env WATTSON_TEST_DEFAULTS_SUITE="$suite" "$app"
    /usr/bin/grep 'POPUP_PROBE' "$share/probe-results/$mode.log"
done
