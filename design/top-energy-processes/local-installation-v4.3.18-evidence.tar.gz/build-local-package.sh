#!/bin/bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
source "$ROOT/scripts/lib/local_cleanup.sh"
wattson_cleanup_init
VERSION="$(cat "$ROOT/VERSION")"
[[ "$VERSION" == 4.3.18 ]]
FINAL="$ROOT/dist/local-v$VERSION"
[[ ! -e "$FINAL" ]] || { echo 'Local artifact destination already exists' >&2; exit 65; }
mkdir -p "$ROOT/.build/local.noindex"
WATTSON_RELEASE_BUILD_ROOT="$(mktemp -d "$ROOT/.build/local.noindex/process-release.XXXXXX")"
wattson_cleanup_add_dir "$WATTSON_RELEASE_BUILD_ROOT"
export WATTSON_RELEASE_BUILD_ROOT
export WATTSON_RELEASE_DIST_DIR="$FINAL"
export WATTSON_DEVELOPER_ID_APP=- WATTSON_DEVELOPER_ID_INSTALLER=-
export WATTSON_NOTARIZE=0
wattson_run_script "$ROOT/scripts/build_release.sh"
wattson_run_script "$ROOT/scripts/verify_release.sh" --build-only
wattson_run_script "$ROOT/scripts/package_pkg.sh" "$VERSION"
WATTSON_RELEASE_ORCHESTRATED=1 wattson_run_script "$ROOT/scripts/package_dmg.sh" "$VERSION"
PKG="Wattson-v$VERSION-macos-universal.pkg"
DMG="Wattson-v$VERSION-macos-universal.dmg"
wattson_run_script "$ROOT/scripts/verify_release.sh" "$FINAL/$PKG" "$FINAL/$DMG"
cp "$WATTSON_RELEASE_BUILD_ROOT/BUILD-METADATA.txt" "$FINAL/Wattson-v$VERSION-release-info.txt"
{
    printf 'source_commit=%s\n' "$(git -C "$ROOT" rev-parse HEAD)"
    printf 'distribution_mode=community-ad-hoc\npackage_signature=unsigned\ndmg_signature=unsigned\nnotarized=no\npublic_release=no\n'
} >> "$FINAL/Wattson-v$VERSION-release-info.txt"
(
    cd "$FINAL"
    shasum -a 256 "$PKG" "$DMG" "Wattson-v$VERSION-release-info.txt" > SHA256SUMS.txt
    shasum -a 256 -c SHA256SUMS.txt
)
printf 'LOCAL_PACKAGE_VERIFIED=%s\n' "$FINAL/$PKG"
