on run arguments
    if (count of arguments) is not 2 then error "Expected verified package and log paths"
    set packagePath to item 1 of arguments
    set logPath to item 2 of arguments
    set installCommand to "/usr/sbin/installer -pkg " & quoted form of packagePath & " -target / > " & quoted form of logPath & " 2>&1"
    do shell script installCommand with administrator privileges
end run
