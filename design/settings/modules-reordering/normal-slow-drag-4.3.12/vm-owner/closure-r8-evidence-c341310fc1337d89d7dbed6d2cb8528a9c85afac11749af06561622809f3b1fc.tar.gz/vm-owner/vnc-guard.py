#!/usr/bin/env python3
"""Own Tart's private VNC output; export credentials only after PID/bind proof."""
import argparse
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import tempfile
import time
from urllib.parse import unquote, urlsplit


INTERPOSE_ROOT = Path(__file__).resolve().parent.parent / 'loopback-vz'
TRACE_ENV = 'WATTSON_LOOPBACK_TRACE_FD'


class GuardError(Exception):
    pass


def reject_listener(reason, pid, result, path):
    evidence = {'requestedPID': pid, 'reason': reason, 'inputAuthorized': False,
                'lsofReturnCode': None if result is None else result.returncode,
                'stderrBytes': 0 if result is None else len(result.stderr), 'fields': []}
    if result is not None:
        evidence['stdoutBytes'] = len(result.stdout)
        evidence['stdoutTruncated'] = len(result.stdout) > 65536
        for raw in result.stdout[:65536].split(b'\0'):
            token = raw.lstrip(b'\n')
            if not token:
                continue
            field, value = chr(token[0]), token[1:].decode('ascii', errors='replace')
            item = {'field': field if field.isascii() and field.isalpha() else 'unknown',
                    'valueBytes': len(token)-1, 'leadingNewlines': len(raw)-len(token)}
            safe = ((field == 'p' and re.fullmatch(r'[0-9]+[\r\n]*', value)) or
                    (field == 'f' and re.fullmatch(r'[0-9]+[a-z]*[\r\n]*', value)) or
                    (field == 'n' and re.fullmatch(r'[0-9A-Fa-f.*:%\[\]]+:[0-9]+[\r\n]*', value)) or
                    (field == 'T' and re.fullmatch(r'(ST=(LISTEN|ESTABLISHED|CLOSED)|Q[RS]=[0-9]+)[\r\n]*', value)))
            item['value'] = value if safe and len(value) <= 256 else '[redacted]'
            evidence['fields'].append(item)
    if path is not None:
        write_json(path, evidence, exclusive=True)
    raise GuardError(reason)


def listeners(binary, pid, rejection_path=None):
    try:
        result = subprocess.run([binary, '-nP', '-a', '-p', str(pid), '-iTCP',
                                 '-sTCP:LISTEN', '-Ts', '-F0pcfnT'], capture_output=True, timeout=3)
    except (OSError, subprocess.TimeoutExpired):
        reject_listener('listener-query-failed', pid, None, rejection_path)
    if result.returncode == 1 and not result.stdout and not result.stderr:
        return []
    if result.returncode != 0 or result.stderr:
        reject_listener('listener-query-failed', pid, result, rejection_path)
    try:
        tokens = result.stdout.decode('ascii').split('\0')
        current_pid, record, found = None, None, []
        def finish():
            if record is None:
                return
            if current_pid != pid or set(record) - {'QR', 'QS'} != {'n', 'T'} or record['T'] != 'ST=LISTEN':
                raise ValueError()
            address = record['n']
            match = re.fullmatch(r'(127\.0\.0\.1|\[::1\]|::1):(\d+)', address)
            if not match or not 0 < int(match[2]) < 65536:
                raise ValueError()
            host = match[1].strip('[]')
            found.append({'host': host, 'port': int(match[2]), 'pid': pid})
        for token in tokens:
            token = token.lstrip('\n')
            if not token:
                continue
            field, value = token[0], token[1:]
            if field == 'p':
                finish()
                if current_pid is not None or int(value) != pid:
                    raise ValueError()
                current_pid, record = int(value), None
            elif field == 'c':
                if current_pid != pid or record is not None or not value:
                    raise ValueError()
            elif field == 'f':
                finish()
                if current_pid != pid or not value:
                    raise ValueError()
                record = {}
            elif field == 'T' and record is not None and value.startswith(('QR=', 'QS=')):
                key, queue = value.split('=', 1)
                if key in record or not re.fullmatch(r'[0-9]+', queue):
                    raise ValueError()
                record[key] = queue
            elif field in ('n', 'T') and record is not None and field not in record:
                record[field] = value
            else:
                raise ValueError()
        finish()
        if current_pid != pid or not found:
            raise ValueError()
        return sorted(found, key=lambda bind: (bind['host'], bind['port']))
    except (ValueError, UnicodeError):
        reject_listener('listener-proof-invalid', pid, result, rejection_path)


def connection(raw):
    matches = re.findall(rb'vnc://[^\s<>"\']+', raw)
    if not matches:
        return None
    if len(set(matches)) != 1:
        raise GuardError('connection-output-invalid')
    try:
        parsed = urlsplit(matches[0].decode('utf-8'))
        if parsed.scheme != 'vnc' or not parsed.hostname or not parsed.port or parsed.path or parsed.query or parsed.fragment:
            raise ValueError()
        password = unquote(parsed.password or '')
        if not password:
            raise ValueError()
        return {'port': parsed.port, 'password': password}
    except (ValueError, UnicodeError):
        raise GuardError('connection-output-invalid') from None


def write_json(path, data, exclusive=False):
    flags = os.O_WRONLY | os.O_CREAT | (os.O_EXCL if exclusive else os.O_TRUNC)
    descriptor = os.open(path, flags, 0o600)
    with os.fdopen(descriptor, 'w') as target:
        json.dump(data, target, sort_keys=True)
        target.write('\n')


def child_environment(executable, library):
    environment = os.environ.copy()
    environment.pop('DYLD_INSERT_LIBRARIES', None)
    environment.pop(TRACE_ENV, None)
    resolved_executable = Path(executable).resolve(strict=True)
    if library is not None:
        paths = [Path(executable), Path(library)]
        if any(not path.is_absolute() or str(path) != raw or '..' in path.parts or path.resolve(strict=True) != path
               for path, raw in zip(paths, (executable, library))):
            raise GuardError('interpose-path-not-owned')
        runtime = paths[0].parent
        if (paths[0].name != 'tart' or not runtime.name.startswith('runtime.') or runtime.name == 'runtime.' or
                runtime.parent != INTERPOSE_ROOT.resolve() or paths[1].parent != runtime or
                paths[1].name != 'loopback.dylib' or not all(path.is_file() for path in paths) or
                not os.access(paths[0], os.X_OK)):
            raise GuardError('interpose-path-not-owned')
        environment['DYLD_INSERT_LIBRARIES'] = str(paths[1])
    return environment, str(resolved_executable)


def interpose_events(path):
    data = path.read_bytes()
    if len(data) > 65536:
        raise GuardError('interpose-trace-invalid')
    seen, rewritten, listening = set(), set(), set()
    try:
        for line in data.splitlines():
            item = json.loads(line)
            if (set(item) != {'event', 'fd', 'family', 'address', 'result', 'errno'} or
                    item['event'] not in {'loaded', 'bind-rewrite', 'bind-pass', 'listen-refuse', 'listen-pass'} or
                    item['address'] not in {'none', 'literal-loopback', 'unchanged', 'nonliteral-loopback', 'getsockname-failed', 'non-internet-tcp'} or
                    any(type(item[key]) is not int for key in ('fd', 'family', 'result', 'errno')) or
                    item['family'] not in {0, 1, 2, 30} or item['fd'] < -1 or
                    item['result'] not in {-1, 0} or item['errno'] < 0):
                raise ValueError()
            event = item['event']
            if event == 'loaded' and item != {'event':'loaded','fd':-1,'family':0,'address':'none','result':0,'errno':0}:
                raise ValueError()
            seen.add(event)
            if item['fd'] >= 0 and item['family'] in {2, 30} and item['result'] == 0 and item['errno'] == 0 and item['address'] == 'literal-loopback':
                if event == 'bind-rewrite': rewritten.add((item['fd'], item['family']))
                if event == 'listen-pass': listening.add((item['fd'], item['family']))
        return seen, 'loaded' in seen and bool(rewritten & listening)
    except (ValueError, TypeError, KeyError):
        raise GuardError('interpose-trace-invalid') from None


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--session', type=Path, required=True)
    parser.add_argument('--owned-vm', required=True)
    parser.add_argument('--lsof', default='/usr/sbin/lsof')
    parser.add_argument('--tart-interpose-library')
    parser.add_argument('command', nargs=argparse.REMAINDER)
    args = parser.parse_args()
    command = args.command[1:] if args.command[:1] == ['--'] else args.command
    required = {'--vnc-experimental', '--no-graphics', '--no-audio', '--no-clipboard'}
    if len(command) < 3 or command[1] != 'run' or not required.issubset(command) or command[-1] != args.owned_vm or any(arg.startswith(('--net', '--bridge', '--host')) for arg in command[2:]):
        return 64
    os.umask(0o077)
    child, raw_path, own_connection, proof, status, reason = None, None, False, None, 1, None
    trace_fd = None
    private = args.session / 'vnc-connection.json'
    proof_path = args.session / 'vnc-bind-proof.json'
    rejection_path = args.session / 'vnc-bind-rejection.json'
    trace_path = args.session / 'vnc-interpose-trace.jsonl'
    def interrupted(signum, _frame):
        raise SystemExit(128 + signum)
    for signum in (signal.SIGHUP, signal.SIGINT, signal.SIGTERM):
        signal.signal(signum, interrupted)
    try:
        if not args.session.is_dir() or private.exists() or proof_path.exists() or rejection_path.exists() or trace_path.exists():
            raise GuardError('session-not-fresh')
        environment, executable_path = child_environment(command[0], args.tart_interpose_library)
        previous_mask = signal.pthread_sigmask(signal.SIG_BLOCK, {signal.SIGHUP, signal.SIGINT, signal.SIGTERM})
        try:
            if args.tart_interpose_library is not None:
                trace_fd = os.open(trace_path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_APPEND, 0o600)
                environment[TRACE_ENV] = str(trace_fd)
            descriptor, name = tempfile.mkstemp(prefix='.vnc-raw-', dir=args.session)
            raw_path = Path(name)
        finally:
            signal.pthread_sigmask(signal.SIG_SETMASK, previous_mask)
        with os.fdopen(descriptor, 'wb') as output:
            previous_mask = signal.pthread_sigmask(signal.SIG_BLOCK, {signal.SIGHUP, signal.SIGINT, signal.SIGTERM})
            try:
                # This shim is single-threaded; restore the inherited mask before exec.
                child = subprocess.Popen(command, stdout=output, stderr=subprocess.STDOUT, start_new_session=True,
                                         env=environment, pass_fds=() if trace_fd is None else (trace_fd,),
                                         preexec_fn=lambda: signal.pthread_sigmask(signal.SIG_SETMASK, previous_mask))
            finally:
                try:
                    if trace_fd is not None:
                        os.close(trace_fd)
                        trace_fd = None
                finally:
                    signal.pthread_sigmask(signal.SIG_SETMASK, previous_mask)
            deadline, ready = time.monotonic() + 20, False
            while True:
                code = child.poll()
                if code is not None:
                    status = code if code >= 0 else 128 - code
                    if not ready and status == 0:
                        status = 1
                    break
                binds = listeners(args.lsof, child.pid, rejection_path)
                events, interpose_proven = interpose_events(trace_path) if args.tart_interpose_library else (set(), True)
                if raw_path.stat().st_size > 1048576:
                    raise GuardError('connection-output-too-large')
                secret = connection(raw_path.read_bytes())
                if binds and secret and interpose_proven:
                    matching = [bind for bind in binds if bind['port'] == secret['port']]
                    if not matching:
                        raise GuardError('connection-port-unbound')
                    host = '127.0.0.1' if any(bind['host'] == '127.0.0.1' for bind in matching) else '::1'
                    if not ready:
                        proof = {'vncBackend': 'directVZ', 'vncHost': host, 'vncPort': secret['port'],
                                 'vncListenerPID': child.pid, 'ownedVM': args.owned_vm,
                                 'vncExecutablePath': executable_path,
                                 'actualBinds': binds, 'inputAuthorized': False, 'active': True}
                        if args.tart_interpose_library:
                            proof.update(vncInterposeTracePath=str(trace_path), interposeEvents=sorted(events))
                        write_json(proof_path, proof, exclusive=True)
                        previous_mask = signal.pthread_sigmask(signal.SIG_BLOCK, {signal.SIGHUP, signal.SIGINT, signal.SIGTERM})
                        try:
                            private_fd = os.open(private, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
                            own_connection = True
                        finally:
                            signal.pthread_sigmask(signal.SIG_SETMASK, previous_mask)
                        with os.fdopen(private_fd, 'w') as target:
                            json.dump({'host': host, **secret}, target)
                        ready = True
                        print('VNC_BIND_READY ' + str(proof_path), flush=True)
                    elif binds != proof['actualBinds']:
                        raise GuardError('listener-bind-changed')
                elif not interpose_proven and (ready or time.monotonic() >= deadline):
                    raise GuardError('interpose-trace-unproven')
                elif ready:
                    raise GuardError('listener-disappeared')
                elif time.monotonic() >= deadline:
                    raise GuardError('initialization-timeout')
                time.sleep(1)
    except GuardError as error:
        reason = str(error)
        print('VNC_GUARD_FAILED ' + reason, flush=True)
    except SystemExit as error:
        status = int(error.code)
    except Exception:
        reason = 'guard-operation-failed'
        print('VNC_GUARD_FAILED ' + reason, flush=True)
    finally:
        for signum in (signal.SIGHUP, signal.SIGINT, signal.SIGTERM):
            signal.signal(signum, signal.SIG_IGN)
        cleanup_failed = False
        if trace_fd is not None:
            try: os.close(trace_fd)
            except OSError: cleanup_failed = True
        if child is not None:
            try:
                try:
                    os.killpg(child.pid, signal.SIGTERM)
                except ProcessLookupError:
                    pass
                try:
                    child.wait(timeout=3)
                except subprocess.TimeoutExpired:
                    os.killpg(child.pid, signal.SIGKILL)
                    child.wait(timeout=3)
                try:
                    os.killpg(child.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
            except Exception:
                cleanup_failed = True
        for owned in ([private] if own_connection else []) + ([raw_path] if raw_path is not None else []):
            try:
                owned.unlink()
            except Exception:
                cleanup_failed = True
        if cleanup_failed and status == 0:
            status = 1
        if proof is not None:
            try:
                proof.update(active=False, exitCode=status, failureReason=reason)
                write_json(proof_path, proof)
            except Exception:
                if status == 0:
                    status = 1
    return status


if __name__ == '__main__':
    raise SystemExit(main())
