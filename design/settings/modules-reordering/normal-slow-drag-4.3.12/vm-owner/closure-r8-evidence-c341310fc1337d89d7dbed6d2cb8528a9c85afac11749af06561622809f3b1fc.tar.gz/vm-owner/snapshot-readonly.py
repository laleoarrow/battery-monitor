"""Read-only host resource, VM, and canonical installation inventory."""
import datetime, hashlib, json, plistlib, re, subprocess, sys
from pathlib import Path

def command(args):
    r = subprocess.run(args, capture_output=True, text=True, timeout=30)
    return {'argv': args, 'exitCode': r.returncode, 'stdout': r.stdout, 'stderr': r.stderr}

output = Path(sys.argv[1]); assert not output.exists()
app = Path('/Applications/Wattson.app'); executable = app / 'Contents/MacOS/Wattson'
commands = {
    'vms': command(['/opt/homebrew/bin/tart', 'list', '--format', 'json']),
    'memoryPressure': command(['/usr/bin/memory_pressure', '-Q']),
    'memoryAndSwap': command(['/usr/sbin/sysctl', 'hw.memsize', 'vm.swapusage']),
    'disk': command(['/bin/df', '-k', str(Path(__file__).resolve().parent)]),
    'signatureVerify': command(['/usr/bin/codesign', '--verify', '--deep', '--strict', str(app)]),
    'signatureIdentity': command(['/usr/bin/codesign', '-dv', '--verbose=4', str(app)]),
    'receipt': command(['/usr/sbin/pkgutil', '--pkg-info-plist', 'com.leoarrow.wattson.pkg']),
    'processes': command(['/bin/ps', '-axo', 'pid=,uid=,comm=,args=']),
}
assert all(r['exitCode'] == 0 for r in commands.values())
info = plistlib.loads((app / 'Contents/Info.plist').read_bytes())
receipt = plistlib.loads(commands['receipt']['stdout'].encode())
pids = []
for row in commands['processes']['stdout'].splitlines():
    values = row.split(None, 3)
    if len(values) == 4 and (values[2] == str(executable) or values[3].split(' ', 1)[0] == str(executable)):
        pids.append({'pid': int(values[0]), 'uid': int(values[1]), 'executable': values[2]})
# Do not retain unrelated host process arguments.
del commands['processes']
record = {'schema': 1, 'atUTC': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'readOnly': True, 'commands': commands,
          'canonical': {'version': info['CFBundleShortVersionString'], 'bundleID': info['CFBundleIdentifier'], 'executableSHA256': hashlib.sha256(executable.read_bytes()).hexdigest(), 'infoSHA256': hashlib.sha256((app / 'Contents/Info.plist').read_bytes()).hexdigest(), 'pids': pids, 'receiptVersion': receipt['pkg-version'], 'signatureVerified': True},
          'expectedPeerObservedAbsent': 'Wattson-ModulesDefaultsSidebar-20261017' not in {x['Name'] for x in json.loads(commands['vms']['stdout'])},
          'peerAttribution': 'Read-only inventory only. Any absent or changed peer was not targeted by this owner; correlate with peer owner evidence.'}
output.write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({'output': str(output), 'canonical': record['canonical'], 'vms': json.loads(commands['vms']['stdout'])}))
