import json, sys
from pathlib import Path
VM = 'Wattson-NormalSlowDrag-20261017'
BASES = ['macOS-TestLab', 'macOS-TestLab-Base']
mode = sys.argv[1]
raw = json.load(sys.stdin) if sys.argv[2] == '-' else json.loads(Path(sys.argv[2]).read_text()); before = {v['Name']: v for v in raw}
if mode == 'preflight':
    assert VM not in before, 'Owned VM name already exists; refuse reuse'
    assert all(before[n]['State'] == 'stopped' and not before[n]['Running'] for n in BASES)
    assert sum(bool(v['Running']) for v in raw) < 2, 'No available VM slot'
elif mode == 'state':
    v = before.get(VM)
    print('missing' if v is None else 'stopped' if v.get('State') == 'stopped' and v.get('Running') is False else 'running' if v.get('State') == 'running' or v.get('Running') is True else 'unknown')
elif mode == 'after':
    after_raw = json.load(sys.stdin) if sys.argv[3] == '-' else json.loads(Path(sys.argv[3]).read_text())
    after = {v['Name']: v for v in after_raw}
    record = {'ownCloneRemoved': VM not in after, 'baseAndTestLabStillStopped': all(n in after and after[n]['State'] == 'stopped' and not after[n]['Running'] for n in BASES),
              'independentlyRemovedPeers': [n for n in before if n not in BASES and n not in after],
              'independentlyChangedPeers': [n for n, v in before.items() if n not in BASES and n in after and (v['State'], v['Running']) != (after[n]['State'], after[n]['Running'])],
              'independentlyAddedPeers': [n for n in after if n not in before and n != VM],
              'attribution': 'This owner issued clone/set/run/stop/delete only for ' + VM + '. Peer changes are observations of other owners, not repaired or counted as own cleanup failures.'}
    print(json.dumps(record, indent=2))
    raise SystemExit(0 if record['ownCloneRemoved'] and record['baseAndTestLabStillStopped'] else 1)
else:
    raise SystemExit(64)
