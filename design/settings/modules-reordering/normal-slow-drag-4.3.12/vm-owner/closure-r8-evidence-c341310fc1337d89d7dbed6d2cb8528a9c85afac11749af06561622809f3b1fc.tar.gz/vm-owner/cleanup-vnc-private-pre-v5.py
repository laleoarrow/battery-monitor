"""Unlink only this owner's fresh session's VNC private files, without reading them."""
from pathlib import Path
import sys
owner = Path(__file__).resolve().parent
session = Path(sys.argv[1])
assert session.parent.resolve() == owner and session.name.startswith('session.')
failed = False
for path in [session / 'vnc-connection.json', *session.glob('.vnc-raw-*')]:
    try:
        path.unlink(missing_ok=True)
    except OSError:
        failed = True
raise SystemExit(1 if failed else 0)
