"""Unlink only this owner's fresh session's VNC private files, without reading them."""
from pathlib import Path
import json
import os
import stat
import sys
owner = Path(__file__).resolve().parent
session = Path(sys.argv[1])
assert session.parent.resolve() == owner and session.name.startswith('session.')
failed = False
for path in [session / 'vnc-connection.json', *session.glob('.vnc-raw-*')]:
    try:
        path.unlink(missing_ok=True)
    except OSError:
        failed = True
if session.name == 'session.tBZbx0':
    # Root created this single credential for this exact session; never read it.
    try:
        record = json.loads((session / 'direct-vz-private-owner.json').read_text())
        path = owner.parent / 'private/direct-vz-password'
        assert record['sessionDirectory'] == str(session) and record['path'] == str(path)
        assert record['rootOuterExecSessionID'] == 23371 and record['uid'] == os.getuid()
        try:
            current = path.lstat()
        except FileNotFoundError:
            current = None
        if current is not None:
            assert stat.S_ISREG(current.st_mode) and stat.S_IMODE(current.st_mode) == 0o600
            assert (current.st_dev, current.st_ino, current.st_uid) == (record['device'], record['inode'], record['uid'])
            path.unlink()
    except (OSError, ValueError, KeyError, AssertionError):
        failed = True
raise SystemExit(1 if failed else 0)
