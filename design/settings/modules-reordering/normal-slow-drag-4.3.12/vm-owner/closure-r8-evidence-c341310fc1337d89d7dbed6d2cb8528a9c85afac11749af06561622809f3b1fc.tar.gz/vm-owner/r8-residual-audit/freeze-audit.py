"""Freeze this VM's v2-v8 resource union after the v8 stage has closed."""
import hashlib
import io
import json
import re
import tarfile
from pathlib import Path

root = Path(__file__).resolve().parent
share = root.parents[1]
previous = root.parent / 'r4-residual-audit/owned-package-resources.json'
manifest = json.loads(previous.read_text())
domains = set(manifest['ownedDomains'])
for label in ('normal-slow-drag-v5', 'normal-slow-drag-v6', 'normal-slow-drag-v7', 'normal-slow-drag-v8'):
    run = share / label
    domains_file = run / 'drag/owned-domains.txt'
    stage_exit = run / 'stage-exit-code.txt'
    assert domains_file.is_file() and stage_exit.is_file(), label + ' must finish before union freeze'
    domains.update(domains_file.read_text().splitlines())
    for path in (domains_file, stage_exit):
        manifest['sourceFiles'][str(path.relative_to(share))] = hashlib.sha256(path.read_bytes()).hexdigest()
assert all(re.fullmatch(r'(com\.leoarrow\.wattson\.modules-slow\.|Wattson\.SwiftTests\.ModuleOrderView\.)[A-Fa-f0-9-]+', x) for x in domains)
manifest['ownedDomains'] = sorted(domains)
manifest['ownedPaths'] = [str(Path('/Users/admin/Library') / parent / (domain + suffix))
                          for domain in sorted(domains)
                          for parent, suffix in [('Preferences', '.plist'), ('Containers', ''), ('Application Scripts', '')]]
manifest['ownedPaths'].append(manifest['ownedGuestProbe'])
manifest['ownedSharedIPCRoots'] = ['/Volumes/My Shared Files/normaldrag/normal-slow-drag-v' + str(n) + '/drag/manual-classic-0' for n in range(2, 9)]
manifest['scope'] = 'v2-v8 resource union; current direct-VZ loopback VM; no guest legacy VNC configuration'
(root / 'owned-package-resources.json').write_text(json.dumps(manifest, indent=2) + '\n')
files = {name: (root / name).read_bytes() for name in ['package-audit-probe.py', 'owned-package-resources.json']}
buffer = io.BytesIO()
with tarfile.open(fileobj=buffer, mode='w:gz') as archive:
    for name, data in files.items():
        member = tarfile.TarInfo(name)
        member.size = len(data)
        member.mode = 0o600
        archive.addfile(member, io.BytesIO(data))
payload = buffer.getvalue()
digest = hashlib.sha256(payload).hexdigest()
archive = root / ('audit-tools-' + digest + '.tar.gz')
archive.write_bytes(payload)
freeze = {'archive': str(archive.relative_to(share)), 'archiveSHA256': digest,
          'files': {name: hashlib.sha256(data).hexdigest() for name, data in files.items()},
          'bootstrapSHA256': hashlib.sha256((root / 'bootstrap-package-audit.py').read_bytes()).hexdigest()}
(root / 'audit-freeze.json').write_text(json.dumps(freeze, indent=2) + '\n')
print(json.dumps({'resourceDomainCount': len(domains), 'archiveSHA256': digest, 'auditNotExecuted': True}))
