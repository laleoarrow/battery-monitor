"""Read-only residual audit of this disposable VM's owned package installation."""
import datetime, json, os, re, subprocess, sys, time
from pathlib import Path

manifest = json.loads(Path(sys.argv[1]).read_text())
project = Path.home() / 'Project/Wattson-NormalSlowDrag-QA'
self_root = Path(__file__).resolve().parent

def command(args):
    return subprocess.run(args, capture_output=True, text=True, encoding='utf-8', errors='replace', timeout=35)

assert os.getuid() != 0
model = command(['/usr/sbin/sysctl', '-n', 'hw.model'])
assert model.returncode == 0 and model.stdout.strip().startswith('VirtualMac')
assert command(['/usr/bin/sudo', '-n', '/usr/bin/true']).returncode == 0
assert manifest['guestProject'] == str(project)
assert all(re.fullmatch(r'(com\.leoarrow\.wattson\.modules-slow\.|Wattson\.SwiftTests\.ModuleOrderView\.)[A-Fa-f0-9-]+', x) for x in manifest['ownedDomains'])
paths = [Path(x) for x in manifest['ownedPaths']]

def observe():
    record = {'atUTC': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'systemMonotonic': time.clock_gettime(time.CLOCK_MONOTONIC)}
    record['residualOwnedPaths'] = [str(p) for p in paths if p.exists() or p.is_symlink()]
    record['residualSharedIPCTemporaryFiles'] = [str(p) for root in manifest['ownedSharedIPCRoots'] for pattern in ('.command-*', '*.pending') for p in Path(root).glob(pattern)]
    defaults = {x: command(['/usr/bin/defaults', 'read', x]) for x in manifest['ownedDomains']}
    record['defaultsDomains'] = {x: {'exitCode': r.returncode, 'explicitMissingDomain': r.returncode == 1 and x.casefold() in (r.stdout + r.stderr).casefold() and 'does not exist' in (r.stdout + r.stderr).casefold()} for x, r in defaults.items()}
    registrar = '/System/Library/Frameworks/CoreServices.framework/Frameworks/LaunchServices.framework/Support/lsregister'
    registrations = command([registrar, '-dump'])
    spotlight = command(['/usr/bin/mdfind', ' || '.join('(kMDItemCFBundleIdentifier == \"' + x + '\")' for x in manifest['ownedDomains'])])
    processes = command(['/bin/ps', '-axo', 'pid=,ppid=,args='])
    mounts = command(['/sbin/mount'])
    results = dict(registrations=registrations, spotlight=spotlight, processes=processes, mounts=mounts)
    record['commandExitCodes'] = {n: r.returncode for n, r in results.items()}
    record['residualRegistrations'] = [x for x in manifest['ownedDomains'] + [str(project)] if x.casefold() in registrations.stdout.casefold()]
    record['residualSpotlightApps'] = spotlight.stdout.splitlines()
    rows = {}
    for row in processes.stdout.splitlines():
        values = row.split(None, 2)
        if len(values) == 3:
            rows[int(values[0])] = {'ppid': int(values[1]), 'args': values[2]}
    ancestors = {os.getpid()}; current = os.getpid()
    while current in rows and rows[current]['ppid'] not in ancestors:
        current = rows[current]['ppid']; ancestors.add(current)
    needles = [str(project)]
    record['residualProcesses'] = [{'pid': pid, **v} for pid, v in rows.items() if pid not in ancestors and any(x in v['args'] for x in needles)]
    record['residualProjectMounts'] = [x for x in mounts.stdout.splitlines() if str(project) in x]
    record['residualProjectContents'] = [str(p) for p in project.rglob('*') if p != self_root and self_root not in p.parents and p not in self_root.parents]
    record['allAbsent'] = not record['residualOwnedPaths'] and all(n['explicitMissingDomain'] for n in record['defaultsDomains'].values()) and all(n == 0 for n in record['commandExitCodes'].values()) and not any(record[x] for x in ['residualSharedIPCTemporaryFiles', 'residualRegistrations', 'residualSpotlightApps', 'residualProcesses', 'residualProjectMounts', 'residualProjectContents'])
    return record

immediate = observe()
start = time.clock_gettime(time.CLOCK_MONOTONIC)
time.sleep(95)
elapsed = time.clock_gettime(time.CLOCK_MONOTONIC) - start
assert elapsed >= 95
delayed = observe()
record = {'schema': 1, 'scope': 'Disposable native fixture VM only; read-only audit; guest legacy-VNC disable proof recorded separately; no product verdict', 'manifest': manifest, 'immediate': immediate, 'delayed': delayed, 'withinProcessQuietSeconds': elapsed, 'allAbsent': immediate['allAbsent'] and delayed['allAbsent'], 'deletedAnything': False}
print(json.dumps(record, indent=2), flush=True)
raise SystemExit(0 if record['allAbsent'] else 1)
