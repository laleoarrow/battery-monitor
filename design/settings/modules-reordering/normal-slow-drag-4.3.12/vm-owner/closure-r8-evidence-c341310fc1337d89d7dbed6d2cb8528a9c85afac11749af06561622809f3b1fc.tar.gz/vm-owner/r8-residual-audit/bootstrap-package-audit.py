"""Saved transport. Execute sealed audit inputs from guest-native storage and own staging cleanup."""
import hashlib, json, os, shutil, signal, subprocess, sys, tarfile, tempfile
from pathlib import Path

manifest = json.loads(sys.argv[1])
share = Path('/Volumes/My Shared Files/normaldrag')
project = Path.home() / 'Project/Wattson-NormalSlowDrag-QA'
root = project / '.build/package-residual-audit.noindex'
created = []; run = None; child = None; status = 1; record = None
signals = [signal.SIGHUP, signal.SIGINT, signal.SIGTERM]
def interrupted(number, frame):
    global status
    status = 128 + number
    raise SystemExit(status)
for number in signals:
    signal.signal(number, interrupted)
try:
    assert project.parent.is_dir()
    for p in [project, project / '.build', root]:
        if not p.exists():
            created.append(p)
            p.mkdir()
    blocked = signal.pthread_sigmask(signal.SIG_BLOCK, signals)
    try:
        run = Path(tempfile.mkdtemp(prefix='run.', dir=root))
    finally:
        signal.pthread_sigmask(signal.SIG_SETMASK, blocked)
    archive = run / 'audit.tar.gz'
    shutil.copyfile(share / manifest['archive'], archive)
    assert hashlib.sha256(archive.read_bytes()).hexdigest() == manifest['archiveSHA256']
    with tarfile.open(archive, 'r:gz') as t:
        assert set(t.getnames()) == set(manifest['files'])
        for m in t.getmembers():
            assert m.isfile() and m.name in manifest['files']
            (run / m.name).write_bytes(t.extractfile(m).read())
    assert {n: hashlib.sha256((run / n).read_bytes()).hexdigest() for n in manifest['files']} == manifest['files']
    blocked = signal.pthread_sigmask(signal.SIG_BLOCK, signals)
    try:
        child = subprocess.Popen(['/usr/bin/python3', str(run / 'package-audit-probe.py'), str(run / 'owned-package-resources.json')], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, start_new_session=True)
    finally:
        signal.pthread_sigmask(signal.SIG_SETMASK, blocked)
    stdout, stderr = child.communicate(timeout=260)
    status = child.returncode
    try:
        audit = json.loads(stdout)
    except json.JSONDecodeError:
        if status == 0: status = 1
        audit = {'probeDidNotProduceJSON': True, 'stdout': stdout}
    record = {'probeExitCode': status, 'audit': audit, 'stderr': stderr, 'toolArchiveSHA256': manifest['archiveSHA256'], 'verifiedGuestLocalBeforeExecution': True}
finally:
    for number in signals:
        signal.signal(number, signal.SIG_IGN)
    cleanup_errors = []
    try:
        if child is not None:
            if child.poll() is None:
                try: os.killpg(child.pid, signal.SIGTERM)
                except ProcessLookupError: pass
                try: child.wait(timeout=5)
                except subprocess.TimeoutExpired: pass
            try: os.killpg(child.pid, signal.SIGKILL)
            except ProcessLookupError: pass
            child.wait(timeout=5)
    except Exception as error:
        cleanup_errors.append(repr(error))
    finally:
        try:
            if run is not None:
                shutil.rmtree(run)
        except OSError as error:
            cleanup_errors.append(repr(error))
        for p in reversed(created):
            try: p.rmdir()
            except FileNotFoundError: pass
            except OSError as error: cleanup_errors.append(repr(error))
        if cleanup_errors and status == 0:
            status = 1
        if record is not None:
            record['stageExitCode'] = status
            record['stagingRemoved'] = run is None or not run.exists()
            record['newStageParentsRemoved'] = all(not p.exists() for p in created)
            record['createdStageParents'] = [str(p) for p in created]
            record['cleanupErrors'] = cleanup_errors
            try:
                output = share / 'vm-owner/r8-residual-audit/final-owned-residual-audit.json'
                assert not output.exists()
                output.write_text(json.dumps(record, indent=2) + '\n')
            except Exception as error:
                if status == 0: status = 1
                print('Audit export failed: ' + repr(error), file=sys.stderr)
raise SystemExit(status)
