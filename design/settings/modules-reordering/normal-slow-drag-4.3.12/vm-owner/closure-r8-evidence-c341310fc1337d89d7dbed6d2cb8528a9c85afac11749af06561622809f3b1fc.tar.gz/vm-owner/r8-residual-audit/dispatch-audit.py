import hashlib,json,subprocess
from pathlib import Path
p=Path(__file__).resolve().parent
m=json.loads((p/'audit-freeze.json').read_text());code=(p/'bootstrap-package-audit.py').read_text()
assert hashlib.sha256(code.encode()).hexdigest()==m['bootstrapSHA256']
raise SystemExit(subprocess.call(['/opt/homebrew/bin/tart','exec','Wattson-NormalSlowDrag-20261017','/usr/bin/python3','-c',code,json.dumps(m)]))
