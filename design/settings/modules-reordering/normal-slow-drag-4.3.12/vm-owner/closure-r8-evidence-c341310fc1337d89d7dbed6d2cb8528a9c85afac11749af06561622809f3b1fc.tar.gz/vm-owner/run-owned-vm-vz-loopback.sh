#!/bin/bash
set -euo pipefail
umask 077
[[ "${1:-}" == --launch-go && "$#" == 1 ]] || { echo 'Prepared only: require explicit parent launch GO (--launch-go).' >&2; exit 64; }
repo='/Users/leoarrow/Project/mypackage/agents/电池功率'
owner="$repo/.build/normal-slow-drag.noindex/vm-owner"
share="$repo/.build/normal-slow-drag.noindex"
vm='Wattson-NormalSlowDrag-20261017'
TART='/opt/homebrew/bin/tart'
export TART_NO_AUTO_PRUNE=1
source "$repo/scripts/lib/local_cleanup.sh"
wattson_cleanup_init
owned_vm=0
session=''
return_status() { return "$1"; }
mark_cleanup_failure() { [[ "$status" != 0 ]] || status=1; }
vm_cleanup() {
  local status=$? state='' cleanup_error=0
  trap - EXIT
  trap '' HUP INT TERM
  set +e
  if [[ -n "${_WATTSON_RUNNER_PID:-}" ]]; then
    kill -TERM "$_WATTSON_RUNNER_PID" 2>/dev/null
    wait "$_WATTSON_RUNNER_PID" 2>/dev/null
    _WATTSON_RUNNER_PID=''
  fi
  if [[ "$owned_vm" == 1 ]]; then
    # Cleanup mutations never depend on opening a log file.
    wattson_run_timeout 30 "$TART" stop "$vm" --timeout 20 >/dev/null 2>&1
    local stop_status=$? current_json=''
    if ! current_json="$(wattson_run_timeout 10 "$TART" list --format json)"; then
      if ! current_json="$(wattson_run_timeout 10 "$TART" list --format json)"; then
        current_json=''; cleanup_error=1
      fi
    fi
    if [[ -n "$current_json" ]]; then
      printf '%s\n' "$current_json" > "$session/vms-after-stop.json" || cleanup_error=1
      state="$(printf '%s\n' "$current_json" | /usr/bin/python3 "$owner/vm-state.py" state -)" || cleanup_error=1
    fi
    case "$state" in
      stopped)
        wattson_run_timeout 20 "$TART" delete "$vm" >/dev/null 2>&1
        local delete_status=$?
        [[ "$delete_status" == 0 ]] || cleanup_error=1
        printf '%s\n' "$delete_status" > "$session/delete-command-exit.txt" || cleanup_error=1;;
      missing) ;;
      *) cleanup_error=1;;
    esac
    if current_json="$(wattson_run_timeout 10 "$TART" list --format json)"; then
      printf '%s\n' "$current_json" > "$session/vms-after-cleanup.json" || cleanup_error=1
      printf '%s\n' "$current_json" | /usr/bin/python3 "$owner/vm-state.py" after "$session/vms-before.json" - > "$session/vm-cleanup-summary.json" 2> "$session/vm-cleanup-summary.err" || cleanup_error=1
    else cleanup_error=1; fi
    printf '%s\n' "$stop_status" > "$session/stop-command-exit.txt" || cleanup_error=1
  fi
  if [[ -n "$session" ]]; then
    wattson_run_timeout 10 /usr/bin/python3 "$owner/cleanup-vnc-private.py" "$session" || cleanup_error=1
  fi
  [[ "$cleanup_error" == 0 ]] || mark_cleanup_failure
  if [[ -n "$session" ]]; then
    printf '%s\n' "$status" > "$session/exit-code.txt" || mark_cleanup_failure
  fi
  return_status "$status"
  _wattson_cleanup
}
trap vm_cleanup EXIT
# Retained evidence, not disposable runnable content. VM disk is always removed.
session="$(mktemp -d "$owner/session.XXXXXX")"
printf '%s\n' "$$" > "$session/owner.pid"
printf '%s\n' "$session" > "$owner/latest-session-path.txt"
wattson_run_timeout 90 /usr/bin/python3 "$owner/snapshot-readonly.py" "$session/host-before.json" > "$session/host-before.log"
wattson_run_timeout 10 "$TART" list --format json > "$session/vms-before.json"
/usr/bin/python3 "$owner/vm-state.py" preflight "$session/vms-before.json"
# Register this absent runtime before allocation, so every later exit owns cleanup.
runtime="$share/loopback-vz/runtime.${session##*/}"
[[ ! -e "$runtime" && ! -L "$runtime" ]] || exit 1
wattson_cleanup_add_dir "$runtime"
/bin/mkdir -m 700 "$runtime"
printf '%s\n' "$runtime" > "$session/runtime-path.txt"
/usr/bin/python3 "$repo/scripts/lib/run_owned.py" --grace 8 --timeout 300 -- /usr/bin/python3 "$share/loopback-vz/prepare-runtime.py" "$runtime" > "$session/runtime-build.log" 2>&1 &
_WATTSON_RUNNER_PID=$!
build_status=0
wait "$_WATTSON_RUNNER_PID" || build_status=$?
_WATTSON_RUNNER_PID=''
for artifact in metadata.json entitlements.plist version-probe-trace.jsonl; do
  if [[ -f "$runtime/$artifact" && ! -L "$runtime/$artifact" ]]; then
    copy_status=0
    wattson_run_timeout 10 /bin/cp "$runtime/$artifact" "$session/runtime-$artifact" || copy_status=$?
    [[ "$copy_status" == 0 || "$build_status" != 0 ]] || build_status=$copy_status
  elif [[ "$build_status" == 0 ]]; then
    build_status=1
  fi
done
[[ "$build_status" == 0 ]] || exit "$build_status"
# Preflight and copy validation succeeded; claim the exact VM identity before clone.
owned_vm=1
wattson_run_timeout 300 "$TART" clone macOS-TestLab-Base "$vm" > "$session/vm-clone.log" 2>&1
wattson_run_timeout 30 "$TART" set "$vm" --cpu 2 --memory 8192 --no-display-refit > "$session/vm-config.log" 2>&1
printf 'OWNED_VM_CREATED %s\nEVIDENCE %s\n' "$vm" "$session"
/usr/bin/python3 "$repo/scripts/lib/run_owned.py" --grace 8 --timeout 1800 -- /usr/bin/python3 "$owner/vnc-guard.py" --session "$session" --owned-vm "$vm" --tart-interpose-library "$runtime/loopback.dylib" -- "$runtime/tart" run --vnc-experimental --no-graphics --no-audio --no-clipboard --dir "repo:$repo:ro" --dir "normaldrag:$share" "$vm" > "$session/vm-run.log" 2>&1 &
_WATTSON_RUNNER_PID=$!
run_status=0
wait "$_WATTSON_RUNNER_PID" || run_status=$?
_WATTSON_RUNNER_PID=''
exit "$run_status"
