#!/usr/bin/env python3
"""Run real injection and failure/interruption cleanup without a VM or UI."""
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
PROJECT = ROOT.parents[2]
RUNNER = PROJECT / "scripts/lib/run_owned.py"
active = None


def interrupted(number, _frame):
    raise SystemExit(128 + number)


for caught in (signal.SIGHUP, signal.SIGINT, signal.SIGTERM):
    signal.signal(caught, interrupted)


def alive(pid):
    try:
        os.kill(pid, 0)
        state = subprocess.run(["/bin/ps", "-o", "stat=", "-p", str(pid)], text=True, capture_output=True, timeout=5).stdout.strip()
        return bool(state) and not state.startswith("Z")
    except ProcessLookupError:
        return False


def run_case(label, mode, number=None, timeout=None, expected_status=None):
    global active
    out = ROOT / "evidence" / ("nat-" + label)
    out.mkdir(exist_ok=False)
    command = [sys.executable, str(RUNNER), "--grace", "10"]
    if timeout is not None:
        command += ["--timeout", str(timeout)]
    command += ["--", "/bin/bash", str(ROOT / "run-native.sh"), str(out), mode]
    with (out / "entry.log").open("w") as log:
        active = subprocess.Popen(command, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        try:
            if number is not None or timeout is not None:
                ready = out / "hold-ready.json"
                deadline = time.monotonic() + 90
                while not ready.exists() and active.poll() is None and time.monotonic() < deadline:
                    time.sleep(.05)
                if not ready.exists():
                    raise RuntimeError(f"{label}: no ready child")
                if number is not None:
                    os.kill(active.pid, number)
            status = active.wait(timeout=100)
        finally:
            if active.poll() is None:
                os.kill(active.pid, signal.SIGTERM)
                try:
                    active.wait(timeout=15)
                except subprocess.TimeoutExpired:
                    os.killpg(active.pid, signal.SIGKILL)
                    active.wait()
            active = None
    runtime = Path((out / "runtime-path.txt").read_text().strip())
    ready = out / "hold-ready.json"
    children = json.loads(ready.read_text()) if ready.exists() else {}
    no_children = all(not alive(pid) for pid in children.values())
    expected = expected_status if expected_status is not None else 128 + number if number is not None else 124 if timeout is not None else 23 if mode == "fail" else 0
    result = {"case": label, "exitCode": status, "expectedExitCode": expected,
              "runtimeAbsent": not runtime.exists(), "ownedChildPIDs": children,
              "ownedChildrenAbsent": no_children}
    result["passed"] = status == expected and result["runtimeAbsent"] and no_children
    (out / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    if not result["passed"]:
        raise RuntimeError(json.dumps(result))
    return result


results = [run_case("native-success", "normal"), run_case("ordinary-failure", "fail")]
for label, number in (("hup", signal.SIGHUP), ("int", signal.SIGINT), ("term", signal.SIGTERM)):
    results.append(run_case(label, "hold", number=number))
# Includes compilation/signing; once ready it must remain held until timeout.
results.append(run_case("timeout", "hold", timeout=20))
checks = [json.loads(line) for line in (ROOT / "evidence/nat-native-success/harness.jsonl").read_text().splitlines()]
trace = [json.loads(line) for line in (ROOT / "evidence/nat-native-success/harness-trace.jsonl").read_text().splitlines()]
version_trace = [json.loads(line) for line in (ROOT / "evidence/nat-native-success/version-trace.jsonl").read_text().splitlines()]
if not checks or not all(row["passed"] for row in checks):
    raise RuntimeError("native fixture did not pass")
summary = {"lifecycle": results, "nativeAssertions": checks, "nativeAssertionCount": len(checks),
           "traceCounts": {event: sum(row["event"] == event for row in trace) for event in sorted({row["event"] for row in trace})},
           "nativeSocketAssertionsPassed": True, "copyVersionExitCode": 0,
           "copyVersionRanInjected": any(row["event"] == "loaded" for row in version_trace),
           "copyExecutableFeasibilityPassed": True, "vmGO": False, "noVMStarted": True,
           "remainingRuntimeDirectories": [str(path) for path in ROOT.glob("runtime.*")],
           "limits": "Native socket shim proved; actual Virtualization.framework listener path, VM entitlement validity and actual lsof listener gate await separate VM verification."}
if summary["remainingRuntimeDirectories"]:
    raise RuntimeError("owned runtime remained")
(ROOT / "evidence/summary-nat.json").write_text(json.dumps(summary, indent=2) + "\n")
manifest = {}
for directory in (ROOT / "source", ROOT / "evidence"):
    for path in sorted(directory.rglob("*")):
        if path.is_file() and path.name != "SHA256.json":
            manifest[str(path.relative_to(ROOT))] = hashlib.sha256(path.read_bytes()).hexdigest()
for name in ("prepare-runtime.py", "run-native.sh", "launch-probe.py", "verify-native.py"):
    manifest[name] = hashlib.sha256((ROOT / name).read_bytes()).hexdigest()
(ROOT / "evidence/SHA256-nat.json").write_text(json.dumps(manifest, indent=2) + "\n")
print(json.dumps({"nativeSocketAssertionsPassed": True, "copyExecutableFeasibilityPassed": True, "vmGO": False,
                  "nativeAssertions": len(checks), "lifecycleCases": len(results)}))
