#!/usr/bin/env python3
"""Fill a caller-owned empty runtime.* directory; caller owns its final cleanup."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import plistlib
import shutil
import signal
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
PROJECT = ROOT.parents[2]
RUNNER = PROJECT / "scripts/lib/run_owned.py"
ORIGINAL = Path("/Users/leoarrow/Applications/tart.app/Contents/MacOS/tart")
SOURCE_ENTITLEMENTS = {"com.apple.security.virtualization": True, "com.apple.vm.networking": True}
COPY_ENTITLEMENTS = {"com.apple.security.virtualization": True}
active = None


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def command(arguments, env=None, pass_fds=(), check=True):
    global active
    active = subprocess.Popen([sys.executable, str(RUNNER), "--timeout", "60", "--", *map(str, arguments)],
                              env=env, pass_fds=pass_fds, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                              text=True, start_new_session=True)
    try:
        stdout, stderr = active.communicate(timeout=70)
        status = active.returncode
    finally:
        if active.poll() is None:
            os.kill(active.pid, signal.SIGTERM)
            try:
                active.communicate(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(active.pid, signal.SIGKILL)
                active.communicate()
        active = None
    if check and status != 0:
        raise RuntimeError(f"command failed ({status}): {arguments[0]}\n{stderr}")
    return {"stdout": stdout, "stderr": stderr, "exitCode": status}


def interruption(number, _frame):
    raise SystemExit(128 + number)


def prepare(output):
    if output != Path(os.path.abspath(output)) or output.is_symlink() or output.parent != ROOT or not output.name.startswith("runtime."):
        raise ValueError("output must be an absolute nonsymlink loopback-vz/runtime.* directory")
    if not output.is_dir() or any(output.iterdir()):
        raise ValueError("caller must create an empty runtime.* directory")
    source_hash = digest(ORIGINAL)
    complete = False
    try:
        source_signature = command(["/usr/bin/codesign", "-dvvv", ORIGINAL])["stderr"]
        source_entitlements = command(["/usr/bin/codesign", "-d", "--entitlements", ":-", ORIGINAL])["stdout"]
        if plistlib.loads(source_entitlements.encode()) != SOURCE_ENTITLEMENTS or "flags=0x10000(runtime)" not in source_signature:
            raise ValueError("original signature/entitlements differ from reviewed original")
        entitlements_path = output / "entitlements.plist"
        entitlements_path.write_bytes(plistlib.dumps(COPY_ENTITLEMENTS))
        compiler = command(["/usr/bin/xcrun", "clang", "--version"])["stdout"]
        compile_command = ["/usr/bin/xcrun", "clang", "-dynamiclib", "-O2", "-Wall", "-Wextra", "-Werror",
                           ROOT / "source/loopback_bind.c", "-o", output / "loopback.dylib"]
        command(compile_command)
        command(["/usr/bin/codesign", "--force", "--sign", "-", output / "loopback.dylib"])
        shutil.copyfile(ORIGINAL, output / "tart")
        os.chmod(output / "tart", 0o700)
        copy_before_sign = digest(output / "tart")
        if copy_before_sign != source_hash:
            raise ValueError("copy differs before signing")
        command(["/usr/bin/codesign", "--force", "--sign", "-", "--options", "0", "--entitlements", entitlements_path, output / "tart"])
        command(["/usr/bin/codesign", "--verify", "--strict", output / "tart"])
        copy_signature = command(["/usr/bin/codesign", "-dvvv", output / "tart"])["stderr"]
        copy_entitlements = command(["/usr/bin/codesign", "-d", "--entitlements", ":-", output / "tart"])["stdout"]
        directory_line = next((line for line in copy_signature.splitlines() if line.startswith("CodeDirectory ")), "")
        if plistlib.loads(copy_entitlements.encode()) != COPY_ENTITLEMENTS or "Signature=adhoc" not in copy_signature or "flags=0x2(adhoc)" not in directory_line:
            raise ValueError("copy signing verification failed")
        if digest(ORIGINAL) != source_hash:
            raise ValueError("original changed")
        metadata = {
            "sourcePath": str(ORIGINAL), "sourceSHA256": source_hash,
            "copyBeforeSigningSHA256": copy_before_sign, "copySHA256": digest(output / "tart"),
            "librarySHA256": digest(output / "loopback.dylib"),
            "shimSourceSHA256": digest(ROOT / "source/loopback_bind.c"),
            "builderSHA256": digest(Path(__file__)), "entitlements": COPY_ENTITLEMENTS,
            "sourceEntitlements": SOURCE_ENTITLEMENTS, "copyProfile": "NAT-only",
            "compiler": compiler, "compileCommand": [str(p) for p in compile_command],
            "sourceSignature": source_signature, "copySignature": copy_signature,
            "sourceUnchanged": True, "runtimeEnvironment": {
                "DYLD_INSERT_LIBRARIES": str(output / "loopback.dylib"),
                "WATTSON_LOOPBACK_TRACE_FD": "caller-opened private regular-file FD > 2"},
            "limitations": "No VM launch; Virtualization.framework listener interception remains unproven."
        }
        version = command([sys.executable, ROOT / "launch-probe.py", output / "loopback.dylib",
                           output / "version-probe-trace.jsonl", "--", output / "tart", "--version"], check=False)
        version_trace = [json.loads(line) for line in (output / "version-probe-trace.jsonl").read_text().splitlines()]
        version["shimLoaded"] = any(row.get("event") == "loaded" for row in version_trace)
        version["traceSHA256"] = digest(output / "version-probe-trace.jsonl")
        metadata["versionProbe"] = version
        (output / "metadata.json").write_text(json.dumps(metadata, indent=2) + "\n")
        if version["exitCode"] != 0 or not version["shimLoaded"]:
            raise RuntimeError("copied Tart execution gate rejected: " + json.dumps(version))
        complete = True
        print(json.dumps({"prepared": str(output), "copySHA256": metadata["copySHA256"], "librarySHA256": metadata["librarySHA256"]}))
    finally:
        if not complete:
            for path in output.iterdir():
                if path.is_dir() and not path.is_symlink():
                    shutil.rmtree(path)
                else:
                    path.unlink()


if __name__ == "__main__":
    for caught in (signal.SIGHUP, signal.SIGINT, signal.SIGTERM):
        signal.signal(caught, interruption)
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    prepare(args.output)
