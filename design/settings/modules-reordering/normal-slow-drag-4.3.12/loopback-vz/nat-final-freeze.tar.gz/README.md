# Child-local loopback transport experiment

The native socket shim and NAT-only copied Tart execution passed. No VM was
started by these checks. Actual Virtualization.framework interception remains
subject to the VM owner's exact-process `lsof` loopback check and matching
successful bind-rewrite / listen-pass trace.

`prepare-runtime.py /absolute/path/to/loopback-vz/runtime.UNIQUE` fills an
existing empty caller-owned directory. The caller must register that directory
with the shared lifecycle cleanup before invoking the builder, and remove it
after stopping its owned VM. The directory must be directly under this folder.

The builder creates `tart`, `loopback.dylib`, `entitlements.plist`,
`metadata.json`, and private `version-probe-trace.jsonl`. Only the latter three
are safe retained evidence. The builder verifies the unchanged original Tart,
signs its copy ad hoc with only `com.apple.security.virtualization=true` and
without hardened runtime, then requires copied `--version` exit 0 and an actual
shim constructor trace before returning. A failure removes all files it created.
The original keeps its Developer ID signature, hardened runtime and its original
two entitlements; no original bytes or host permissions are changed.

The child launcher supplies `DYLD_INSERT_LIBRARIES` and
`WATTSON_LOOPBACK_TRACE_FD` only to the copy process. The constructor clears both
from that process environment and makes the validated private trace descriptor
close on exec. The parent environment is untouched. Trace fields contain only
fixed labels, descriptor/family values and call status, never credentials or IPs.

All Internet TCP wildcard binds in that process are rewritten to literal
127.0.0.1 / ::1. `listen` independently refuses a nonliteral Internet stream
address, and refuses any stream whose local address cannot be established.
Normal UDP, Unix and nonwildcard bind calls retain system behavior. No port is
used to identify VNC. The actual listener remains independently verified.

`source/getname_failure.c` is a native-harness-only fault injector. It never
appears in the runtime builder's output. The fixture first checks both bind and
listen function imports resolve to the exact private shim, checks the actual
post-bind addresses, and refuses to proceed with ambiguous injection. All
nonliteral refusal cases run only after that gate. The forced getsockname
failure socket is already bound to loopback. Nonblocking accept checks actual
listener state because this Darwin kernel rejects SO_ACCEPTCONN with
ENOPROTOOPT. Every socket closes on the tested path or process exit.

Frozen two-entitlement evidence preserves the OS-killed copied `--version`
status 137 separately from 17 passing native assertions and six cleanup cases.
The subsequent authorized NAT-only copy returned version 2.35.0 with actual
constructor loading; 17 native assertions and success/failure/HUP/INT/TERM/timeout
cleanup all passed. These are local transport feasibility results, not chart
performance measurements, a VZ proof, or host app installation evidence.
