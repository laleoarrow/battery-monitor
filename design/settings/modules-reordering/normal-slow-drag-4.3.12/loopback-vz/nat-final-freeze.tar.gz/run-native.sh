#!/bin/bash
set -euo pipefail
root="$(cd "$(dirname "$0")" && pwd)"
project="$(cd "$root/../../.." && pwd)"
source "$project/scripts/lib/local_cleanup.sh"
wattson_cleanup_init
evidence="$1"
mode="${2:-normal}"
[[ -d "$evidence" && "$evidence" == "$root/evidence/"* ]] || exit 2
runtime="$(mktemp -d "$root/runtime.XXXXXX")"
wattson_cleanup_add_dir "$runtime"
printf '%s\n' "$runtime" > "$evidence/runtime-path.txt"
wattson_run_timeout 120 /usr/bin/python3 "$root/prepare-runtime.py" "$runtime" > "$evidence/build.log" 2>&1
cp "$runtime/metadata.json" "$evidence/runtime-metadata.json"
wattson_run_timeout 60 /usr/bin/xcrun clang -O2 -Wall -Wextra -Werror "$root/source/socket_harness.c" -o "$runtime/socket-harness" > "$evidence/harness-build.log" 2>&1
wattson_run_timeout 60 /usr/bin/xcrun clang -dynamiclib -O2 -Wall -Wextra -Werror "$root/source/getname_failure.c" -o "$runtime/getname-failure.dylib" >> "$evidence/harness-build.log" 2>&1
wattson_run_timeout 10 /usr/bin/shasum -a 256 "$runtime/socket-harness" "$runtime/getname-failure.dylib" > "$evidence/native-artifacts.sha256"
wattson_run_timeout 10 /usr/bin/codesign -dvvv "$runtime/socket-harness" 2> "$evidence/harness-signature.txt"
wattson_run_timeout 10 /usr/bin/codesign -dvvv "$runtime/getname-failure.dylib" 2> "$evidence/getname-failure-signature.txt"
cp "$root/source/hold.py" "$runtime/hold.py"
if [[ "$mode" == "fail" ]]; then exit 23; fi
if [[ "$mode" == "hold" ]]; then
    wattson_run_timeout 120 /usr/bin/python3 "$runtime/hold.py" "$evidence/hold-ready.json"
    exit 0
fi
cd "$runtime"
status=0
wattson_run_timeout 30 /usr/bin/python3 "$root/launch-probe.py" --append-fd --extra-library "$runtime/getname-failure.dylib" "$runtime/loopback.dylib" "$runtime/harness-trace.jsonl" -- "$runtime/socket-harness" . > "$evidence/harness.jsonl" 2> "$evidence/harness.stderr" || status=$?
[[ ! -f "$runtime/harness-trace.jsonl" ]] || cp "$runtime/harness-trace.jsonl" "$evidence/harness-trace.jsonl"
[[ "$status" == 0 ]] || exit "$status"
status=0
wattson_run_timeout 30 /usr/bin/python3 "$root/launch-probe.py" "$runtime/loopback.dylib" "$runtime/version-trace.jsonl" -- "$runtime/tart" --version > "$evidence/tart-version.txt" 2> "$evidence/tart-version.stderr" || status=$?
printf '{"exitCode":%s}\n' "$status" > "$evidence/tart-version-status.json"
[[ ! -f "$runtime/version-trace.jsonl" ]] || cp "$runtime/version-trace.jsonl" "$evidence/version-trace.jsonl"
exit "$status"
