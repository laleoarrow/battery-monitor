#include <arpa/inet.h>
#include <dlfcn.h>
#include <errno.h>
#include <fcntl.h>
#include <ifaddrs.h>
#include <limits.h>
#include <mach-o/dyld.h>
#include <net/if.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <sys/wait.h>
#include <unistd.h>

static int failures;
static void check(const char *name, bool passed) {
    printf("{\"case\":\"%s\",\"passed\":%s}\n", name, passed ? "true" : "false");
    fflush(stdout);
    if (!passed) ++failures;
}
static bool address_is(int fd, int family, bool loopback) {
    struct sockaddr_storage local;
    socklen_t length = sizeof local;
    if (getsockname(fd, (struct sockaddr *)&local, &length) != 0 || local.ss_family != family) return false;
    if (family == AF_INET) {
        return ((struct sockaddr_in *)&local)->sin_addr.s_addr ==
               htonl(loopback ? INADDR_LOOPBACK : INADDR_ANY);
    }
    return loopback ? IN6_IS_ADDR_LOOPBACK(&((struct sockaddr_in6 *)&local)->sin6_addr) :
                      IN6_IS_ADDR_UNSPECIFIED(&((struct sockaddr_in6 *)&local)->sin6_addr);
}
static bool accepting(int fd) {
    /* This Darwin kernel rejects SO_ACCEPTCONN with ENOPROTOOPT. A nonblocking
       accept distinguishes a listener (EAGAIN) from an unlistened socket. */
    int saved = errno;
    int flags = fcntl(fd, F_GETFL);
    if (flags < 0 || fcntl(fd, F_SETFL, flags | O_NONBLOCK) != 0) { errno = saved; return false; }
    int accepted = accept(fd, NULL, NULL), error = errno;
    if (accepted >= 0) close(accepted);
    bool restored = fcntl(fd, F_SETFL, flags) == 0;
    errno = saved;
    return restored && (accepted >= 0 || error == EAGAIN || error == EWOULDBLOCK);
}
static void internet_case(int family, int kind, bool explicit_loopback) {
    int fd = socket(family, kind, 0);
    bool passed = fd >= 0;
    struct sockaddr_storage address = {0};
    socklen_t length;
    if (family == AF_INET) {
        struct sockaddr_in *v4 = (struct sockaddr_in *)&address;
        v4->sin_len = sizeof *v4; v4->sin_family = family;
        v4->sin_addr.s_addr = htonl(explicit_loopback ? INADDR_LOOPBACK : INADDR_ANY);
        length = sizeof *v4;
    } else {
        struct sockaddr_in6 *v6 = (struct sockaddr_in6 *)&address;
        v6->sin6_len = sizeof *v6; v6->sin6_family = family;
        v6->sin6_addr = explicit_loopback ? in6addr_loopback : in6addr_any;
        length = sizeof *v6;
    }
    bool tcp = kind == SOCK_STREAM;
    passed = passed && bind(fd, (struct sockaddr *)&address, length) == 0;
    passed = passed && address_is(fd, family, tcp || explicit_loopback) && !accepting(fd);
    errno = 123;
    int result = passed || !tcp ? listen(fd, 1) : -1, error = errno;
    if (tcp) passed = passed && result == 0 && error == 123 && accepting(fd) && address_is(fd, family, true);
    else passed = passed && result == -1 && error != EACCES && !accepting(fd) && address_is(fd, family, false);
    if (fd >= 0) close(fd);
    char name[80];
    snprintf(name, sizeof name, "%s-v%d-%s", tcp ? "tcp" : "udp", family == AF_INET ? 4 : 6,
             explicit_loopback ? "explicit-loopback" : "wildcard");
    check(name, passed);
}
static void implicit_case(int family) {
    int fd = socket(family, SOCK_STREAM, 0);
    errno = 0;
    int result = listen(fd, 1), error = errno;
    bool passed = fd >= 0 && result == -1 && error == EACCES && !accepting(fd) && address_is(fd, family, false);
    if (fd >= 0) close(fd);
    check(family == AF_INET ? "implicit-v4-refused" : "implicit-v6-refused", passed);
}
static void lan_case(void) {
    struct ifaddrs *addresses = NULL;
    bool found = false, passed = false;
    if (getifaddrs(&addresses) == 0) {
        for (struct ifaddrs *it = addresses; it; it = it->ifa_next) {
            if (!it->ifa_addr || it->ifa_addr->sa_family != AF_INET ||
                !(it->ifa_flags & IFF_UP) || (it->ifa_flags & IFF_LOOPBACK)) continue;
            found = true;
            struct sockaddr_in address = *(struct sockaddr_in *)it->ifa_addr;
            address.sin_port = 0;
            int fd = socket(AF_INET, SOCK_STREAM, 0);
            bool bound = fd >= 0 && bind(fd, (struct sockaddr *)&address, sizeof address) == 0;
            bool was_closed = bound && !accepting(fd);
            errno = 0;
            int result = bound ? listen(fd, 1) : 0, error = errno;
            passed = was_closed && result == -1 && error == EACCES && !accepting(fd);
            if (fd >= 0) close(fd);
            break;
        }
        freeifaddrs(addresses);
    }
    check("explicit-lan-bind-preserved-listen-refused", found && passed);
}
static void getname_failure_case(void) {
    int fd = socket(AF_INET, SOCK_STREAM, 0);
    struct sockaddr_in address = {.sin_len = sizeof address, .sin_family = AF_INET,
                                  .sin_addr.s_addr = htonl(INADDR_LOOPBACK)};
    bool bound = fd >= 0 && bind(fd, (struct sockaddr *)&address, sizeof address) == 0;
    bool target_unused = fcntl(40, F_GETFD) == -1 && errno == EBADF;
    int failed_fd = bound && target_unused ? dup2(fd, 40) : -1;
    if (fd >= 0) close(fd);
    errno = 0;
    int result = failed_fd >= 0 ? listen(failed_fd, 1) : 0, error = errno;
    bool passed = failed_fd >= 0 && result == -1 && error == EACCES && !accepting(failed_fd);
    if (failed_fd >= 0) close(failed_fd);
    check("getsockname-failure-refuses-stream", passed);
}
static void unix_case(const char *directory) {
    struct sockaddr_un address = {0};
    address.sun_len = sizeof address; address.sun_family = AF_UNIX;
    bool path_fits = snprintf(address.sun_path, sizeof address.sun_path, "%s/u.sock", directory) < (int)sizeof address.sun_path;
    int fd = socket(AF_UNIX, SOCK_STREAM, 0);
    bool bound = path_fits && fd >= 0 && bind(fd, (struct sockaddr *)&address, sizeof address) == 0;
    bool passed = bound && listen(fd, 1) == 0 && accepting(fd);
    if (fd >= 0) close(fd);
    if (bound) unlink(address.sun_path);
    check("unix-bind-listen-preserved", passed);
}
int main(int argc, char **argv) {
    if (argc == 3 && strcmp(argv[1], "--child-env") == 0) {
        bool clean = !getenv("DYLD_INSERT_LIBRARIES") && !getenv("WATTSON_LOOPBACK_TRACE_FD");
        errno = 0;
        clean = clean && fcntl(atoi(argv[2]), F_GETFD) == -1 && errno == EBADF;
        for (uint32_t i = 0; i < _dyld_image_count(); ++i) {
            const char *name = _dyld_get_image_name(i);
            if (name && strstr(name, "/loopback.dylib")) clean = false;
        }
        return clean ? 0 : 1;
    }
    if (argc != 3) return 2;
    Dl_info bind_image = {0}, listen_image = {0};
    char expected[PATH_MAX], bind_path[PATH_MAX], listen_path[PATH_MAX];
    const char *slash = strrchr(argv[0], '/');
    int expected_length = slash ? snprintf(expected, sizeof expected, "%.*s/loopback.dylib", (int)(slash - argv[0]), argv[0]) : -1;
    bool hooks_present = dladdr((const void *)bind, &bind_image) != 0 &&
                         dladdr((const void *)listen, &listen_image) != 0 &&
                         bind_image.dli_fname && listen_image.dli_fname &&
                         expected_length > 0 && expected_length < (int)sizeof expected &&
                         realpath(bind_image.dli_fname, bind_path) && realpath(listen_image.dli_fname, listen_path) &&
                         strcmp(bind_path, expected) == 0 && strcmp(listen_path, expected) == 0;
    check("bind-and-listen-imports-resolve-to-shim", hooks_present);
    if (!hooks_present) return 1;
    check("constructor-cleared-child-injection-environment", !getenv("DYLD_INSERT_LIBRARIES") && !getenv("WATTSON_LOOPBACK_TRACE_FD"));
    int trace_fd = atoi(argv[2]);
    int descriptor_flags = fcntl(trace_fd, F_GETFD);
    check("trace-fd-cloexec", descriptor_flags >= 0 && (descriptor_flags & FD_CLOEXEC) != 0);
    pid_t child = fork();
    if (child == 0) { execl(argv[0], argv[0], "--child-env", argv[2], NULL); _exit(127); }
    int status = -1;
    if (child > 0) while (waitpid(child, &status, 0) < 0 && errno == EINTR) {}
    check("exec-child-no-injection-no-trace-fd", child > 0 && WIFEXITED(status) && WEXITSTATUS(status) == 0);
    internet_case(AF_INET, SOCK_STREAM, false);
    internet_case(AF_INET6, SOCK_STREAM, false);
    internet_case(AF_INET, SOCK_STREAM, true);
    internet_case(AF_INET6, SOCK_STREAM, true);
    implicit_case(AF_INET); implicit_case(AF_INET6);
    lan_case();
    getname_failure_case();
    internet_case(AF_INET, SOCK_DGRAM, false);
    internet_case(AF_INET6, SOCK_DGRAM, false);
    unix_case(argv[1]);
    errno = 0;
    check("invalid-listen-errno-preserved", listen(-1, 1) == -1 && errno == EBADF);
    struct sockaddr_in address = {.sin_len = sizeof address, .sin_family = AF_INET};
    errno = 0;
    check("invalid-bind-errno-preserved", bind(-1, (struct sockaddr *)&address, sizeof address) == -1 && errno == EBADF);
    return failures ? 1 : 0;
}
