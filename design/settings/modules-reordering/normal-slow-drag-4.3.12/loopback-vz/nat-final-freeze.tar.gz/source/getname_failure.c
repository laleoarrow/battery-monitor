#include <errno.h>
#include <sys/socket.h>
/* Native harness only. Descriptor 40 is allocated after a confirmed loopback bind. */
static int failed_getsockname(int fd, struct sockaddr *address, socklen_t *length) {
    if (fd == 40) { errno = EIO; return -1; }
    return getsockname(fd, address, length);
}
__attribute__((used)) static struct { const void *replacement; const void *original; }
interpose_getsockname __attribute__((section("__DATA,__interpose"))) =
    {(const void *)failed_getsockname, (const void *)getsockname};
