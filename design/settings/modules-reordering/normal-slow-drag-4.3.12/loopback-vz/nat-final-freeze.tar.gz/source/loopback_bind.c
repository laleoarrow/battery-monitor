#include <arpa/inet.h>
#include <errno.h>
#include <fcntl.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <unistd.h>

/* Child-local transport guard. No filesystem or machine-wide configuration. */
static int trace_fd = -1;

static void trace_event(const char *event, int fd, int family,
                        const char *address, int result, int error) {
    int saved = errno;
    if (trace_fd >= 0) {
        if (family != 0 && family != AF_UNIX && family != AF_INET && family != AF_INET6) family = 0;
        char line[240];
        int n = snprintf(line, sizeof line,
            "{\"event\":\"%s\",\"fd\":%d,\"family\":%d,"
            "\"address\":\"%s\",\"result\":%d,\"errno\":%d}\n",
            event, fd, family, address, result, error);
        if (n > 0 && (size_t)n < sizeof line) {
            ssize_t written;
            do { written = write(trace_fd, line, (size_t)n); }
            while (written < 0 && errno == EINTR);
        }
    }
    errno = saved;
}

__attribute__((constructor)) static void initialize(void) {
    int saved = errno;
    const char *value = getenv("WATTSON_LOOPBACK_TRACE_FD");
    if (value && *value) {
        char *end;
        long candidate = strtol(value, &end, 10);
        struct stat state;
        int flags = candidate > STDERR_FILENO && candidate <= 0x7fffffff ? fcntl((int)candidate, F_GETFL) : -1;
        if (!*end && flags >= 0 && candidate > STDERR_FILENO && candidate <= 0x7fffffff &&
            fstat((int)candidate, &state) == 0 && S_ISREG(state.st_mode) &&
            state.st_uid == getuid() && !(state.st_mode & 0077) &&
            (flags & O_ACCMODE) != O_RDONLY &&
            fcntl((int)candidate, F_SETFD, FD_CLOEXEC) == 0) {
            trace_fd = (int)candidate;
        }
    }
    unsetenv("DYLD_INSERT_LIBRARIES");
    unsetenv("WATTSON_LOOPBACK_TRACE_FD");
    trace_event("loaded", -1, 0, "none", 0, 0);
    errno = saved;
}

static bool stream_socket(int fd) {
    int kind = 0;
    socklen_t length = sizeof kind;
    return getsockopt(fd, SOL_SOCKET, SO_TYPE, &kind, &length) == 0 &&
           kind == SOCK_STREAM;
}

static int guarded_bind(int fd, const struct sockaddr *address, socklen_t length) {
    int saved = errno;
    struct sockaddr_storage replacement;
    const struct sockaddr *selected = address;
    bool rewritten = false;
    int family = address && length >= sizeof(struct sockaddr) ? address->sa_family : 0;
    if ((family == AF_INET || family == AF_INET6) && stream_socket(fd)) {
        if (family == AF_INET && length >= sizeof(struct sockaddr_in)) {
            const struct sockaddr_in *v4 = (const struct sockaddr_in *)address;
            if (v4->sin_addr.s_addr == htonl(INADDR_ANY)) {
                memcpy(&replacement, v4, sizeof *v4);
                ((struct sockaddr_in *)&replacement)->sin_addr.s_addr = htonl(INADDR_LOOPBACK);
                selected = (const struct sockaddr *)&replacement;
                length = sizeof *v4;
                rewritten = true;
            }
        } else if (family == AF_INET6 && length >= sizeof(struct sockaddr_in6)) {
            const struct sockaddr_in6 *v6 = (const struct sockaddr_in6 *)address;
            if (IN6_IS_ADDR_UNSPECIFIED(&v6->sin6_addr)) {
                memcpy(&replacement, v6, sizeof *v6);
                ((struct sockaddr_in6 *)&replacement)->sin6_addr = in6addr_loopback;
                selected = (const struct sockaddr *)&replacement;
                length = sizeof *v6;
                rewritten = true;
            }
        }
    }
    errno = saved;
    /* dyld does not interpose references from the image defining the replacement. */
    int result = bind(fd, selected, length);
    int error = result < 0 ? errno : 0;
    trace_event(rewritten ? "bind-rewrite" : "bind-pass", fd, family,
                rewritten ? "literal-loopback" : "unchanged", result, error);
    return result;
}

static int guarded_listen(int fd, int backlog) {
    int saved = errno;
    struct sockaddr_storage local;
    socklen_t length = sizeof local;
    bool is_stream = stream_socket(fd);
    bool have_address = getsockname(fd, (struct sockaddr *)&local, &length) == 0;
    int family = have_address ? local.ss_family : 0;
    bool internet_tcp = is_stream && have_address && (family == AF_INET || family == AF_INET6);
    bool loopback = have_address && (
        (family == AF_INET && length >= sizeof(struct sockaddr_in) &&
         ((struct sockaddr_in *)&local)->sin_addr.s_addr == htonl(INADDR_LOOPBACK)) ||
        (family == AF_INET6 && length >= sizeof(struct sockaddr_in6) &&
         IN6_IS_ADDR_LOOPBACK(&((struct sockaddr_in6 *)&local)->sin6_addr)));
    if (is_stream && (!have_address || (internet_tcp && !loopback))) {
        errno = EACCES;
        trace_event("listen-refuse", fd, family,
                    have_address ? "nonliteral-loopback" : "getsockname-failed", -1, EACCES);
        return -1;
    }
    errno = saved;
    int result = listen(fd, backlog);
    int error = result < 0 ? errno : 0;
    trace_event("listen-pass", fd, family,
                internet_tcp ? "literal-loopback" : "non-internet-tcp", result, error);
    return result;
}

#define INTERPOSE(replacement, original) \
    __attribute__((used)) static struct { const void *replacement; const void *original; } \
    interpose_##original __attribute__((section("__DATA,__interpose"))) = \
    { (const void *)&replacement, (const void *)&original }
INTERPOSE(guarded_bind, bind);
INTERPOSE(guarded_listen, listen);
