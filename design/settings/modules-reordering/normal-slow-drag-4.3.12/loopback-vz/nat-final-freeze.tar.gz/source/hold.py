import json
import os
from pathlib import Path
import subprocess
import sys
import time

child = subprocess.Popen(["/bin/sleep", "120"])
Path(sys.argv[1]).write_text(json.dumps({"pid": os.getpid(), "childPID": child.pid}) + "\n")
# run_owned must also terminate the descendant when this parent is interrupted.
while True:
    time.sleep(1)
