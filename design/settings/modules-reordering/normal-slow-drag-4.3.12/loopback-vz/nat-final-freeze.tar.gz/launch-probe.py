#!/usr/bin/env python3
"""Private-FD launcher, itself run inside run_owned's process group."""
import argparse
import os
from pathlib import Path
import signal
import subprocess
import sys

parser = argparse.ArgumentParser()
parser.add_argument("library", type=Path)
parser.add_argument("trace", type=Path)
parser.add_argument("--append-fd", action="store_true")
parser.add_argument("--extra-library", type=Path)
parser.add_argument("command", nargs=argparse.REMAINDER)
args = parser.parse_args()
command = args.command[1:] if args.command[:1] == ["--"] else args.command
if not command:
    raise SystemExit(2)
fd = os.open(args.trace, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
child = None


def interrupted(number, _frame):
    raise SystemExit(128 + number)


for caught in (signal.SIGHUP, signal.SIGINT, signal.SIGTERM):
    signal.signal(caught, interrupted)
try:
    env = {key: value for key, value in os.environ.items() if not key.startswith("DYLD_")}
    env["DYLD_INSERT_LIBRARIES"] = str(args.library) + (":" + str(args.extra_library) if args.extra_library else "")
    env["WATTSON_LOOPBACK_TRACE_FD"] = str(fd)
    if args.append_fd:
        command.append(str(fd))
    child = subprocess.Popen(command, env=env, pass_fds=(fd,))
    status = child.wait()
finally:
    if child and child.poll() is None:
        child.terminate()
        try:
            child.wait(timeout=3)
        except subprocess.TimeoutExpired:
            child.kill()
            child.wait()
    os.close(fd)
raise SystemExit(status if status >= 0 else 128 - status)
