#include "manual-window-capture.h"
CGImageRef WattsonModulesCaptureOwnedWindow(CGRect bounds, CGWindowID foreground) {
    CFArrayRef owned = CGWindowListCreate(kCGWindowListOptionIncludingWindow, foreground);
    if (!owned || CFArrayGetCount(owned) != 1) {
        if (owned) CFRelease(owned);
        return NULL;
    }
    CGImageRef image = CGWindowListCreateImageFromArray(bounds, owned, kCGWindowImageBestResolution);
    CFRelease(owned);
    return image;
}
