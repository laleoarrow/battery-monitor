import AppKit
import ObjectiveC.runtime

/// Fixture-only observation of callbacks dispatched by AppKit. Each original
/// implementation is invoked exactly once with the untouched arguments.
final class NativeDragObserver {
    typealias Begin = @convention(c) (AnyObject, Selector, NSDraggingSession, NSPoint) -> Void
    typealias End = @convention(c) (AnyObject, Selector, NSDraggingSession, NSPoint, UInt) -> Void
    typealias Mouse = @convention(c) (AnyObject, Selector, NSEvent) -> Void
    typealias HandleObservation = (String, NSView, NSEvent) -> Void
    private let handleSources = NSHashTable<NSView>.weakObjects()
    private var handleClass: AnyClass?
    private var handleObservation: HandleObservation?
    private(set) var handleInstallation: [String: Any] = [:]
    typealias Observation = (String, NSView, NSDraggingSession, NSPoint, UInt?) -> Void
    private let beginSelector = NSSelectorFromString("draggingSession:willBeginAtPoint:")
    private let endSelector = NSSelectorFromString("draggingSession:endedAtPoint:operation:")
    private var replacements: [(Method, IMP, IMP)] = []
    private var installedClass: AnyClass?
    private weak var source: NSView?
    private var observation: Observation?
    private(set) var installation: [String: Any] = [:]

    func observe(_ source: NSView, callback: @escaping Observation) -> Bool {
        guard let cls = object_getClass(source) else { return false }
        self.source = source
        observation = callback
        if let installedClass { return installedClass === cls }
        guard String(describing: cls).contains("ModuleReorderList"),
              let beginMethod = class_getInstanceMethod(cls, beginSelector),
              let endMethod = class_getInstanceMethod(cls, endSelector),
              let beginEncoding = method_getTypeEncoding(beginMethod),
              let endEncoding = method_getTypeEncoding(endMethod) else { return false }
        let originalBegin = method_getImplementation(beginMethod)
        let originalEnd = method_getImplementation(endMethod)
        let beginCall = unsafeBitCast(originalBegin, to: Begin.self)
        let endCall = unsafeBitCast(originalEnd, to: End.self)
        let beginSelector = self.beginSelector
        let endSelector = self.endSelector
        let beginBlock: @convention(block) (AnyObject, NSDraggingSession, NSPoint) -> Void = { [weak self] object, session, point in
            self?.record("willBegin.enter", object, session, point, nil)
            beginCall(object, beginSelector, session, point)
            self?.record("willBegin.return", object, session, point, nil)
        }
        let endBlock: @convention(block) (AnyObject, NSDraggingSession, NSPoint, UInt) -> Void = { [weak self] object, session, point, operation in
            self?.record("endedAt.enter", object, session, point, operation)
            endCall(object, endSelector, session, point, operation)
            self?.record("endedAt.return", object, session, point, operation)
        }
        let replacementBegin = imp_implementationWithBlock(beginBlock)
        let replacementEnd = imp_implementationWithBlock(endBlock)
        method_setImplementation(beginMethod, replacementBegin)
        method_setImplementation(endMethod, replacementEnd)
        replacements = [(beginMethod, originalBegin, replacementBegin), (endMethod, originalEnd, replacementEnd)]
        installedClass = cls
        installation = ["installed": true, "class": NSStringFromClass(cls),
            "beginSelector": NSStringFromSelector(beginSelector), "endSelector": NSStringFromSelector(endSelector),
            "beginTypeEncoding": String(cString: beginEncoding), "endTypeEncoding": String(cString: endEncoding),
            "originalIMPInvokedExactlyOncePerObservedCallback": true, "argumentsForwardedUnchanged": true,
            "callbacksGeneratedByFixture": false, "productionSourceEdited": false]
        return true
    }

    func observeHandles(_ handles: [NSView], callback: @escaping HandleObservation) -> Bool {
        guard handles.count == 5, let first = handles.first, let cls = object_getClass(first),
              String(describing: cls).contains("ModuleReorderHandle"),
              handles.allSatisfy({ object_getClass($0) === cls }) else { return false }
        handleSources.removeAllObjects()
        handles.forEach { handleSources.add($0) }
        handleObservation = callback
        if let handleClass { return handleClass === cls }
        let names = [("mouseDragged:", "mouseDragged"), ("mouseUp:", "mouseUp")]
        let methods = names.compactMap { name, phase -> (Selector, String, Method)? in
            let selector = NSSelectorFromString(name)
            guard let method = class_getInstanceMethod(cls, selector) else { return nil }
            return (selector, phase, method)
        }
        guard methods.count == 2 else { return false }
        var encodings: [String: String] = [:]
        for (selector, phase, method) in methods {
            guard let encoding = method_getTypeEncoding(method) else { return false }
            let original = method_getImplementation(method)
            let originalCall = unsafeBitCast(original, to: Mouse.self)
            let block: @convention(block) (AnyObject, NSEvent) -> Void = { [weak self] object, event in
                self?.recordHandle(phase + ".enter", object, event)
                originalCall(object, selector, event)
                self?.recordHandle(phase + ".return", object, event)
            }
            let replacement = imp_implementationWithBlock(block)
            method_setImplementation(method, replacement)
            replacements.append((method, original, replacement))
            encodings[NSStringFromSelector(selector)] = String(cString: encoding)
        }
        handleClass = cls
        handleInstallation = ["installed": true, "class": NSStringFromClass(cls), "typeEncodings": encodings,
            "originalIMPInvokedExactlyOncePerObservedCallback": true, "argumentsForwardedUnchanged": true,
            "eventsGeneratedByFixture": false, "callbackPersistence": "memory-only-existing-sampler"]
        return true
    }

    private func recordHandle(_ phase: String, _ object: AnyObject, _ event: NSEvent) {
        guard let handle = object as? NSView,
              handleSources.allObjects.contains(where: { $0 === handle }) else { return }
        handleObservation?(phase, handle, event)
    }

    private func record(_ phase: String, _ object: AnyObject, _ session: NSDraggingSession, _ point: NSPoint, _ operation: UInt?) {
        guard let source, object === source else { return }
        observation?(phase, source, session, point, operation)
    }

    func restore() {
        for (method, original, replacement) in replacements {
            method_setImplementation(method, original)
            imp_removeBlock(replacement)
        }
        replacements.removeAll()
        installedClass = nil
        source = nil
        observation = nil
        handleSources.removeAllObjects()
        handleClass = nil
        handleObservation = nil
    }
    deinit { restore() }
}
