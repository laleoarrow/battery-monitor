import AppKit
import IOKit

/// Uses the real application event queue, never direct drag callbacks.
@main private enum NormalSlowDragProbe {
    static func main() {
        guard CommandLine.arguments.count == 2,
              let suite = ProcessInfo.processInfo.environment["WATTSON_TEST_DEFAULTS_SUITE"],
              suite.hasPrefix("Wattson.SwiftTests.ModuleOrderView."),
              let defaults = CountingDefaults(suiteName: suite),
              #available(macOS 26.0, *) else { exit(64) }
        defaults.removePersistentDomain(forName: suite)
        Settings.configureForTest(defaults: defaults)
        Settings.checksForUpdatesOnLaunch = false
        let app = NSApplication.shared
        app.setActivationPolicy(.accessory)
        if let style = ProcessInfo.processInfo.environment["WATTSON_MODULES_MANUAL_STYLE"] {
            guard ["classic", "standard", "clear"].contains(style) else { exit(64) }
            let manual = ManualDragDelegate(directory: URL(fileURLWithPath: CommandLine.arguments[1]),
                                            suite: suite, defaults: defaults, style: style)
            app.delegate = manual
            withExtendedLifetime(manual) { app.run() }
            Settings.resetTestConfiguration()
            return
        }
        exit(64)
    }
}

/// A passive fixture for guest CGEvent input after caller authorization. No events are
/// generated here and no internal dragging methods are invoked.
@available(macOS 26.0, *)
private final class ManualDragDelegate: NSObject, NSApplicationDelegate {
    let directory: URL
    let suite: String
    let defaults: CountingDefaults
    var style: String
    let started = ProcessInfo.processInfo.systemUptime
    var reduced = ProcessInfo.processInfo.environment["WATTSON_FORCE_REDUCE_MOTION"] == "1"
    var controller: SettingsWindowController?
    // Retain only this fixture window's content so a real close remains
    // observable after AppKit removes the content from its visible hierarchy.
    var observedContent: NSView?
    var closeObserver: NSObjectProtocol?
    var lifecycleEvents: [[String: Any]] = []
    var closeOnPreviewArmed = false
    var closeOnPreviewEvidence: [String: Any] = [:]
    var timer: Timer?
    var observer: NSObjectProtocol?
    var monitor: Any?
    var history: FileHandle?
    var previousState: Data?
    var lastReset: Data?
    var lastCapture: Data?
    var lastCaptureResult: [String: Any] = [:]
    var lastCommand: [String: Any] = [:]
    var events: [[String: Any]] = []
    var eventCount = 0
    var writes = 0
    var visibilityChanges = 0
    let nativeDragObserver = NativeDragObserver()
    var nativeDragSessionEvents: [[String: Any]] = []
    var nativeHandleEvents: [[String: Any]] = []
    var caseName = "initial"
    var status = "running"
    var finished = false

    init(directory: URL, suite: String, defaults: CountingDefaults, style: String) {
        self.directory = directory; self.suite = suite; self.defaults = defaults; self.style = style
    }

    func applicationDidFinishLaunching(_ notification: Notification) {
        Settings.moduleOrder = Settings.Module.allCases
        Settings.Module.allCases.forEach { Settings.setModule($0, visible: true) }
        defaults.orderWrites = 0
        showWindow()
        observer = NotificationCenter.default.addObserver(forName: Settings.didChange, object: nil, queue: .main) { [weak self] notification in
            guard let self, let change = notification.userInfo?[Settings.changeUserInfoKey] as? Settings.Change else { return }
            if change == .moduleOrder { self.writes += 1 }
            if case .module = change { self.visibilityChanges += 1 }
        }
        monitor = NSEvent.addLocalMonitorForEvents(matching: [.leftMouseDown, .leftMouseDragged, .leftMouseUp, .keyDown, .keyUp]) { [weak self] event in
            guard let self, event.window === self.controller?.windowForTest else { return event }
            self.eventCount += 1
            let key = event.type == .keyDown || event.type == .keyUp
            self.events.append(["number": self.eventCount, "type": event.type.rawValue,
                "elapsed": ProcessInfo.processInfo.systemUptime - self.started, "monotonicUptime": ProcessInfo.processInfo.systemUptime,
                "eventTimestamp": event.timestamp, "pressedMouseButtons": NSEvent.pressedMouseButtons,
                "x": event.locationInWindow.x, "y": event.locationInWindow.y,
                "keyCode": key ? Int(event.keyCode) : -1])
            if self.events.count > 80 { self.events.removeFirst(self.events.count - 80) }
            return event
        }
        let log = directory.appendingPathComponent("history.jsonl")
        guard FileManager.default.createFile(atPath: log.path, contents: nil),
              let stream = try? FileHandle(forWritingTo: log) else { finish(code: 1, reason: "history-file-failure"); return }
        history = stream
        let sampler = Timer(timeInterval: 0.1, repeats: true) { [weak self] _ in self?.sample() }
        timer = sampler
        RunLoop.main.add(sampler, forMode: .common)
        RunLoop.main.add(sampler, forMode: .eventTracking)
        sample()
        print("NORMAL_SLOW_DRAG_READY style=\(style) reduceMotion=\(reduced); read state.json; create done to finish")
        fflush(stdout)
    }

    private func showWindow() {
        if let closeObserver { NotificationCenter.default.removeObserver(closeObserver); self.closeObserver = nil }
        controller?.windowForTest?.close(); controller = nil
        observedContent = nil
        Settings.liquidGlassEnabled = style != "classic"
        Settings.liquidGlassStyle = style == "clear" ? .clear : .regular
        let dependencies = SettingsWindowDependencies(
            loginItemState: { .enabled }, refreshLoginItem: { $0(.enabled) },
            setLoginItemEnabled: { _, _ in fatalError("Read-only fixture") },
            systemBatteryIconHidden: { false }, helperAvailable: { true },
            refreshSystemBatteryIcon: { $0(false) },
            setSystemBatteryIconHidden: { _, _ in fatalError("Read-only fixture") },
            systemBatteryIconDidChange: Notification.Name("Wattson.ModulesDrag.FixedBattery"),
            currentVersion: { "QA" }, checkForUpdates: { _ in }, openUpdateURL: { _ in false },
            increaseContrast: { false }, announceAccessibility: { _ in }, systemBatteryIconReadStatus: { .ready })
        let settings = SettingsWindowController(dependencies: dependencies, frameAutosaveName: nil)
        controller = settings
        settings.windowForTest?.animationBehavior = .none
        settings.windowForTest?.center()
        settings.selectSectionForTest(identifier: "modules"); settings.show()
        observedContent = settings.windowForTest?.contentView
        let preflight = preflightOverrideSnapshot
        guard preflight["available"] as? Bool == true,
              preflight["pressedMouseButtonsForTestIsNil"] as? Bool == true,
              preflight["nativeDragStartObserverForTestIsNil"] as? Bool == true else {
            finish(code: 78, reason: "production-preflight-override-present"); return
        }
        guard let stack, nativeDragObserver.observe(stack, callback: { [weak self] phase, source, session, point, operation in
            guard let self else { return }
            var event: [String: Any] = ["phase": phase, "case": self.caseName,
                "elapsed": ProcessInfo.processInfo.systemUptime - self.started, "monotonicUptime": ProcessInfo.processInfo.systemUptime,
                "sessionIdentity": String(describing: ObjectIdentifier(session)),
                "sourceIdentity": String(describing: ObjectIdentifier(source)),
                "screenPoint": [point.x, point.y], "savedOrder": Settings.moduleOrder.map(\.rawValue),
                "displayOrder": self.displayedOrder, "rowAlpha": self.rows.map { $0.alphaValue },
                "dragState": self.dragStateSnapshot, "syntheticCallback": false,
                "pressedMouseButtons": NSEvent.pressedMouseButtons,
                "callbackPersistence": "memory-only-existing-sampler"]
            if let current = NSApp.currentEvent {
                event["currentEvent"] = ["type": current.type.rawValue, "timestamp": current.timestamp,
                    "windowNumber": current.windowNumber,
                    "locationInWindow": [current.locationInWindow.x, current.locationInWindow.y]]
            } else { event["currentEvent"] = NSNull() }
            if let operation { event["operation"] = operation }
            self.nativeDragSessionEvents.append(event)
            // Preserve native timing: the existing sampler persists this in-memory record.
        }) else { finish(code: 78, reason: "native-callback-observation-unavailable"); return }
        let observedHandles = views.filter { $0.identifier?.rawValue.hasPrefix("settings.modules.reorder.") == true }
        guard nativeDragObserver.observeHandles(observedHandles, callback: { [weak self] phase, handle, event in
            guard let self else { return }
            var record: [String: Any] = ["phase": phase, "case": self.caseName,
                "elapsed": ProcessInfo.processInfo.systemUptime - self.started, "monotonicUptime": ProcessInfo.processInfo.systemUptime,
                "handleIdentity": String(describing: ObjectIdentifier(handle)), "handleID": handle.identifier?.rawValue ?? "",
                "eventType": event.type.rawValue, "eventTimestamp": event.timestamp,
                "eventWindowNumber": event.windowNumber, "eventLocationInWindow": [event.locationInWindow.x, event.locationInWindow.y],
                "pressedMouseButtons": NSEvent.pressedMouseButtons, "dragState": self.dragStateSnapshot,
                "inputGeneratedByFixture": false, "callbackPersistence": "memory-only-existing-sampler"]
            if let current = NSApp.currentEvent {
                record["currentEvent"] = ["type": current.type.rawValue, "timestamp": current.timestamp,
                    "windowNumber": current.windowNumber]
            } else { record["currentEvent"] = NSNull() }
            self.nativeHandleEvents.append(record)
        }) else { finish(code: 78, reason: "native-handle-observation-unavailable"); return }
        if let window = settings.windowForTest {
            closeObserver = NotificationCenter.default.addObserver(forName: NSWindow.willCloseNotification, object: window, queue: .main) { [weak self] _ in
                guard let self else { return }
                self.lifecycleEvents.append(["event": "willClose", "elapsed": ProcessInfo.processInfo.systemUptime - self.started, "monotonicUptime": ProcessInfo.processInfo.systemUptime,
                    "savedOrder": Settings.moduleOrder.map(\.rawValue), "orderWrites": self.defaults.orderWrites,
                    "rowAlphaAtNotification": self.rows.map { $0.alphaValue }])
            }
        }
    }

    private func descendants(_ view: NSView) -> [NSView] { [view] + view.subviews.flatMap(descendants) }
    private var views: [NSView] { observedContent.map(descendants) ?? [] }
    private var rows: [NSView] { views.filter { $0.identifier?.rawValue.hasPrefix("settings.modules.row.") == true } }
    private var stack: NSStackView? {
        views.compactMap { $0 as? NSStackView }.first { list in
            list.arrangedSubviews.count == 5 && list.arrangedSubviews.allSatisfy {
                $0.identifier?.rawValue.hasPrefix("settings.modules.row.") == true
            }
        }
    }
    private var displayedOrder: [String] {
        stack?.arrangedSubviews.compactMap { $0.identifier?.rawValue.replacingOccurrences(of: "settings.modules.row.", with: "") } ?? []
    }
    private var dragStateSnapshot: [String: Any] {
        guard let stack else { return ["available": false] }
        let fields = Dictionary(uniqueKeysWithValues: Mirror(reflecting: stack).children.compactMap { child in
            child.label.map { ($0, child.value) }
        })
        guard let dragged = fields["draggedModule"], let original = fields["originalOrder"] as? [Settings.Module],
              let session = fields["dragSession"] else { return ["available": false] }
        let isNil: (Any) -> Bool = { value in
            let mirror = Mirror(reflecting: value)
            return mirror.displayStyle == .optional && mirror.children.isEmpty
        }
        return ["available": true, "draggedModuleIsNil": isNil(dragged),
            "originalOrderIsEmpty": original.isEmpty, "dragSessionIsNil": isNil(session),
            "readOnlySwiftReflection": true]
    }
    private var preflightOverrideSnapshot: [String: Any] {
        guard let stack else { return ["available": false] }
        let fields = Dictionary(uniqueKeysWithValues: Mirror(reflecting: stack).children.compactMap { child in
            child.label.map { ($0, child.value) }
        })
        let names = ["pressedMouseButtonsForTest", "nativeDragStartObserverForTest"]
        var result: [String: Any] = ["available": names.allSatisfy { fields[$0] != nil }, "readOnlySwiftReflection": true]
        for name in names {
            guard let field = fields[name] else { result[name + "IsNil"] = false; continue }
            let mirror = Mirror(reflecting: field)
            result[name + "IsNil"] = mirror.displayStyle == .optional && mirror.children.isEmpty
        }
        return result
    }
    private lazy var hardwareUUID: String = {
        let service = IOServiceGetMatchingService(kIOMainPortDefault, IOServiceMatching("IOPlatformExpertDevice"))
        guard service != 0 else { return "" }
        defer { IOObjectRelease(service) }
        return IORegistryEntryCreateCFProperty(service, "IOPlatformUUID" as CFString, kCFAllocatorDefault, 0)?.takeRetainedValue() as? String ?? ""
    }()
    private func cgPoint(_ point: NSPoint, screen: NSScreen, displayBounds: CGRect) -> [CGFloat] {
        [displayBounds.minX + point.x - screen.frame.minX,
         displayBounds.minY + screen.frame.maxY - point.y]
    }
    private func state() -> [String: Any] {
        var value: [String: Any] = ["schema": 2, "pid": ProcessInfo.processInfo.processIdentifier, "hardwareUUID": hardwareUUID, "bundleID": Bundle.main.bundleIdentifier ?? "", "fixtureGeneratesInput": false, "inputMethod": "guest-VNC", "mode": "observational-owned-guest-slow-drag", "style": style, "reduceMotion": reduced,
            "status": status, "case": caseName, "pressedMouseButtons": NSEvent.pressedMouseButtons, "inputGeneratedByFixture": false, "directDragCallbacks": false,
            "lastCommand": lastCommand, "lastCapture": lastCaptureResult,
            "nativeDragObservation": nativeDragObserver.installation,
            "nativeDragSessionEvents": nativeDragSessionEvents,
            "nativeHandleObservation": nativeDragObserver.handleInstallation,
            "nativeHandleEvents": nativeHandleEvents,
            "dragState": dragStateSnapshot, "productionPreflightOverrides": preflightOverrideSnapshot,
            "keyboardFocusVisible": Dictionary(uniqueKeysWithValues: Settings.Module.allCases.map {
                ($0.rawValue, controller?.moduleReorderShowsKeyboardFocusForTest($0) ?? false)
            }),
            "windowLifecycleEvents": lifecycleEvents,
            "closeOnPreviewArmed": closeOnPreviewArmed, "closeOnPreviewEvidence": closeOnPreviewEvidence,
            "testVerdict": "not-automatically-evaluated", "savedOrder": Settings.moduleOrder.map(\.rawValue),
            "displayOrder": displayedOrder,
            "orderWrites": defaults.orderWrites, "orderNotifications": writes, "visibilityNotifications": visibilityChanges,
            "visibility": Dictionary(uniqueKeysWithValues: Settings.Module.allCases.map { ($0.rawValue, Settings.isModuleVisible($0)) }),
            "observedOwnWindowEventCount": eventCount, "recentOwnWindowEvents": events,
            "visible": controller?.windowForTest?.isVisible == true, "keyWindow": controller?.windowForTest?.isKeyWindow == true,
            "rows": rows.map { row -> [String: Any] in
                let frame = row.convert(row.bounds, to: nil)
                return ["id": row.identifier?.rawValue ?? "", "alpha": row.alphaValue,
                        "objectIdentity": String(describing: ObjectIdentifier(row)), "attachedToWindow": row.window != nil,
                        "frameInWindow": [frame.minX, frame.minY, frame.width, frame.height],
                        "animationKeys": row.layer?.animationKeys() ?? []]
            }]
        if let window = controller?.windowForTest {
            value["windowNumber"] = window.windowNumber
            value["windowID"] = window.windowNumber
            value["windowIdentity"] = String(describing: ObjectIdentifier(window))
            if let responder = window.firstResponder {
                value["firstResponder"] = ["objectIdentity": String(describing: ObjectIdentifier(responder)),
                    "viewIdentifier": (responder as? NSView)?.identifier?.rawValue ?? "",
                    "class": String(describing: type(of: responder))]
            }
            value["settingsScrollViews"] = views.compactMap { $0 as? NSScrollView }.map { scroll -> [String: Any] in
                ["objectIdentity": String(describing: ObjectIdentifier(scroll)), "id": scroll.identifier?.rawValue ?? "",
                 "origin": [scroll.contentView.bounds.origin.x, scroll.contentView.bounds.origin.y]]
            }
            value["windowFrameInScreen"] = [window.frame.minX, window.frame.minY, window.frame.width, window.frame.height]
            if let info = CGWindowListCopyWindowInfo(.optionIncludingWindow, CGWindowID(window.windowNumber)) as? [[String: Any]],
               let owned = info.first(where: { ($0[kCGWindowNumber as String] as? Int) == window.windowNumber }) {
                value["cgWindow"] = owned
            }
            if let screen = window.screen,
               let displayID = screen.deviceDescription[NSDeviceDescriptionKey("NSScreenNumber")] as? NSNumber,
               let stack {
                let bounds = CGDisplayBounds(CGDirectDisplayID(displayID.uint32Value))
                let stackFrame = window.convertToScreen(stack.convert(stack.bounds, to: nil))
                // End point remains inside the list, below every unchanged row center.
                let drop = NSPoint(x: stackFrame.midX, y: stackFrame.minY + 3)
                let outside = NSPoint(x: min(screen.frame.maxX - 20, window.frame.maxX + 60), y: window.frame.midY)
                let handles = views.filter { $0.identifier?.rawValue.hasPrefix("settings.modules.reorder.") == true }.map { handle -> [String: Any] in
                    let frame = window.convertToScreen(handle.convert(handle.bounds, to: nil))
                    return ["id": handle.identifier?.rawValue ?? "", "centerInCGScreen": cgPoint(NSPoint(x: frame.midX, y: frame.midY), screen: screen, displayBounds: bounds)]
                }
                value["inputGeometry"] = ["coordinateSpace": "CG-global-top-left", "displayID": displayID.uint32Value,
                    "screenCount": NSScreen.screens.count,
                    "screenFrameAppKit": [screen.frame.minX, screen.frame.minY, screen.frame.width, screen.frame.height],
                    "displayBoundsCG": [bounds.minX, bounds.minY, bounds.width, bounds.height],
                    "stackFrameAppKit": [stackFrame.minX, stackFrame.minY, stackFrame.width, stackFrame.height],
                    "handles": handles, "dropAfterLastRowInCGScreen": cgPoint(drop, screen: screen, displayBounds: bounds),
                    "outsideWindowInCGScreen": cgPoint(outside, screen: screen, displayBounds: bounds)]
                if let first = handles.first(where: { ($0["id"] as? String) == "settings.modules.reorder.flow" }),
                   let source = first["centerInCGScreen"] as? [CGFloat], source.count == 2 {
                    let targetPoint: ([CGFloat]) -> [String: CGFloat] = { ["x": $0[0], "y": $0[1]] }
                    let common: [String: Any] = ["hardwareUUID": hardwareUUID, "pid": ProcessInfo.processInfo.processIdentifier,
                        "bundleID": Bundle.main.bundleIdentifier ?? "", "windowID": window.windowNumber,
                        "caseName": caseName, "source": targetPoint(source), "duration": 1.5, "holdBefore": 0.3, "holdAfter": 0.5]
                    var dropTarget = common
                    dropTarget["target"] = targetPoint(cgPoint(drop, screen: screen, displayBounds: bounds))
                    var outsideTarget = common
                    outsideTarget["target"] = targetPoint(cgPoint(outside, screen: screen, displayBounds: bounds))
                    value["inputTargets"] = ["drop": dropTarget, "outside": outsideTarget]
                }
            }
            value["handles"] = views.filter { $0.identifier?.rawValue.hasPrefix("settings.modules.reorder.") == true }.map { handle -> [String: Any] in
                let frame = window.convertToScreen(handle.convert(handle.bounds, to: nil))
                return ["id": handle.identifier?.rawValue ?? "", "frameInScreen": [frame.minX, frame.minY, frame.width, frame.height]]
            }
        }
        return value
    }
    private func regularMarker(_ name: String) -> Bool {
        let url = directory.appendingPathComponent(name)
        guard let keys = try? url.resourceValues(forKeys: [.isRegularFileKey, .isSymbolicLinkKey]) else { return false }
        return keys.isRegularFile == true && keys.isSymbolicLink != true
    }
    private func sample() {
        guard !finished else { return }
        if regularMarker("done") { finish(code: 0, reason: "done-marker"); return }
        if ProcessInfo.processInfo.systemUptime - started >= 600 { finish(code: 124, reason: "600-second-deadline"); return }
        if regularMarker("reset.json"), let data = try? Data(contentsOf: directory.appendingPathComponent("reset.json")), data != lastReset {
            lastReset = data
            handleReset(data)
        }
        if regularMarker("capture.json"), let data = try? Data(contentsOf: directory.appendingPathComponent("capture.json")), data != lastCapture {
            lastCapture = data
            captureOwnWindow(data)
        }
        do {
            if closeOnPreviewArmed, rows.count == 5, rows.contains(where: { $0.alphaValue < 0.5 }),
               displayedOrder != Settings.moduleOrder.map(\.rawValue), let window = controller?.windowForTest, window.isVisible {
                closeOnPreviewArmed = false
                closeOnPreviewEvidence = ["mechanism": "fixture-window.close-after-real-preview",
                    "userCloseInput": false, "directDragCallbacks": false, "testVerdict": "not-automatically-evaluated",
                    "observedPreview": ["elapsed": ProcessInfo.processInfo.systemUptime - started,
                        "savedOrder": Settings.moduleOrder.map(\.rawValue), "displayOrder": displayedOrder,
                        "rowAlpha": rows.map { $0.alphaValue }, "orderWrites": defaults.orderWrites,
                        "windowIdentity": String(describing: ObjectIdentifier(window))]]
                try persist()
                // Exercise a real window-lifecycle close after an actual pointer
                // drag. This is not a claim that CUA sent a close key mid-drag.
                window.close()
                closeOnPreviewEvidence["closeCallReturned"] = true
            }
            try persist()
        } catch { finish(code: 1, reason: "state-write-failure") }
    }
    private func captureOwnWindow(_ data: Data) {
        lastCaptureResult = ["result": "rejected-invalid-command"]
        guard data.count <= 4096, let object = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any],
              let name = object["name"] as? String,
              name.range(of: "^[A-Za-z0-9][A-Za-z0-9._-]{0,79}$", options: .regularExpression) != nil,
              let window = controller?.windowForTest, window.isVisible, let screen = window.screen else { return }
        let target = directory.appendingPathComponent(name + ".png")
        guard !FileManager.default.fileExists(atPath: target.path) else { lastCaptureResult = ["name": name, "result": "refused-overwrite"]; return }
        window.displayIfNeeded()
        let rect = NSRect(x: window.frame.minX - 8, y: screen.frame.maxY - window.frame.maxY - 8,
            width: window.frame.width + 16, height: window.frame.height + 16)
        guard let image = WattsonModulesCaptureOwnedWindow(rect, CGWindowID(window.windowNumber)),
              let png = NSBitmapImageRep(cgImage: image).representation(using: .png, properties: [:]) else {
            lastCaptureResult = ["name": name, "result": "capture-unavailable"]; return
        }
        do {
            try png.write(to: target, options: .atomic)
            lastCaptureResult = ["name": name, "result": "captured", "ownedWindowID": window.windowNumber,
                "pixels": [image.width, image.height], "elapsed": ProcessInfo.processInfo.systemUptime - started,
                "onlyExplicitOwnedWindow": true]
            try JSONSerialization.data(withJSONObject: state(), options: [.prettyPrinted, .sortedKeys])
                .write(to: directory.appendingPathComponent(name + ".json"), options: .atomic)
        } catch { lastCaptureResult = ["name": name, "result": "capture-write-failed"] }
    }
    private func handleReset(_ data: Data) {
        lastCommand = ["result": "rejected-invalid-command"]
        guard data.count <= 4096, let object = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any],
              let name = object["case"] as? String,
              name.range(of: "^[A-Za-z0-9][A-Za-z0-9._-]{0,79}$", options: .regularExpression) != nil else { return }
        let nextStyle = object["style"] as? String ?? style
        let nextReduced = object["reduceMotion"] as? Bool ?? reduced
        guard ["classic", "standard", "clear"].contains(nextStyle) else { return }
        lastCommand = ["case": name, "result": "rejected-active-gesture"]
        guard rows.count == 5, rows.allSatisfy({ abs($0.alphaValue - 1) < 0.001 }), NSEvent.pressedMouseButtons & 1 == 0 else { return }
        // Test-process override only; this never writes macOS accessibility prefs.
        setenv("WATTSON_FORCE_REDUCE_MOTION", nextReduced ? "1" : "0", 1)
        guard ProcessInfo.processInfo.environment["WATTSON_FORCE_REDUCE_MOTION"] == (nextReduced ? "1" : "0") else {
            lastCommand["result"] = "rejected-process-environment-readback"; return
        }
        let rebuild = nextStyle != style || nextReduced != reduced || controller?.windowForTest?.isVisible != true
        style = nextStyle; reduced = nextReduced
        Settings.moduleOrder = Settings.Module.allCases
        Settings.Module.allCases.forEach { Settings.setModule($0, visible: true) }
        if rebuild { showWindow() }
        defaults.orderWrites = 0; writes = 0; visibilityChanges = 0; events.removeAll(); eventCount = 0
        lifecycleEvents.removeAll(); nativeDragSessionEvents.removeAll(); nativeHandleEvents.removeAll()
        closeOnPreviewArmed = object["closeOnPreview"] as? Bool ?? false
        closeOnPreviewEvidence = [:]
        caseName = name
        lastCommand = ["case": name, "result": "applied", "style": style, "reduceMotion": reduced,
                       "windowRebuilt": rebuild, "closeOnPreviewArmed": closeOnPreviewArmed]
    }
    private func persist() throws {
        var value = state()
        let signature = try JSONSerialization.data(withJSONObject: value, options: [.sortedKeys])
        value["monotonicUptime"] = ProcessInfo.processInfo.systemUptime
        value["elapsed"] = ProcessInfo.processInfo.systemUptime - started
        value["epoch"] = Date().timeIntervalSince1970
        let data = try JSONSerialization.data(withJSONObject: value, options: [.sortedKeys])
        try data.write(to: directory.appendingPathComponent("state.json"), options: .atomic)
        if signature != previousState {
            try history?.write(contentsOf: data + Data([10]))
            previousState = signature
        }
    }
    private func finish(code: Int32, reason: String) {
        guard !finished else { return }
        var exitCode = code
        status = reason
        do {
            try persist()
            var value = state()
            value["sessionEnded"] = true; value["exitCode"] = code
            let data = try JSONSerialization.data(withJSONObject: value, options: [.prettyPrinted, .sortedKeys])
            try data.write(to: directory.appendingPathComponent("result.json"), options: .atomic)
            if code == 0 { try data.write(to: directory.appendingPathComponent("complete.json"), options: .atomic) }
        } catch { fputs("Manual evidence write failed: \(error)\n", stderr); exitCode = 1 }
        finished = true
        clean()
        if exitCode != 0 { exit(exitCode) }
        NSApp.terminate(nil)
    }
    private func clean() {
        timer?.invalidate(); timer = nil
        nativeDragObserver.restore()
        if let observer { NotificationCenter.default.removeObserver(observer); self.observer = nil }
        if let monitor { NSEvent.removeMonitor(monitor); self.monitor = nil }
        if let closeObserver { NotificationCenter.default.removeObserver(closeObserver); self.closeObserver = nil }
        try? history?.close(); history = nil
        controller?.windowForTest?.close(); controller = nil
        observedContent = nil
        defaults.removePersistentDomain(forName: suite); defaults.synchronize()
        UserDefaults.standard.synchronize(); Settings.resetTestConfiguration()
    }
    func applicationWillTerminate(_ notification: Notification) { clean() }
}

private final class CountingDefaults: UserDefaults {
    var orderWrites = 0
    override func set(_ value: Any?, forKey key: String) {
        if key == "popover.moduleOrder" { orderWrites += 1 }
        super.set(value, forKey: key)
    }
}

