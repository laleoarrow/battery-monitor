#include <CoreGraphics/CoreGraphics.h>
CGImageRef _Nullable WattsonModulesCaptureOwnedWindow(CGRect bounds, CGWindowID foreground) CF_RETURNS_RETAINED;
