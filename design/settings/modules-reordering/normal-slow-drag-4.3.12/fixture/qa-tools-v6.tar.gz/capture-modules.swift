import AppKit

/// Fixed telemetry through production controllers; run only in the disposable VM.
@main private enum ModulesProbe {
    static func main() {
        guard CommandLine.arguments.count == 3, #available(macOS 26.0, *) else { exit(64) }
        let defaults = MemoryDefaults()
        Settings.configureForTest(defaults: defaults)
        Settings.checksForUpdatesOnLaunch = false
        Settings.Module.allCases.forEach { Settings.setModule($0, visible: true) }
        let app = NSApplication.shared
        app.setActivationPolicy(.accessory)
        let delegate = CaptureDelegate(directory: URL(fileURLWithPath: CommandLine.arguments[1]),
                                       scenario: CommandLine.arguments[2])
        app.delegate = delegate
        withExtendedLifetime((defaults, delegate)) { app.run() }
        Settings.resetTestConfiguration()
    }
}

private final class MemoryDefaults: UserDefaults {
    private var values: [String: Any] = [:]
    override func object(forKey key: String) -> Any? { values[key] }
    override func string(forKey key: String) -> String? { values[key] as? String }
    override func array(forKey key: String) -> [Any]? { values[key] as? [Any] }
    override func set(_ value: Any?, forKey key: String) { values[key] = value }
    override func set(_ value: Bool, forKey key: String) { values[key] = value }
    override func removeObject(forKey key: String) { values.removeValue(forKey: key) }
}

@available(macOS 26.0, *)
private final class CaptureDelegate: NSObject, NSApplicationDelegate {
    let directory: URL
    let scenario: String
    var settings: SettingsWindowController?
    var popup: PopoverController?
    var backdrop: NSWindow?
    var statusItem: NSStatusItem?
    var records: [[String: Any]] = []

    init(directory: URL, scenario: String) { self.directory = directory; self.scenario = scenario }
    func applicationDidFinishLaunching(_ notification: Notification) {
        DispatchQueue.main.asyncAfter(deadline: .now() + 120) { [weak self] in self?.stop(); exit(1) }
        Task { @MainActor in
            do { try await run(); stop(); NSApp.terminate(nil) }
            catch { fputs("MODULES_CAPTURE_FAILED: \(error)\n", stderr); stop(); exit(1) }
        }
    }
    func applicationWillTerminate(_ notification: Notification) { stop() }
    private func stop() {
        settings?.windowForTest?.close(); settings = nil
        popup?.handleOutsideClick(); popup = nil
        backdrop?.close(); backdrop = nil
        if let statusItem { NSStatusBar.system.removeStatusItem(statusItem) }
        statusItem = nil
    }
    private func descendants(_ view: NSView) -> [NSView] { [view] + view.subviews.flatMap(descendants) }
    private func failure(_ message: String) -> NSError {
        NSError(domain: "ModulesProbe", code: 1, userInfo: [NSLocalizedDescriptionKey: message])
    }
    private func sample() throws -> PowerSnapshot {
        switch scenario {
        case "charging": return PowerSnapshot(percent: 72, plugged: true, adapterW: 68,
            batteryW: 22.2, systemW: 45.8, temperatureC: 34.2, cycleCount: 282,
            lowPowerMode: false, batteryTimeEstimate: .charging(42))
        case "full": return PowerSnapshot(percent: 100, plugged: true, adapterW: 35.5,
            batteryW: 0, systemW: 35.5, temperatureC: 30.2, cycleCount: 282,
            lowPowerMode: false, batteryTimeEstimate: .full)
        case "on-battery": return PowerSnapshot(percent: 67, plugged: false, adapterW: 0,
            batteryW: -22.4, systemW: 22.4, temperatureC: 33.1, cycleCount: 282,
            lowPowerMode: false, batteryTimeEstimate: .remaining(265))
        case "mixed-supply": return PowerSnapshot(percent: 72, plugged: true, adapterW: 30,
            batteryW: -10, systemW: 40, temperatureC: 35.2, cycleCount: 282,
            lowPowerMode: false, batteryTimeEstimate: .notCharging)
        case "low-battery": return PowerSnapshot(percent: 8, plugged: false, adapterW: 0,
            batteryW: -18, systemW: 18, temperatureC: 31.2, cycleCount: 282,
            lowPowerMode: false, batteryTimeEstimate: .remaining(22))
        case "low-power": return PowerSnapshot(percent: 41, plugged: false, adapterW: 0,
            batteryW: -8, systemW: 8, temperatureC: 29.8, cycleCount: 282,
            lowPowerMode: true, batteryTimeEstimate: .remaining(210))
        default: throw failure("Unknown fixed power scenario")
        }
    }
    private func capture(_ window: NSWindow, name: String, extra: [String: Any]) throws {
        guard let backdrop, let screen = window.screen else { throw failure("Missing own windows/screen") }
        let rect = NSRect(x: window.frame.minX - 8, y: screen.frame.maxY - window.frame.maxY - 8,
                          width: window.frame.width + 16, height: window.frame.height + 16)
        guard let image = WattsonCaptureOwnedWindows(rect, CGWindowID(window.windowNumber),
                                                     CGWindowID(backdrop.windowNumber)) else {
            throw failure("Own-window composited capture refused")
        }
        let bitmap = NSBitmapImageRep(cgImage: image)
        guard let png = bitmap.representation(using: .png, properties: [:]) else { throw failure("Missing PNG") }
        try png.write(to: directory.appendingPathComponent(name + ".png"), options: .atomic)
        var row = extra
        row["name"] = name; row["scenario"] = scenario
        row["pixels"] = [bitmap.pixelsWide, bitmap.pixelsHigh]
        row["windowFrame"] = [window.frame.minX, window.frame.minY, window.frame.width, window.frame.height]
        row["moduleOrder"] = Settings.moduleOrder.map(\.rawValue)
        records.append(row)
    }
    @MainActor private func run() async throws {
        guard let screen = NSScreen.main else { throw failure("Missing screen") }
        let background = NSWindow(contentRect: screen.frame, styleMask: .borderless, backing: .buffered, defer: false)
        background.isReleasedWhenClosed = false; background.isRestorable = false
        background.isOpaque = true; background.hasShadow = false
        background.level = .init(rawValue: NSWindow.Level.normal.rawValue - 1)
        background.orderFrontRegardless(); backdrop = background
        if scenario != "settings" {
            let item = NSStatusBar.system.statusItem(withLength: NSStatusItem.variableLength)
            item.button?.image = NSImage(systemSymbolName: "battery.100", accessibilityDescription: "Modules QA")
            item.button?.title = " QA"; statusItem = item
            try await Task.sleep(nanoseconds: 600_000_000)
        }
        for scheme in [Settings.ColorScheme.light, .dark] {
            Settings.colorScheme = scheme; NSApp.appearance = scheme.appearance
            let level: CGFloat = scheme == .light ? 0.85 : 0.15
            background.backgroundColor = NSColor(srgbRed: level, green: level, blue: level, alpha: 1)
            for style in ["classic", "standard", "clear"] {
                Settings.liquidGlassEnabled = style != "classic"
                Settings.liquidGlassStyle = style == "clear" ? .clear : .regular
                let name = "\(style)-\(scheme.rawValue)"
                if scenario == "settings" { try await captureSettings(name: name) }
                else { try await capturePopup(name: name) }
            }
        }
        try JSONSerialization.data(withJSONObject: ["complete": true, "scenario": scenario,
            "captures": records.count, "fixtureValues": true, "productionGeometryUnmodified": true,
            "records": records], options: [.prettyPrinted, .sortedKeys])
            .write(to: directory.appendingPathComponent("complete.json"))
    }
    @MainActor private func captureSettings(name: String) async throws {
        let dependencies = SettingsWindowDependencies(
            loginItemState: { .enabled }, refreshLoginItem: { $0(.enabled) },
            setLoginItemEnabled: { _, _ in fatalError("Read-only fixture") },
            systemBatteryIconHidden: { false }, helperAvailable: { true },
            refreshSystemBatteryIcon: { $0(false) },
            setSystemBatteryIconHidden: { _, _ in fatalError("Read-only fixture") },
            systemBatteryIconDidChange: Notification.Name("Wattson.ModulesCapture.FixedBattery"),
            currentVersion: { Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "QA" },
            checkForUpdates: { _ in }, openUpdateURL: { _ in false }, increaseContrast: { ProcessInfo.processInfo.environment["WATTSON_FORCE_INCREASE_CONTRAST"] == "1" },
            announceAccessibility: { _ in }, systemBatteryIconReadStatus: { .ready })
        let controller = SettingsWindowController(dependencies: dependencies, frameAutosaveName: nil)
        settings = controller
        guard let window = controller.windowForTest, let content = window.contentView else {
            throw failure("Missing production Settings window")
        }
        window.animationBehavior = .none; window.center()
        controller.selectSectionForTest(identifier: "modules"); controller.show()
        try await Task.sleep(nanoseconds: 600_000_000)
        content.layoutSubtreeIfNeeded()
        let rows = descendants(content).filter { $0.identifier?.rawValue.hasPrefix("settings.modules.row.") == true }
        guard rows.count == 5 else { throw failure("Expected all five production Modules rows") }
        try capture(window, name: name, extra: ["surface": "settings", "moduleRows": rows.count])
        window.close(); settings = nil
    }
    @MainActor private func capturePopup(name: String) async throws {
        guard let anchor = statusItem?.button else { throw failure("Missing owned status item") }
        let value = try sample()
        let history = (0..<32).map { value.totalInputW * (0.88 + 0.08 * sin(Double($0) * 0.4)) }
        let controller = PopoverController(); popup = controller
        controller.update(snapshot: value, history: history, peak: value.totalInputW, degraded: false)
        controller.updateSystemBatteryIconState(false)
        controller.openForSettingsCommandTest(relativeTo: anchor)
        try await Task.sleep(nanoseconds: 1_200_000_000)
        guard let window = controller.contentWindowForTest, let content = controller.contentViewForTest,
              let footer = descendants(content).compactMap({ $0 as? PopoverFooterView }).first,
              let scroll = descendants(content).compactMap({ $0 as? NSScrollView }).first,
              let document = scroll.documentView else { throw failure("Missing production popover hierarchy") }
        footer.update(mode: value.lowPowerMode ? .low : .auto, helperInstalled: true,
                      systemBatteryIconHidden: false, tint: PopoverStyle.stateColor(value.state))
        content.layoutSubtreeIfNeeded()
        let positions = document.bounds.height > scroll.contentView.bounds.height + 1 ? ["top", "bottom"] : ["full"]
        for position in positions {
            scroll.contentView.scroll(to: NSPoint(x: 0, y: position == "bottom"
                ? max(0, document.bounds.height - scroll.contentView.bounds.height) : 0))
            scroll.reflectScrolledClipView(scroll.contentView)
            content.layoutSubtreeIfNeeded()
            try await Task.sleep(nanoseconds: 400_000_000)
            try capture(window, name: name + "-" + position,
                        extra: ["surface": "popover", "scrollPosition": position,
                                "documentHeight": document.bounds.height, "historySampleCount": history.count])
        }
        controller.handleOutsideClick(); popup = nil
        try await Task.sleep(nanoseconds: 300_000_000)
    }
}
