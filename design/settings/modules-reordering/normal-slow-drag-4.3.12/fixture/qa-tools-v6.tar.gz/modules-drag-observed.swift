import AppKit

/// Uses the real application event queue, never direct drag callbacks.
@main private enum ModulesDragProbe {
    static func main() {
        guard CommandLine.arguments.count == 2,
              let suite = ProcessInfo.processInfo.environment["WATTSON_TEST_DEFAULTS_SUITE"],
              suite.hasPrefix("Wattson.SwiftTests.ModuleOrderView."),
              let defaults = CountingDefaults(suiteName: suite),
              #available(macOS 26.0, *) else { exit(64) }
        defaults.removePersistentDomain(forName: suite)
        Settings.configureForTest(defaults: defaults)
        Settings.checksForUpdatesOnLaunch = false
        let app = NSApplication.shared
        app.setActivationPolicy(.accessory)
        if let style = ProcessInfo.processInfo.environment["WATTSON_MODULES_MANUAL_STYLE"] {
            guard ["classic", "standard", "clear"].contains(style) else { exit(64) }
            let manual = ManualDragDelegate(directory: URL(fileURLWithPath: CommandLine.arguments[1]),
                                            suite: suite, defaults: defaults, style: style)
            app.delegate = manual
            withExtendedLifetime(manual) { app.run() }
            Settings.resetTestConfiguration()
            return
        }
        let delegate = DragDelegate(directory: URL(fileURLWithPath: CommandLine.arguments[1]),
                                    suite: suite, defaults: defaults)
        app.delegate = delegate
        withExtendedLifetime(delegate) { app.run() }
        Settings.resetTestConfiguration()
    }
}

/// A passive fixture for actual pointer input through the VM UI. No events are
/// generated here and no internal dragging methods are invoked.
@available(macOS 26.0, *)
private final class ManualDragDelegate: NSObject, NSApplicationDelegate {
    let directory: URL
    let suite: String
    let defaults: CountingDefaults
    var style: String
    let started = ProcessInfo.processInfo.systemUptime
    var reduced = ProcessInfo.processInfo.environment["WATTSON_FORCE_REDUCE_MOTION"] == "1"
    var controller: SettingsWindowController?
    // Retain only this fixture window's content so a real close remains
    // observable after AppKit removes the content from its visible hierarchy.
    var observedContent: NSView?
    var closeObserver: NSObjectProtocol?
    var lifecycleEvents: [[String: Any]] = []
    var closeOnPreviewArmed = false
    var closeOnPreviewEvidence: [String: Any] = [:]
    var timer: Timer?
    var observer: NSObjectProtocol?
    var monitor: Any?
    var history: FileHandle?
    var previousState: Data?
    var lastReset: Data?
    var lastCapture: Data?
    var lastCaptureResult: [String: Any] = [:]
    var lastCommand: [String: Any] = [:]
    var events: [[String: Any]] = []
    var eventCount = 0
    var writes = 0
    var visibilityChanges = 0
    let nativeDragObserver = NativeDragObserver()
    var nativeDragSessionEvents: [[String: Any]] = []
    var caseName = "initial"
    var status = "running"
    var finished = false

    init(directory: URL, suite: String, defaults: CountingDefaults, style: String) {
        self.directory = directory; self.suite = suite; self.defaults = defaults; self.style = style
    }

    func applicationDidFinishLaunching(_ notification: Notification) {
        Settings.moduleOrder = Settings.Module.allCases
        Settings.Module.allCases.forEach { Settings.setModule($0, visible: true) }
        defaults.orderWrites = 0
        showWindow()
        observer = NotificationCenter.default.addObserver(forName: Settings.didChange, object: nil, queue: .main) { [weak self] notification in
            guard let self, let change = notification.userInfo?[Settings.changeUserInfoKey] as? Settings.Change else { return }
            if change == .moduleOrder { self.writes += 1 }
            if case .module = change { self.visibilityChanges += 1 }
        }
        monitor = NSEvent.addLocalMonitorForEvents(matching: [.leftMouseDown, .leftMouseDragged, .leftMouseUp, .keyDown, .keyUp]) { [weak self] event in
            guard let self, event.window === self.controller?.windowForTest else { return event }
            self.eventCount += 1
            let key = event.type == .keyDown || event.type == .keyUp
            self.events.append(["number": self.eventCount, "type": event.type.rawValue,
                "elapsed": ProcessInfo.processInfo.systemUptime - self.started,
                "x": event.locationInWindow.x, "y": event.locationInWindow.y,
                "keyCode": key ? Int(event.keyCode) : -1])
            if self.events.count > 80 { self.events.removeFirst(self.events.count - 80) }
            return event
        }
        let log = directory.appendingPathComponent("history.jsonl")
        guard FileManager.default.createFile(atPath: log.path, contents: nil),
              let stream = try? FileHandle(forWritingTo: log) else { finish(code: 1, reason: "history-file-failure"); return }
        history = stream
        let sampler = Timer(timeInterval: 0.1, repeats: true) { [weak self] _ in self?.sample() }
        timer = sampler
        RunLoop.main.add(sampler, forMode: .common)
        RunLoop.main.add(sampler, forMode: .eventTracking)
        sample()
        print("MANUAL_MODULES_READY style=\(style) reduceMotion=\(reduced); read state.json; create done to finish")
        fflush(stdout)
    }

    private func showWindow() {
        if let closeObserver { NotificationCenter.default.removeObserver(closeObserver); self.closeObserver = nil }
        controller?.windowForTest?.close(); controller = nil
        observedContent = nil
        Settings.liquidGlassEnabled = style != "classic"
        Settings.liquidGlassStyle = style == "clear" ? .clear : .regular
        let dependencies = SettingsWindowDependencies(
            loginItemState: { .enabled }, refreshLoginItem: { $0(.enabled) },
            setLoginItemEnabled: { _, _ in fatalError("Read-only fixture") },
            systemBatteryIconHidden: { false }, helperAvailable: { true },
            refreshSystemBatteryIcon: { $0(false) },
            setSystemBatteryIconHidden: { _, _ in fatalError("Read-only fixture") },
            systemBatteryIconDidChange: Notification.Name("Wattson.ModulesDrag.FixedBattery"),
            currentVersion: { "QA" }, checkForUpdates: { _ in }, openUpdateURL: { _ in false },
            increaseContrast: { false }, announceAccessibility: { _ in }, systemBatteryIconReadStatus: { .ready })
        let settings = SettingsWindowController(dependencies: dependencies, frameAutosaveName: nil)
        controller = settings
        settings.windowForTest?.animationBehavior = .none
        settings.windowForTest?.center()
        settings.selectSectionForTest(identifier: "modules"); settings.show()
        observedContent = settings.windowForTest?.contentView
        guard let stack, nativeDragObserver.observe(stack, callback: { [weak self] phase, source, session, point, operation in
            guard let self else { return }
            var event: [String: Any] = ["phase": phase, "case": self.caseName,
                "elapsed": ProcessInfo.processInfo.systemUptime - self.started,
                "sessionIdentity": String(describing: ObjectIdentifier(session)),
                "sourceIdentity": String(describing: ObjectIdentifier(source)),
                "screenPoint": [point.x, point.y], "savedOrder": Settings.moduleOrder.map(\.rawValue),
                "displayOrder": self.displayedOrder, "rowAlpha": self.rows.map { $0.alphaValue },
                "dragState": self.dragStateSnapshot, "syntheticCallback": false]
            if let operation { event["operation"] = operation }
            self.nativeDragSessionEvents.append(event)
            do { try self.persist() } catch { self.finish(code: 1, reason: "callback-observation-write-failure") }
        }) else { finish(code: 78, reason: "native-callback-observation-unavailable"); return }
        if let window = settings.windowForTest {
            closeObserver = NotificationCenter.default.addObserver(forName: NSWindow.willCloseNotification, object: window, queue: .main) { [weak self] _ in
                guard let self else { return }
                self.lifecycleEvents.append(["event": "willClose", "elapsed": ProcessInfo.processInfo.systemUptime - self.started,
                    "savedOrder": Settings.moduleOrder.map(\.rawValue), "orderWrites": self.defaults.orderWrites,
                    "rowAlphaAtNotification": self.rows.map { $0.alphaValue }])
            }
        }
    }

    private func descendants(_ view: NSView) -> [NSView] { [view] + view.subviews.flatMap(descendants) }
    private var views: [NSView] { observedContent.map(descendants) ?? [] }
    private var rows: [NSView] { views.filter { $0.identifier?.rawValue.hasPrefix("settings.modules.row.") == true } }
    private var stack: NSStackView? {
        views.compactMap { $0 as? NSStackView }.first { list in
            list.arrangedSubviews.count == 5 && list.arrangedSubviews.allSatisfy {
                $0.identifier?.rawValue.hasPrefix("settings.modules.row.") == true
            }
        }
    }
    private var displayedOrder: [String] {
        stack?.arrangedSubviews.compactMap { $0.identifier?.rawValue.replacingOccurrences(of: "settings.modules.row.", with: "") } ?? []
    }
    private var dragStateSnapshot: [String: Any] {
        guard let stack else { return ["available": false] }
        let fields = Dictionary(uniqueKeysWithValues: Mirror(reflecting: stack).children.compactMap { child in
            child.label.map { ($0, child.value) }
        })
        guard let dragged = fields["draggedModule"], let original = fields["originalOrder"] as? [Settings.Module],
              let session = fields["dragSession"] else { return ["available": false] }
        let isNil: (Any) -> Bool = { value in
            let mirror = Mirror(reflecting: value)
            return mirror.displayStyle == .optional && mirror.children.isEmpty
        }
        return ["available": true, "draggedModuleIsNil": isNil(dragged),
            "originalOrderIsEmpty": original.isEmpty, "dragSessionIsNil": isNil(session),
            "readOnlySwiftReflection": true]
    }
    private func state() -> [String: Any] {
        var value: [String: Any] = ["schema": 1, "mode": "manual", "style": style, "reduceMotion": reduced,
            "status": status, "case": caseName, "syntheticInput": false, "directDragCallbacks": false,
            "lastCommand": lastCommand, "lastCapture": lastCaptureResult,
            "nativeDragObservation": nativeDragObserver.installation,
            "nativeDragSessionEvents": nativeDragSessionEvents,
            "dragState": dragStateSnapshot,
            "keyboardFocusVisible": Dictionary(uniqueKeysWithValues: Settings.Module.allCases.map {
                ($0.rawValue, controller?.moduleReorderShowsKeyboardFocusForTest($0) ?? false)
            }),
            "windowLifecycleEvents": lifecycleEvents,
            "closeOnPreviewArmed": closeOnPreviewArmed, "closeOnPreviewEvidence": closeOnPreviewEvidence,
            "testVerdict": "not-automatically-evaluated", "savedOrder": Settings.moduleOrder.map(\.rawValue),
            "displayOrder": displayedOrder,
            "orderWrites": defaults.orderWrites, "orderNotifications": writes, "visibilityNotifications": visibilityChanges,
            "visibility": Dictionary(uniqueKeysWithValues: Settings.Module.allCases.map { ($0.rawValue, Settings.isModuleVisible($0)) }),
            "observedOwnWindowEventCount": eventCount, "recentOwnWindowEvents": events,
            "visible": controller?.windowForTest?.isVisible == true, "keyWindow": controller?.windowForTest?.isKeyWindow == true,
            "rows": rows.map { row -> [String: Any] in
                let frame = row.convert(row.bounds, to: nil)
                return ["id": row.identifier?.rawValue ?? "", "alpha": row.alphaValue,
                        "objectIdentity": String(describing: ObjectIdentifier(row)), "attachedToWindow": row.window != nil,
                        "frameInWindow": [frame.minX, frame.minY, frame.width, frame.height],
                        "animationKeys": row.layer?.animationKeys() ?? []]
            }]
        if let window = controller?.windowForTest {
            value["windowNumber"] = window.windowNumber
            value["windowIdentity"] = String(describing: ObjectIdentifier(window))
            if let responder = window.firstResponder {
                value["firstResponder"] = ["objectIdentity": String(describing: ObjectIdentifier(responder)),
                    "viewIdentifier": (responder as? NSView)?.identifier?.rawValue ?? "",
                    "class": String(describing: type(of: responder))]
            }
            value["settingsScrollViews"] = views.compactMap { $0 as? NSScrollView }.map { scroll -> [String: Any] in
                ["objectIdentity": String(describing: ObjectIdentifier(scroll)), "id": scroll.identifier?.rawValue ?? "",
                 "origin": [scroll.contentView.bounds.origin.x, scroll.contentView.bounds.origin.y]]
            }
            value["windowFrameInScreen"] = [window.frame.minX, window.frame.minY, window.frame.width, window.frame.height]
            value["handles"] = views.filter { $0.identifier?.rawValue.hasPrefix("settings.modules.reorder.") == true }.map { handle -> [String: Any] in
                let frame = window.convertToScreen(handle.convert(handle.bounds, to: nil))
                return ["id": handle.identifier?.rawValue ?? "", "frameInScreen": [frame.minX, frame.minY, frame.width, frame.height]]
            }
        }
        return value
    }
    private func regularMarker(_ name: String) -> Bool {
        let url = directory.appendingPathComponent(name)
        guard let keys = try? url.resourceValues(forKeys: [.isRegularFileKey, .isSymbolicLinkKey]) else { return false }
        return keys.isRegularFile == true && keys.isSymbolicLink != true
    }
    private func sample() {
        guard !finished else { return }
        if regularMarker("done") { finish(code: 0, reason: "done-marker"); return }
        if ProcessInfo.processInfo.systemUptime - started >= 600 { finish(code: 124, reason: "600-second-deadline"); return }
        if regularMarker("reset.json"), let data = try? Data(contentsOf: directory.appendingPathComponent("reset.json")), data != lastReset {
            lastReset = data
            handleReset(data)
        }
        if regularMarker("capture.json"), let data = try? Data(contentsOf: directory.appendingPathComponent("capture.json")), data != lastCapture {
            lastCapture = data
            captureOwnWindow(data)
        }
        do {
            if closeOnPreviewArmed, rows.count == 5, rows.contains(where: { $0.alphaValue < 0.5 }),
               displayedOrder != Settings.moduleOrder.map(\.rawValue), let window = controller?.windowForTest, window.isVisible {
                closeOnPreviewArmed = false
                closeOnPreviewEvidence = ["mechanism": "fixture-window.close-after-real-preview",
                    "userCloseInput": false, "directDragCallbacks": false, "testVerdict": "not-automatically-evaluated",
                    "observedPreview": ["elapsed": ProcessInfo.processInfo.systemUptime - started,
                        "savedOrder": Settings.moduleOrder.map(\.rawValue), "displayOrder": displayedOrder,
                        "rowAlpha": rows.map { $0.alphaValue }, "orderWrites": defaults.orderWrites,
                        "windowIdentity": String(describing: ObjectIdentifier(window))]]
                try persist()
                // Exercise a real window-lifecycle close after an actual pointer
                // drag. This is not a claim that CUA sent a close key mid-drag.
                window.close()
                closeOnPreviewEvidence["closeCallReturned"] = true
            }
            try persist()
        } catch { finish(code: 1, reason: "state-write-failure") }
    }
    private func captureOwnWindow(_ data: Data) {
        lastCaptureResult = ["result": "rejected-invalid-command"]
        guard data.count <= 4096, let object = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any],
              let name = object["name"] as? String,
              name.range(of: "^[A-Za-z0-9][A-Za-z0-9._-]{0,79}$", options: .regularExpression) != nil,
              let window = controller?.windowForTest, window.isVisible, let screen = window.screen else { return }
        let target = directory.appendingPathComponent(name + ".png")
        guard !FileManager.default.fileExists(atPath: target.path) else { lastCaptureResult = ["name": name, "result": "refused-overwrite"]; return }
        window.displayIfNeeded()
        let rect = NSRect(x: window.frame.minX - 8, y: screen.frame.maxY - window.frame.maxY - 8,
            width: window.frame.width + 16, height: window.frame.height + 16)
        guard let image = WattsonModulesCaptureOwnedWindow(rect, CGWindowID(window.windowNumber)),
              let png = NSBitmapImageRep(cgImage: image).representation(using: .png, properties: [:]) else {
            lastCaptureResult = ["name": name, "result": "capture-unavailable"]; return
        }
        do {
            try png.write(to: target, options: .atomic)
            lastCaptureResult = ["name": name, "result": "captured", "ownedWindowID": window.windowNumber,
                "pixels": [image.width, image.height], "elapsed": ProcessInfo.processInfo.systemUptime - started,
                "onlyExplicitOwnedWindow": true]
            try JSONSerialization.data(withJSONObject: state(), options: [.prettyPrinted, .sortedKeys])
                .write(to: directory.appendingPathComponent(name + ".json"), options: .atomic)
        } catch { lastCaptureResult = ["name": name, "result": "capture-write-failed"] }
    }
    private func handleReset(_ data: Data) {
        lastCommand = ["result": "rejected-invalid-command"]
        guard data.count <= 4096, let object = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any],
              let name = object["case"] as? String,
              name.range(of: "^[A-Za-z0-9][A-Za-z0-9._-]{0,79}$", options: .regularExpression) != nil else { return }
        let nextStyle = object["style"] as? String ?? style
        let nextReduced = object["reduceMotion"] as? Bool ?? reduced
        guard ["classic", "standard", "clear"].contains(nextStyle) else { return }
        lastCommand = ["case": name, "result": "rejected-active-gesture"]
        guard rows.count == 5, rows.allSatisfy({ abs($0.alphaValue - 1) < 0.001 }), NSEvent.pressedMouseButtons & 1 == 0 else { return }
        // Test-process override only; this never writes macOS accessibility prefs.
        setenv("WATTSON_FORCE_REDUCE_MOTION", nextReduced ? "1" : "0", 1)
        guard ProcessInfo.processInfo.environment["WATTSON_FORCE_REDUCE_MOTION"] == (nextReduced ? "1" : "0") else {
            lastCommand["result"] = "rejected-process-environment-readback"; return
        }
        let rebuild = nextStyle != style || nextReduced != reduced || controller?.windowForTest?.isVisible != true
        style = nextStyle; reduced = nextReduced
        Settings.moduleOrder = Settings.Module.allCases
        Settings.Module.allCases.forEach { Settings.setModule($0, visible: true) }
        if rebuild { showWindow() }
        defaults.orderWrites = 0; writes = 0; visibilityChanges = 0; events.removeAll(); eventCount = 0
        lifecycleEvents.removeAll(); nativeDragSessionEvents.removeAll()
        closeOnPreviewArmed = object["closeOnPreview"] as? Bool ?? false
        closeOnPreviewEvidence = [:]
        caseName = name
        lastCommand = ["case": name, "result": "applied", "style": style, "reduceMotion": reduced,
                       "windowRebuilt": rebuild, "closeOnPreviewArmed": closeOnPreviewArmed]
    }
    private func persist() throws {
        var value = state()
        let signature = try JSONSerialization.data(withJSONObject: value, options: [.sortedKeys])
        value["elapsed"] = ProcessInfo.processInfo.systemUptime - started
        value["epoch"] = Date().timeIntervalSince1970
        let data = try JSONSerialization.data(withJSONObject: value, options: [.sortedKeys])
        try data.write(to: directory.appendingPathComponent("state.json"), options: .atomic)
        if signature != previousState {
            try history?.write(contentsOf: data + Data([10]))
            previousState = signature
        }
    }
    private func finish(code: Int32, reason: String) {
        guard !finished else { return }
        var exitCode = code
        status = reason
        do {
            try persist()
            var value = state()
            value["sessionEnded"] = true; value["exitCode"] = code
            let data = try JSONSerialization.data(withJSONObject: value, options: [.prettyPrinted, .sortedKeys])
            try data.write(to: directory.appendingPathComponent("result.json"), options: .atomic)
            if code == 0 { try data.write(to: directory.appendingPathComponent("complete.json"), options: .atomic) }
        } catch { fputs("Manual evidence write failed: \(error)\n", stderr); exitCode = 1 }
        finished = true
        clean()
        if exitCode != 0 { exit(exitCode) }
        NSApp.terminate(nil)
    }
    private func clean() {
        timer?.invalidate(); timer = nil
        nativeDragObserver.restore()
        if let observer { NotificationCenter.default.removeObserver(observer); self.observer = nil }
        if let monitor { NSEvent.removeMonitor(monitor); self.monitor = nil }
        if let closeObserver { NotificationCenter.default.removeObserver(closeObserver); self.closeObserver = nil }
        try? history?.close(); history = nil
        controller?.windowForTest?.close(); controller = nil
        observedContent = nil
        defaults.removePersistentDomain(forName: suite); defaults.synchronize()
        UserDefaults.standard.synchronize(); Settings.resetTestConfiguration()
    }
    func applicationWillTerminate(_ notification: Notification) { clean() }
}

private final class CountingDefaults: UserDefaults {
    var orderWrites = 0
    override func set(_ value: Any?, forKey key: String) {
        if key == "popover.moduleOrder" { orderWrites += 1 }
        super.set(value, forKey: key)
    }
}

private struct ProbeFailure: Error, CustomStringConvertible {
    let description: String
    let unsupported: Bool
    init(_ description: String, unsupported: Bool = false) {
        self.description = description; self.unsupported = unsupported
    }
}

@available(macOS 26.0, *)
private final class DragDelegate: NSObject, NSApplicationDelegate {
    let directory: URL
    let suite: String
    let defaults: CountingDefaults
    let reduced = ProcessInfo.processInfo.environment["WATTSON_FORCE_REDUCE_MOTION"] == "1"
    var controller: SettingsWindowController?
    var observer: NSObjectProtocol?
    var eventMonitor: Any?
    var records: [[String: Any]] = []
    var posted: [[String: Any]] = []
    var eventCount = 0
    var orderNotifications = 0
    var moduleNotifications = 0
    var nativeDropCount = 0
    var caseName = "startup"
    var finished = false
    var eventNumber = 1

    init(directory: URL, suite: String, defaults: CountingDefaults) {
        self.directory = directory; self.suite = suite; self.defaults = defaults
    }

    func applicationDidFinishLaunching(_ notification: Notification) {
        observer = NotificationCenter.default.addObserver(forName: Settings.didChange, object: nil, queue: .main) { [weak self] notification in
            guard let self, let change = notification.userInfo?[Settings.changeUserInfoKey] as? Settings.Change else { return }
            if change == .moduleOrder { self.orderNotifications += 1 }
            if case .module = change { self.moduleNotifications += 1 }
        }
        eventMonitor = NSEvent.addLocalMonitorForEvents(matching: [.leftMouseDown, .leftMouseDragged, .leftMouseUp, .keyDown, .keyUp]) { [weak self] event in
            if event.window === self?.controller?.windowForTest { self?.eventCount += 1 }
            return event
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 120) { [weak self] in
            self?.finish(error: ProbeFailure("Application event loop timed out; native drag is not verified", unsupported: true))
        }
        Task { @MainActor in
            do { try await run(); finish(error: nil) }
            catch { finish(error: error) }
        }
    }

    func applicationWillTerminate(_ notification: Notification) { clean() }

    private func clean() {
        if let eventMonitor { NSEvent.removeMonitor(eventMonitor); self.eventMonitor = nil }
        if let observer { NotificationCenter.default.removeObserver(observer); self.observer = nil }
        controller?.windowForTest?.close(); controller = nil
        defaults.removePersistentDomain(forName: suite)
        defaults.synchronize()
        UserDefaults.standard.synchronize()
        Settings.resetTestConfiguration()
    }

    private func finish(error: Error?) {
        guard !finished else { return }
        finished = true
        let code: Int32 = error == nil ? 0 : ((error as? ProbeFailure)?.unsupported == true ? 78 : 1)
        var report: [String: Any] = ["schema": 1, "complete": error == nil, "exitCode": code,
            "method": "NSEvent -> NSApplication.postEvent -> production AppKit window",
            "directDragCallbacksUsed": false, "systemEventInjectionUsed": false,
            "reduceMotion": reduced, "nativeDropCount": nativeDropCount,
            "nativeDropVerified": nativeDropCount > 0, "lastCase": caseName,
            "records": records, "postedEvents": posted, "observedOwnWindowEvents": eventCount,
            "stateAtFinish": state()]
        if let error { report["error"] = String(describing: error) }
        do {
            let data = try JSONSerialization.data(withJSONObject: report, options: [.prettyPrinted, .sortedKeys])
            try data.write(to: directory.appendingPathComponent("result.json"), options: .atomic)
            if error == nil { try data.write(to: directory.appendingPathComponent("complete.json"), options: .atomic) }
        } catch { fputs("Could not persist native drag evidence: \(error)\n", stderr); clean(); exit(1) }
        clean()
        if let error { fputs("MODULES_NATIVE_DRAG_UNVERIFIED_OR_FAILED: \(error)\n", stderr); exit(code) }
        print("MODULES_NATIVE_DRAG_PASSED; actual native drops=\(nativeDropCount); reduceMotion=\(reduced)")
        NSApp.terminate(nil)
    }

    private func descendants(_ view: NSView) -> [NSView] { [view] + view.subviews.flatMap(descendants) }
    private var views: [NSView] { controller?.windowForTest?.contentView.map(descendants) ?? [] }
    private var rows: [NSView] { views.filter { $0.identifier?.rawValue.hasPrefix("settings.modules.row.") == true } }
    private var list: NSStackView? {
        views.compactMap { $0 as? NSStackView }.first { stack in
            stack.arrangedSubviews.count == 5 && stack.arrangedSubviews.allSatisfy {
                $0.identifier?.rawValue.hasPrefix("settings.modules.row.") == true
            }
        }
    }
    private var displayOrder: [String] {
        list?.arrangedSubviews.compactMap { $0.identifier?.rawValue.replacingOccurrences(of: "settings.modules.row.", with: "") } ?? []
    }
    private var visibility: [Bool] { Settings.Module.allCases.map(Settings.isModuleVisible) }
    private var feedbackCleared: Bool { rows.count == 5 && rows.allSatisfy { abs($0.alphaValue - 1) < 0.001 } }
    private func state() -> [String: Any] {
        ["savedOrder": Settings.moduleOrder.map(\.rawValue), "displayOrder": displayOrder,
         "rowAlpha": rows.map { $0.alphaValue }, "orderWrites": defaults.orderWrites,
         "orderNotifications": orderNotifications, "moduleNotifications": moduleNotifications,
         "visibility": visibility, "ownWindowVisible": controller?.windowForTest?.isVisible == true,
         "ownWindowKey": controller?.windowForTest?.isKeyWindow == true]
    }
    private func record(_ name: String) throws {
        records.append(["case": caseName, "checkpoint": name, "state": state()])
        try JSONSerialization.data(withJSONObject: ["complete": false, "records": records, "postedEvents": posted],
                                   options: [.prettyPrinted, .sortedKeys])
            .write(to: directory.appendingPathComponent("progress.json"), options: .atomic)
    }
    private func require(_ condition: Bool, _ description: String) throws {
        guard condition else { throw ProbeFailure(description) }
    }
    @MainActor private func wait(_ seconds: Double = 0.08) async throws {
        try await Task.sleep(nanoseconds: UInt64(seconds * 1_000_000_000))
    }
    @MainActor private func until(_ condition: () -> Bool, seconds: Double = 2) async throws -> Bool {
        let deadline = ProcessInfo.processInfo.systemUptime + seconds
        while !condition(), ProcessInfo.processInfo.systemUptime < deadline { try await wait(0.04) }
        return condition()
    }
    private func view(_ identifier: String) throws -> NSView {
        guard let view = views.first(where: { $0.identifier?.rawValue == identifier }) else {
            throw ProbeFailure("Missing production view: \(identifier)")
        }
        return view
    }
    private func center(_ view: NSView) -> NSPoint { view.convert(NSPoint(x: view.bounds.midX, y: view.bounds.midY), to: nil) }
    private func mouse(_ type: NSEvent.EventType, at point: NSPoint) throws {
        guard let window = controller?.windowForTest,
              let event = NSEvent.mouseEvent(with: type, location: point, modifierFlags: [],
                  timestamp: ProcessInfo.processInfo.systemUptime, windowNumber: window.windowNumber,
                  context: nil, eventNumber: eventNumber, clickCount: 1, pressure: type == .leftMouseUp ? 0 : 1) else {
            throw ProbeFailure("Could not construct own-window mouse event")
        }
        posted.append(["case": caseName, "type": type.rawValue, "x": point.x, "y": point.y,
                       "eventNumber": eventNumber, "windowNumber": window.windowNumber])
        eventNumber += 1
        NSApp.postEvent(event, atStart: false)
    }
    private func escape() throws {
        guard let window = controller?.windowForTest else { throw ProbeFailure("No own window for Escape") }
        for type in [NSEvent.EventType.keyDown, .keyUp] {
            guard let event = NSEvent.keyEvent(with: type, location: .zero, modifierFlags: [],
                timestamp: ProcessInfo.processInfo.systemUptime, windowNumber: window.windowNumber,
                context: nil, characters: "\u{1b}", charactersIgnoringModifiers: "\u{1b}", isARepeat: false, keyCode: 53) else {
                throw ProbeFailure("Could not construct own-window Escape event")
            }
            posted.append(["case": caseName, "type": type.rawValue, "keyCode": 53, "windowNumber": window.windowNumber])
            NSApp.postEvent(event, atStart: false)
        }
    }
    @MainActor private func resetCase(_ name: String) async throws {
        caseName = name
        Settings.moduleOrder = Settings.Module.allCases
        Settings.Module.allCases.forEach { Settings.setModule($0, visible: true) }
        controller?.windowForTest?.contentView?.layoutSubtreeIfNeeded()
        try await wait(0.25)
        defaults.orderWrites = 0; orderNotifications = 0; moduleNotifications = 0
        try require(feedbackCleared, "Previous gesture leaked drag feedback")
        try record("before")
    }
    @MainActor private func beginDrag() async throws -> NSPoint {
        let handle = try view("settings.modules.reorder.flow")
        let start = center(handle)
        let threshold = NSPoint(x: start.x - 5, y: start.y)
        try mouse(.leftMouseDown, at: start)
        try mouse(.leftMouseDragged, at: threshold)
        let entered = try await until({ self.rows.contains { $0.alphaValue < 0.5 } })
        try record("after-drag-start-events")
        guard entered else {
            // Posted NSEvents may be insufficient for a WindowServer drag session.
            // Never replace this gate with direct calls to the production methods.
            throw ProbeFailure("Own-window NSEvents did not establish observable native drag feedback; native drag remains unverified", unsupported: true)
        }
        try require(defaults.orderWrites == 0 && orderNotifications == 0, "Drag start persisted a transient order")
        return threshold
    }
    private func targetPoint(last: Bool) throws -> NSPoint {
        guard let list else { throw ProbeFailure("Missing production Modules stack") }
        let y: CGFloat = last ? (list.isFlipped ? list.bounds.maxY - 3 : list.bounds.minY + 3)
                              : (list.isFlipped ? list.bounds.minY + 3 : list.bounds.maxY - 3)
        return list.convert(NSPoint(x: list.bounds.maxX - 20, y: y), to: nil)
    }
    @MainActor private func previewLast() async throws -> NSPoint {
        _ = try await beginDrag()
        let target = try targetPoint(last: true)
        try mouse(.leftMouseDragged, at: target)
        let preview = try await until({ self.displayOrder == ["ring", "lanes", "history", "runtime", "flow"] })
        try record("before-mouse-up")
        guard preview else {
            throw ProbeFailure("Native drag start was observed, but the posted move did not reach a destination preview; no direct drop callback was substituted", unsupported: true)
        }
        try require(Settings.moduleOrder == Settings.Module.allCases && defaults.orderWrites == 0 && orderNotifications == 0,
                    "Preview wrote the saved order before a valid drop")
        if reduced {
            try require(rows.allSatisfy { ($0.layer?.animationKeys() ?? []).isEmpty }, "Reduce Motion left row animations running")
        }
        return target
    }
    @MainActor private func run() async throws {
        guard NSScreen.main != nil else { throw ProbeFailure("No GUI session", unsupported: true) }
        for style in ["classic", "standard", "clear"] {
            Settings.liquidGlassEnabled = style != "classic"
            Settings.liquidGlassStyle = style == "clear" ? .clear : .regular
            let dependencies = SettingsWindowDependencies(
                loginItemState: { .enabled }, refreshLoginItem: { $0(.enabled) },
                setLoginItemEnabled: { _, _ in fatalError("Read-only fixture") },
                systemBatteryIconHidden: { false }, helperAvailable: { true },
                refreshSystemBatteryIcon: { $0(false) },
                setSystemBatteryIconHidden: { _, _ in fatalError("Read-only fixture") },
                systemBatteryIconDidChange: Notification.Name("Wattson.ModulesDrag.FixedBattery"),
                currentVersion: { "QA" }, checkForUpdates: { _ in }, openUpdateURL: { _ in false },
                increaseContrast: { false }, announceAccessibility: { _ in }, systemBatteryIconReadStatus: { .ready })
            let settings = SettingsWindowController(dependencies: dependencies, frameAutosaveName: nil)
            controller = settings
            guard let window = settings.windowForTest else { throw ProbeFailure("Missing production Settings window") }
            window.animationBehavior = .none; window.center()
            settings.selectSectionForTest(identifier: "modules"); settings.show()
            let ready = try await until({ window.isVisible && window.isKeyWindow }, seconds: 3)
            try require(ready, "Production Settings window did not become visible and key")
            try require(rows.count == 5 && list != nil, "Production Modules rows are incomplete")
            let rowIdentities = Set(rows.map(ObjectIdentifier.init))

            try await resetCase("\(style)-toggle-is-not-drag")
            let flowRow = try view("settings.modules.row.flow")
            let controls = descendants(flowRow).filter { $0.accessibilityLabel() == Settings.Module.flow.title }
            guard let toggle = controls.first(where: { $0 is NSSwitch }) ?? controls.first(where: { $0 is NSButton }) else {
                throw ProbeFailure("Missing production module toggle")
            }
            let togglePoint = center(toggle)
            // Queue both halves before yielding so NSButton tracking can consume
            // the release without waiting for another main-queue task.
            try mouse(.leftMouseDown, at: togglePoint); try mouse(.leftMouseUp, at: togglePoint)
            let toggled = try await until({ !Settings.isModuleVisible(.flow) })
            try require(toggled && moduleNotifications == 1 && defaults.orderWrites == 0 && orderNotifications == 0 && feedbackCleared,
                        "Toggle routing changed order, failed to toggle once, or started a drag")
            try record("passed")

            try await resetCase("\(style)-valid-drop-saves-once")
            let target = try await previewLast()
            try mouse(.leftMouseUp, at: target)
            let dropped = try await until({ Settings.moduleOrder.map(\.rawValue) == ["ring", "lanes", "history", "runtime", "flow"] && self.feedbackCleared })
            try require(dropped && defaults.orderWrites == 1 && orderNotifications == 1 && moduleNotifications == 0 && visibility.allSatisfy { $0 },
                        "Native mouse-up did not commit exactly one valid drop")
            try require(Set(rows.map(ObjectIdentifier.init)) == rowIdentities, "Drop rebuilt production rows")
            nativeDropCount += 1
            try record("passed-real-native-drop")

            try await resetCase("\(style)-same-position-no-write")
            _ = try await beginDrag()
            let original = try targetPoint(last: false)
            try mouse(.leftMouseDragged, at: original)
            try await wait(0.2)
            try mouse(.leftMouseUp, at: original)
            let sameSettled = try await until({ self.feedbackCleared })
            try require(sameSettled && Settings.moduleOrder == Settings.Module.allCases && defaults.orderWrites == 0 && orderNotifications == 0,
                        "Same-position native drop changed settings")
            try record("passed")

            try await resetCase("\(style)-escape-cancels-preview")
            let escapedTarget = try await previewLast()
            try escape()
            let escaped = try await until({ self.feedbackCleared })
            try mouse(.leftMouseUp, at: escapedTarget)
            try await wait(0.2)
            try require(escaped && displayOrder == Settings.Module.allCases.map(\.rawValue) && defaults.orderWrites == 0 && orderNotifications == 0,
                        "Escape did not cancel native drag and restore its original order")
            try record("passed")

            try await resetCase("\(style)-outside-drop-cancels")
            _ = try await previewLast()
            guard let content = window.contentView else { throw ProbeFailure("Missing own window content") }
            // An in-window point outside Modules, away from controls. It proves
            // invalid-destination cancellation without another app's window.
            let outside = content.convert(NSPoint(x: 8, y: 8), to: nil)
            try mouse(.leftMouseDragged, at: outside)
            try await wait(0.2)
            try mouse(.leftMouseUp, at: outside)
            let cancelled = try await until({ self.feedbackCleared })
            try require(cancelled && displayOrder == Settings.Module.allCases.map(\.rawValue) && defaults.orderWrites == 0 && orderNotifications == 0,
                        "Dropping outside Modules changed saved order or leaked feedback")
            try record("passed")
            window.close(); controller = nil
            try await wait(0.2)
        }
    }
}
