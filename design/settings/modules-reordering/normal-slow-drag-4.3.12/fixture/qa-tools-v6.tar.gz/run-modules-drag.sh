#!/bin/bash
# Post NSEvents only into this disposable app's own production Settings window.
set -euo pipefail
repo="${WATTSON_MODULES_SOURCE_ROOT:?}"
tools="${WATTSON_MODULES_TOOLS_DIR:?}"
results="${WATTSON_MODULES_RESULTS:?}/drag"
manual_style="${WATTSON_MODULES_MANUAL_STYLE:-}"
manual_reduced="${WATTSON_FORCE_REDUCE_MOTION:-0}"
if [[ -n "$manual_style" ]]; then
  [[ "$manual_style" == classic || "$manual_style" == standard || "$manual_style" == clear ]] || exit 64
  [[ "$manual_reduced" == 0 || "$manual_reduced" == 1 ]] || exit 64
fi
[[ "$HOME" == /Users/admin && "$(/usr/sbin/sysctl -n hw.model)" == VirtualMac* ]] || exit 65
source "$repo/scripts/lib/local_cleanup.sh"
wattson_cleanup_init
cd "$repo"
mkdir -p "$results" "$repo/.build/modules-drag-native.noindex"
run_dir="$(mktemp -d "$repo/.build/modules-drag-native.noindex/run.XXXXXX")"
wattson_cleanup_add_dir "$run_dir"
app="$run_dir/ModulesDragProbe.app"
executable="$app/Contents/MacOS/ModulesDragProbe"
bundle_id="com.leoarrow.wattson.modulesdragqa.$(/usr/bin/uuidgen | /usr/bin/tr '[:upper:]' '[:lower:]')"
normal_suite="Wattson.SwiftTests.ModuleOrderView.$(/usr/bin/uuidgen)"
reduced_suite="Wattson.SwiftTests.ModuleOrderView.$(/usr/bin/uuidgen)"
domains=("$bundle_id" "$normal_suite" "$reduced_suite")
for domain in "${domains[@]}"; do
  [[ ! -e "$HOME/Library/Preferences/$domain.plist" && ! -L "$HOME/Library/Preferences/$domain.plist" ]] || exit 65
  wattson_cleanup_add_defaults "$domain"
done
wattson_cleanup_add_app "$app"
wattson_cleanup_add_container "$bundle_id"
wattson_cleanup_add_executable "$executable"
# Parent ownership is recorded before any Foundation/AppKit child starts.
printf '%s\n' "${domains[@]}" > "$results/owned-domains.txt"
printf 'bundleID=%s\nbundlePath=%s\nsourceCommit=%s\n' "$bundle_id" "$app" "${WATTSON_MODULES_SOURCE_COMMIT:?}" > "$results/capture-provenance.txt"
return_status() { return "$1"; }
finish() {
  local status=$? domain defaults_status
  trap - EXIT
  trap '' HUP INT TERM
  set +e
  if [[ -n "${_WATTSON_RUNNER_PID:-}" ]]; then
    kill -TERM "$_WATTSON_RUNNER_PID" 2>/dev/null
    wait "$_WATTSON_RUNNER_PID" 2>/dev/null
    _WATTSON_RUNNER_PID=''
  fi
  wattson_stop_executable "$executable" || status=1
  for domain in "${domains[@]}"; do
    defaults_status=0
    wattson_run_timeout 10 /usr/bin/defaults delete "$domain" > "$results/defaults-delete-$domain.log" 2>&1 || defaults_status=$?
    printf '%s\n' "$defaults_status" > "$results/defaults-delete-$domain-exit-code.txt"
    # A Foundation late flush is settled by the exact-domain finalizer below.
    # Preserve defaults' diagnostic exit separately; a timeout remains failure.
    if [[ "$defaults_status" == 124 ]]; then status=1; fi
    wattson_run_timeout 25 /usr/bin/python3 "$tools/finalize-owned-defaults.py" "$domain" > "$results/defaults-finalized-$domain.json" 2>&1 || status=1
  done
  printf '%s\n' "$status" > "$results/exit-code.txt"
  return_status "$status"
  _wattson_cleanup
}
trap finish EXIT
mkdir -p "$app/Contents/MacOS" "$app/Contents/Resources"
for logo in AppLogoColor AppLogoClearLight AppLogoClearDark; do
  cp "$repo/design/icon/in-app-logo/$logo.png" "$app/Contents/Resources/$logo.png"
done
wattson_run_timeout 300 /usr/bin/xcrun swiftc Core/*.swift MenuBar/*.swift Popover/*.swift "$tools/modules-drag.swift" -D DEBUG -swift-version 5 -warnings-as-errors -framework AppKit -framework CoreGraphics -framework IOKit -o "$executable" > "$results/build.log" 2>&1
cat > "$app/Contents/Info.plist" <<EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
<key>CFBundleIdentifier</key><string>$bundle_id</string>
<key>CFBundleName</key><string>ModulesDragProbe</string>
<key>CFBundleExecutable</key><string>ModulesDragProbe</string>
<key>CFBundlePackageType</key><string>APPL</string>
<key>CFBundleShortVersionString</key><string>$(cat VERSION)</string>
<key>CFBundleVersion</key><string>$(cat VERSION)</string>
<key>LSUIElement</key><true/>
</dict></plist>
EOF
wattson_run_timeout 30 /usr/bin/codesign --force --sign - "$app" > "$results/sign.log" 2>&1
if [[ -n "$manual_style" ]]; then
  output="$results/manual-$manual_style-$manual_reduced"
  mkdir "$output"
  # Compile/sign is separate from the bounded CUA session. Root explicitly starts it.
  /usr/bin/python3 - "$output" <<'PYWAIT'
import json, pathlib, time
out=pathlib.Path(__import__('sys').argv[1])
(out/'compiled-ready.json').write_text(json.dumps({'compiled':True,'signed':True,'manualProcessStarted':False,'waitingForRootCUAReady':True,'epoch':time.time()})+'\n')
deadline=time.clock_gettime(time.CLOCK_MONOTONIC)+600
while not (out/'start-manual').is_file():
    if (out/'cancel-before-start').exists(): raise SystemExit(78)
    if time.clock_gettime(time.CLOCK_MONOTONIC)>=deadline: raise SystemExit(124)
    time.sleep(0.25)
(out/'root-start-observed.json').write_text(json.dumps({'epoch':time.time(),'manualProcessStarted':False})+'\n')
PYWAIT
  child_status=0
  wattson_run_timeout 630 /usr/bin/env WATTSON_TEST_DEFAULTS_SUITE="$normal_suite" WATTSON_MODULES_MANUAL_STYLE="$manual_style" WATTSON_FORCE_REDUCE_MOTION="$manual_reduced" WATTSON_FORCE_REDUCE_TRANSPARENCY=0 WATTSON_FORCE_INCREASE_CONTRAST=0 "$executable" "$output" > "$output/run.log" 2> "$output/run.err" || child_status=$?
  printf '%s\n' "$child_status" > "$output/exit-code.txt"
  [[ "$child_status" == 0 ]] || exit "$child_status"
  [[ -s "$output/complete.json" ]] || exit 1
  echo MODULES_MANUAL_SESSION_ENDED_REVIEW_EVIDENCE_FOR_TEST_RESULT
  exit 0
fi
status=0
for mode in normal reduced; do
  output="$results/$mode"
  mkdir "$output"
  reduced=0
  suite="$normal_suite"
  if [[ "$mode" == reduced ]]; then reduced=1; suite="$reduced_suite"; fi
  child_status=0
  wattson_run_timeout 150 /usr/bin/env WATTSON_TEST_DEFAULTS_SUITE="$suite" WATTSON_FORCE_REDUCE_MOTION="$reduced" WATTSON_FORCE_REDUCE_TRANSPARENCY=0 WATTSON_FORCE_INCREASE_CONTRAST=0 "$executable" "$output" > "$output/run.log" 2> "$output/run.err" || child_status=$?
  printf '%s\n' "$child_status" > "$output/exit-code.txt"
  if [[ "$child_status" != 0 ]]; then status="$child_status"; fi
  if [[ "$child_status" == 0 && ! -s "$output/complete.json" ]]; then status=1; fi
done
[[ "$status" == 0 ]] || exit "$status"
echo MODULES_REAL_NATIVE_DRAG_LIFECYCLE_COMPLETED
