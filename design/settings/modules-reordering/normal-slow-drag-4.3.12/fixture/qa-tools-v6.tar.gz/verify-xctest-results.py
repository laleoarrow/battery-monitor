#!/usr/bin/env python3
"""Require every frozen selected XCTest method to start and pass once."""
import json
from pathlib import Path
import re
import sys

assert len(sys.argv) == 3
manifest = json.loads(Path(sys.argv[1]).read_text())
text = Path(sys.argv[2]).read_text()
expected = {(suite, method) for suite, methods in manifest['suites'].items() for method in methods}
assert len(expected) == manifest['expectedCount'] == 61
started = re.findall(r"Test Case '-\[WattsonTests\.(\w+) (\w+)\]' started\.", text)
passed = re.findall(r"Test Case '-\[WattsonTests\.(\w+) (\w+)\]' passed \(", text)
assert len(started) == len(passed) == len(expected)
assert set(started) == set(passed) == expected
assert 'Executed 61 tests, with 0 failures' in text
for suite in manifest['suites']:
    assert "Test Suite '" + suite + "' passed" in text
print(json.dumps({'sourceCommit': manifest['sourceCommit'], 'expectedCount': len(expected),
                  'startedOnceAndPassedOnce': True,
                  'suiteCounts': {suite: len(methods) for suite, methods in manifest['suites'].items()}}))
