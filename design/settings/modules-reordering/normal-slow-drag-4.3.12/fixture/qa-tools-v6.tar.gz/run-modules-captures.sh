#!/bin/bash
# Fixture-only native Settings and popover captures, all in the dedicated VM.
set -euo pipefail
repo="${WATTSON_MODULES_SOURCE_ROOT:?}"
tools="${WATTSON_MODULES_TOOLS_DIR:?}"
results="${WATTSON_MODULES_RESULTS:?}"
[[ "$HOME" == /Users/admin && "$(/usr/sbin/sysctl -n hw.model)" == VirtualMac* ]] || exit 65
source "$repo/scripts/lib/local_cleanup.sh"
wattson_cleanup_init
cd "$repo"
mkdir -p "$results/captures" "$repo/.build/modules-captures.noindex"
run_dir="$(mktemp -d "$repo/.build/modules-captures.noindex/run.XXXXXX")"
wattson_cleanup_add_dir "$run_dir"
app="$run_dir/ModulesProbe.app"
bundle_id="com.leoarrow.wattson.modulesdragqa.$(/usr/bin/uuidgen | /usr/bin/tr '[:upper:]' '[:lower:]')"
[[ ! -e "$HOME/Library/Preferences/$bundle_id.plist" && ! -L "$HOME/Library/Preferences/$bundle_id.plist" ]] || exit 65
wattson_cleanup_add_app "$app"
wattson_cleanup_add_container "$bundle_id"
wattson_cleanup_add_defaults "$bundle_id"
wattson_cleanup_add_executable "$app/Contents/MacOS/ModulesProbe"
return_status() { return "$1"; }
finish() {
  local status=$?
  trap - EXIT
  trap '' HUP INT TERM
  set +e
  if [[ -n "${_WATTSON_RUNNER_PID:-}" ]]; then
    kill -TERM "$_WATTSON_RUNNER_PID" 2>/dev/null
    wait "$_WATTSON_RUNNER_PID" 2>/dev/null
    _WATTSON_RUNNER_PID=''
  fi
  wattson_stop_executable "$app/Contents/MacOS/ModulesProbe" || status=1
  wattson_run_timeout 20 /usr/bin/osascript -l JavaScript "$tools/synchronize-owned-defaults.js" "$bundle_id" > "$results/defaults-synchronized.log" 2>&1 || status=1
  wattson_run_timeout 25 /usr/bin/python3 "$tools/finalize-owned-defaults.py" "$bundle_id" > "$results/defaults-finalized.json" 2>&1 || status=1
  printf '%s\n' "$status" > "$results/qa-exit-code.txt"
  return_status "$status"
  _wattson_cleanup
}
trap finish EXIT
printf 'bundleID=%s\nbundlePath=%s\nsourceCommit=%s\n' "$bundle_id" "$app" "$WATTSON_MODULES_SOURCE_COMMIT" > "$results/capture-provenance.txt"
mkdir -p "$app/Contents/MacOS" "$app/Contents/Resources"
for logo in AppLogoColor AppLogoClearLight AppLogoClearDark; do
  cp "$repo/design/icon/in-app-logo/$logo.png" "$app/Contents/Resources/$logo.png"
done
wattson_run /usr/bin/xcrun clang -mmacosx-version-min=12.0 -Wno-deprecated-declarations -c tests/visual/capture_glass_shadow.c -o "$run_dir/capture.o" > "$results/capture-build.log" 2>&1
wattson_run /usr/bin/xcrun swiftc Core/*.swift MenuBar/*.swift Popover/*.swift "$tools/capture-modules.swift" "$run_dir/capture.o" -D DEBUG -swift-version 5 -warnings-as-errors -import-objc-header tests/visual/capture_glass_shadow.h -framework AppKit -framework CoreGraphics -framework IOKit -o "$app/Contents/MacOS/ModulesProbe" >> "$results/capture-build.log" 2>&1
cat > "$app/Contents/Info.plist" <<EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
<key>CFBundleIdentifier</key><string>$bundle_id</string>
<key>CFBundleName</key><string>ModulesProbe</string>
<key>CFBundleExecutable</key><string>ModulesProbe</string>
<key>CFBundlePackageType</key><string>APPL</string>
<key>CFBundleShortVersionString</key><string>$(cat VERSION)</string>
<key>CFBundleVersion</key><string>$(cat VERSION)</string>
<key>LSUIElement</key><true/>
</dict></plist>
EOF
wattson_run /usr/bin/codesign --force --sign - "$app" > "$results/capture-sign.log" 2>&1
for contrast in 0 1; do
  scenario=settings
  output="$results/captures/contrast-$contrast"
  mkdir "$output"
  wattson_run_timeout 150 /usr/bin/env WATTSON_FORCE_REDUCE_MOTION=0 WATTSON_FORCE_REDUCE_TRANSPARENCY=0 WATTSON_FORCE_INCREASE_CONTRAST="$contrast" "$app/Contents/MacOS/ModulesProbe" "$output" "$scenario" > "$output/run.log" 2> "$output/run.err"
  [[ -s "$output/complete.json" ]] || exit 1
done
/usr/bin/python3 "$tools/verify-captures.py" "$results/captures" > "$results/capture-verification.json"
echo MODULES_NATIVE_CAPTURES_COMPLETED_VISUAL_REVIEW_PENDING
