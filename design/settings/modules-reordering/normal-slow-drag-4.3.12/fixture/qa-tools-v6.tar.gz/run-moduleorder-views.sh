#!/bin/bash
# VM-only focused module settings and view tests; never broad discovery on the host.
set -euo pipefail
repo="${WATTSON_MODULES_SOURCE_ROOT:?}"
tools="${WATTSON_MODULES_TOOLS_DIR:?}"
results="${WATTSON_MODULES_RESULTS:?}"
[[ "$HOME" == /Users/admin && "$(/usr/sbin/sysctl -n hw.model)" == VirtualMac* ]] || exit 65
source "$repo/scripts/lib/local_cleanup.sh"
wattson_cleanup_init
cd "$repo"
mkdir "$results/swift"
export WATTSON_MODULE_ORDER_TEST_RUN_ID="$(/usr/bin/uuidgen)"
owned_domains=("Wattson.SwiftTests.ModuleOrder.$WATTSON_MODULE_ORDER_TEST_RUN_ID" "Wattson.SwiftTests.ModuleOrderView.$WATTSON_MODULE_ORDER_TEST_RUN_ID")
for domain in "${owned_domains[@]}"; do
  [[ ! -e "$HOME/Library/Preferences/$domain.plist" && ! -L "$HOME/Library/Preferences/$domain.plist" ]] || exit 65
  wattson_cleanup_add_defaults "$domain"
  wattson_cleanup_add_container "$domain"
done
printf '%s\n' "${owned_domains[@]}" > "$results/swift/owned-domains.txt"
printf 'registeredBeforeAnyTestChild=true\nrunID=%s\n' "$WATTSON_MODULE_ORDER_TEST_RUN_ID" > "$results/swift/owner-hook.txt"
return_status() { return "$1"; }
finish() {
  local status=$?
  trap - EXIT
  trap '' HUP INT TERM
  set +e
  if [[ -n "${_WATTSON_RUNNER_PID:-}" ]]; then
    kill -TERM "$_WATTSON_RUNNER_PID" 2>/dev/null
    wait "$_WATTSON_RUNNER_PID" 2>/dev/null
    _WATTSON_RUNNER_PID=''
  fi
  for domain in "${owned_domains[@]}"; do
    wattson_run_timeout 20 /usr/bin/osascript -l JavaScript "$tools/synchronize-owned-defaults.js" "$domain" >> "$results/swift/domain-cleanup.log" 2>&1 || status=1
    wattson_run_timeout 25 /usr/bin/python3 "$tools/finalize-owned-defaults.py" "$domain" >> "$results/swift/domain-cleanup.log" 2>&1 || status=1
  done
  printf '%s\n' "$status" > "$results/swift/wrapper-exit-code.txt"
  return_status "$status"
  _wattson_cleanup
}
trap finish EXIT
scratch="$repo/.build/modules-view-tests.noindex"
[[ ! -e "$scratch" && ! -L "$scratch" ]] || exit 65
wattson_cleanup_add_dir "$scratch"
mkdir -p "$scratch"
dependencies="$scratch/xctest-dependencies"
wattson_run_timeout 30 /usr/bin/python3 "$tools/extract-xctest.py" "$dependencies" > "$results/swift/dependencies-verified.json"
frameworks="$dependencies/Library/Frameworks"
private_frameworks="$dependencies/Library/PrivateFrameworks"
libraries="$dependencies/usr/lib"
flags=(-Xswiftc -F -Xswiftc "$frameworks" -Xswiftc -F -Xswiftc "$private_frameworks"
       -Xswiftc -I -Xswiftc "$libraries" -Xswiftc -L -Xswiftc "$libraries"
       -Xlinker -F -Xlinker "$frameworks" -Xlinker -F -Xlinker "$private_frameworks"
       -Xlinker -L -Xlinker "$libraries"
       -Xlinker -rpath -Xlinker "$frameworks" -Xlinker -rpath -Xlinker "$private_frameworks"
       -Xlinker -rpath -Xlinker "$libraries")
printf 'method=SwiftPM build --build-tests then matched native XCTest runner\noriginalSwiftTestFailurePreserved=true\n' > "$results/swift/method.txt"
code=0
wattson_run_timeout 900 /usr/bin/xcrun swift build --build-tests --enable-xctest --disable-swift-testing --scratch-path "$scratch/build" "${flags[@]}" > "$results/swift/build.log" 2>&1 || code=$?
printf '%s\n' "$code" > "$results/swift/build-exit-code.txt"
if [[ "$code" != 0 ]]; then exit "$code"; fi
bundle="$scratch/build/arm64-apple-macosx/debug/WattsonPackageTests.xctest"
[[ -d "$bundle" ]] || exit 65
wattson_cleanup_add_app "$bundle"
wattson_cleanup_add_executable "$dependencies/Library/Xcode/Agents/xctest"
wattson_run_timeout 180 /usr/bin/env WATTSON_FORCE_REDUCE_MOTION=0 WATTSON_FORCE_REDUCE_TRANSPARENCY=0 DYLD_FRAMEWORK_PATH="$frameworks:$private_frameworks" DYLD_LIBRARY_PATH="$libraries" "$dependencies/Library/Xcode/Agents/xctest" -XCTest 'WattsonTests.ModuleOrderSettingsTests,WattsonTests.ModuleOrderViewTests' "$bundle" > "$results/swift/run.log" 2>&1 || code=$?
printf '%s\n' "$code" > "$results/swift/exit-code.txt"
if [[ "$code" == 0 ]]; then
  /usr/bin/python3 "$tools/verify-moduleorder-results.py" "$tools/expected-moduleorder-tests.json" "$results/swift/run.log" > "$results/swift/methods-verified.json"
fi
exit "$code"
