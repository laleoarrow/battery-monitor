#!/usr/bin/env python3
import hashlib
import json
from pathlib import Path
import sys

base = Path(sys.argv[1])
scenarios = ["contrast-0", "contrast-1"]
expected_styles = {style + "-" + theme for style in ["classic", "standard", "clear"] for theme in ["light", "dark"]}
records = []
for scenario in scenarios:
    manifest = json.loads((base / scenario / "complete.json").read_text())
    assert manifest["complete"] and manifest["scenario"] == "settings"
    assert manifest["captures"] == len(manifest["records"])
    styles = set()
    for row in manifest["records"]:
        styles.add("-".join(row["name"].split("-")[:2]))
        assert set(row["moduleOrder"]) == {"flow", "ring", "lanes", "history", "runtime"}
        if True:
            assert row["moduleRows"] == 5
        path = base / scenario / (row["name"] + ".png")
        raw = path.read_bytes()
        assert raw.startswith(b"\x89PNG\r\n\x1a\n") and len(raw) > 1000
        records.append({"path": str(path.relative_to(base)), "sha256": hashlib.sha256(raw).hexdigest()})
    assert styles == expected_styles
print(json.dumps({"allExpectedSurfacesCaptured": True, "screenshots": len(records), "records": records,
                  "visualReviewPending": True, "doesNotProveDragInteraction": True}, indent=2))
