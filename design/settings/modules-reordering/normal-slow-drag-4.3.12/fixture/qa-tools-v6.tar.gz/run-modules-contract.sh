#!/bin/bash
# Only the frozen native Settings contract; no full test suite or package work.
set -euo pipefail
repo="${WATTSON_MODULES_SOURCE_ROOT:?}"
tools="${WATTSON_MODULES_TOOLS_DIR:?}"
results="${WATTSON_MODULES_RESULTS:?}"
[[ "$HOME" == /Users/admin && "$(/usr/sbin/sysctl -n hw.model)" == VirtualMac* ]] || exit 65
source "$repo/scripts/lib/local_cleanup.sh"
wattson_cleanup_init
cd "$repo"
mkdir -p "$results/settings"
code=0
/usr/bin/python3 "$repo/scripts/lib/run_owned.py" --grace 90 --timeout 600 -- /usr/bin/env WATTSON_RUN_INTERACTION=1 /usr/bin/python3 "$tools/run-settings-contract.py" > "$results/settings/run.log" 2>&1 &
_WATTSON_RUNNER_PID=$!
wait "$_WATTSON_RUNNER_PID" || code=$?
_WATTSON_RUNNER_PID=''
printf '%s\n' "$code" > "$results/settings/exit-code.txt"
exit "$code"
