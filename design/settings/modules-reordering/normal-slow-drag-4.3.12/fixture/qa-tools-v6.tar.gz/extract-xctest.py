#!/usr/bin/env python3
"""Extract an exact inventoried dependency archive to a new task-owned directory."""
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import posixpath
import sys
import tarfile

share = Path('/Volumes/My Shared Files/modulesfinalui2')
archive_path = share / 'xctest-dependencies-v1.tar.gz'
manifest_path = share / 'xctest-dependencies-v1.json'
assert len(sys.argv) == 2
target = Path(sys.argv[1])
assert target.is_absolute() and not target.exists() and not target.is_symlink()
assert target.is_relative_to('/Users/admin/Project/Wattson-ModulesFinalUI2-QA/.build')
assert hashlib.sha256(archive_path.read_bytes()).hexdigest() == '7e666d05029a86a8dbcc60468fd1864af27662a3f16606a5516fde3c3164556e'
assert hashlib.sha256(manifest_path.read_bytes()).hexdigest() == '7f90d3ff85e0cd2a35ee4b53a02ffcba7b91295b45a57a2f59970d4b80a0ec68'
manifest = json.loads(manifest_path.read_text())
expected = {item['relativePath']: item for item in manifest['files']}
assert len(expected) == len(manifest['files'])
with tarfile.open(archive_path, 'r:gz') as archive:
    members = archive.getmembers()
    names = set()
    for member in members:
        name = PurePosixPath(member.name)
        assert not name.is_absolute() and '..' not in name.parts and str(name) == member.name
        assert member.name not in names
        names.add(member.name)
        assert member.isdir() or member.isfile() or member.issym()
        if member.isdir(): continue
        item = expected[member.name]
        if member.issym():
            assert member.linkname == item['symlinkTarget']
            assert not PurePosixPath(member.linkname).is_absolute()
            resolved = posixpath.normpath(posixpath.join(posixpath.dirname(member.name), member.linkname))
            assert resolved != '..' and not resolved.startswith('../')
        else:
            assert 'sha256' in item
    assert {m.name for m in members if not m.isdir()} == set(expected)
    target.mkdir()
    for member in members:
        path = target / member.name
        if member.isdir(): path.mkdir(parents=True, exist_ok=True)
        elif member.isfile():
            path.parent.mkdir(parents=True, exist_ok=True)
            data = archive.extractfile(member).read()
            assert hashlib.sha256(data).hexdigest() == expected[member.name]['sha256']
            with path.open('xb') as stream: stream.write(data)
            path.chmod(member.mode & 0o777)
    for member in members:
        if member.issym(): (target / member.name).symlink_to(member.linkname)
    for item in expected.values():
        path = target / item['relativePath']
        assert path.resolve().is_relative_to(target) and path.exists()
print(json.dumps({'archiveSHA256': manifest['sha256'], 'filesVerified': len(expected),
                  'ownedExtraction': str(target), 'systemDeveloperDirectoryModified': False}))
