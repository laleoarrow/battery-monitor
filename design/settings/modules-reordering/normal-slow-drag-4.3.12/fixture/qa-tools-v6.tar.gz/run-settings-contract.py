import json,os,pathlib,sys,unittest
repo=pathlib.Path(os.environ['WATTSON_MODULES_SOURCE_ROOT'])
results=pathlib.Path(os.environ['WATTSON_MODULES_RESULTS'])
sys.path.insert(0,str(repo/'tests'))
import local_runtime
original=local_runtime.TemporaryDirectory.__init__
def record_owned(self,*args,**kwargs):
    original(self,*args,**kwargs)
    with (results/'settings-owned-workspaces.jsonl').open('a') as stream:
        stream.write(json.dumps({'domain':self.defaults_suite,'workspace':self.name,'beforeAnyTestChild':True,'localRuntimeSource':str(pathlib.Path(local_runtime.__file__).resolve())})+'\n')
local_runtime.TemporaryDirectory.__init__=record_owned
import test_settings_window_contract
suite=unittest.defaultTestLoader.loadTestsFromModule(test_settings_window_contract)
result=unittest.TextTestRunner(verbosity=2).run(suite)
sys.exit(0 if result.wasSuccessful() else 1)
