#!/usr/bin/env python3
"""Read one frozen manual case. Exit 0=verified assertions, 1=failed, 78=unverified.

Usage: evaluate-manual-case.py CASE_DIR --case NAME --kind drop|noop|outside|close-preview
No files are changed. done markers, session exit codes and complete.json are ignored.
"""
import argparse
import hashlib
import json
import math
from pathlib import Path
import sys

DEFAULT = ["flow", "ring", "lanes", "history", "runtime"]
DROPPED = DEFAULT[1:] + DEFAULT[:1]
ROW_IDS = {"settings.modules.row." + name for name in DEFAULT}


def number(value):
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)


def read_frozen(path):
    if path.is_symlink() or not path.is_file():
        raise ValueError("Expected regular frozen evidence: " + str(path))
    before = path.stat()
    data = path.read_bytes()
    after = path.stat()
    if (before.st_ino, before.st_size, before.st_mtime_ns) != (after.st_ino, after.st_size, after.st_mtime_ns):
        raise ValueError("Evidence changed while reading: " + str(path))
    return data


def row_map(snapshot):
    rows = snapshot.get("rows", [])
    if not isinstance(rows, list) or not all(isinstance(row, dict) for row in rows):
        return {}
    result = {row.get("id"): row for row in rows}
    return result if len(rows) == 5 and set(result) == ROW_IDS else {}


def active_preview(snapshot, reordered):
    rows = row_map(snapshot)
    display = snapshot.get("displayOrder")
    return bool(rows) and any(number(row.get("alpha")) and row["alpha"] < 0.5 for row in rows.values()) \
        and snapshot.get("savedOrder") == DEFAULT and isinstance(display, list) \
        and sorted(display) == sorted(DEFAULT) and ((display != DEFAULT) if reordered else (display == DEFAULT)) \
        and snapshot.get("orderWrites") == 0 and snapshot.get("orderNotifications") == 0


def evaluate(args):
    state_bytes = read_frozen(args.directory / "state.json")
    history_bytes = read_frozen(args.directory / "history.jsonl")
    state = json.loads(state_bytes)
    history = [json.loads(line) for line in history_bytes.splitlines() if line.strip()]
    if not isinstance(state, dict) or not all(isinstance(item, dict) for item in history):
        raise ValueError("State/history must contain JSON objects")
    samples = [item for item in history if item.get("case") == args.case]
    missing, failed, checks = [], [], {}
    def need(condition, reason):
        if not condition:
            missing.append(reason)
        return condition
    def check(name, condition):
        checks[name] = bool(condition)
        if not condition:
            failed.append(name)

    need(state.get("case") == args.case, "Final state belongs to a different case")
    need(bool(samples), "No history samples for the requested case")
    case_samples = samples + [state]
    applied = lambda item: item.get("lastCommand", {}).get("result") == "applied" \
        and item.get("lastCommand", {}).get("case") == args.case
    need(applied(state) and any(applied(item) for item in samples), "Requested case reset was not recorded as applied")
    for field in ("syntheticInput", "directDragCallbacks"):
        need(all(field in item for item in case_samples), "Missing " + field + " declaration")
        check(field + "Absent", all(item.get(field) is False for item in case_samples))

    baseline = next((item for item in samples if applied(item) and item.get("savedOrder") == DEFAULT
        and item.get("displayOrder") == DEFAULT and item.get("orderWrites") == 0
        and item.get("orderNotifications") == 0 and item.get("observedOwnWindowEventCount") == 0), None)
    need(baseline is not None, "No pre-input default-order baseline")
    baseline = baseline or {}
    events = {json.dumps(event, sort_keys=True): event for item in case_samples
              for event in item.get("recentOwnWindowEvents", []) if isinstance(event, dict)}
    event_types = [event.get("type") for event in events.values()]
    need(1 in event_types and 6 in event_types, "Missing own-window mouse-down and mouse-drag evidence")
    previews = [item for item in samples if active_preview(item, args.kind != "noop")]
    need(bool(previews), "Required native preview was not observed; no drop/cancel conclusion")

    expected = DROPPED if args.kind == "drop" else DEFAULT
    writes = 1 if args.kind == "drop" else 0
    need(all(type(state.get(key)) is int for key in ("orderWrites", "orderNotifications", "visibilityNotifications")),
         "Missing or non-integer final persistence/notification counters")
    check("savedOrder", state.get("savedOrder") == expected)
    check("displayOrder", state.get("displayOrder") == expected)
    check("persistCount", state.get("orderWrites") == writes)
    check("notificationCount", state.get("orderNotifications") == writes)
    before_rows, after_rows = row_map(baseline), row_map(state)
    need(bool(before_rows) and bool(after_rows), "Missing five-row identity/alpha snapshots")
    need(all(row.get("objectIdentity") for row in list(before_rows.values()) + list(after_rows.values())),
         "Missing row object identity")
    check("rowIdentityRetained", bool(before_rows) and bool(after_rows) and
          all(before_rows[key].get("objectIdentity") == after_rows[key].get("objectIdentity") for key in before_rows))
    check("alphaRestored", bool(after_rows) and all(number(row.get("alpha")) and abs(row["alpha"] - 1) < 0.001 for row in after_rows.values()))
    visibility = baseline.get("visibility")
    need(isinstance(visibility, dict) and set(visibility) == set(DEFAULT), "Missing visibility baseline")
    check("visibilityUnchanged", visibility is not None and state.get("visibility") == visibility
          and state.get("visibilityNotifications") == 0)
    need(baseline.get("windowIdentity") is not None and state.get("windowIdentity") is not None, "Missing Settings window identity")
    check("windowIdentityRetained", baseline.get("windowIdentity") == state.get("windowIdentity"))

    close = state.get("closeOnPreviewEvidence", {})
    if args.kind == "close-preview":
        observed = close.get("observedPreview", {})
        need(bool(observed), "Missing close-on-preview observation")
        check("closeMechanism", close.get("mechanism") == "fixture-window.close-after-real-preview"
              and close.get("userCloseInput") is False and close.get("directDragCallbacks") is False)
        check("closeSawUncommittedPreview", observed.get("savedOrder") == DEFAULT
              and observed.get("displayOrder") != DEFAULT and sorted(observed.get("displayOrder", [])) == sorted(DEFAULT)
              and observed.get("orderWrites") == 0
              and any(number(alpha) and alpha < 0.5 for alpha in observed.get("rowAlpha", [])))
        check("closeReturned", close.get("closeCallReturned") is True)
        check("windowClosed", state.get("visible") is False)
        check("willCloseObserved", any(item.get("event") == "willClose"
              and number(item.get("elapsed")) and number(observed.get("elapsed"))
              and item["elapsed"] >= observed["elapsed"] for item in state.get("windowLifecycleEvents", [])))

    focus = {"baseline": baseline.get("firstResponder"), "firstPreview": previews[0].get("firstResponder") if previews else None,
             "final": state.get("firstResponder"), "assessment": "reported-only; drag handle may legitimately take focus; close may clear it"}
    focus["baselineUnchanged"] = focus["baseline"] == focus["final"] if focus["baseline"] is not None else None
    focus["previewUnchanged"] = focus["firstPreview"] == focus["final"] if focus["firstPreview"] is not None else None
    scroll = {"baseline": baseline.get("settingsScrollViews"), "final": state.get("settingsScrollViews")}
    scroll["assessment"] = "not-present" if scroll["baseline"] == [] and scroll["final"] == [] else \
        ("unverified" if scroll["baseline"] is None or scroll["final"] is None else
         ("retained" if scroll["baseline"] == scroll["final"] else "changed; inspect reported identities/origins"))
    if scroll["baseline"] is not None and scroll["final"] is not None:
        check("settingsScrollRetained", scroll["baseline"] == scroll["final"])
    else:
        need(False, "Missing Settings scroll-view snapshot")
    declarations_false = any(item.get(field) is True for item in case_samples for field in ("syntheticInput", "directDragCallbacks"))
    verdict = "failed" if declarations_false else ("unverified" if missing else ("failed" if failed else "passed"))
    report = {"schema": 1, "case": args.case, "kind": args.kind, "verdict": verdict,
        "scope": "Recorded manual drop/cancel assertions only; no History or Escape assertion. Session exit/done is not evidence of passing.",
        "inputs": {"stateSHA256": hashlib.sha256(state_bytes).hexdigest(), "historySHA256": hashlib.sha256(history_bytes).hexdigest()},
        "style": state.get("style"), "reduceMotion": state.get("reduceMotion"),
        "actual": {key: state.get(key) for key in ("savedOrder", "displayOrder", "orderWrites", "orderNotifications", "visibility", "rows")},
        "expectedOrder": expected, "expectedWritesAndNotifications": writes,
        "previewSamples": len(previews), "mouseDownEvents": event_types.count(1), "mouseDraggedEvents": event_types.count(6),
        "checks": checks, "unverifiedReasons": missing, "failedAssertions": failed,
        "focus": focus, "settingsScroll": scroll, "closeOnPreviewEvidence": close if args.kind == "close-preview" else None}
    print(json.dumps(report, indent=2, sort_keys=True))
    return {"passed": 0, "failed": 1, "unverified": 78}[verdict]


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("directory", type=Path)
    parser.add_argument("--case", required=True)
    parser.add_argument("--kind", required=True, choices=("drop", "noop", "outside", "close-preview"))
    args = parser.parse_args()
    try:
        sys.exit(evaluate(args))
    except (OSError, ValueError, TypeError, KeyError, AttributeError) as error:
        print(json.dumps({"verdict": "unverified", "case": args.case, "error": str(error)}, indent=2))
        sys.exit(78)
