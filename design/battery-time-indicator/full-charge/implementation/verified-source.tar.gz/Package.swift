// swift-tools-version: 6.1
import PackageDescription

let package = Package(
    name: "Wattson",
    platforms: [
        .macOS(.v12),
    ],
    products: [
        .executable(name: "Wattson", targets: ["Wattson"]),
        .executable(name: "wattson-helper", targets: ["WattsonHelper"]),
    ],
    targets: [
        .executableTarget(
            name: "Wattson",
            path: ".",
            exclude: [
                ".agent",
                ".codex",
                ".github",
                "AGENTS.md",
                "BatteryPowerApp.entitlements",
                "BatteryPowerWidgetExtension.entitlements",
                "BatteryPowerWidgetExtension.swift",
                "BatteryPowerWidgetExtension.xcodeproj",
                "HANDOFF.md",
                "Helper",
                "HelperV5",
                "HelperV5Tests",
                "Packaging",
                "README.md",
                "Support",
                "SwiftTests",
                "TODO.md",
                "VERSION",
                "WidgetExtensionInfo.plist",
                "battery_monitor.py",
                "design",
                "design-qa.md",
                "dist",
                "docs",
                "script",
                "scripts",
                "tests",
                "website",
            ],
            sources: [
                "Core",
                "MenuBar",
                "Popover",
                "main.swift",
            ],
            linkerSettings: [
                .linkedFramework("AppKit"),
                .linkedFramework("CoreGraphics"),
                .linkedFramework("IOKit"),
            ]
        ),
        .target(
            name: "WattsonHelperV5Support",
            path: "HelperV5"
        ),
        .executableTarget(
            name: "WattsonHelper",
            dependencies: ["WattsonHelperV5Support"],
            path: "Helper",
            exclude: ["com.leoarrow.wattson.helper.plist"],
            sources: ["wattson-helper.swift"],
            linkerSettings: [
                .linkedFramework("IOKit"),
            ]
        ),
        .testTarget(
            name: "WattsonHelperV5SupportTests",
            dependencies: ["WattsonHelperV5Support"],
            path: "HelperV5Tests"
        ),
        .testTarget(
            name: "WattsonTests",
            dependencies: ["Wattson"],
            path: "SwiftTests",
            resources: [
                .copy("Fixtures"),
            ]
        ),
    ],
    swiftLanguageModes: [.v5]
)
