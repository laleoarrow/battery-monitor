#!/bin/bash
# Build the universal Wattson application and privileged helper.
set -euo pipefail
umask 022

export COPYFILE_DISABLE=1
export LC_ALL=C
export ZERO_AR_DATE=1

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
ROOT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
source "$SCRIPT_DIR/lib/local_cleanup.sh"
wattson_cleanup_init
VERSION_FILE="$ROOT_DIR/VERSION"
MIN_MACOS_VERSION="12.0"
APP_NAME="Wattson"
HELPER_LABEL="com.leoarrow.wattson.helper"
KEEP_BUILD=0
if [[ "$#" == 1 && "$1" == --keep-build ]]; then
    KEEP_BUILD=1
elif [[ "$#" != 0 ]]; then
    echo "usage: $0 [--keep-build]" >&2
    exit 2
fi
if [[ -n "${WATTSON_RELEASE_BUILD_ROOT:-}" ]]; then
    [[ "$KEEP_BUILD" == 0 ]] || { echo "--keep-build cannot use a caller-owned build root" >&2; exit 2; }
    BUILD_ROOT="$WATTSON_RELEASE_BUILD_ROOT"
    [[ -d "$BUILD_ROOT" && ! -L "$BUILD_ROOT" ]] || { echo "caller-owned build root is missing" >&2; exit 2; }
    BUILD_ROOT="$(cd "$BUILD_ROOT" && pwd -P)"
    case "$BUILD_ROOT/" in
        "$ROOT_DIR/.build/"*) ;;
        *) echo "caller-owned build root must be under the project .build directory" >&2; exit 2 ;;
    esac
else
    /bin/mkdir -p "$ROOT_DIR/.build/local.noindex"
    BUILD_ROOT="$(/usr/bin/mktemp -d "$ROOT_DIR/.build/local.noindex/release.XXXXXX")"
    wattson_cleanup_add_dir "$BUILD_ROOT"
fi
SWIFTPM_BUILD_DIR="$BUILD_ROOT/swiftpm"
ICON_BUILD_DIR="$BUILD_ROOT/icon-assets"
APP_DIR="$BUILD_ROOT/${APP_NAME}.app"
APP_EXECUTABLE="$APP_DIR/Contents/MacOS/$APP_NAME"
HELPER_EXECUTABLE="$BUILD_ROOT/$HELPER_LABEL"
BUILD_METADATA="$BUILD_ROOT/BUILD-METADATA.txt"

fail() {
    echo "build_release.sh: $*" >&2
    exit 1
}

[[ -f "$VERSION_FILE" ]] || fail "missing VERSION file"
APP_VERSION="$(/bin/cat "$VERSION_FILE")"
[[ "$APP_VERSION" =~ ^[0-9]+\.[0-9]+\.[0-9]+$ ]] \
    || fail "VERSION must contain one semantic version (x.y.z)"
BUILD_NUMBER="${WATTSON_BUILD_NUMBER:-$APP_VERSION}"
[[ "$BUILD_NUMBER" =~ ^[0-9]+(\.[0-9]+){0,2}$ ]] \
    || fail "WATTSON_BUILD_NUMBER must contain one to three dot-separated integers"

[[ -f "$ROOT_DIR/Package.swift" ]] || fail "missing Package.swift"
[[ -f "$ROOT_DIR/Packaging/AppInfo.plist" ]] || fail "missing Packaging/AppInfo.plist"
[[ -f "$ROOT_DIR/design/icon/WattsonGlass.icon/icon.json" ]] \
    || fail "missing native WattsonGlass.icon source"

# Caller-owned roots are shared by later packaging stages; never delete them.
[[ -z "$(/bin/ls -A "$BUILD_ROOT")" ]] || fail "build root must be empty"

echo "Building Wattson $APP_VERSION ($BUILD_NUMBER) for arm64 and x86_64..."
# Multiple --arch values force SwiftPM onto the Xcode build service even when
# native is requested. Build each slice natively, then combine before signing.
APP_SLICES=()
HELPER_SLICES=()
for architecture in arm64 x86_64; do
    BUILD_ARGUMENTS=(
        --package-path "$ROOT_DIR"
        --scratch-path "$SWIFTPM_BUILD_DIR/$architecture"
        --configuration release
        --build-system native
        --arch "$architecture"
    )
    wattson_run /usr/bin/swift build "${BUILD_ARGUMENTS[@]}"
    BIN_PATH_FILE="$BUILD_ROOT/bin-path-$architecture.txt"
    wattson_run /usr/bin/swift build "${BUILD_ARGUMENTS[@]}" \
        --show-bin-path > "$BIN_PATH_FILE"
    BIN_DIR="$(/bin/cat "$BIN_PATH_FILE")"
    [[ -x "$BIN_DIR/Wattson" ]] || fail "SwiftPM did not produce $BIN_DIR/Wattson"
    [[ -x "$BIN_DIR/wattson-helper" ]] || fail "SwiftPM did not produce $BIN_DIR/wattson-helper"
    APP_SLICES+=("$BIN_DIR/Wattson")
    HELPER_SLICES+=("$BIN_DIR/wattson-helper")
done
BUILT_APP_EXECUTABLE="$BUILD_ROOT/universal/Wattson"
BUILT_HELPER_EXECUTABLE="$BUILD_ROOT/universal/wattson-helper"
/bin/mkdir "$BUILD_ROOT/universal"
wattson_run /usr/bin/xcrun lipo -create "${APP_SLICES[@]}" -output "$BUILT_APP_EXECUTABLE"
wattson_run /usr/bin/xcrun lipo -create "${HELPER_SLICES[@]}" -output "$BUILT_HELPER_EXECUTABLE"

verify_universal_binary() {
    local binary_path="$1"
    local architecture
    local build_info

    for architecture in arm64 x86_64; do
        /usr/bin/xcrun lipo "$binary_path" -verify_arch "$architecture" \
            || fail "binary is missing $architecture: $binary_path"
        build_info="$(/usr/bin/xcrun vtool -arch "$architecture" -show-build "$binary_path")"
        /usr/bin/grep -Eq "minos[[:space:]]+$MIN_MACOS_VERSION([[:space:]]|$)" <<< "$build_info" \
            || fail "$architecture slice does not target macOS $MIN_MACOS_VERSION: $binary_path"
    done
}

verify_universal_binary "$BUILT_APP_EXECUTABLE"
verify_universal_binary "$BUILT_HELPER_EXECUTABLE"

/bin/mkdir -p \
    "$APP_DIR/Contents/MacOS" \
    "$APP_DIR/Contents/Resources"
/usr/bin/ditto --noextattr --noqtn "$BUILT_APP_EXECUTABLE" "$APP_EXECUTABLE"
/usr/bin/ditto --noextattr --noqtn "$BUILT_HELPER_EXECUTABLE" "$HELPER_EXECUTABLE"
/bin/cp "$ROOT_DIR/Packaging/AppInfo.plist" "$APP_DIR/Contents/Info.plist"
/bin/cp "$ROOT_DIR/design/icon/AppIcon.icns" "$APP_DIR/Contents/Resources/AppIcon.icns"
/usr/bin/sips -s format png "$ROOT_DIR/design/icon/AppIcon.icns" \
    --out "$APP_DIR/Contents/Resources/AppIconSettings.png" >/dev/null
for logo_resource in AppLogoColor.png AppLogoClearLight.png AppLogoClearDark.png; do
    /bin/cp "$ROOT_DIR/design/icon/in-app-logo/$logo_resource" \
        "$APP_DIR/Contents/Resources/$logo_resource"
done
for dock_logo_resource in AppDockLogoColor.png AppDockLogoClearLight.png AppDockLogoClearDark.png; do
    /bin/cp "$ROOT_DIR/design/icon/dock-logo/$dock_logo_resource" \
        "$APP_DIR/Contents/Resources/$dock_logo_resource"
done

/bin/mkdir -p "$ICON_BUILD_DIR"
wattson_run /usr/bin/xcrun actool "$ROOT_DIR/design/icon/WattsonGlass.icon" \
    --compile "$ICON_BUILD_DIR" \
    --platform macosx --target-device mac \
    --minimum-deployment-target "$MIN_MACOS_VERSION" \
    --app-icon WattsonGlass --standalone-icon-behavior all \
    --output-partial-info-plist "$ICON_BUILD_DIR/icon-info.plist" \
    --output-format human-readable-text --warnings --notices
/bin/cp "$ICON_BUILD_DIR/Assets.car" "$ICON_BUILD_DIR/WattsonGlass.icns" \
    "$APP_DIR/Contents/Resources/"
# The template selects WattsonGlass for both the layered system icon and its
# static fallback. Keep the classic resources for Settings, not a bundle rewrite.
/usr/bin/plutil -replace CFBundleShortVersionString -string "$APP_VERSION" \
    "$APP_DIR/Contents/Info.plist"
/usr/bin/plutil -replace CFBundleVersion -string "$BUILD_NUMBER" \
    "$APP_DIR/Contents/Info.plist"
/usr/bin/plutil -lint "$APP_DIR/Contents/Info.plist" >/dev/null
/bin/chmod 755 "$APP_EXECUTABLE" "$HELPER_EXECUTABLE"
/usr/bin/xattr -cr "$APP_DIR" "$HELPER_EXECUTABLE"

APP_SIGN_IDENTITY="${WATTSON_DEVELOPER_ID_APP:-}"
if [[ -n "$APP_SIGN_IDENTITY" && "$APP_SIGN_IDENTITY" != "-" ]]; then
    SIGNING_MODE="developer-id"
    SIGN_ARGUMENTS=(
        --force
        --timestamp
        --options runtime
        --sign "$APP_SIGN_IDENTITY"
    )
else
    SIGNING_MODE="ad-hoc"
    SIGN_ARGUMENTS=(--force --sign -)
fi

/usr/bin/codesign \
    "${SIGN_ARGUMENTS[@]}" \
    --identifier "$HELPER_LABEL" \
    "$HELPER_EXECUTABLE"
/usr/bin/codesign \
    "${SIGN_ARGUMENTS[@]}" \
    --entitlements "$ROOT_DIR/BatteryPowerApp.entitlements" \
    "$APP_DIR"
/usr/bin/codesign --verify --strict "$HELPER_EXECUTABLE"
/usr/bin/codesign --verify --deep --strict "$APP_DIR"

{
    printf 'version=%s\n' "$APP_VERSION"
    printf 'build_number=%s\n' "$BUILD_NUMBER"
    printf 'architectures=arm64,x86_64\n'
    printf 'minimum_macos=%s\n' "$MIN_MACOS_VERSION"
    printf 'app_signature=%s\n' "$SIGNING_MODE"
    printf 'helper_signature=%s\n' "$SIGNING_MODE"
} > "$BUILD_METADATA"

if [[ -z "${WATTSON_RELEASE_BUILD_ROOT:-}" ]]; then
    WATTSON_RELEASE_BUILD_ROOT="$BUILD_ROOT" \
        wattson_run_script "$SCRIPT_DIR/verify_release.sh" --build-only
fi
if [[ "$KEEP_BUILD" == 1 ]]; then
    RETAINED_ROOT="$ROOT_DIR/.build/release"
    wattson_unregister_app "$RETAINED_ROOT/$APP_NAME.app"
    /bin/rm -rf -- "$RETAINED_ROOT"
    /bin/mv "$BUILD_ROOT" "$RETAINED_ROOT"
    BUILD_ROOT="$RETAINED_ROOT"
    APP_DIR="$BUILD_ROOT/$APP_NAME.app"
    HELPER_EXECUTABLE="$BUILD_ROOT/$HELPER_LABEL"
fi

echo "Built universal app: $APP_DIR"
echo "Built universal helper: $HELPER_EXECUTABLE"
if [[ "$SIGNING_MODE" == "ad-hoc" ]]; then
    echo "Signing: ad-hoc community build (not notarized)"
else
    echo "Signing: Developer ID application identity configured"
    echo "Notarization status: no (build_release.sh does not submit artifacts)"
fi
if [[ -z "${WATTSON_RELEASE_BUILD_ROOT:-}" && "$KEEP_BUILD" == 0 ]]; then
    echo "Build verified; disposable app and build files are removed on exit."
fi
