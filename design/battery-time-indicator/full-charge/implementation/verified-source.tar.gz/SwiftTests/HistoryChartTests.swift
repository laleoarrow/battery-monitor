import Foundation
import XCTest
@testable import Wattson

final class HistoryChartTests: XCTestCase {
    func testNativeHandleLoopCannotBeReusedAsMonotoneHistory() {
        let old = HistoryChartGeometry(samples: [20, 40, 30],
            timing: .init(sampledAt: [0, 2, 4], referenceTime: 4), ceiling: 50)
        let target = HistoryChartGeometry(samples: [20, 40, 30, 35],
            timing: .init(sampledAt: [0, 2, 4, 6], referenceTime: 6), ceiling: 50)
        var shown = old.segments
        let first = shown[0], width = first.end.x - first.start.x
        shown[0] = .init(start: first.start,
            control1: .init(x: first.start.x + 4 * width, y: first.control1.y),
            control2: .init(x: first.start.x - 3 * width, y: first.control2.y), end: first.end)
        XCTAssertFalse(shown[0].isXMonotone)
        XCTAssertNil(target.alignedStart(from: old, presentedSegments: shown,
            fraction: 2 / 120, oldCeiling: 50, newCeiling: 50))
    }

    func testPresentationCubicInvertsNonuniformControlX() {
        let curve = HistoryChartGeometry.Cubic(
            start: .init(x: 325.2666667, y: 40.689665),
            control1: .init(x: 327.0888889, y: 40.689665),
            control2: .init(x: 328.0012630, y: 6.7624353),
            end: .init(x: 330.7333333, y: -27.2))
        for step in 0...100 {
            let t = Double(step) / 100, u = 1 - t
            let x = u * u * u * curve.start.x + 3 * u * u * t * curve.control1.x
                + 3 * u * t * t * curve.control2.x + t * t * t * curve.end.x
            XCTAssertEqual(curve.value(atX: x), curve.value(at: t), accuracy: 1e-8)
        }
    }

    func testBlendedHeadUsesAllFourActualCoordinates() throws {
        let previous = HistoryChartGeometry(samples: [20, 60, 90],
            timing: .init(sampledAt: [0, 2, 4], referenceTime: 4), ceiling: 150)
        let target = HistoryChartGeometry(samples: [20, 60, 90, 140],
            timing: .init(sampledAt: [0, 2, 4, 6], referenceTime: 6), ceiling: 200)
        let presented = previous.segments.map { curve in
            let width = curve.end.x - curve.start.x
            return HistoryChartGeometry.Cubic(start: curve.start,
                control1: .init(x: curve.start.x + width * 0.17, y: curve.control1.y),
                control2: .init(x: curve.start.x + width * 0.58, y: curve.control2.y), end: curve.end)
        }
        let start = try XCTUnwrap(target.alignedStart(from: previous, presentedSegments: presented,
            fraction: 2 / 120, oldCeiling: 150, newCeiling: 200))
        for q in [0.0, 0.13, 0.37, 0.69, 1.0] {
            for (a, b) in zip(start.segments, target.segments) {
                func mix(_ x: HistoryChartGeometry.Point, _ y: HistoryChartGeometry.Point) -> HistoryChartGeometry.Point {
                    .init(x: x.x * (1 - q) + y.x * q, y: x.y * (1 - q) + y.y * q)
                }
                let p = [mix(a.start, b.start), mix(a.control1, b.control1),
                         mix(a.control2, b.control2), mix(a.end, b.end)]
                for t in [0.07, 0.23, 0.51, 0.82, 0.97] {
                    let u = 1 - t
                    let x = u * u * u * p[0].x + 3 * u * u * t * p[1].x
                        + 3 * u * t * t * p[2].x + t * t * t * p[3].x
                    let y = u * u * u * p[0].y + 3 * u * u * t * p[1].y
                        + 3 * u * t * t * p[2].y + t * t * t * p[3].y
                    XCTAssertEqual(try XCTUnwrap(target.value(at: x, blendingFrom: start, progress: q)),
                                   y, accuracy: 1e-9)
                }
            }
        }
    }

    private func geometry(_ values: [Double], times: [Double]? = nil, now: Double? = nil) -> HistoryChartGeometry {
        let times = times ?? values.indices.map { Double($0) * 2 }
        return HistoryChartGeometry(samples: values,
            timing: .init(sampledAt: times, referenceTime: now ?? times.last ?? 0), ceiling: 100)
    }

    func testSingleSampleDoesNotInventAHistory() {
        let graph = geometry([25])
        XCTAssertEqual(graph.points.count, 1)
        XCTAssertTrue(graph.segments.isEmpty)
        XCTAssertEqual(graph.points[0].x, 1)
    }

    func testShortHistoryUsesItsRealDuration() {
        let graph = geometry([10, 20, 30], times: [10, 12, 14])
        XCTAssertEqual(graph.points[0].x, 1 - 4.0 / 120, accuracy: 1e-12)
        XCTAssertEqual(graph.points[2].x, 1)
    }

    func testIrregularSamplingPreservesTimeSpacing() {
        let graph = geometry([10, 20, 30], times: [0, 1, 5])
        XCTAssertEqual((graph.points[2].x - graph.points[1].x) /
            (graph.points[1].x - graph.points[0].x), 4, accuracy: 1e-10)
    }

    func testPeakAndTroughHaveHorizontalTangents() {
        let graph = geometry([10, 90, 10, 70])
        XCTAssertEqual(graph.segments.count, 3)
        XCTAssertEqual(graph.segments[0].control2.y, 0.9, accuracy: 1e-12)
        XCTAssertEqual(graph.segments[1].control1.y, 0.9, accuracy: 1e-12)
        XCTAssertEqual(graph.segments[1].control2.y, 0.1, accuracy: 1e-12)
        XCTAssertEqual(graph.segments[2].control1.y, 0.1, accuracy: 1e-12)
    }

    func testCurvePassesThroughEverySample() {
        let graph = geometry([10, 58.1, 20, 25])
        for (index, segment) in graph.segments.enumerated() {
            XCTAssertEqual(segment.start, graph.points[index])
            XCTAssertEqual(segment.end, graph.points[index + 1])
            XCTAssertEqual(segment.value(at: 0), segment.start.y, accuracy: 1e-12)
            XCTAssertEqual(segment.value(at: 1), segment.end.y, accuracy: 1e-12)
        }
        XCTAssertEqual(graph.points.map(\.y).max()!, 0.581, accuracy: 1e-12)
    }

    func testPlateauStaysFlat() {
        let graph = geometry([0, 40, 40, 40, 0])
        for segment in graph.segments[1...2] {
            for t in stride(from: 0.0, through: 1.0, by: 0.05) {
                XCTAssertEqual(segment.value(at: t), 0.4, accuracy: 1e-12)
            }
        }
    }

    func testNoOvershootAcrossDeterministicStressSequences() {
        var state: UInt64 = 719
        for _ in 0..<300 {
            var times: [Double] = [0]
            var values: [Double] = []
            for index in 0..<60 {
                state = state &* 6364136223846793005 &+ 1
                values.append(Double((state >> 32) % 10001) / 100)
                if index > 0 { times.append(times.last! + 0.5 + Double(state % 500) / 100) }
            }
            let graph = geometry(values, times: times)
            for s in graph.segments {
                let lo = min(s.start.y, s.end.y), hi = max(s.start.y, s.end.y)
                for t in stride(from: 0.0, through: 1.0, by: 0.025) {
                    let y = s.value(at: t)
                    XCTAssertTrue(y.isFinite && y >= lo - 1e-12 && y <= hi + 1e-12)
                }
            }
        }
    }

    func testInternalTangentsMatchForUnequalTimeSteps() {
        let graph = geometry([10, 20, 65, 80], times: [0, 0.5, 4, 6])
        for index in 1..<graph.segments.count {
            let a = graph.segments[index - 1], b = graph.segments[index]
            let incoming = (a.end.y - a.control2.y) / (a.end.x - a.control2.x)
            let outgoing = (b.control1.y - b.start.y) / (b.control1.x - b.start.x)
            XCTAssertEqual(incoming, outgoing, accuracy: 1e-9)
        }
    }

    func testGapDoesNotBecomeASmoothInventedReading() {
        let graph = geometry([10, 15, 80, 90], times: [0, 2, 20, 22])
        XCTAssertEqual(graph.runs.count, 2)
        XCTAssertEqual(graph.segments.count, 2)
    }

    func testInvalidTimingFailsClosed() {
        for times in [[0, 0], [2, 1], [0, Double.nan], [0]] {
            XCTAssertTrue(geometry([10, 20], times: times, now: 4).points.isEmpty)
        }
        XCTAssertTrue(geometry([10, 20], times: [0, 2], now: 1).points.isEmpty)
    }

    func testDepartingPointCanBeClippedDrawingContextOnly() {
        let timing = HistoryChartTiming(sampledAt: [0, 2, 4], referenceTime: 121)
        let normal = HistoryChartGeometry(samples: [10, 20, 30], timing: timing, ceiling: 100)
        let drawing = HistoryChartGeometry(samples: [10, 20, 30], timing: timing, ceiling: 100,
                                           leadingContextCount: 1)
        XCTAssertEqual(normal.points.count, 2)
        XCTAssertEqual(drawing.points.count, 3)
        XCTAssertLessThan(drawing.points[0].x, 0)
        XCTAssertEqual(Array(drawing.points.dropFirst()), normal.points)
        XCTAssertEqual(drawing.points.last, normal.points.last)
    }

    func testDepartingPeakRetainsItsRawHeightWhenTheViewportScaleContracts() {
        let graph = HistoryChartGeometry(samples: [100, 10, 20],
            timing: .init(sampledAt: [0, 2, 4], referenceTime: 121), ceiling: 40,
            leadingContextCount: 1)
        XCTAssertEqual(graph.points[0].y, 2.5)
        XCTAssertLessThan(graph.points[0].x, 0)
        XCTAssertEqual(graph.points.dropFirst().map(\.y), [0.25, 0.5])
        for segment in graph.segments {
            for t in stride(from: 0.0, through: 1, by: 0.05) {
                XCTAssertGreaterThanOrEqual(segment.value(at: t), min(segment.start.y, segment.end.y) - 1e-12)
                XCTAssertLessThanOrEqual(segment.value(at: t), max(segment.start.y, segment.end.y) + 1e-12)
            }
        }
    }

    func testNonFiniteSampleBreaksTheLine() {
        let graph = geometry([10, 20, .nan, 40, 50])
        XCTAssertEqual(graph.runs.count, 2)
        XCTAssertEqual(graph.segments.count, 2)
    }

    func testScaleHoldsSmallChangesAndOnlyShrinksAfterDelay() {
        var scale = HistoryChartScale()
        let first = scale.update(peak: 58.1, at: 0)
        XCTAssertGreaterThanOrEqual(first, 58.1 * 1.14)
        XCTAssertEqual(scale.update(peak: 58.2, at: 2), first)
        XCTAssertEqual(scale.update(peak: 20, at: 4), first)
        XCTAssertEqual(scale.update(peak: 20, at: 11.99), first)
        XCTAssertLessThan(scale.update(peak: 20, at: 12), first)
    }

    func testScaleExpansionAndReset() {
        var scale = HistoryChartScale()
        _ = scale.update(peak: 10, at: 0)
        XCTAssertGreaterThanOrEqual(scale.update(peak: 200, at: 2), 200 * 1.14)
        scale.reset()
        XCTAssertEqual(scale.update(peak: 0, at: 3), 8)
        XCTAssertTrue(scale.update(peak: Double.greatestFiniteMagnitude, at: 4).isFinite)
    }

    func testScaleRecoveryCancelsPendingShrink() {
        var scale = HistoryChartScale()
        let initial = scale.update(peak: 90, at: 0)
        _ = scale.update(peak: 10, at: 2)
        _ = scale.update(peak: 90, at: 9)
        XCTAssertEqual(scale.update(peak: 10, at: 11), initial)
        XCTAssertEqual(scale.update(peak: 10, at: 18.99), initial)
        XCTAssertLessThan(scale.update(peak: 10, at: 19), initial)
    }

    func testScrollRequiresMatchingRetainedSamples() {
        let old = HistoryChartTiming(sampledAt: [0, 2, 4], referenceTime: 4)
        let next = HistoryChartTiming(sampledAt: [2, 4, 6], referenceTime: 6)
        XCTAssertEqual(HistoryChartTiming.scrollFraction(from: old, samples: [10, 20, 30],
            to: next, samples: [20, 30, 40])!, 2.0 / 120, accuracy: 1e-12)
        XCTAssertNil(HistoryChartTiming.scrollFraction(from: old, samples: [10, 20, 30],
            to: next, samples: [99, 30, 40]))
        XCTAssertNil(HistoryChartTiming.scrollFraction(from: old, samples: [10, 20, 30],
            to: .init(sampledAt: [20, 22], referenceTime: 22), samples: [1, 2]))
        XCTAssertNil(HistoryChartTiming.scrollFraction(from: old, samples: [10, 20, 30],
            to: old, samples: [10, 20, 30]))
    }

    func testHistoryKeepsCadenceReferenceUntilSamplingGap() {
        var now = 0.0
        let history = PowerHistory(clock: { now })
        history.append(10)
        now = 2
        history.append(20)
        let initial = history.chartPresentation
        let count = history.presentationMaterializationCountForTest

        now = 8
        XCTAssertEqual(history.chartPresentation.timing, initial.timing)
        now = 8.001
        let paused = history.chartPresentation
        XCTAssertEqual(paused.samples, initial.samples)
        XCTAssertEqual(paused.timing.sampledAt, initial.timing.sampledAt)
        XCTAssertEqual(paused.timing.referenceTime, now)
        XCTAssertEqual(history.presentationMaterializationCountForTest, count)
    }

    func testScrollRejectsMoreDeparturesThanRendererCanPreserve() {
        let old = HistoryChartTiming(sampledAt: [0, 2, 4, 6], referenceTime: 6)
        let next = HistoryChartTiming(sampledAt: [4, 6, 8], referenceTime: 8)
        XCTAssertNil(HistoryChartTiming.scrollFraction(from: old, samples: [10, 20, 30, 40],
            to: next, samples: [30, 40, 50]))
    }

    func testScrollRequiresPreviousEndpointAtTheRightEdge() {
        let next = HistoryChartTiming(sampledAt: [0, 2, 4], referenceTime: 4)
        XCTAssertNil(HistoryChartTiming.scrollFraction(
            from: .init(sampledAt: [0, 2], referenceTime: 3), samples: [10, 20],
            to: next, samples: [10, 20, 30]))
        XCTAssertNil(HistoryChartTiming.scrollFraction(
            from: .init(sampledAt: [0, 2], referenceTime: 1.99), samples: [10, 20],
            to: next, samples: [10, 20, 30]))
        XCTAssertEqual(HistoryChartTiming.scrollFraction(
            from: .init(sampledAt: [0, 2], referenceTime: 2), samples: [10, 20],
            to: next, samples: [10, 20, 30]), 2.0 / 120)
        XCTAssertEqual(HistoryChartTiming.scrollFraction(
            from: .init(sampledAt: [0, 2], referenceTime: 2.05), samples: [10, 20],
            to: next, samples: [10, 20, 30]), (4 - 2.05) / 120)
    }

    func testViewportMatchesStationaryAndAgingHistoryWithoutInventingReadings() throws {
        let old = HistoryChartTiming(sampledAt: [0, 2, 4], referenceTime: 4)
        let values = [10.0, 20, 30]
        XCTAssertEqual(HistoryChartTiming.viewportFraction(from: old, samples: values,
            to: old, samples: values), 0)
        XCTAssertEqual(HistoryChartTiming.viewportFraction(from: old, samples: values,
            to: .init(sampledAt: old.sampledAt, referenceTime: 6), samples: values), 2.0 / 120)
        XCTAssertNil(HistoryChartTiming.viewportFraction(from: old, samples: values,
            to: .init(sampledAt: [0, 2, 11], referenceTime: 11), samples: values))
        XCTAssertNil(HistoryChartTiming.viewportFraction(from: old, samples: values,
            to: old, samples: [10, 99, 30]))
    }

    func testViewportStartPreservesVisibleAnchorsAndControlsAcrossScaleChanges() throws {
        for (oldCeiling, newCeiling, shownScale) in [(40.0, 100.0, 1.0), (100, 40, 1.0), (100, 40, 1.8)] {
            let old = HistoryChartGeometry(samples: [10, 20, 30],
                timing: .init(sampledAt: [0, 2, 4], referenceTime: 4), ceiling: oldCeiling)
            let target = HistoryChartGeometry(samples: [10, 20, 30, 15],
                timing: .init(sampledAt: [0, 2, 4, 6], referenceTime: 6), ceiling: newCeiling)
            func shown(_ p: HistoryChartGeometry.Point) -> HistoryChartGeometry.Point {
                .init(x: p.x + 0.01, y: p.y * shownScale)
            }
            let presented = old.segments.map { HistoryChartGeometry.Cubic(start: shown($0.start),
                control1: shown($0.control1), control2: shown($0.control2), end: shown($0.end)) }
            let start = try XCTUnwrap(target.alignedStart(from: old, presentedSegments: presented,
                fraction: 2.0 / 120, oldCeiling: oldCeiling, newCeiling: newCeiling))
            for (actual, expected) in zip(start.segments, presented) {
                XCTAssertEqual(actual.start, expected.start)
                XCTAssertEqual(actual.control1, expected.control1)
                XCTAssertEqual(actual.control2, expected.control2)
                XCTAssertEqual(actual.end, expected.end)
            }
            XCTAssertGreaterThan(try XCTUnwrap(start.points.last).x, 1)
            XCTAssertEqual(start.segmentIDs, target.segmentIDs)
        }
    }

    func testViewportStartRejectsInvalidPresentationAndTiming() {
        let old = HistoryChartGeometry(samples: [10, 20],
            timing: .init(sampledAt: [0, 2], referenceTime: 2), ceiling: 40)
        let target = HistoryChartGeometry(samples: [10, 20, 30],
            timing: .init(sampledAt: [0, 2, 4], referenceTime: 4), ceiling: 40)
        for fraction in [-1.0, .nan, .infinity, 7.0 / 120] {
            XCTAssertNil(target.alignedStart(from: old, presentedSegments: old.segments,
                fraction: fraction, oldCeiling: 40, newCeiling: 40))
        }
        XCTAssertNil(target.alignedStart(from: old, presentedSegments: [],
            fraction: 2.0 / 120, oldCeiling: 40, newCeiling: 40))
        XCTAssertNil(target.alignedStart(from: old, presentedSegments: old.segments,
            fraction: 2.0 / 120, oldCeiling: 0, newCeiling: 40))
        let bad = old.segments.map { HistoryChartGeometry.Cubic(start: $0.start,
            control1: .init(x: .nan, y: 0), control2: $0.control2, end: $0.end) }
        XCTAssertNil(target.alignedStart(from: old, presentedSegments: bad,
            fraction: 2.0 / 120, oldCeiling: 40, newCeiling: 40))
    }

    func testAllZeroViewportRetainsItsBaselineWhenANewPeakAppears() throws {
        let old = HistoryChartGeometry(samples: [0, 0, 0],
            timing: .init(sampledAt: [0, 2, 4], referenceTime: 4), ceiling: 8)
        let target = HistoryChartGeometry(samples: [0, 0, 0, 100],
            timing: .init(sampledAt: [0, 2, 4, 6], referenceTime: 6), ceiling: 150)
        let start = try XCTUnwrap(target.alignedStart(from: old, presentedSegments: old.segments,
            fraction: 2.0 / 120, oldCeiling: 8, newCeiling: 150))
        XCTAssertEqual(Array(start.points.prefix(3)).map(\.y), [0, 0, 0])
        XCTAssertGreaterThan(start.points.last!.x, 1)
        XCTAssertEqual(start.segments.last!.end.y, 100 / 8)
        XCTAssertLessThanOrEqual(start.segments.last!.control1.y, 100 / 8)
        XCTAssertLessThanOrEqual(start.segments.last!.control2.y, 100 / 8)
    }

    func testAlignedControlsPreserveTheActuallyDisplayedFormerTerminalCubic() throws {
        let old = HistoryChartGeometry(samples: [0, 0, 100],
            timing: .init(sampledAt: [0, 2, 4], referenceTime: 4), ceiling: 200)
        let target = HistoryChartGeometry(samples: [0, 0, 100, 150],
            timing: .init(sampledAt: [0, 2, 4, 6], referenceTime: 6), ceiling: 200)
        let start = try XCTUnwrap(target.alignedStart(from: old, presentedSegments: old.segments,
            fraction: 2.0 / 120, oldCeiling: 200, newCeiling: 200))
        XCTAssertEqual(try XCTUnwrap(start.value(at: 1 - 1.0 / 120)), 31.25 / 200, accuracy: 1e-10)
        XCTAssertEqual(try XCTUnwrap(target.value(at: 1 - 3.0 / 120)), 41.6666666667 / 200, accuracy: 1e-10)
        XCTAssertEqual(start.segmentIDs, target.segmentIDs)
        for (a, b) in zip(start.segments, old.segments) {
            XCTAssertEqual(a.start, b.start)
            XCTAssertEqual(a.end, b.end)
        }
    }

    func testAlignedControlsPreserveTheTailWhenANewSampleReversesTheSlope() throws {
        let old = HistoryChartGeometry(samples: [0, 0, 100],
            timing: .init(sampledAt: [0, 2, 4], referenceTime: 4), ceiling: 100)
        let target = HistoryChartGeometry(samples: [0, 0, 100, 0],
            timing: .init(sampledAt: [0, 2, 4, 6], referenceTime: 6), ceiling: 100)
        let start = try XCTUnwrap(target.alignedStart(from: old, presentedSegments: old.segments,
            fraction: 2.0 / 120, oldCeiling: 100, newCeiling: 100))
        XCTAssertEqual(try XCTUnwrap(start.value(at: 1 - 1.0 / 120)), 0.3125, accuracy: 1e-10)
        XCTAssertEqual(try XCTUnwrap(target.value(at: 1 - 3.0 / 120)), 0.5, accuracy: 1e-10)
    }

    func testSeveralDepartingContextPointsKeepTheirRawValuesAndTimestampPairs() {
        let graph = HistoryChartGeometry(samples: [100, 90, 80, 10],
            timing: .init(sampledAt: [0, 2, 4, 6], referenceTime: 124), ceiling: 40,
            leadingContextCount: 3)
        XCTAssertEqual(graph.points.map(\.y), [2.5, 2.25, 2, 0.25])
        XCTAssertEqual(graph.segmentIDs, [
            .init(startTime: 0, endTime: 2), .init(startTime: 2, endTime: 4), .init(startTime: 4, endTime: 6),
        ])
        XCTAssertEqual(graph.points[0].x, -4.0 / 120, accuracy: 1e-12)
    }

    func testRetargetedControlsUseThePresentationBlendRatherThanItsFinalTarget() throws {
        let original = HistoryChartGeometry(samples: [0, 0, 100],
            timing: .init(sampledAt: [0, 2, 4], referenceTime: 4), ceiling: 200)
        let current = HistoryChartGeometry(samples: [0, 0, 100, 150],
            timing: .init(sampledAt: [0, 2, 4, 6], referenceTime: 6), ceiling: 200)
        let currentStart = try XCTUnwrap(current.alignedStart(from: original,
            presentedSegments: original.segments, fraction: 2.0 / 120, oldCeiling: 200, newCeiling: 200))
        let next = HistoryChartGeometry(samples: [0, 0, 100, 150, 200],
            timing: .init(sampledAt: [0, 2, 4, 6, 8], referenceTime: 8), ceiling: 250)
        for progress in [0.25, 0.5, 0.9] {
            func mix(_ a: HistoryChartGeometry.Point, _ b: HistoryChartGeometry.Point) -> HistoryChartGeometry.Point {
                .init(x: a.x + (b.x - a.x) * progress, y: a.y + (b.y - a.y) * progress)
            }
            let presented = zip(currentStart.segments, current.segments).map { a, b in
                HistoryChartGeometry.Cubic(start: mix(a.start, b.start), control1: mix(a.control1, b.control1),
                    control2: mix(a.control2, b.control2), end: mix(a.end, b.end))
            }
            let start = try XCTUnwrap(next.alignedStart(from: current, presentedSegments: presented,
                fraction: 2.0 / 120, oldCeiling: 200, newCeiling: 250))
            XCTAssertEqual(start.segments[1].control2, presented[1].control2)
            XCTAssertNotEqual(start.segments[1].control2.y, current.segments[1].control2.y)
            for t in [0.0, 0.125, 0.5, 0.875, 1] {
                XCTAssertEqual(start.segments[1].value(at: t), presented[1].value(at: t), accuracy: 1e-12)
            }
        }
    }

    func testOnlyIdenticalRawTimestampPairsAndAnchorsCanSupplyControls() throws {
        let target = HistoryChartGeometry(samples: [0, 0, 100, 150],
            timing: .init(sampledAt: [0, 2, 4, 6], referenceTime: 6), ceiling: 200)
        let unrelated = HistoryChartGeometry(samples: [0, 0, 100],
            timing: .init(sampledAt: [100, 102, 104], referenceTime: 104), ceiling: 200)
        XCTAssertNil(target.alignedStart(from: unrelated, presentedSegments: unrelated.segments,
            fraction: 2.0 / 120, oldCeiling: 200, newCeiling: 200))
        let changed = HistoryChartGeometry(samples: [0, 0, 99],
            timing: .init(sampledAt: [0, 2, 4], referenceTime: 4), ceiling: 200)
        let start = try XCTUnwrap(target.alignedStart(from: changed, presentedSegments: changed.segments,
            fraction: 2.0 / 120, oldCeiling: 200, newCeiling: 200))
        XCTAssertEqual(start.segments[1].control2.y, target.segments[1].control2.y)
        XCTAssertEqual(start.segments[1].control2.x, target.segments[1].control2.x + 2.0 / 120, accuracy: 1e-12)
    }

    func testPresentationAnchorRoundingCannotDiscardMatchingRawSegmentControls() throws {
        let old = HistoryChartGeometry(samples: [0, 0, 100],
            timing: .init(sampledAt: [0, 2, 4], referenceTime: 4), ceiling: 200)
        let target = HistoryChartGeometry(samples: [0, 0, 100, 150],
            timing: .init(sampledAt: [0, 2, 4, 6], referenceTime: 6), ceiling: 200)
        func rounded(_ p: HistoryChartGeometry.Point) -> HistoryChartGeometry.Point {
            .init(x: Double(Float(p.x)), y: Double(Float(p.y)))
        }
        let shown = old.segments.map { HistoryChartGeometry.Cubic(start: rounded($0.start),
            control1: $0.control1, control2: $0.control2, end: rounded($0.end)) }
        let start = try XCTUnwrap(target.alignedStart(from: old, presentedSegments: shown,
            fraction: 2.0 / 120, oldCeiling: 200, newCeiling: 200))
        XCTAssertEqual(start.segments[1].control1, shown[1].control1)
        XCTAssertEqual(start.segments[1].control2, shown[1].control2)
        XCTAssertEqual(start.segments[1].start, shown[1].start)
        XCTAssertEqual(start.segments[1].end, shown[1].end)
    }

    func testMatchedControlBlendsRemainInsideEachRawSamplePair() throws {
        var state: UInt64 = 8719
        for _ in 0..<40 {
            let values: [Double] = (0..<20).map { _ in
                state = state &* 6364136223846793005 &+ 1
                return Double((state >> 32) % 10001) / 100
            }
            let old = HistoryChartGeometry(samples: Array(values.dropLast()),
                timing: .init(sampledAt: (0..<19).map { Double($0) * 2 }, referenceTime: 36), ceiling: 100)
            let target = HistoryChartGeometry(samples: values,
                timing: .init(sampledAt: (0..<20).map { Double($0) * 2 }, referenceTime: 38), ceiling: 150)
            let start = try XCTUnwrap(target.alignedStart(from: old, presentedSegments: old.segments,
                fraction: 2.0 / 120, oldCeiling: 100, newCeiling: 150))
            for (a, b) in zip(start.segments, target.segments) {
                for q in stride(from: 0.0, through: 1, by: 0.1) {
                    for t in stride(from: 0.0, through: 1, by: 0.05) {
                        let y = a.value(at: t) * (1 - q) + b.value(at: t) * q
                        let left = a.start.y * (1 - q) + b.start.y * q
                        let right = a.end.y * (1 - q) + b.end.y * q
                        XCTAssertGreaterThanOrEqual(y, min(left, right) - 1e-12)
                        XCTAssertLessThanOrEqual(y, max(left, right) + 1e-12)
                        let x0 = a.start.x * (1 - q) + b.start.x * q
                        let x1 = a.end.x * (1 - q) + b.end.x * q
                        XCTAssertEqual(try XCTUnwrap(target.value(at: x0 + (x1 - x0) * t,
                            blendingFrom: start, progress: q)), y, accuracy: 1e-9)
                    }
                }
            }
        }
    }

    func testPausedSamplingMovesCachedHistoryToItsActualAge() {
        var now = 0.0
        let history = PowerHistory(clock: { now })
        history.append(10)
        now = 2
        history.append(20)
        let initial = history.chartPresentation
        let count = history.presentationMaterializationCountForTest

        // Degraded sampling still presents history, but adds no new readings.
        now = 119
        let aged = history.chartPresentation
        XCTAssertEqual(aged.samples, initial.samples)
        XCTAssertEqual(aged.timing.sampledAt, initial.timing.sampledAt)
        XCTAssertEqual(aged.timing.referenceTime, now)
        XCTAssertEqual(history.presentationMaterializationCountForTest, count)
        let geometry = HistoryChartGeometry(samples: aged.samples, timing: aged.timing, ceiling: 100)
        XCTAssertEqual(geometry.points.count, 2)
        XCTAssertEqual(geometry.points.last!.x, 3.0 / 120, accuracy: 1e-12)
        XCTAssertNil(HistoryChartTiming.scrollFraction(from: initial.timing, samples: initial.samples,
            to: aged.timing, samples: aged.samples))

        now = 122
        XCTAssertTrue(history.chartPresentation.samples.isEmpty)
    }

    func testHistoryTimingCacheRingAndExpiry() {
        var now = 0.0
        let history = PowerHistory(clock: { now })
        for i in 0..<65 { now = Double(i); history.append(Double(i)) }
        let frame = history.chartPresentation
        XCTAssertEqual(frame.samples, Array(5..<65).map(Double.init))
        XCTAssertEqual(frame.timing.sampledAt, frame.samples)
        XCTAssertEqual(frame.timing.referenceTime, 64)
        let count = history.presentationMaterializationCountForTest
        now = 64.5
        XCTAssertEqual(history.chartPresentation.timing, frame.timing)
        XCTAssertEqual(history.presentationMaterializationCountForTest, count)
        XCTAssertEqual(history.presentation.peak, 64)
        now = 184
        XCTAssertTrue(history.chartPresentation.samples.isEmpty)
        XCTAssertTrue(history.chartPresentation.timing.sampledAt.isEmpty)
        history.reset()
        now = 185
        history.append(3)
        XCTAssertEqual(history.chartPresentation.timing.sampledAt, [185])
    }
}
