import json
import pathlib
import plistlib
import re
import shlex
import stat
import struct
import subprocess
import sys
import unittest
import xml.etree.ElementTree as ET
import zlib

from local_runtime import TemporaryDirectory, run


ROOT = pathlib.Path(__file__).resolve().parents[1]
SCRIPTS = {
    name: ROOT / "scripts" / name
    for name in (
        "build_release.sh",
        "package_pkg.sh",
        "package_dmg.sh",
        "verify_dmg.sh",
        "notarize.sh",
        "release.sh",
        "verify_release.sh",
    )
}
PREINSTALL = ROOT / "Packaging" / "pkg" / "preinstall"
POSTINSTALL = ROOT / "Packaging" / "pkg" / "postinstall"
RELEASE_GUIDE = ROOT / ".agent" / "release.md"
README = ROOT / "README.md"
HANDOFF = ROOT / "HANDOFF.md"
PROMOTE_WORKFLOW = ROOT / ".github" / "workflows" / "promote-release.yml"
CANDIDATE_WORKFLOW = ROOT / ".github" / "workflows" / "macos-helper-install.yml"
IN_APP_LOGOS = ("AppLogoColor.png", "AppLogoClearLight.png", "AppLogoClearDark.png")
DOCK_LOGOS = ("AppDockLogoColor.png", "AppDockLogoClearLight.png", "AppDockLogoClearDark.png")


class ReleasePackagingContractTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.source = {
            name: path.read_text(encoding="utf-8") for name, path in SCRIPTS.items()
        }
        cls.preinstall = PREINSTALL.read_text(encoding="utf-8")
        cls.postinstall = POSTINSTALL.read_text(encoding="utf-8")
        cls.release_guide = RELEASE_GUIDE.read_text(encoding="utf-8")
        cls.readme = README.read_text(encoding="utf-8")
        cls.handoff = HANDOFF.read_text(encoding="utf-8")
        cls.promote_workflow = PROMOTE_WORKFLOW.read_text(encoding="utf-8")
        cls.candidate_workflow = CANDIDATE_WORKFLOW.read_text(encoding="utf-8")

    def test_version_is_the_single_source_and_plist_template_is_english(self):
        self.assertRegex((ROOT / "VERSION").read_text(encoding="utf-8"),
                         r"\A[0-9]+\.[0-9]+\.[0-9]+\n\Z")
        with (ROOT / "Packaging" / "AppInfo.plist").open("rb") as handle:
            info = plistlib.load(handle)
        self.assertEqual(info["CFBundleIdentifier"], "com.leoarrow.wattson")
        self.assertEqual(info["CFBundleName"], "Wattson")
        self.assertEqual(info["CFBundleDisplayName"], "Wattson")
        self.assertEqual(info["LSMinimumSystemVersion"], "12.0")
        self.assertFalse(list((ROOT / "Packaging").rglob("InfoPlist.strings")))

    def test_current_release_support_and_promotion_copy_are_not_stale(self):
        self.assertIn("support-diagnostics-v1.1.0", self.readme)
        self.assertNotIn("support-diagnostics-v1.0.0", self.readme)
        normalized_readme = " ".join(self.readme.split())
        normalized_promote_workflow = " ".join(self.promote_workflow.split())
        self.assertIn(
            "[GitHub Releases](https://github.com/laleoarrow/battery-monitor/releases)",
            self.readme,
        )
        self.assertIn(
            "A newer source version does not mean an update has been published.",
            normalized_readme,
        )
        self.assertNotRegex(self.readme, r"(?im)^#{1,6}\s+What's new\b")
        self.assertNotRegex(self.readme, r"(?im)^#{1,6}\s+.*\bhistorical\b")
        current_handoff = self.handoff.split(
            "## v3.0.23 strict power observation runtime", 1
        )[1].split("## v3.0.18 measured attached-device output (historical)", 1)[0]
        normalized_current_handoff = " ".join(current_handoff.split())
        historical_v3017 = self.handoff.split(
            "## v3.0.17 lighter power-flow node family (historical)", 1
        )[1].split("## v3.0.16 unified power-flow node scale (historical)", 1)[0]
        normalized_historical_v3017 = " ".join(historical_v3017.split())
        historical_v3016 = self.handoff.split(
            "## v3.0.16 unified power-flow node scale (historical)", 1
        )[1].split("## v3.0.15 restored power-flow node artwork", 1)[0]
        normalized_historical_v3016 = " ".join(historical_v3016.split())
        historical_v3015 = self.handoff.split(
            "## v3.0.15 restored power-flow node artwork", 1
        )[1].split("## v3.0.14 update checks", 1)[0]
        normalized_historical_v3015 = " ".join(historical_v3015.split())

        for current_icon_topic in (
            "approved A1 power-flow icon direction",
            "slightly smaller, lighter",
            "21-point Regular",
            "1.6-point custom outlines",
            "existing 36-point wells",
            "real visible extents target 19.25–21.5 points",
            "measure 20–21.25 points",
            "diagonal adapter plug",
            "simplified matching System chip",
            "green bracketed charging battery",
            "central lightning mark",
            "semantic source and load colours remain unchanged",
        ):
            self.assertIn(current_icon_topic, normalized_promote_workflow)
            self.assertIn(current_icon_topic, normalized_historical_v3017)

        for candidate_topic in (
            "Device Output",
            "auxiliary breakdown",
            "Cycle Count",
            "positive coherent",
            "three-node",
            "Mac Load",
            "measured",
            "incoherent",
        ):
            self.assertIn(candidate_topic, normalized_promote_workflow)
            self.assertIn(candidate_topic, normalized_current_handoff)

        for plugged_output_topic in (
            "plugged, charging, and mixed-supply states",
            "auxiliary readout",
            "included in System Total",
            "never double-counted",
            "does not claim external-meter absolute accuracy",
        ):
            self.assertIn(plugged_output_topic, normalized_current_handoff)

        for battery_direction_topic in (
            "signed battery voltage × current",
            "direct adapter and system rails arrive asynchronously",
            "iPhone",
            "Device Output",
            "Battery Assist",
            "Mixed Power",
            "flow consistency",
            "does not claim external-meter absolute accuracy",
        ):
            self.assertIn(battery_direction_topic, normalized_current_handoff)

        for connector_topic in (
            "one closed port template extracted from the selected visual source",
            "compact plugged-state accessory",
            "existing on-battery Device Output node",
            "reuse that same template",
            "inconsistent cable-connector glyphs",
            "existing inline readout",
            "three-node and two-pipe layouts",
            "popover height",
            "power totals",
            "conservation math",
            "does not accelerate firmware publication or hardware recognition",
        ):
            self.assertIn(connector_topic, normalized_current_handoff)

        for technical_topic in (
            "`PowerOutDetails.Watts`",
            "`PDPowermW`",
            "`FilteredPower`",
            "`Configured*`",
            "auxiliary breakdown of `systemW`",
            "fixed 138-point",
            "valid zero",
            "three-node, two-pipe split",
        ):
            self.assertIn(technical_topic, normalized_current_handoff)

        for current_release_topic in (
            "dedicated Menu Bar Icon page",
            "Wattson icon only",
            "Wattson with percentage",
            "macOS 26 icon only",
            "macOS 26 with percentage",
            "appearances vertically",
            "one full-width option per row",
            "seven real production-rendered states",
            "Battery, Full, Charging, Low, Low + AC, Saver, and Saver + AC",
            "real BatteryIcon renderer",
            "percentage rows show matching per-state values to the left of each glyph",
            "full-size macOS 26 Control Center battery parts from the running system",
            "23×12 outline and 11×14 bolt",
            "Every connected state uses the system bolt",
            "only the battery fill is yellow",
            "outline, cap, and bolt keep the menu-bar foreground colour",
            "General adds Check for Updates and Check for Updates on Launch",
            "Manual checks read GitHub Latest Release",
            "launch checks default on, stay quiet when current or offline",
            "never download or install automatically",
            "packaged Wattson app icon",
            "720×520",
        ):
            self.assertIn(current_release_topic, normalized_promote_workflow)

        for misleading_install_claim in (
            "Every installer now converges",
            "All installers converge",
            "Converges every install route",
            "Installers converge",
            "same-bundle-ID residue",
            "only after the canonical app passes validation",
            "rollback backup outside `/Applications`",
            "hidden `.app`",
        ):
            for release_surface in (
                normalized_readme,
                normalized_promote_workflow,
                normalized_current_handoff,
            ):
                self.assertNotIn(misleading_install_claim, release_surface)

        for historical_v3016_topic in (
            "superseded v3.0.16 release",
            "one shared optical scale",
            "simplified matching chip glyph",
            "v3.0.17 keeps that family and reduces its weight and scale",
        ):
            self.assertIn(historical_v3016_topic, normalized_historical_v3016)

        for historical_handoff_topic in (
            "clear diagonal plug",
            "green bracketed battery with a central lightning mark",
            "24-point Medium",
            "36-point wells",
            "Check for Updates",
            "four-by-seven Menu Bar Icon selector",
            "macOS 26 native battery artwork",
        ):
            self.assertIn(historical_handoff_topic, normalized_historical_v3015)

        self.assertIn("## v3.0.23 strict power observation runtime", self.handoff)
        self.assertIn(
            "## v3.0.18 measured attached-device output (historical)", self.handoff
        )
        self.assertIn(
            "## v3.0.17 lighter power-flow node family (historical)", self.handoff
        )
        self.assertIn(
            "## v3.0.16 unified power-flow node scale (historical)", self.handoff
        )
        self.assertIn("## v3.0.15 restored power-flow node artwork", self.handoff)
        self.assertIn("## v3.0.14 update checks", self.handoff)
        self.assertIn("## v3.0.13 macOS 26 native icon correction", self.handoff)
        self.assertIn("## v3.0.12 complete runtime-state previews", self.handoff)
        self.assertIn("## v3.0.11 complete menu-bar appearance presets", self.handoff)
        self.assertIn("## v3.0.10 Settings and website work", self.handoff)
        self.assertIn("## v3.0.9 selector and rendering work", self.handoff)
        self.assertIn("## v3.0.8 dynamic Reduce Motion and transaction work", self.handoff)
        self.assertLess(
            self.handoff.index("## v3.0.23 strict power observation runtime"),
            self.handoff.index("## v3.0.18 measured attached-device output (historical)"),
        )
        self.assertLess(
            self.handoff.index("## v3.0.18 measured attached-device output (historical)"),
            self.handoff.index("## v3.0.17 lighter power-flow node family (historical)"),
        )
        self.assertLess(
            self.handoff.index("## v3.0.17 lighter power-flow node family (historical)"),
            self.handoff.index("## v3.0.16 unified power-flow node scale (historical)"),
        )
        self.assertLess(
            self.handoff.index("## v3.0.16 unified power-flow node scale (historical)"),
            self.handoff.index("## v3.0.15 restored power-flow node artwork"),
        )
        self.assertLess(
            self.handoff.index("## v3.0.15 restored power-flow node artwork"),
            self.handoff.index("## v3.0.14 update checks"),
        )
        self.assertLess(
            self.handoff.index("## v3.0.14 update checks"),
            self.handoff.index("## v3.0.13 macOS 26 native icon correction"),
        )
        self.assertLess(
            self.handoff.index("## v3.0.13 macOS 26 native icon correction"),
            self.handoff.index("## v3.0.12 complete runtime-state previews"),
        )
        self.assertLess(
            self.handoff.index("## v3.0.12 complete runtime-state previews"),
            self.handoff.index("## v3.0.11 complete menu-bar appearance presets"),
        )
        self.assertLess(
            self.handoff.index("## v3.0.11 complete menu-bar appearance presets"),
            self.handoff.index("## v3.0.10 Settings and website work"),
        )
        self.assertLess(
            self.handoff.index("## v3.0.10 Settings and website work"),
            self.handoff.index("## v3.0.9 selector and rendering work"),
        )
        self.assertLess(
            self.handoff.index("## v3.0.9 selector and rendering work"),
            self.handoff.index("## v3.0.8 dynamic Reduce Motion and transaction work"),
        )

        for stale_copy in (
            "percentage control remains in General",
            "percentage stays in General",
            "all four complete appearances in one row",
            "all four complete menu-bar appearances in one row",
        ):
            self.assertNotIn(stale_copy, normalized_readme)
            self.assertNotIn(stale_copy, normalized_promote_workflow)
            self.assertNotIn(stale_copy, normalized_current_handoff)

        self.assertIn("**Verified distribution:**", self.promote_workflow)
        self.assertIn("Developer ID signed", self.promote_workflow)
        self.assertIn("Apple accepted both release containers", self.promote_workflow)

    def test_release_workflows_read_repository_version_when_input_is_blank(self):
        for workflow in (self.candidate_workflow, self.promote_workflow):
            version_input = workflow.split("      version:\n", 1)[1].split(
                "        type: string\n", 1
            )[0]
            self.assertIn("required: false", version_input)
            self.assertIn("leave blank", version_input)
            self.assertNotIn("default:", version_input)
            self.assertIn('if [[ -z "$WATTSON_VERSION" ]]; then', workflow)
            self.assertIn("< VERSION", workflow)

    def test_release_scripts_are_executable_and_parse_as_bash(self):
        for path in (*SCRIPTS.values(), PREINSTALL, POSTINSTALL):
            with self.subTest(path=path):
                self.assertTrue(path.stat().st_mode & stat.S_IXUSR)
                result = subprocess.run(
                    ["/bin/bash", "-n", str(path)],
                    check=False,
                    text=True,
                    capture_output=True,
                )
                self.assertEqual(result.returncode, 0, result.stderr)

    def test_swiftpm_build_must_be_universal_and_target_macos_12(self):
        build = self.source["build_release.sh"]
        self.assertIn("/usr/bin/swift build", build)
        self.assertIn("for architecture in arm64 x86_64; do", build)
        self.assertIn("--build-system native", build)
        self.assertIn('--arch "$architecture"', build)
        self.assertIn('--scratch-path "$SWIFTPM_BUILD_DIR/$architecture"', build)
        self.assertIn('lipo -create "${APP_SLICES[@]}"', build)
        self.assertIn('lipo -create "${HELPER_SLICES[@]}"', build)
        self.assertIn('lipo "$binary_path" -verify_arch "$architecture"', build)
        self.assertIn('vtool -arch "$architecture" -show-build', build)
        self.assertIn('MIN_MACOS_VERSION="12.0"', build)
        self.assertNotIn("swiftc", build)
        self.assertNotIn("fall back", build.lower())

    @unittest.skipUnless(sys.platform == "darwin", "requires the macOS lipo tool")
    def test_universal_verifiers_require_both_architectures_with_single_arch_arguments(self):
        # Xcode 27 rejects the former two-architecture argv. Exercise the real
        # verifier functions with real Mach-O fixtures, then a stricter parser
        # seam so an older host lipo cannot hide the regression.
        with TemporaryDirectory(prefix="lipo contract-") as folder:
            scratch = pathlib.Path(folder)
            source = scratch / "fixture.c"
            source.write_text("int main(void) { return 0; }\n", encoding="utf-8")
            for architecture in ("arm64", "x86_64"):
                run(["/usr/bin/xcrun", "clang", "-target",
                     f"{architecture}-apple-macos12.0", str(source),
                     "-o", str(scratch / architecture)], check=True,
                    capture_output=True, timeout=30)
            universal = scratch / "universal"
            run(["/usr/bin/xcrun", "lipo", "-create", str(scratch / "arm64"),
                 str(scratch / "x86_64"), "-output", str(universal)],
                check=True, capture_output=True, timeout=10)
            malformed = scratch / "malformed"
            malformed.write_text("not a Mach-O file\n", encoding="utf-8")
            parser = scratch / "xcrun"
            parser.write_text("""#!/usr/bin/python3
import os, sys
arguments = sys.argv[1:]
if arguments[0] == 'lipo' and '-verify_arch' in arguments:
    if len(arguments[arguments.index('-verify_arch') + 1:]) != 1:
        sys.exit('verify_arch requires exactly one architecture')
os.execv('/usr/bin/xcrun', ['/usr/bin/xcrun', *arguments])
""", encoding="utf-8")
            parser.chmod(0o755)
            old_arguments = run([str(parser), "lipo", str(universal),
                                 "-verify_arch", "arm64", "x86_64"],
                                capture_output=True, text=True, timeout=10)
            self.assertNotEqual(old_arguments.returncode, 0)
            self.assertIn("exactly one architecture", old_arguments.stderr)
            for script_name, function in (("build_release.sh", "verify_universal_binary"),
                                          ("verify_release.sh", "verify_binary")):
                body = re.search(rf"(?ms)^{function}\(\) \{{.*?^\}}",
                                 self.source[script_name]).group()
                for tool in ("/usr/bin/xcrun", str(parser)):
                    harness = ('set -euo pipefail\nMIN_MACOS_VERSION=12.0\n'
                               'fail() { echo "$*" >&2; exit 1; }\n'
                               + body.replace("/usr/bin/xcrun", shlex.quote(tool))
                               + f'\n{function} "$1"\n')
                    for fixture in (universal, scratch / "arm64", scratch / "x86_64", malformed):
                        with self.subTest(script=script_name, tool=tool, fixture=fixture.name):
                            result = run(["/bin/bash", "-c", harness, "lipo-verifier", str(fixture)],
                                         capture_output=True, text=True, timeout=10)
                            self.assertEqual(result.returncode == 0, fixture == universal,
                                             result.stdout + result.stderr)
        shipping = [self.source[name] for name in ("build_release.sh", "verify_release.sh",
                    "verify_dmg.sh", "package_pkg.sh")]
        shipping += [(ROOT / name).read_text(encoding="utf-8") for name in (
            "scripts/build_diagnostics.sh", ".github/workflows/macos-helper-install.yml",
            ".github/workflows/homebrew-install-test.yml")]
        for text in shipping:
            self.assertNotIn("-verify_arch arm64 x86_64", text)
            self.assertIn('-verify_arch "$architecture"', text)

    def test_app_and_helper_use_one_explicit_signing_mode(self):
        build = self.source["build_release.sh"]
        self.assertIn("WATTSON_DEVELOPER_ID_APP", build)
        self.assertIn("--options runtime", build)
        self.assertIn('SIGNING_MODE="ad-hoc"', build)
        self.assertIn('--identifier "$HELPER_LABEL"', build)
        helper_signing = build.index('--identifier "$HELPER_LABEL"')
        app_signing = build.index('--entitlements "$ROOT_DIR/BatteryPowerApp.entitlements"')
        self.assertLess(helper_signing, app_signing)

    def test_native_icon_resources_are_built_before_app_signing(self):
        build = self.source["build_release.sh"]
        self.assertIn('ICON_BUILD_DIR="$BUILD_ROOT/icon-assets"', build)
        self.assertIn('actool "$ROOT_DIR/design/icon/WattsonGlass.icon"', build)
        self.assertIn('--minimum-deployment-target "$MIN_MACOS_VERSION"', build)
        self.assertIn('--app-icon WattsonGlass --standalone-icon-behavior all', build)
        self.assertIn('"$ICON_BUILD_DIR/Assets.car" "$ICON_BUILD_DIR/WattsonGlass.icns"', build)
        app_signing = build.index('--entitlements "$ROOT_DIR/BatteryPowerApp.entitlements"')
        self.assertLess(build.index("AppIconSettings.png"), app_signing)
        self.assertLess(build.index("/usr/bin/xcrun actool"), app_signing)
        self.assertNotIn("ictool", build)
        with (ROOT / "Packaging" / "AppInfo.plist").open("rb") as handle:
            info = plistlib.load(handle)
        self.assertEqual(info["CFBundleIconFile"], "WattsonGlass")
        self.assertEqual(info["CFBundleIconName"], "WattsonGlass")

    def test_native_icon_layers_match_sources_without_baked_filters(self):
        icon = ROOT / "design" / "icon" / "WattsonGlass.icon"
        document = json.loads((icon / "icon.json").read_text(encoding="utf-8"))
        layers = [layer for group in document["groups"] for layer in group["layers"]]
        names = ("03-particles.svg", "02-energy.svg", "01-track.svg")
        self.assertEqual([layer["image-name"] for layer in layers], list(names))
        for layer in layers:
            self.assertFalse(layer.get("hidden", False))
        for name in names:
            with self.subTest(layer=name):
                source = ROOT / "design" / "icon" / "liquid-glass" / name
                self.assertEqual((icon / "Assets" / name).read_bytes(), source.read_bytes())
                svg = ET.fromstring(source.read_bytes())
                self.assertEqual([float(value) for value in svg.attrib["viewBox"].split()],
                                 [0, 0, 1024, 1024])
                for node in svg.iter():
                    tag = node.tag.rsplit("}", 1)[-1]
                    self.assertNotEqual(tag, "filter")
                    self.assertFalse(tag.startswith("fe"), f"baked SVG effect: {tag}")
                    self.assertNotIn("filter", node.attrib)
                    self.assertNotIn("transform", node.attrib)
                    self.assertNotRegex(node.get("style", ""), r"(?i)\b(?:filter|backdrop-filter)\s*:")

    def test_native_icon_particles_stay_inside_the_original_energy_band(self):
        assets = ROOT / "design" / "icon" / "WattsonGlass.icon" / "Assets"
        namespace = {"svg": "http://www.w3.org/2000/svg"}
        control_points = ((240, 672), (452, 672), (566, 334), (784, 334))
        band_width = 134
        for name in ("01-track.svg", "02-energy.svg"):
            with self.subTest(layer=name):
                paths = ET.parse(assets / name).findall(".//svg:path", namespace)
                self.assertEqual(len(paths), 1)
                path = paths[0]
                tokens = re.findall(r"[A-Za-z]|[-+]?(?:\d+\.?\d*|\.\d+)(?:[eE][-+]?\d+)?", path.attrib["d"])
                self.assertEqual((tokens[0], tokens[3]), ("M", "C"))
                self.assertEqual([float(value) for value in tokens[1:3] + tokens[4:]],
                                 [value for point in control_points for value in point])
                self.assertEqual(float(path.attrib["stroke-width"]), band_width)
                self.assertEqual(path.attrib["stroke-linecap"], "round")
        particles = ET.parse(assets / "03-particles.svg").findall(".//svg:circle", namespace)
        self.assertEqual(len(particles), 4)
        for particle, t in zip(particles, (0.17, 0.41, 0.64, 0.87)):
            with self.subTest(t=t):
                weights = ((1 - t) ** 3, 3 * (1 - t) ** 2 * t, 3 * (1 - t) * t ** 2, t ** 3)
                for axis, coordinate in enumerate(("cx", "cy")):
                    expected = sum(weight * point[axis] for weight, point in zip(weights, control_points))
                    self.assertAlmostEqual(float(particle.attrib[coordinate]), expected, delta=1e-5)
                radius = float(particle.attrib["r"])
                self.assertGreater(radius, 0)
                self.assertLess(radius, band_width / 2)

    def test_release_verifier_requires_classic_and_native_icon_resources(self):
        verify = self.source["verify_release.sh"]
        for resource in (
            "AppIcon.icns", "AppIconSettings.png", "Assets.car",
            "WattsonGlass.icns", *IN_APP_LOGOS, *DOCK_LOGOS,
        ):
            self.assertIn(resource, verify)
        self.assertIn('-f "$app_dir/Contents/Resources/$icon_resource"', verify)
        self.assertIn('! -L "$app_dir/Contents/Resources/$icon_resource"', verify)
        self.assertIn('-s "$app_dir/Contents/Resources/$icon_resource"', verify)
        self.assertIn("for icon_key in CFBundleIconFile CFBundleIconName", verify)
        self.assertIn('Print :$icon_key', verify)
        self.assertIn('[[ "$icon_name" == "WattsonGlass" ]]', verify)

    def test_in_app_logos_are_checked_in_and_copied_before_signing(self):
        for name in IN_APP_LOGOS:
            source = ROOT / "design" / "icon" / "in-app-logo" / name
            with self.subTest(resource=name):
                self.assertTrue(source.is_file())
                self.assertFalse(source.is_symlink())
                data = source.read_bytes()
                self.assertEqual(data[:8], b"\x89PNG\r\n\x1a\n")
                self.assertEqual(struct.unpack(">II", data[16:24]), (128, 128))
        for name in ("build_release.sh", "build_glass_preview.sh", "install.sh"):
            build = (ROOT / "scripts" / name).read_text(encoding="utf-8")
            with self.subTest(script=name):
                copy_position = build.index('"$ROOT_DIR/design/icon/in-app-logo/$logo_resource"')
                self.assertLess(copy_position, build.index("codesign "))
                for resource in IN_APP_LOGOS:
                    self.assertLess(build.index(resource), copy_position)
                self.assertNotIn("ictool", build)

    def test_dock_logos_are_checked_in_and_copied_before_signing(self):
        for name in DOCK_LOGOS:
            source = ROOT / "design" / "icon" / "dock-logo" / name
            with self.subTest(resource=name):
                self.assertTrue(source.is_file())
                self.assertFalse(source.is_symlink())
                data = source.read_bytes()
                self.assertTrue(data)
                self.assertEqual(data[:8], b"\x89PNG\r\n\x1a\n")
                self.assertEqual(struct.unpack(">II", data[16:24]), (512, 512))
        for name in ("build_release.sh", "build_glass_preview.sh", "install.sh"):
            build = (ROOT / "scripts" / name).read_text(encoding="utf-8")
            with self.subTest(script=name):
                copy_position = build.index('"$ROOT_DIR/design/icon/dock-logo/$dock_logo_resource"')
                self.assertLess(copy_position, build.index("codesign "))
                for resource in DOCK_LOGOS:
                    self.assertLess(build.index(resource), copy_position)
                self.assertNotIn("ictool", build)

    def test_bundle_verifier_rejects_invalid_native_icon_resources(self):
        verifier = "verify_app_bundle() {" + self.source["verify_release.sh"].split(
            "verify_app_bundle() {", 1
        )[1].split("\nverify_expected_team_id()", 1)[0]
        shell = (
            "set -euo pipefail\nAPP_VERSION=0.0.0\nMIN_MACOS_VERSION=12.0\n"
            'fail() { echo "$*" >&2; exit 1; }\n' + verifier
            + '\nverify_app_bundle "$1"\n'
        )
        with TemporaryDirectory(prefix="wattson-icon-verifier-") as temp:
            app = pathlib.Path(temp) / "Wattson.app"
            resources = app / "Contents" / "Resources"
            resources.mkdir(parents=True)
            info_path = app / "Contents" / "Info.plist"
            info = {
                "CFBundleIdentifier": "com.leoarrow.wattson",
                "CFBundleShortVersionString": "0.0.0",
                "LSMinimumSystemVersion": "12.0",
                "CFBundleIconFile": "WattsonGlass",
                "CFBundleIconName": "WattsonGlass",
            }
            info_path.write_bytes(plistlib.dumps(info))
            for name in (
                "AppIcon.icns", "AppIconSettings.png", "Assets.car",
                "WattsonGlass.icns",
            ):
                (resources / name).write_bytes(b"fixture")
            for directory, names in (("in-app-logo", IN_APP_LOGOS), ("dock-logo", DOCK_LOGOS)):
                for name in names:
                    (resources / name).write_bytes(
                        (ROOT / "design" / "icon" / directory / name).read_bytes()
                    )

            def verify_bundle():
                return run(
                    ["/bin/bash", "-c", shell, "icon-verifier", str(app)],
                    capture_output=True, text=True, check=False,
                )

            self.assertEqual(verify_bundle().returncode, 0)
            for name in ("Assets.car", "WattsonGlass.icns", *IN_APP_LOGOS, *DOCK_LOGOS):
                resource = resources / name
                original_data = resource.read_bytes()
                for invalid_state in ("missing", "empty", "symlink"):
                    with self.subTest(resource=name, state=invalid_state):
                        resource.unlink()
                        if invalid_state == "empty":
                            resource.touch()
                        elif invalid_state == "symlink":
                            target = pathlib.Path(temp) / "icon-symlink-target"
                            target.write_bytes(original_data)
                            resource.symlink_to(target)
                        result = verify_bundle()
                        self.assertNotEqual(result.returncode, 0)
                        self.assertIn(name, result.stderr)
                        if resource.exists() or resource.is_symlink():
                            resource.unlink()
                        resource.write_bytes(original_data)
            def png_chunk(kind, data):
                return (struct.pack(">I", len(data)) + kind + data
                        + struct.pack(">I", zlib.crc32(kind + data)))

            one_pixel_png = (
                b"\x89PNG\r\n\x1a\n"
                + png_chunk(b"IHDR", struct.pack(">IIBBBBB", 1, 1, 8, 6, 0, 0, 0))
                + png_chunk(b"IDAT", zlib.compress(b"\x00\x00\x00\x00\x00"))
                + png_chunk(b"IEND", b"")
            )
            for name in (*IN_APP_LOGOS, *DOCK_LOGOS):
                resource = resources / name
                original_data = resource.read_bytes()
                for invalid_data in (
                    b"not an image",
                    (ROOT / "design" / "icon" / "AppIcon.icns").read_bytes(),
                    one_pixel_png,
                ):
                    with self.subTest(resource=name, invalid_image=invalid_data[:8]):
                        resource.write_bytes(invalid_data)
                        result = verify_bundle()
                        self.assertNotEqual(result.returncode, 0)
                        self.assertIn(name, result.stderr)
                        resource.write_bytes(original_data)
            for preview_name, dock_name in zip(IN_APP_LOGOS, DOCK_LOGOS):
                for name, replacement in ((preview_name, dock_name), (dock_name, preview_name)):
                    with self.subTest(resource=name, wrong_size_source=replacement):
                        resource = resources / name
                        original_data = resource.read_bytes()
                        try:
                            resource.write_bytes((resources / replacement).read_bytes())
                            result = verify_bundle()
                            self.assertNotEqual(result.returncode, 0)
                            self.assertIn(name, result.stderr)
                        finally:
                            resource.write_bytes(original_data)
            for key in ("CFBundleIconFile", "CFBundleIconName"):
                for invalid_value in (None, "AppIcon", "MissingIcon"):
                    with self.subTest(key=key, value=invalid_value):
                        if invalid_value is None:
                            info.pop(key)
                        else:
                            info[key] = invalid_value
                        info_path.write_bytes(plistlib.dumps(info))
                        self.assertNotEqual(verify_bundle().returncode, 0)
                        info[key] = "WattsonGlass"
            info_path.write_bytes(plistlib.dumps(info))
            self.assertEqual(verify_bundle().returncode, 0)

    def test_pkg_owns_the_canonical_app_and_full_helper_payload(self):
        package = self.source["package_pkg.sh"]
        for path in (
            "$PKG_ROOT/Applications/Wattson.app",
            "$PKG_ROOT/Library/PrivilegedHelperTools/$HELPER_LABEL",
            "$PKG_ROOT/Library/LaunchDaemons/$HELPER_LABEL.plist",
        ):
            self.assertIn(path, package)
        self.assertIn("--ownership recommended", package)
        self.assertIn("--install-location /", package)
        self.assertIn('--component-plist "$COMPONENT_PLIST"', package)
        self.assertIn("WATTSON_DEVELOPER_ID_INSTALLER", package)
        self.assertNotIn('$HOME/Applications/Wattson.app', package)

        with (ROOT / "Packaging" / "pkg" / "component.plist").open("rb") as handle:
            components = plistlib.load(handle)
        self.assertEqual(components[0]["RootRelativeBundlePath"], "Applications/Wattson.app")
        self.assertFalse(components[0]["BundleIsRelocatable"])

    def test_pkg_scripts_replace_and_restart_the_existing_helper(self):
        self.assertIn('launchctl bootout "$HELPER_TARGET"', self.preinstall)
        self.assertIn('/bin/rm -f -- "$HELPER_SOCKET"', self.preinstall)
        self.assertIn('APP_DIR="/Applications/Wattson.app"', self.postinstall)
        self.assertIn('/bin/launchctl enable "$HELPER_TARGET"', self.postinstall)
        self.assertIn('/bin/launchctl bootstrap system "$HELPER_PLIST"', self.postinstall)
        self.assertIn('"$HELPER_BIN" --health-probe', self.postinstall)
        self.assertIn('"$HELPER_BIN" --migrate-legacy-login-item', self.postinstall)
        self.assertLess(
            self.postinstall.index('"$HELPER_BIN" --migrate-legacy-login-item'),
            self.postinstall.index("remove_v2_user_app\n"),
        )
        self.assertNotIn("NSStatusItem", self.postinstall)
        self.assertNotIn("--installer-ready-token", self.postinstall)
        recovery = self.postinstall.split("recover_monitoring() {", 1)[1].split("\n}\n", 1)[0]
        finish = self.postinstall.split("finish_installation() {", 1)[1].split("\n}\n", 1)[0]
        successful_install = self.postinstall.split('trap \'finish_installation "$?"\' EXIT', 1)[1]
        self.assertEqual(self.postinstall.count("/usr/bin/open"), 1)
        self.assertIn('/usr/bin/codesign --verify --deep --strict "$APP_DIR" || return 1', recovery)
        self.assertIn('/bin/launchctl asuser "$console_uid"', recovery)
        self.assertIn('/usr/bin/sudo -n -u "#$console_uid" --', recovery)
        self.assertIn('/usr/bin/open -g "$APP_DIR"', recovery)
        self.assertIn('if [[ "$installation_status" != "0" ]]; then', finish)
        self.assertIn('if recover_monitoring; then', finish)
        self.assertIn('exit "$installation_status"', finish)
        self.assertNotIn("/usr/bin/open", successful_install)
        self.assertNotIn("recover_monitoring", successful_install)

    def test_interactive_pkg_install_probes_v4_and_v5_as_console_user(self):
        probe = self.postinstall.split(
            "# Probe the socket only in an interactive install.", 1
        )[1].split('"$HELPER_BIN" --migrate-legacy-login-item', 1)[0]
        self.assertIn('/bin/launchctl print "gui/$console_uid"', probe)
        self.assertIn('/bin/launchctl asuser "$console_uid"', self.postinstall)
        self.assertIn('/usr/bin/sudo -n -u "#$console_uid"', self.postinstall)
        self.assertIn('--helper-health-probe', probe)
        self.assertIn('--helper-v5-observation-probe', probe)
        self.assertIn('console_user" != "loginwindow"', probe)

    def test_release_verifier_checks_the_v5_surface_in_built_and_packaged_bytes(self):
        verify = self.source["verify_release.sh"]
        self.assertIn("verify_v5_protocol_surface()", verify)
        self.assertGreaterEqual(verify.count("verify_v5_protocol_surface "), 2)
        self.assertIn("--helper-v5-observation-probe", verify)
        self.assertIn("getPowerObservation", verify)

    def test_v2_user_app_cleanup_is_identity_pinned_and_unprivileged(self):
        self.assertIn('legacy_app="$home_dir/Applications/Wattson.app"', self.postinstall)
        self.assertIn('[[ "$legacy_id" == "$APP_BUNDLE_ID" ]]', self.postinstall)
        identity_check = self.postinstall.index('[[ "$legacy_id" == "$APP_BUNDLE_ID" ]]')
        stop_process = self.postinstall.index('/usr/bin/pkill', identity_check)
        delete_app = self.postinstall.index('/bin/rm -rf -- "$legacy_app"', stop_process)
        self.assertLess(identity_check, stop_process)
        self.assertLess(stop_process, delete_app)
        self.assertIn('-u "$console_uid"', self.postinstall[stop_process:delete_app])
        self.assertIn('legacy_process_pattern', self.postinstall[stop_process:delete_app])
        self.assertIn('/usr/bin/sudo -n -u "#$console_uid"', self.postinstall)
        self.assertNotIn('rm -rf -- "$home_dir"', self.postinstall)

    def test_dmg_contains_the_same_app_without_the_privileged_installer(self):
        package = self.source["package_dmg.sh"]
        verify = self.source["verify_dmg.sh"]
        self.assertIn('/usr/bin/ditto --noextattr --noqtn "$APP_DIR" "$STAGING_DIR/$APP_NAME.app"', package)
        self.assertIn('/usr/bin/diff -qr "$APP_DIR" "$STAGING_DIR/$APP_NAME.app"', package)
        self.assertIn('/bin/ln -s /Applications "$STAGING_DIR/Applications"', package)
        self.assertIn('/usr/bin/diff -qr "$EXPECTED_APP" "$EMBEDDED_APP"', verify)
        self.assertIn("DMG must expose only Wattson.app and an Applications link", verify)
        self.assertIn('/usr/bin/readlink "$MOUNT_DIR/Applications"', verify)
        self.assertIn('/usr/bin/codesign --verify --deep --strict "$EMBEDDED_APP"', verify)
        self.assertIn('lipo "$APP_BIN" -verify_arch "$architecture"', verify)
        self.assertIn(
            'verify_dmg.sh" "$DMG_PATH" "$PACKAGED_APP_DIR"',
            self.source["verify_release.sh"],
        )
        self.assertNotIn("PKG_PATH", package)
        self.assertNotIn("PrivilegedHelperTools", package)
        self.assertNotIn("sudo", package)
        self.assertNotIn("Install Wattson.app", package)

    def test_notarization_is_opt_in_and_claimed_only_after_acceptance(self):
        release = self.source["release.sh"]
        notarize = self.source["notarize.sh"]
        self.assertIn('NOTARIZE_RELEASE="${WATTSON_NOTARIZE:-0}"', release)
        self.assertIn('|| -z "${WATTSON_NOTARY_ISSUER:-}"', release)
        self.assertIn('|| -n "${WATTSON_NOTARY_ISSUER:-}"', notarize)
        self.assertIn('|| -z "${WATTSON_NOTARY_ISSUER:-}"', notarize)
        self.assertIn('--issuer "$WATTSON_NOTARY_ISSUER"', notarize)
        self.assertIn('-extract status raw "$SUBMISSION_RESULT"', notarize)
        self.assertIn('-extract id raw "$SUBMISSION_RESULT"', notarize)
        self.assertIn("notarytool log", notarize)
        self.assertIn('-type issues "$NOTARY_LOG"', notarize)
        self.assertIn('-extract issues raw "$NOTARY_LOG"', notarize)
        self.assertIn('NOTARY_ISSUE_COUNT" != "0"', notarize)
        self.assertIn('NOTARY_STATUS" != "Accepted"', notarize)
        self.assertLess(
            notarize.index("notarytool log"),
            notarize.index('NOTARY_STATUS" != "Accepted"'),
        )
        self.assertLess(
            notarize.index('NOTARY_STATUS" != "Accepted"'),
            notarize.index("stapler staple"),
        )
        self.assertLess(
            notarize.index('NOTARY_ISSUE_COUNT" != "0"'),
            notarize.index("stapler staple"),
        )
        self.assertIn('/usr/bin/mktemp -d', notarize)
        self.assertIn("wattson_cleanup_init", notarize)
        self.assertIn('wattson_cleanup_add_dir "$TEMP_DIR"', notarize)
        self.assertIn(".build/local.noindex", notarize)
        self.assertIn('$SCRATCH_PARENT/notary.XXXXXX', notarize)
        self.assertIn("wattson_run /usr/bin/xcrun notarytool", notarize)
        self.assertLess(
            release.index('notarize.sh" "$DMG_PATH"'),
            release.index('NOTARIZED="yes"'),
        )
        self.assertIn('NOTARIZED="no"', release)
        self.assertIn("configure both Developer ID Application and Installer", release)

    def test_release_checksums_are_written_after_final_artifacts(self):
        release = self.source["release.sh"]
        checksum_write = release.index('> "$CHECKSUM_PATH"')
        self.assertLess(release.index('notarize.sh" "$DMG_PATH"'), checksum_write)
        self.assertLess(release.index('verify_release.sh" "$PKG_PATH" "$DMG_PATH"'), checksum_write)
        self.assertIn('/usr/bin/shasum -a 256 "$PKG_NAME"', release)
        self.assertIn('/usr/bin/shasum -a 256 "$DMG_NAME"', release)
        self.assertIn('/usr/bin/shasum -a 256 -c', release)
        self.assertIn("dmg_contents=app-only", release)
        self.assertIn("pkg_contents=app-and-helper", release)

    def test_stable_release_requires_installing_verified_public_pkg_locally(self):
        guide = self.release_guide
        self.assertIn("A stable release is not complete", guide)
        self.assertIn("Do not use\n`scripts/install.sh`", guide)
        self.assertIn("/usr/bin/shasum -a 256 -c", guide)
        self.assertIn('sudo /usr/sbin/installer -pkg "$verified_pkg" -target /', guide)
        self.assertIn("Print :CFBundleShortVersionString", guide)
        self.assertIn("Print :CFBundleVersion", guide)
        self.assertIn("pkgutil --pkg-info com.leoarrow.wattson.pkg", guide)
        self.assertIn("/usr/bin/codesign --verify --deep --strict", guide)
        self.assertIn("/usr/bin/open -n /Applications/Wattson.app", guide)


if __name__ == "__main__":
    unittest.main()
