import pathlib
import re
import unittest

ROOT = pathlib.Path(__file__).resolve().parents[1]
ICON_SOURCE = ROOT / "MenuBar" / "BatteryIcon.swift"
ICON27_SOURCE = ROOT / "MenuBar" / "BatteryIcon27.swift"


class BatteryIconContractTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.source = ICON_SOURCE.read_text(encoding="utf-8")
        cls.source27 = ICON27_SOURCE.read_text(encoding="utf-8")

    def test_default_state_is_a_template_image(self):
        # Template is the only way the icon matches the system battery across
        # light, dark and selected menu bars.
        self.assertIn("isTemplate = true", self.source)

    def test_colored_states_are_not_template(self):
        self.assertIn("isTemplate = false", self.source)

    def test_pressed_state_falls_back_to_template(self):
        # A colored image does not invert under the selection highlight.
        self.assertIn("pressed", self.source)
        key = self.source.split("static func renderKey", 1)[1].split(
            "static func image", 1
        )[0]
        self.assertIn("if pressed", key)
        self.assertIn(".template", key)

    def test_render_key_tracks_every_input_that_can_change_the_pixels(self):
        self.assertIn("struct RenderKey: Equatable", self.source)
        for field in ("percent", "showsBolt", "style", "tintRole", "appearanceName",
                      "increasedContrast"):
            self.assertIn(field, self.source)

    def test_native_style_uses_the_real_macos_menu_bar_battery_assets(self):
        self.assertIn(
            '"/System/Library/CoreServices/ControlCenter.app"', self.source
        )
        for asset in (
            "battery-outline",
            "battery-cap",
            "battery-bolt",
            "battery-bolt-mask",
        ):
            self.assertIn(f'"{asset}"', self.source)
        self.assertNotIn('"battery-small-', self.source)
        self.assertNotIn('"battery-plug', self.source)
        self.assertNotIn("systemSymbolName:", self.source)
        native = self.source.split("private static func nativeImage", 1)[1]
        self.assertIn("nativeFillColor", native)

    def test_native_low_power_colors_only_the_fill_layer(self):
        native = self.source.split("private static func nativeImage", 1)[1].split(
            "private static func nativeFallbackImage", 1
        )[0]
        self.assertIn("NSColor.systemYellow", self.source)
        self.assertIn("fillColor", native)
        self.assertIn("foregroundColor", native)
        self.assertIn("image.isTemplate = fillColor == nil", native)

    def test_native_style_keeps_a_vector_fallback(self):
        self.assertIn("private static func nativeFallbackImage", self.source)
        self.assertIn("NSImage(size:", self.source)

    def test_native_uses_the_system_bolt_for_every_connected_power_state(self):
        native = self.source.split("private static func nativeImage", 1)[1].split(
            "private static func nativeFallbackImage", 1
        )[0]
        self.assertIn("snapshot.plugged ? .bolt : .none", native)
        self.assertNotIn("case .plug", native)

    def test_native_cache_key_tracks_exact_fill_and_bolt_pixels(self):
        native_key = self.source.split("if style == .native {", 1)[1].split(
            "let tintRole", 1
        )[0]
        self.assertIn("percent: percent", native_key)
        self.assertIn("showsBolt: snapshot.plugged", native_key)
        self.assertNotIn("showsPlug", self.source)
        fallback = self.source.split("private static func nativeFallbackImage", 1)[1].split(
            "/// Priority", 1
        )[0]
        self.assertIn("snapshot.percent", fallback)

    def test_native27_is_a_separate_renderer_with_inset_digits(self):
        new_style = self.source.split("if style == .native27 {", 2)[2].split(
            "if style == .native {", 1
        )[0]
        self.assertIn("BatteryIcon27.image", new_style)
        self.assertIn("showsPercentage: showsPercentage", new_style)
        self.assertIn("string: String(percent)", self.source27)
        self.assertIn(".destinationOut", self.source27)
        self.assertNotIn('String(percent) + "%"', self.source27)

    def test_native27_loads_running_os_adornments_without_bundled_apple_artwork(self):
        self.assertIn('"/System/Library/CoreServices/ControlCenter.app"', self.source27)
        for asset in ("battery-bolt-large", "battery-bolt-mask-large",
                      "battery-plug-large", "battery-plug-mask-large"):
            self.assertIn(f'"{asset}"', self.source27)
        self.assertIn("fallbackAdornment", self.source27)
        self.assertIn("snapshot.isChargingPresentation ? .bolt : .plug", self.source27)

    def test_native27_key_tracks_internal_percentage_and_connected_state(self):
        key = self.source.split("if style == .native27 {", 1)[1].split(
            "if style == .native {", 1
        )[0]
        self.assertIn("showsInlinePercentage: showsPercentage", key)
        self.assertIn("native27Adornment: adornment", key)
        legacy = self.source.split("if style == .native {", 1)[1].split(
            "static func image", 1
        )[0]
        self.assertNotIn("showsInlinePercentage:", legacy)
        self.assertNotIn("native27Adornment:", legacy)

    def test_native27_canvas_and_low_power_preserve_template_behavior(self):
        self.assertIn("static let width: CGFloat = 25", self.source27)
        self.assertIn("static let height: CGFloat = 16", self.source27)
        self.assertIn("let isLowPower = !pressed && mode == .low", self.source27)
        self.assertIn("isLowPower ? NSColor.systemYellow : foreground", self.source27)
        self.assertIn("image.isTemplate = !isLowPower", self.source27)

    def test_color_priority_is_low_power_then_low_battery_then_charging(self):
        low_power = self.source.index("systemYellow")
        low_battery = self.source.index("systemRed")
        charging = self.source.index("systemGreen")
        self.assertLess(low_power, low_battery)
        self.assertLess(low_battery, charging)

    def test_native_canvas_fits_the_current_system_outline_cap_and_bolt(self):
        width = re.search(r"static let nativeWidth: CGFloat = ([\d.]+)", self.source)
        height = re.search(r"static let nativeHeight: CGFloat = ([\d.]+)", self.source)
        self.assertIsNotNone(width)
        self.assertIsNotNone(height)
        self.assertEqual(float(width.group(1)), 25.0)
        self.assertEqual(float(height.group(1)), 14.0)
        native = self.source.split("private static func nativeImage", 1)[1].split(
            "private static func nativeFillColor", 1
        )[0]
        self.assertIn("width: 23, height: 12", native)
        self.assertIn("width: 2, height: 12", native)
        self.assertIn("width: 11, height: 14", native)


    def test_bolt_overflows_the_shell(self):
        # The system bolt is 9x12 against a 10pt shell, so it breaks the
        # outline top and bottom. Containing it inside the shell is what made
        # the glyph read as undersized.
        shell = re.search(r"let shell = NSRect\(x: [\d.]+, y: ([\d.]+), width: [\d.]+, height: ([\d.]+)\)", self.source)
        self.assertIsNotNone(shell)
        top = float(shell.group(1)) + float(shell.group(2))
        ys = [float(m) for m in re.findall(r"bolt\.(?:move|line)\(to: NSPoint\(x: [\d.]+, y: ([\d.]+)\)\)", self.source)]
        self.assertTrue(ys, "bolt path not found")
        self.assertGreater(max(ys), top, "bolt must break the top of the shell")
        self.assertLess(min(ys), float(shell.group(1)), "bolt must break the bottom of the shell")


if __name__ == "__main__":
    unittest.main()
