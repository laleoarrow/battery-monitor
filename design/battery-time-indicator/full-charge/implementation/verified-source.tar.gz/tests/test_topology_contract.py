import pathlib
import unittest

ROOT = pathlib.Path(__file__).resolve().parents[1]
SOURCE = ROOT / "Popover" / "PowerFlowLayer.swift"


class TopologyContractTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.source = SOURCE.read_text(encoding="utf-8")

    def test_has_three_layouts_and_all_four_power_states(self):
        for layout in ("case adapterLed", "case batteryLed", "case batteryOutputSplit"):
            self.assertIn(layout, self.source)
        for state in ("case .charging", "case .pluggedIdle", "case .onBattery", "case .mixedSupply"):
            self.assertIn(state, self.source)

    def test_device_split_requires_valid_on_battery_measurement(self):
        split_gate = self.source.split(
            "private func batteryOutputSplitDeviceW", 1
        )[1].split("private func layoutMode", 1)[0]
        self.assertIn("snapshot.state == .onBattery", split_gate)
        self.assertIn("snapshot.batteryW < -PowerSnapshot.epsilon", split_gate)
        self.assertIn("snapshot.coherentDeviceOutputW", split_gate)
        self.assertIn("deviceOutputW > 0", split_gate)
        self.assertNotIn("deviceOutputW > PowerSnapshot.epsilon", split_gate)

    def test_device_split_reuses_two_pipes_and_three_nodes(self):
        split = self.source.split("case .batteryOutputSplit:", 1)[1]
        self.assertIn("snapshot.systemW - deviceOutputW", split)
        self.assertIn('caption: "Mac Load"', split)
        self.assertIn('caption: "Device Output"', split)
        self.assertIn('topology: "batteryOutputSplit.0"', split)
        self.assertIn('topology: "batteryOutputSplit.1"', split)

    def test_mixed_supply_keeps_adapter_blue_and_battery_orange(self):
        # Orange carries information here: the charger cannot keep up and the
        # battery is draining while plugged in.
        mixed = self.source.split("case .mixedSupply:", 1)[1]
        self.assertIn("tint: PopoverStyle.blue", mixed)
        self.assertIn("tint: PopoverStyle.amber", mixed)

    def test_keeps_exactly_two_pipe_bundles_and_three_node_views(self):
        # Plugged Device Output is only an inline accessory below the existing
        # plot. It must not grow the stable graph into a fourth node/third pipe.
        self.assertIn("(0..<2).map", self.source)
        self.assertIn("[adapterNode, batteryNode, systemNode]", self.source)
        self.assertIn("pluggedDeviceOutputReadout", self.source)
        self.assertNotIn("deviceOutputNode", self.source)
        self.assertNotIn("bundles[2]", self.source)

    def test_inline_device_accessory_preserves_the_existing_height_slot(self):
        # The selected treatment is a surgical enhancement of the existing
        # one-line readout, not a taller fourth-row card.
        self.assertIn("deviceOutputReadoutSlotHeight: CGFloat = 22", self.source)
        self.assertIn(
            "plotHeight + deviceOutputReadoutSlotHeight + PopoverStyle.sectionPadding * 2",
            self.source,
        )

    def test_device_output_uses_one_shared_port_icon_template(self):
        icon_factory = self.source.split(
            "fileprivate static func nodeIconImage", 1
        )[1].split("private static func nodeSymbolImage", 1)[0]
        plugged = self.source.split(
            "private func configurePluggedDeviceOutputReadout", 1
        )[1].split("private func configure(_ bundle", 1)[0]
        on_battery = self.source.split("case .onBattery:", 1)[1].split(
            "case .mixedSupply:", 1
        )[0]

        self.assertIn('case "device.output.port":', icon_factory)
        self.assertIn('symbol: "device.output.port"', plugged)
        self.assertIn('symbol: "device.output.port"', on_battery)
        self.assertNotIn('symbol: "cable.connector.horizontal"', plugged)
        self.assertNotIn('symbol: "cable.connector"', on_battery)

    def test_layout_positions_depend_only_on_layout(self):
        # Filling the gap left by a disconnected adapter puts the battery box
        # straight on top of the adapter's caption.
        self.assertIn("private func positions(for layout: FlowLayout)", self.source)
        self.assertIn("Self.adapterLedPositions", self.source)
        self.assertIn("Self.batteryLedPositions", self.source)

    def test_every_pipe_uses_the_same_cubic_shape(self):
        # Equal control-point counts are required for CAShapeLayer to
        # interpolate between topologies rather than snap.
        self.assertIn("path.move(to: start)", self.source)
        self.assertIn("path.addCurve(to: end, control1: control1, control2: control2)", self.source)
        self.assertEqual(self.source.count("PipeGeometry(start:"), 2)

    def test_plot_is_flipped(self):
        # Node and pipe coordinates are written with y growing downward. A
        # plain NSView mirrors the whole diagram vertically.
        self.assertIn("override var isFlipped: Bool { true }", self.source)
        self.assertIn("class FlippedPlot", self.source)

    def test_idle_battery_keeps_a_static_dashed_link(self):
        # The battery is still connected at full charge; drawing nothing would
        # claim otherwise.
        self.assertIn("idleConnection", self.source)
        self.assertIn("lineDashPattern = [3, 6]", self.source)

    def test_all_three_nodes_share_one_symbol_scale_and_visual_weight(self):
        # Adapter, System, and Battery are peers in the same 36-point wells.
        # A smaller unconfigured CPU symbol makes the three-node diagram look
        # like it mixes two unrelated icon families.
        self.assertIn(
            "NSImage.SymbolConfiguration(pointSize: 21, weight: .regular)",
            self.source,
        )
        self.assertIn("icon.frame = box.bounds", self.source)
        self.assertIn("icon.imageScaling = .scaleProportionallyDown", self.source)
        self.assertIn("withSymbolConfiguration(Self.powerIconConfiguration)", self.source)
        self.assertNotIn("usesEmphasizedPowerIcon", self.source)
        self.assertNotIn("? .scaleProportionallyDown", self.source)
        self.assertIn("private let icon = PowerIconImageView()", self.source)
        self.assertIn("icon.configurePowerIcon", self.source)
        self.assertIn("side: 32, inset: 4", self.source)
        self.assertIn("PowerIconImageView.image(for: symbol)", self.source)
        artwork = (ROOT / "Popover" / "PowerIconView.swift").read_text()
        for symbol in ("cpu", "powerplug", "powerplug.slash", "battery.100.bolt"):
            self.assertIn('case "' + symbol + '":', artwork)
        self.assertIn("PopoverStyle.neutral.usingColorSpace(.sRGB)", artwork)
        self.assertIn("accent.usingColorSpace(.sRGB)", artwork)


if __name__ == "__main__":
    unittest.main()
