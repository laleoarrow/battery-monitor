import pathlib
import unittest

ROOT = pathlib.Path(__file__).resolve().parents[1]
SETTINGS = ROOT / "Core" / "Settings.swift"
STATUS = ROOT / "MenuBar" / "StatusItemController.swift"
CONTENT = ROOT / "Popover" / "PopoverContentView.swift"


class MenuBarPercentageContractTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.settings = SETTINGS.read_text(encoding="utf-8")
        cls.status = STATUS.read_text(encoding="utf-8")
        cls.content = CONTENT.read_text(encoding="utf-8")

    def test_percentage_is_on_by_default(self):
        # Matches the system battery's "Show Percentage" once enabled.
        self.assertIn("as? Bool ?? true", self.settings)

    def test_percentage_sits_left_of_the_glyph(self):
        # The system puts the number before the battery, not after.
        self.assertIn(
            "button.imagePosition = presentation.showsPercentage ? .imageRight : .imageOnly",
            self.status,
        )

    def test_percentage_uses_tabular_digits(self):
        # Keep the exact menu-bar face and only switch its number-spacing
        # feature. A fully monospaced system font looks unlike its neighbours.
        self.assertIn("menuBarFont", self.status)
        self.assertIn("kMonospacedNumbersSelector", self.status)

    def test_title_is_plain_so_appkit_keeps_the_colour_right(self):
        # An attributed title would not invert under the pressed highlight and
        # would not follow light/dark on its own.
        self.assertNotIn("attributedTitle", self.status)

    def test_hiding_the_percentage_leaves_the_glyph_alone(self):
        self.assertIn(".imageRight : .imageOnly", self.status)

    def test_inline_style_does_not_repeat_the_percentage_outside_the_image(self):
        presentation = self.status.split("struct StatusButtonPresentation", 1)[1].split(
            "struct StartupAvailabilityReducer", 1
        )[0]
        self.assertIn("style: Settings.MenuBarIconStyle = .wattson", presentation)
        self.assertIn("showsPercentage && !style.embedsPercentage", presentation)
        self.assertIn('title = showsExternalPercentage ? "\\(snapshot.percent)% " : ""', presentation)

    def test_image_and_key_receive_one_consistent_percentage_setting(self):
        refresh = self.status.split("private func refreshStatusItem()", 1)[1].split(
            "#if DEBUG", 1
        )[0]
        self.assertEqual(refresh.count("Settings.showsMenuBarPercentage"), 1)
        self.assertEqual(refresh.count("showsPercentage: showsPercentage"), 3)
        self.assertIn("style: iconStyle", refresh)

    def test_inline_percentage_accessibility_follows_the_presentation_cache(self):
        refresh = self.status.split("private func refreshStatusItem()", 1)[1].split(
            "#if DEBUG", 1
        )[0]
        self.assertIn(
            "if presentation.accessibilityLabel != rendered?.accessibilityLabel",
            refresh,
        )
        self.assertIn("button.setAccessibilityLabel(presentation.accessibilityLabel)", refresh)
        unavailable = refresh.split("guard hasUsableSnapshot else {", 1)[1].split(
            "let mode = EnergyModeController.current", 1
        )[0]
        self.assertIn("if renderedStatusButtonPresentation?.accessibilityLabel != nil", unavailable)
        self.assertLess(
            unavailable.index("button.setAccessibilityLabel(nil)"),
            unavailable.index("renderedStatusButtonPresentation = nil"),
        )

    def test_status_item_redraws_when_the_setting_changes(self):
        self.assertIn("Settings.didChange", self.status)
        self.assertIn("static let didChange", self.settings)
        self.assertIn("NotificationCenter.default.post", self.settings)

    def test_toggle_is_reachable_from_the_popover(self):
        self.assertIn("Show Battery Percentage in Menu Bar", self.content)
        self.assertIn("Settings.showsMenuBarPercentage.toggle()", self.content)


if __name__ == "__main__":
    unittest.main()
