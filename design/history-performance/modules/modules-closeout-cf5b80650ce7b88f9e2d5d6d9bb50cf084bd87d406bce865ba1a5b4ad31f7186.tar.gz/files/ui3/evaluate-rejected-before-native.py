#!/usr/bin/env python3
"""Verify an already-released real gesture was safely rejected, never a drop pass."""
import argparse
import hashlib
import json
import math
from pathlib import Path

p = argparse.ArgumentParser()
p.add_argument("directory", type=Path)
p.add_argument("--case", required=True)
a = p.parse_args()
raw = {n: (a.directory / n).read_bytes() for n in ("state.json", "history.jsonl")}
s = json.loads(raw["state.json"])
h = [json.loads(line) for line in raw["history.jsonl"].splitlines() if line.strip()]
h = [x for x in h if x.get("case") == a.case]
default = ["flow", "ring", "lanes", "history", "runtime"]
base = next((x for x in h if x.get("orderWrites") == 0 and x.get("observedOwnWindowEventCount") == 0
             and x.get("savedOrder") == default and x.get("lastCommand", {}).get("result") == "applied"), {})
checks = {}
def check(name, value): checks[name] = bool(value)
def cleared(x):
    return x.get("available") is True and all(x.get(k) is True for k in
        ("draggedModuleIsNil", "originalOrderIsEmpty", "dragSessionIsNil"))
def rows(x): return {r["id"]: r for r in x.get("rows", [])}
check("sameCaseAndBaseline", s.get("case") == a.case and bool(base))
check("nativeObserverInstalled", s.get("nativeDragObservation", {}).get("installed") is True)
ho = s.get("nativeHandleObservation", {})
check("handleOriginalIMPForwarded", ho.get("installed") is True
    and ho.get("originalIMPInvokedExactlyOncePerObservedCallback") is True
    and ho.get("argumentsForwardedUnchanged") is True and ho.get("eventsGeneratedByFixture") is False)
check("zeroNativeBeginOrEnd", s.get("nativeDragSessionEvents") == [])
events = [e for e in s.get("nativeHandleEvents", []) if e.get("case") == a.case]
downs = [e for e in s.get("recentOwnWindowEvents", []) if e.get("type") == 1]
check("realMouseDownObserved", bool(downs))
released = []
if downs:
    origin = downs[0]
    for e in events:
        xy = e.get("eventLocationInWindow", [])
        if e.get("phase") in ("mouseDragged.enter", "mouseDragged.return") and len(xy) == 2:
            if math.hypot(xy[0] - origin["x"], xy[1] - origin["y"]) >= 4 and e.get("pressedMouseButtons", 1) & 1 == 0:
                released.append(e)
check("thresholdDragHandlerObservedReleasedLeftButton", bool(released))
check("realMouseUpHandlerDelivered", any(e.get("phase") == "mouseUp.enter" for e in events)
    and any(e.get("phase") == "mouseUp.return" and e.get("pressedMouseButtons", 1) & 1 == 0 for e in events))
check("stateCleared", cleared(s.get("dragState", {})))
check("noWriteOrNotification", s.get("orderWrites") == 0 and s.get("orderNotifications") == 0)
check("orderUnchanged", s.get("savedOrder") == default and s.get("displayOrder") == default)
r0, r1 = rows(base), rows(s)
check("fiveSameRows", len(r0) == len(r1) == 5 and set(r0) == set(r1)
    and all(r0[k].get("objectIdentity") == r1[k].get("objectIdentity") for k in r0))
check("alphaRestored", len(r1) == 5 and all(abs(x.get("alpha", 0) - 1) < .001 for x in r1.values()))
check("visibilityUnchanged", s.get("visibility") == base.get("visibility") and s.get("visibilityNotifications") == 0)
check("windowAndScrollRetained", s.get("windowIdentity") == base.get("windowIdentity")
    and s.get("settingsScrollViews") == base.get("settingsScrollViews") and s.get("visible") is True)
check("noMouseKeyboardCue", s.get("keyboardFocusVisible") == dict.fromkeys(default, False))
check("noInputInjection", s.get("syntheticInput") is False and s.get("directDragCallbacks") is False
    and all(e.get("syntheticInput") is False for e in events))
verdict = "rejected-before-native-verified" if all(checks.values()) else "unverified"
print(json.dumps({"schema": 1, "case": a.case, "verdict": verdict,
    "countsAsSuccessfulDrop": False, "checks": checks,
    "failedAssertions": [k for k, v in checks.items() if not v],
    "scope": "Real released-left-button handler observation and zero native session with unchanged state; not a successful drop.",
    "inputSHA256": {k: hashlib.sha256(v).hexdigest() for k, v in raw.items()}}, indent=2))
raise SystemExit(0 if all(checks.values()) else 78)
