#!/bin/bash
set -euo pipefail
repo='/Users/leoarrow/Project/mypackage/agents/电池功率'
review="$repo/.build/history-performance.noindex"
lifecycle="${WATTSON_VM_LIFECYCLE_DIR:-$review}"
case "$lifecycle" in "$review"|"$review/package-session"|"$review/package-session-queued-drag") ;; *) echo "Unowned lifecycle directory" >&2; exit 2;; esac
mkdir -p "$lifecycle"
vm='Wattson-HistoryPerf-20261016'
export TART_NO_AUTO_PRUNE=1
source "$repo/scripts/lib/local_cleanup.sh"
wattson_cleanup_init
owned_vm=0
return_status() { return "$1"; }
vm_cleanup() {
  local status=$? state=''
  trap - EXIT
  trap '' HUP INT TERM
  set +e
  if [[ -n "${_WATTSON_RUNNER_PID:-}" ]]; then kill -TERM "$_WATTSON_RUNNER_PID" 2>/dev/null; wait "$_WATTSON_RUNNER_PID" 2>/dev/null; _WATTSON_RUNNER_PID=''; fi
  if [[ "$owned_vm" == 1 ]]; then
    if tart list --format json > "$lifecycle/vms-cleanup-current.json"; then
      state="$(/usr/bin/python3 "$review/vm-state.py" state "$lifecycle/vms-cleanup-current.json")" || status=1
      if [[ "$state" == running ]]; then wattson_run_timeout 45 tart stop "$vm" --timeout 20 >> "$lifecycle/vm-cleanup.log" 2>&1 || status=1; fi
      if tart list --format json > "$lifecycle/vms-cleanup-after-stop.json"; then
        state="$(/usr/bin/python3 "$review/vm-state.py" state "$lifecycle/vms-cleanup-after-stop.json")" || status=1
        case "$state" in stopped) wattson_run_timeout 45 tart delete "$vm" >> "$lifecycle/vm-cleanup.log" 2>&1 || status=1;; missing) ;; *) status=1;; esac
      else status=1; fi
    else status=1; fi
    if tart list --format json > "$lifecycle/vms-after-cleanup.json"; then /usr/bin/python3 "$review/vm-state.py" after "$lifecycle/vms-before.json" "$lifecycle/vms-after-cleanup.json" > "$lifecycle/vm-cleanup-summary.json" 2> "$lifecycle/vm-cleanup-summary.err" || status=1; else status=1; fi
  fi
  printf '%s\n' "$status" > "$lifecycle/vm-session-exit-code.txt"
  return_status "$status"
  _wattson_cleanup
}
trap vm_cleanup EXIT
mkdir -p "$review"
tart list --format json > "$lifecycle/vms-before.json"
/usr/bin/python3 "$review/vm-state.py" preflight "$lifecycle/vms-before.json"
printf '%s\n' "$$" > "$lifecycle/vm-session.pid"
owned_vm=1
wattson_run_timeout 300 tart clone macOS-TestLab-Base "$vm" > "$lifecycle/vm-clone.log" 2>&1
echo "OWNED_VM_CREATED $vm"
wattson_run_timeout 28800 tart run --no-graphics --no-audio --no-clipboard --dir "repo:$repo:ro" --dir "performance:$review" "$vm" > "$lifecycle/vm-run.log" 2>&1
