import hashlib, json, tarfile
from pathlib import Path
base = Path(__file__).resolve().parent
packages = base.parent / 'package-validation'
source_files = {}
for path in sorted(packages.glob('package-results-*.tar.gz')):
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    assert path.name.endswith('-' + digest + '.tar.gz')
    source_files[str(path.relative_to(base.parent))] = digest
for label in ['preliminary-c8e-r2', 'final-91f-r2']:
    ownership = packages / (label + '-ownership-cleanup.json')
    record = json.loads(ownership.read_text())
    assert record['ownedGuestUserDomains'] == ['com.leoarrow.wattson', 'com.leoarrow.Wattson']
    assert record['ownedGuestReceipt'] == 'com.leoarrow.wattson.pkg'
    source_files[str(ownership.relative_to(base.parent))] = hashlib.sha256(ownership.read_bytes()).hexdigest()
home = '/Users/admin'
paths = ['/Applications/Wattson.app', '/Library/PrivilegedHelperTools/com.leoarrow.wattson.helper', '/Library/LaunchDaemons/com.leoarrow.wattson.helper.plist', '/var/run/wattson-helper.sock']
for domain in ['com.leoarrow.Wattson', 'com.leoarrow.wattson']:
    paths += [home + '/Library/' + x for x in ['Preferences/' + domain + '.plist', 'Containers/' + domain, 'Application Scripts/' + domain]]
paths += [home + '/Library/Application Support/Wattson', home + '/Library/LaunchAgents/com.leoarrow.wattson.login.plist']
resources = {'guestProject': home + '/Project/Wattson-HistoryPerf-QA', 'ownedDomains': ['com.leoarrow.Wattson', 'com.leoarrow.wattson'], 'ownedPaths': paths, 'ownedReceipt': 'com.leoarrow.wattson.pkg', 'ownedHelperLabel': 'com.leoarrow.wattson.helper', 'sourceFiles': source_files, 'scope': 'Union of preliminary and final package attempts in the owner disposable VM; never execute on host'}
content = (json.dumps(resources, indent=2) + '\n').encode()
probe = (base / 'package-audit-probe.py').read_bytes()
key = hashlib.sha256(content + probe).hexdigest()
stage = base / 'audit-inputs' / key
stage.mkdir(parents=True, exist_ok=False)
(stage / 'owned-package-resources.json').write_bytes(content)
(stage / 'package-audit-probe.py').write_bytes(probe)
files = {x.name: hashlib.sha256(x.read_bytes()).hexdigest() for x in stage.iterdir()}
archive = stage / 'audit-tools.tar.gz'
with tarfile.open(archive, 'w:gz') as t:
    for name in files: t.add(stage / name, arcname=name)
manifest = {'archive': str(archive.relative_to(base.parent)), 'archiveSHA256': hashlib.sha256(archive.read_bytes()).hexdigest(), 'files': files, 'bootstrapSHA256': hashlib.sha256((base / 'bootstrap-package-audit.py').read_bytes()).hexdigest()}
(base / 'audit-freeze.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps(manifest, indent=2))
