import hashlib, json, subprocess
from pathlib import Path
base = Path(__file__).resolve().parent
manifest = json.loads((base / 'audit-freeze.json').read_text())
code = (base / 'bootstrap-package-audit.py').read_text()
assert hashlib.sha256(code.encode()).hexdigest() == manifest['bootstrapSHA256']
assert hashlib.sha256((base.parent / manifest['archive']).read_bytes()).hexdigest() == manifest['archiveSHA256']
assert not (base / 'final-owned-residual-audit.json').exists()
raise SystemExit(subprocess.call(['tart', 'exec', 'Wattson-HistoryPerf-20261016', '/usr/bin/python3', '-c', code, json.dumps(manifest)]))
