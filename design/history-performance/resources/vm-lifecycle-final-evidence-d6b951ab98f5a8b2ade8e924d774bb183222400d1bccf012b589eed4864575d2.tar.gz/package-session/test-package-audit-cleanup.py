"""Execute the actual bootstrap finally AST against owned temporary fixtures."""
import ast, json, shutil, signal, subprocess, tempfile
from pathlib import Path
base = Path(__file__).resolve().parent
module = ast.parse((base / 'bootstrap-package-audit.py').read_text())
final = next(n.finalbody for n in module.body if isinstance(n, ast.Try))
cases = []
class BadExport:
    def __truediv__(self, other): return self
    def exists(self): return False
    def write_text(self, text): raise OSError('injected export failure')
class CleanThenFail:
    @staticmethod
    def rmtree(path):
        shutil.rmtree(path)
        raise OSError('injected cleanup report failure')
for original in [0, 23, 129, 130, 143]:
    for fail_cleanup in [False, True]:
        for fail_export in [False, True]:
            with tempfile.TemporaryDirectory(prefix='cleanup-check.', dir=base) as directory:
                fixture = Path(directory); project = fixture / 'project'
                parents = [project, project / '.build', project / '.build/audit.noindex']
                run = parents[-1] / 'run.test'; run.mkdir(parents=True)
                (run / 'sentinel').write_text('owned')
                share = fixture / 'share'; (share / 'package-session').mkdir(parents=True)
                env = dict(status=original, signals=[], signal=signal, child=None, shutil=CleanThenFail if fail_cleanup else shutil, run=run, created=parents, record={'originalExit': original}, share=BadExport() if fail_export else share, json=json, sys=__import__('sys'))
                body = [ast.Raise(exc=ast.Call(func=ast.Name(id='SystemExit', ctx=ast.Load()), args=[ast.Constant(original)], keywords=[]))] if original else [ast.Pass()]
                code = ast.fix_missing_locations(ast.Module(body=[ast.Try(body=body, handlers=[], orelse=[], finalbody=final)], type_ignores=[]))
                caught = None
                try: exec(compile(code, '<actual-finally-AST>', 'exec'), env)
                except SystemExit as error: caught = error.code
                expected = original or (1 if fail_cleanup or fail_export else 0)
                assert env['status'] == expected
                assert caught == (original if original else None)
                assert not run.exists() and all(not p.exists() for p in parents)
                cases.append(dict(original=original, failCleanup=fail_cleanup, failExport=fail_export, result=env['status'], allOwnedStagingRemoved=True))
result = {'actualFinallyAST': True, 'caseCount': len(cases), 'allPassed': True, 'cases': cases}
(base / 'cleanup-failure-check.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'caseCount': len(cases), 'allPassed': True}))
