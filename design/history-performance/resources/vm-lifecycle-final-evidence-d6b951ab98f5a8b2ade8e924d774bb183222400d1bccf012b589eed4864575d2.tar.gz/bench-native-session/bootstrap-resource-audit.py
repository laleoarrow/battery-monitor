# Saved minimal transport: verify the archived audit code/data in guest-local scratch.
import hashlib,json,os,shutil,signal,subprocess,sys,tarfile,tempfile
from pathlib import Path
manifest=json.loads(sys.argv[1]);label=sys.argv[2]
share=Path('/Volumes/My Shared Files/performance');project=Path.home()/'Project/Wattson-HistoryPerf-QA'
root=project/'.build/resource-audit.noindex';root.mkdir(parents=True,exist_ok=True)
run=Path(tempfile.mkdtemp(prefix='run.',dir=root));child=None;status=1
signals=[signal.SIGHUP,signal.SIGINT,signal.SIGTERM]
def interrupted(number,frame):
 global status
 status=128+number
 raise SystemExit(status)
for number in signals:signal.signal(number,interrupted)
try:
 archive=run/'audit.tar.gz';shutil.copyfile(share/manifest['archive'],archive)
 assert hashlib.sha256(archive.read_bytes()).hexdigest()==manifest['archiveSHA256']
 with tarfile.open(archive,'r:gz') as t:
  assert set(t.getnames())==set(manifest['files'])
  for m in t.getmembers():
   assert m.isfile() and m.name in manifest['files'];(run/m.name).write_bytes(t.extractfile(m).read())
 assert {name:hashlib.sha256((run/name).read_bytes()).hexdigest() for name in manifest['files']}==manifest['files']
 blocked=signal.pthread_sigmask(signal.SIG_BLOCK,signals)
 try:child=subprocess.Popen(['/usr/bin/python3',str(run/'audit-guest-resources.py'),str(run/'owned-resources.json')],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,start_new_session=True)
 finally:signal.pthread_sigmask(signal.SIG_SETMASK,blocked)
 stdout,stderr=child.communicate(timeout=200);status=child.returncode
 try:audit=json.loads(stdout)
 except json.JSONDecodeError:audit={'probeDidNotProduceJSON':True,'stdout':stdout}
 record={'probeExitCode':status,'audit':audit,'stderr':stderr,'toolArchiveSHA256':manifest['archiveSHA256'],'verifiedGuestLocalBeforeExecution':True,'label':label}
 output=share/('owned-resource-audit-'+label+'.json');assert not output.exists();output.write_text(json.dumps(record,indent=2)+'\n')
 print(json.dumps({'label':label,'probeExitCode':status,'allAbsent':audit.get('allAbsent'),'ownedDomains':len(audit.get('ownedDomains',[]))}),flush=True)
finally:
 for number in signals:signal.signal(number,signal.SIG_IGN)
 try:
  if child is not None:
   if child.poll() is None:
    try:os.killpg(child.pid,signal.SIGTERM)
    except ProcessLookupError:pass
    try:child.wait(timeout=5)
    except subprocess.TimeoutExpired:pass
   try:os.killpg(child.pid,signal.SIGKILL)
   except ProcessLookupError:pass
   child.wait(timeout=5)
 finally:shutil.rmtree(run)
raise SystemExit(status)
