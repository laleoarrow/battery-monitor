import hashlib,json,re,tarfile
from pathlib import Path
base=Path(__file__).resolve().parent
sources=[]
for label in ['baseline-a1','optimized-b1','optimized-b2','baseline-a2','baseline-counts','optimized-counts']:
 sources.append(base/'evidence'/label/'results/owned-bundle.tsv')
ids=set();apps=set();hashes={}
def collect(name,data):
 hashes[name]=hashlib.sha256(data).hexdigest()
 for line in data.decode().splitlines():
  columns=line.split('\t');identifier=columns[0].strip()
  assert re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9.-]+',identifier),identifier
  ids.add(identifier)
  if len(columns)>1:apps.add(columns[1])
for source in sources:
 assert source.is_file();collect(str(source.relative_to(base)),source.read_bytes())
for metadata in sorted((base/'native-review').glob('result-*.json')):
 record=json.loads(metadata.read_text());archive=base/record['archive']
 assert hashlib.sha256(archive.read_bytes()).hexdigest()==record['sha256']
 with tarfile.open(archive,'r:gz') as t:
  for m in t.getmembers():
   if m.isfile() and (m.name.endswith('/capture-bundles.tsv') or m.name.endswith('/owned-domains.txt')):
    collect(record['archive']+'!'+m.name,t.extractfile(m).read())
manifest={'ownedDomains':sorted(ids),'ownedAppPaths':sorted(apps),'sourceFiles':hashes}
encoded=json.dumps(manifest,indent=2)+'\n';key=hashlib.sha256(encoded.encode()).hexdigest();target=base/'resource-audit-inputs'/key
assert not target.exists();target.mkdir(parents=True)
(target/'owned-resources.json').write_text(encoded);(target/'audit-guest-resources.py').write_bytes((base/'audit-guest-resources.py').read_bytes())
files={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in target.iterdir()}
archive=target/'audit-tools.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for name in files:t.add(target/name,arcname=name)
record={'archive':str(archive.relative_to(base)),'archiveSHA256':hashlib.sha256(archive.read_bytes()).hexdigest(),'files':files,'ownedDomains':len(ids),'ownedApps':len(apps)}
(base/'resource-audit-freeze.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record,indent=2))
