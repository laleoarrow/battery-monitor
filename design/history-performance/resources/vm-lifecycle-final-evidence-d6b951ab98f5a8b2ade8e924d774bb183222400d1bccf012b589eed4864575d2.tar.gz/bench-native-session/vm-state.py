import json,sys
from pathlib import Path
name='Wattson-HistoryPerf-20261016';mode=sys.argv[1];before=json.loads(Path(sys.argv[2]).read_text());vms={v['Name']:v for v in before}
if mode=='preflight':
 assert name not in vms, 'Owned name exists, refuse reuse'
 assert vms['macOS-TestLab-Base']['State']=='stopped'
 assert sum(bool(v['Running']) for v in before) < 2, 'No free VM slot'
elif mode=='state': print(vms[name]['State'] if name in vms else 'missing')
elif mode=='after':
 current={v['Name']:v for v in json.loads(Path(sys.argv[3]).read_text())}
 assert name not in current and set(vms).issubset(current)
 checks={n:v['State']==current[n]['State'] and v['Running']==current[n]['Running'] for n,v in vms.items()}
 assert all(checks.values()), 'Other VM state changed; never repair automatically'
 print(json.dumps({'ownedVM':name,'cloneRemoved':True,'othersPreserved':checks},sort_keys=True))
