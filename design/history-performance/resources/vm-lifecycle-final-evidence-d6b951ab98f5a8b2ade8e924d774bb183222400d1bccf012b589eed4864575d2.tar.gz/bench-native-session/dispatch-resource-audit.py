import hashlib,json,re,subprocess,sys
from pathlib import Path
base=Path(__file__).resolve().parent;label=sys.argv[1]
assert re.fullmatch(r'[A-Za-z0-9]+(?:-[A-Za-z0-9]+)*',label)
manifest=json.loads((base/'resource-audit-freeze.json').read_text());code=(base/'bootstrap-resource-audit.py').read_text()
assert not (base/('owned-resource-audit-'+label+'.json')).exists()
(base/('dispatch-owned-resource-audit-'+label+'.json')).write_text(json.dumps({'manifest':manifest,'bootstrapSHA256':hashlib.sha256(code.encode()).hexdigest(),'label':label},indent=2)+'\n')
raise SystemExit(subprocess.call(['tart','exec','Wattson-HistoryPerf-20261016','/usr/bin/python3','-c',code,json.dumps(manifest),label]))
