import datetime,json,os,subprocess,sys,time
from pathlib import Path
root=Path.home()/'Project/Wattson-HistoryPerf-QA'
manifest=json.loads(Path(sys.argv[1]).read_text());ids=manifest['ownedDomains'];app_paths=manifest['ownedAppPaths']
assert all(len(x)>5 and all(c.isalnum() or c in '.-' for c in x) for x in ids)
assert all(p.startswith(str(root)+'/') and p.endswith('.app') for p in app_paths)
record={'schema':1,'atUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'monotonicTime':time.monotonic(),'ownedDomains':ids,'ownedAppPaths':app_paths,'manifestSourceFiles':manifest['sourceFiles'],'ownedDomainState':{},'guestProject':str(root)}
for identifier in ids:
 result=subprocess.run(['/usr/bin/defaults','read',identifier],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,timeout=10)
 paths=[Path.home()/'Library/Preferences'/(identifier+'.plist'),Path.home()/'Library/Containers'/identifier,Path.home()/'Library/Application Scripts'/identifier]
 record['ownedDomainState'][identifier]={'defaultsReadExit':result.returncode,'existingOwnedPaths':[str(p) for p in paths if p.exists() or p.is_symlink()]}
registrar='/System/Library/Frameworks/CoreServices.framework/Frameworks/LaunchServices.framework/Support/lsregister'
registry=subprocess.run([registrar,'-dump'],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,encoding='utf-8',errors='replace',timeout=45)
record['launchServicesAuditExit']=registry.returncode
record['remainingOwnedLaunchServicesIDs']=[identifier for identifier in ids if identifier.casefold() in registry.stdout.casefold()]
query=' || '.join('(kMDItemCFBundleIdentifier == "'+x+'")' for x in ids)
spotlight=subprocess.run(['/usr/bin/mdfind',query],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,encoding='utf-8',errors='replace',timeout=20)
record['spotlightAuditExit']=spotlight.returncode;record['remainingOwnedSpotlightApps']=spotlight.stdout.splitlines()
record['remainingOwnedAppPaths']=[p for p in app_paths if Path(p).exists() or Path(p).is_symlink()]
record['remainingProjectApps']=[str(p) for p in root.rglob('*.app')]
self_root=Path(__file__).resolve().parent
record['remainingOwnedRunDirectories']=[str(p) for p in (root/'.build').rglob('run.*') if p.is_dir() and self_root not in p.parents and p!=self_root and p not in self_root.parents]
ps=subprocess.check_output(['/bin/ps','-axo','pid=,ppid=,uid=,comm=,args='],text=True,timeout=10)
rows={}
for line in ps.splitlines():
 values=line.split(None,4)
 if len(values)==5:rows[int(values[0])]={'ppid':int(values[1]),'uid':int(values[2]),'comm':values[3],'args':values[4]}
ancestors={os.getpid()};current=os.getpid()
while current in rows and rows[current]['ppid'] not in ancestors:
 current=rows[current]['ppid'];ancestors.add(current)
record['remainingOwnedProcesses']=[{'pid':pid,**v} for pid,v in rows.items() if pid not in ancestors and str(root) in v['args']]
mounts=subprocess.check_output(['/sbin/mount'],text=True,timeout=10)
record['remainingProjectMounts']=[line for line in mounts.splitlines() if str(root) in line]
record['allAbsent']=all(v['defaultsReadExit']!=0 and not v['existingOwnedPaths'] for v in record['ownedDomainState'].values()) and registry.returncode==0 and not record['remainingOwnedLaunchServicesIDs'] and spotlight.returncode==0 and not record['remainingOwnedSpotlightApps'] and not record['remainingOwnedAppPaths'] and not record['remainingProjectApps'] and not record['remainingOwnedRunDirectories'] and not record['remainingOwnedProcesses'] and not record['remainingProjectMounts']
print(json.dumps(record,indent=2));raise SystemExit(0 if record['allAbsent'] else 1)
