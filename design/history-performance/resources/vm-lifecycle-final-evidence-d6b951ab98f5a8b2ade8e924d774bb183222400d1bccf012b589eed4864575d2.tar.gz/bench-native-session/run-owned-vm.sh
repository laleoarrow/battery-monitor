#!/bin/bash
set -euo pipefail
repo='/Users/leoarrow/Project/mypackage/agents/电池功率'
review="$repo/.build/history-performance.noindex"
vm='Wattson-HistoryPerf-20261016'
export TART_NO_AUTO_PRUNE=1
source "$repo/scripts/lib/local_cleanup.sh"
wattson_cleanup_init
owned_vm=0
return_status() { return "$1"; }
vm_cleanup() {
  local status=$? state=''
  trap - EXIT
  trap '' HUP INT TERM
  set +e
  if [[ -n "${_WATTSON_RUNNER_PID:-}" ]]; then kill -TERM "$_WATTSON_RUNNER_PID" 2>/dev/null; wait "$_WATTSON_RUNNER_PID" 2>/dev/null; _WATTSON_RUNNER_PID=''; fi
  if [[ "$owned_vm" == 1 ]]; then
    if tart list --format json > "$review/vms-cleanup-current.json"; then
      state="$(/usr/bin/python3 "$review/vm-state.py" state "$review/vms-cleanup-current.json")" || status=1
      if [[ "$state" == running ]]; then wattson_run_timeout 45 tart stop "$vm" --timeout 20 >> "$review/vm-cleanup.log" 2>&1 || status=1; fi
      if tart list --format json > "$review/vms-cleanup-after-stop.json"; then
        state="$(/usr/bin/python3 "$review/vm-state.py" state "$review/vms-cleanup-after-stop.json")" || status=1
        case "$state" in stopped) wattson_run_timeout 45 tart delete "$vm" >> "$review/vm-cleanup.log" 2>&1 || status=1;; missing) ;; *) status=1;; esac
      else status=1; fi
    else status=1; fi
    if tart list --format json > "$review/vms-after-cleanup.json"; then /usr/bin/python3 "$review/vm-state.py" after "$review/vms-before.json" "$review/vms-after-cleanup.json" > "$review/vm-cleanup-summary.json" 2> "$review/vm-cleanup-summary.err" || status=1; else status=1; fi
  fi
  printf '%s\n' "$status" > "$review/vm-session-exit-code.txt"
  return_status "$status"
  _wattson_cleanup
}
trap vm_cleanup EXIT
mkdir -p "$review"
tart list --format json > "$review/vms-before.json"
/usr/bin/python3 "$review/vm-state.py" preflight "$review/vms-before.json"
printf '%s\n' "$$" > "$review/vm-session.pid"
owned_vm=1
wattson_run_timeout 300 tart clone macOS-TestLab-Base "$vm" > "$review/vm-clone.log" 2>&1
echo "OWNED_VM_CREATED $vm"
wattson_run_timeout 28800 tart run --no-graphics --no-audio --no-clipboard --dir "repo:$repo:ro" --dir "performance:$review" "$vm" > "$review/vm-run.log" 2>&1
