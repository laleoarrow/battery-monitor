from pathlib import Path
import json, os, subprocess, sys, time
from datetime import datetime, timezone

assert os.getuid() != 0
assert subprocess.check_output(['/usr/sbin/sysctl', '-n', 'hw.model'], text=True).strip().startswith('VirtualMac')
output, scratch = map(Path, sys.argv[1:3])
assert not output.exists()
delay = float(sys.argv[3]) if len(sys.argv) == 4 else 0
assert delay in (0, 5)
delay_start = time.clock_gettime(time.CLOCK_MONOTONIC)
if delay:
    time.sleep(delay)
delay_elapsed = time.clock_gettime(time.CLOCK_MONOTONIC) - delay_start
assert delay_elapsed >= delay
paths = [Path(p) for p in ['/Applications/Wattson.app', '/Library/PrivilegedHelperTools/com.leoarrow.wattson.helper', '/Library/LaunchDaemons/com.leoarrow.wattson.helper.plist', '/var/run/wattson-helper.sock']]
paths += [Path.home() / p for p in ['Library/Preferences/com.leoarrow.wattson.plist', 'Library/Preferences/com.leoarrow.Wattson.plist', 'Library/Containers/com.leoarrow.wattson', 'Library/Application Scripts/com.leoarrow.wattson', 'Library/Application Support/Wattson', 'Library/LaunchAgents/com.leoarrow.wattson.login.plist']]
residuals = [str(p) for p in paths + [scratch] if p.exists() or p.is_symlink()]
receipt = subprocess.run(['/usr/sbin/pkgutil', '--pkg-info', 'com.leoarrow.wattson.pkg'], capture_output=True, text=True, timeout=15)
job = subprocess.run(['/usr/bin/sudo', '-n', '/bin/launchctl', 'print', 'system/com.leoarrow.wattson.helper'], capture_output=True, text=True, timeout=15)
listing = subprocess.check_output(['/bin/ps', '-axo', 'pid=,comm='], text=True)
processes = [line.strip() for line in listing.splitlines() if any(p in line for p in ['/Applications/Wattson.app/Contents/MacOS/Wattson', '/Library/PrivilegedHelperTools/com.leoarrow.wattson.helper'])]
registrar = '/System/Library/Frameworks/CoreServices.framework/Frameworks/LaunchServices.framework/Support/lsregister'
registrations = [line.strip() for line in subprocess.check_output([registrar, '-dump'], text=True).splitlines() if any(p in line for p in ['/Applications/Wattson.app', str(scratch)])]
checks = {'ownedPathsRemoved': not residuals, 'receiptRemoved': receipt.returncode != 0, 'helperJobRemoved': job.returncode != 0, 'ownedProcessesRemoved': not processes, 'ownedRegistrationsRemoved': not registrations}
record = {'schema': 1, 'atUTC': datetime.now(timezone.utc).isoformat(), 'atSystemMonotonic': time.clock_gettime(time.CLOCK_MONOTONIC), 'requestedDelaySeconds': delay, 'withinProcessDelaySeconds': delay_elapsed, 'checks': checks, 'allPassed': all(checks.values()), 'residualPaths': residuals, 'residualProcesses': processes, 'residualRegistrations': registrations, 'deletedAnything': False}
output.write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record))
raise SystemExit(0 if record['allPassed'] else 1)
