from pathlib import Path
import os, shutil, subprocess

assert os.getuid() == 0
assert subprocess.check_output(['/usr/sbin/sysctl', '-n', 'hw.model'], text=True).strip().startswith('VirtualMac')
for name in ['/Applications/Wattson.app', '/Library/PrivilegedHelperTools/com.leoarrow.wattson.helper', '/Library/LaunchDaemons/com.leoarrow.wattson.helper.plist', '/var/run/wattson-helper.sock']:
    path = Path(name)
    if path.is_symlink() or path.is_file() or path.is_socket():
        path.unlink()
    elif path.is_dir():
        shutil.rmtree(path)
