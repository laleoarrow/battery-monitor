from pathlib import Path
import json, re, sys

assert len(sys.argv) == 3 and sys.argv[2] in ('enabled', 'disabled')
label = 'com.leoarrow.wattson.helper'
lines = [line for line in Path(sys.argv[1]).read_text().splitlines() if f'"{label}"' in line]
if len(lines) != 1:
    raise SystemExit('Expected exactly one helper disabled-state entry')
match = re.fullmatch(r'\s*"' + re.escape(label) + r'"\s*=>\s*(true|false|disabled|enabled)\s*', lines[0])
if match is None:
    raise SystemExit('Unknown helper disabled-state entry')
actual = 'disabled' if match.group(1) in ('true', 'disabled') else 'enabled'
if actual != sys.argv[2]:
    raise SystemExit(f'Expected helper {sys.argv[2]}, got {actual}')
print(json.dumps({'label': label, 'expected': sys.argv[2], 'actual': actual, 'rawValue': match.group(1), 'uniqueExactEntry': True}))
