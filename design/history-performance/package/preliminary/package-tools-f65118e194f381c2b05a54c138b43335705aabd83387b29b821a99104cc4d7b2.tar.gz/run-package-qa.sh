#!/bin/bash
# Run only in the explicitly owned disposable ARM VM, with guest-local inputs.
set -euo pipefail
[[ $# == 8 && "$2" =~ ^[a-f0-9]{64}$ && "$5" =~ ^[a-f0-9]{64}$ && "$8" =~ ^[a-f0-9]{40}$ ]] || exit 64
incoming="$1"; expected_sha="$2"; expected_version="$3"
previous="$4"; previous_sha="$5"; previous_version="$6"; results="$7"; frozen_commit="$8"
[[ "$expected_version" =~ ^[0-9]+\.[0-9]+\.[0-9]+$ && "$previous_version" =~ ^[0-9]+\.[0-9]+\.[0-9]+$ ]] || exit 64
project="$HOME/Project/Wattson-HistoryPerf-QA"
[[ "$incoming" == "$project/.build/"* && "$previous" == "$project/.build/"* && "$results" == "$project/.build/"* ]] || exit 65
[[ "$(/usr/sbin/sysctl -n hw.model)" == VirtualMac* && "$(/usr/bin/uname -m)" == arm64 && "$(/usr/bin/id -u)" != 0 ]] || exit 65
[[ ! -e "$results" && ! -L "$results" ]] || exit 65
tools="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
app='/Applications/Wattson.app'; helper='/Library/PrivilegedHelperTools/com.leoarrow.wattson.helper'; plist='/Library/LaunchDaemons/com.leoarrow.wattson.helper.plist'
label='com.leoarrow.wattson.helper'; receipt='com.leoarrow.wattson.pkg'
assert_absent() {
 for path in "$app" "$helper" "$plist" '/var/run/wattson-helper.sock' "$HOME/Library/Preferences/com.leoarrow.wattson.plist" "$HOME/Library/Preferences/com.leoarrow.Wattson.plist" "$HOME/Library/Containers/com.leoarrow.wattson" "$HOME/Library/Application Scripts/com.leoarrow.wattson" "$HOME/Library/Application Support/Wattson" "$HOME/Library/LaunchAgents/com.leoarrow.wattson.login.plist"; do [[ ! -e "$path" && ! -L "$path" ]] || { echo "Unexpected preexisting path: $path" >&2; return 65; }; done
 ! /usr/sbin/pkgutil --pkg-info "$receipt" >/dev/null 2>&1 || return 65
 ! /usr/bin/sudo -n /bin/launchctl print "system/$label" >/dev/null 2>&1 || return 65
}
/usr/bin/sudo -n /usr/bin/true
assert_absent
source "$tools/lib/local_cleanup.sh"
wattson_cleanup_init
mkdir "$results"
scratch="$(mktemp -d "$project/.build/package-scratch.noindex.XXXXXX")"
wattson_cleanup_add_dir "$scratch"
wattson_cleanup_add_container com.leoarrow.wattson
wattson_cleanup_add_defaults com.leoarrow.wattson
wattson_cleanup_add_defaults com.leoarrow.Wattson
wattson_cleanup_add_dir "$HOME/Library/Application Support/Wattson"
wattson_cleanup_add_dir "$HOME/Library/LaunchAgents/com.leoarrow.wattson.login.plist"
owned_install=0
return_status() { return "$1"; }
remove_install() {
 local mode="$1" failed=0
 [[ "$owned_install" == 1 ]] || return 0
 wattson_stop_executable "$app/Contents/MacOS/Wattson" || failed=1
 wattson_unregister_app "$app" || failed=1
 wattson_run_timeout 20 /usr/bin/sudo -n /bin/launchctl bootout "system/$label" > "$results/$mode-bootout.log" 2>&1 || {
  ! /usr/bin/sudo -n /bin/launchctl print "system/$label" >/dev/null 2>&1 || failed=1
 }
 wattson_run_timeout 20 /usr/bin/sudo -n /usr/bin/python3 "$tools/lib/run_owned.py" --stop-executable "$helper" || failed=1
 wattson_run_timeout 20 /usr/bin/sudo -n /bin/launchctl enable "system/$label" || failed=1
 wattson_run_timeout 20 /usr/bin/sudo -n /usr/bin/python3 "$tools/remove-owned-install.py" || failed=1
 if /usr/sbin/pkgutil --pkg-info "$receipt" >/dev/null 2>&1; then
  wattson_run_timeout 20 /usr/bin/sudo -n /usr/sbin/pkgutil --forget "$receipt" > "$results/$mode-forget.log" 2>&1 || failed=1
 fi
 [[ "$failed" != 0 ]] || owned_install=0
 return "$failed"
}
finish() {
 local status=$?
 trap - EXIT
 trap '' HUP INT TERM
 set +e
 mark_cleanup_failure() { if [[ "$status" == 0 ]]; then status=1; fi; }
 if [[ -n "${_WATTSON_RUNNER_PID:-}" ]]; then kill -TERM "$_WATTSON_RUNNER_PID" 2>/dev/null; wait "$_WATTSON_RUNNER_PID" 2>/dev/null; _WATTSON_RUNNER_PID=''; fi
 remove_install final-cleanup >> "$results/final-cleanup.log" 2>&1 || mark_cleanup_failure
 (return_status "$status"; _wattson_cleanup) > "$results/scratch-cleanup.log" 2>&1 || mark_cleanup_failure
 /usr/bin/python3 "$tools/audit-install.py" "$results/cleanup-immediate.json" "$scratch" > "$results/cleanup-immediate.log" 2>&1 || mark_cleanup_failure
 /bin/sleep 5
 /usr/bin/python3 "$tools/audit-install.py" "$results/cleanup-delayed.json" "$scratch" > "$results/cleanup-delayed.log" 2>&1 || mark_cleanup_failure
 printf '%s\n' "$status" > "$results/exit-code.txt"
 exit "$status"
}
trap finish EXIT
[[ "$(/usr/bin/shasum -a 256 "$incoming" | /usr/bin/awk '{print $1}')" == "$expected_sha" && "$(/usr/bin/shasum -a 256 "$previous" | /usr/bin/awk '{print $1}')" == "$previous_sha" ]] || exit 65
printf '%s\n' "$frozen_commit" > "$results/source-commit.txt"
/usr/bin/shasum -a 256 "$incoming" "$previous" > "$results/package-inputs.sha256"
/usr/sbin/ioreg -r -c AppleSmartBattery > "$results/AppleSmartBattery.txt"
[[ ! -s "$results/AppleSmartBattery.txt" ]] || exit 65
printf '%s\n' 'This VirtualMac has no AppleSmartBattery. Normal app residency is inapplicable; physical battery Mac readiness is verified separately. This matrix tests native package/helper/payload/receipt/signatures.' > "$results/readiness-boundary.txt"
wattson_run_timeout 120 /usr/sbin/pkgutil --expand-full "$incoming" "$scratch/candidate-expanded"
wattson_run_timeout 120 /usr/sbin/pkgutil --expand-full "$previous" "$scratch/previous-expanded"
verify_install() {
 local mode="$1" package="$2" version="$3" expanded="$4" payload_app payload_helper payload_plist
 payload_app="$(/usr/bin/find "$expanded" -type d -path '*/Payload/Applications/Wattson.app' -print)"
 payload_helper="$(/usr/bin/find "$expanded" -type f -path '*/Payload/Library/PrivilegedHelperTools/com.leoarrow.wattson.helper' -print)"
 payload_plist="$(/usr/bin/find "$expanded" -type f -path '*/Payload/Library/LaunchDaemons/com.leoarrow.wattson.helper.plist' -print)"
 [[ -d "$payload_app" && -f "$payload_helper" && -f "$payload_plist" ]]
 owned_install=1
 wattson_run_timeout 180 /usr/bin/sudo -n /usr/sbin/installer -pkg "$package" -target / > "$results/$mode-installer.log" 2>&1
 [[ "$(/usr/libexec/PlistBuddy -c 'Print :CFBundleShortVersionString' "$app/Contents/Info.plist")" == "$version" && "$(/usr/libexec/PlistBuddy -c 'Print :CFBundleVersion' "$app/Contents/Info.plist")" == "$version" ]]
 /usr/sbin/pkgutil --pkg-info "$receipt" > "$results/$mode-receipt.log"
 /usr/bin/grep -Fxq "version: $version" "$results/$mode-receipt.log"
 wattson_run_timeout 20 /usr/bin/codesign --verify --deep --strict "$app" > "$results/$mode-app-signature.log" 2>&1
 wattson_run_timeout 20 /usr/bin/codesign --verify --strict "$helper" > "$results/$mode-helper-signature.log" 2>&1
 wattson_run_timeout 20 "$app/Contents/MacOS/Wattson" --helper-health-probe > "$results/$mode-health.log" 2>&1
 wattson_run_timeout 20 "$app/Contents/MacOS/Wattson" --helper-v5-observation-probe > "$results/$mode-v5.log" 2>&1
 /usr/bin/grep -Fxq 'helperV5=v5' "$results/$mode-v5.log"
 /usr/bin/diff -rq "$payload_app" "$app" > "$results/$mode-payload-app.log"
 /usr/bin/cmp "$payload_helper" "$helper" > "$results/$mode-payload-helper.log"
 /usr/bin/cmp "$payload_plist" "$plist" > "$results/$mode-payload-plist.log"
 wattson_run_timeout 20 /usr/bin/sudo -n /bin/launchctl print "system/$label" > "$results/$mode-launchd.log"
 /usr/bin/shasum -a 256 "$package" "$app/Contents/MacOS/Wattson" "$helper" "$plist" > "$results/$mode-installed.sha256"
 wattson_stop_executable "$app/Contents/MacOS/Wattson"
 echo "PASS $mode"
}
disable_helper() {
 wattson_run_timeout 20 /usr/bin/sudo -n /bin/launchctl bootout "system/$label"
 wattson_run_timeout 20 /usr/bin/sudo -n /bin/launchctl disable "system/$label"
 /usr/bin/sudo -n /bin/launchctl print-disabled system > "$results/$1-disabled.log"
 /usr/bin/grep -Eq '"com.leoarrow.wattson.helper"[[:space:]]*=>[[:space:]]*true' "$results/$1-disabled.log"
}
verify_install previous-fresh "$previous" "$previous_version" "$scratch/previous-expanded"
disable_helper disabled-service-upgrade
verify_install disabled-service-upgrade "$incoming" "$expected_version" "$scratch/candidate-expanded"
remove_install between-matrices
for domain in com.leoarrow.wattson com.leoarrow.Wattson; do
 /usr/bin/defaults delete "$domain" > "$results/between-matrices-$domain-defaults.log" 2>&1 || {
  [[ ! -e "$HOME/Library/Preferences/$domain.plist" ]] || exit 1
 }
done
for path in "$HOME/Library/Containers/com.leoarrow.wattson" "$HOME/Library/Application Scripts/com.leoarrow.wattson" "$HOME/Library/Application Support/Wattson" "$HOME/Library/LaunchAgents/com.leoarrow.wattson.login.plist"; do
 # Initial preflight proved these user paths absent. Only this matrix owns them.
 _wattson_directory_has_mount "$path" && exit 1
 /bin/rm -rf -- "$path"
done
for path in "$HOME/Library/Preferences/com.leoarrow.wattson.plist" "$HOME/Library/Preferences/com.leoarrow.Wattson.plist" "$HOME/Library/Containers/com.leoarrow.wattson" "$HOME/Library/Application Scripts/com.leoarrow.wattson" "$HOME/Library/Application Support/Wattson" "$HOME/Library/LaunchAgents/com.leoarrow.wattson.login.plist"; do
 [[ ! -e "$path" && ! -L "$path" ]] || { echo "Owned user data appeared before second matrix: $path" >&2; exit 1; }
done
assert_absent
for mode in fresh reinstall disabled-service-reinstall; do
 [[ "$mode" != disabled-service-reinstall ]] || disable_helper "$mode"
 verify_install "$mode" "$incoming" "$expected_version" "$scratch/candidate-expanded"
done
echo HISTORY_PERFORMANCE_PACKAGE_MATRIX_PASSED
