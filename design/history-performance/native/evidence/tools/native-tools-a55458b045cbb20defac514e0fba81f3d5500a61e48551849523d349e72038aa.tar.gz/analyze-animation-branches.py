from pathlib import Path
import json, sys

source = Path(sys.argv[1]).resolve()
data = json.loads(source.read_text())
assert data['mode'] == 'scalar' and not data['PNGWorkDuringScalarPass']
checks = []
counts = {'basicScrollStrokes': 0, 'keyframeAxisStrokes': 0, 'matchedFillMorphs': 0}

def check(name, passed, detail=None):
    checks.append({'name': name, 'passed': bool(passed), 'detail': detail})

def valid_path(path):
    return path and path.get('finite') is True and bool(path.get('commands'))

for index, event in enumerate(data['events']):
    if event['event'] != 'update':
        continue
    animations = [a for layer in event['layers'] for a in layer['animations']]
    stroke = next((a for a in animations if a['key'] == 'history.stroke'), None)
    if stroke is None:
        continue
    label = f"{event['phase']} update {index}"
    axis = any(a['key'] == 'history.viewport' for a in animations)
    if axis:
        counts['keyframeAxisStrokes'] += 1
        check(label + ': scaled stroke retains 33 keyframes',
              stroke.get('animationClass') == 'CAKeyframeAnimation'
              and stroke.get('valueCount') == 33 and stroke.get('pathFrameCount') == 33)
        check(label + ': all scaled stroke keyframes finite and same topology',
              stroke.get('finitePathFrames') is True and stroke.get('pathTopologyMatches') is True)
    else:
        counts['basicScrollStrokes'] += 1
        start, end = stroke.get('fromPath'), stroke.get('toPath')
        check(label + ': unscaled stroke uses a basic path transition',
              stroke.get('animationClass') == 'CABasicAnimation' and stroke.get('keyPath') == 'path')
        check(label + ': basic endpoints finite and same topology',
              valid_path(start) and valid_path(end) and start['commands'] == end['commands'])
    for fill in (a for a in animations if a['key'] == 'history.fill'):
        counts['matchedFillMorphs'] += 1
        start, end = fill.get('fromPath'), fill.get('toPath')
        check(label + ': fill morph retains matched finite topology',
              fill.get('animationClass') == 'CABasicAnimation'
              and valid_path(start) and valid_path(end) and start['commands'] == end['commands'])

for phase in [f"basic-to-{target}-{fraction}" for target in ['axis', 'basic'] for fraction in [25, 50, 90]] + ['settled-axis-to-basic']:
    events = [e for e in data['events'] if e['phase'] == phase]
    updates = []
    for event in events:
        if event['event'] != 'update':
            continue
        animations = [a for layer in event['layers'] for a in layer['animations']]
        stroke = next((a for a in animations if a['key'] == 'history.stroke'), None)
        if stroke:
            updates.append(stroke)
    expected = ['CAKeyframeAnimation', 'CABasicAnimation'] if phase == 'settled-axis-to-basic' else ['CABasicAnimation', 'CAKeyframeAnimation' if '-axis-' in phase else 'CABasicAnimation']
    check(phase + ': genuine source updates reach expected branches',
          [a.get('animationClass') for a in updates] == expected,
          {'expected': expected, 'actual': [a.get('animationClass') for a in updates]})
    before = next((e for e in events if e['event'] == 'before-retarget'), None)
    if phase == 'settled-axis-to-basic':
        check(phase + ': axis completed before later basic update', before and before.get('hasChartAnimation') is False)
    else:
        check(phase + ': original basic transition active at retarget', before and before.get('hasChartAnimation') is True,
              {'requestedFraction': int(phase.rsplit('-', 1)[1]) / 100,
               'actualElapsedSeconds': before.get('elapsed') if before else None,
               'actualElapsedFractionOf180ms': before.get('elapsed', 0) / .18 if before else None})
    baseline = next((e for e in events if e['event'] == 'before-update'), None)
    check(phase + ': first model committed before measured update', baseline and len(baseline.get('projectedRetainedSamples', [])) == 3
          and bool(baseline.get('headStroke')))

check('ordinary basic branch observed', counts['basicScrollStrokes'] > 0)
check('scaled 33-keyframe branch observed', counts['keyframeAxisStrokes'] > 0)
check('matched fill morph observed', counts['matchedFillMorphs'] > 0)
report = {'schema': 1, 'source': str(source), 'checks': checks, 'counts': counts,
          'checkCount': len(checks), 'passed': sum(c['passed'] for c in checks),
          'allPassed': all(c['passed'] for c in checks),
          'scope': 'Production animation objects recorded immediately after update. Geometry, constant line width, gradient and presentation continuity are checked separately by the unchanged 4.3.10 scalar analyzer and native interaction tests. Not an FPS measurement.'}
output = source.parent / 'animation-branches.json'
assert not output.exists()
output.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
raise SystemExit(0 if report['allPassed'] else 1)
