import pathlib,re,sys
text=pathlib.Path(sys.argv[1]).read_text()
patterns=[r"com\.leoarrow\.wattson\.interactiontests\.[a-f0-9-]{36}",r"Wattson\.SettingsCommandInteraction\.[A-Fa-f0-9-]{36}"]
domains=sorted(set(m.group(0) for p in patterns for m in re.finditer(p,text)))
if len(domains)!=2: raise RuntimeError('Expected exactly owned interaction bundle and defaults suite')
pathlib.Path(sys.argv[2]).write_text('\n'.join(domains)+'\n')
