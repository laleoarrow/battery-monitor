from pathlib import Path
import hashlib, json, sys
candidate_path, baseline_path = map(Path, sys.argv[1:3])
candidate, baseline = (json.loads(p.read_text()) for p in [candidate_path, baseline_path])
checks = []
for phase, old in baseline['summaries'].items():
    new = candidate['summaries'].get(phase)
    checks.append({'phase': phase, 'check': 'same fixture phase measured', 'passed': new is not None})
    if new is None:
        continue
    for key in ['maxHeadToStrokeDeviationPoints', 'maxGradientBandDriftY']:
        # Both passes sample actual presentations at different run-loop instants.
        # A predeclared 0.05 pt margin is 0.1 physical pixel on the 2x guest.
        limit = old[key] + .05
        checks.append({'phase': phase, 'check': key + ' does not materially worsen',
                       'baseline': old[key], 'candidate': new[key], 'allowedIncreasePoints': .05,
                       'passed': new[key] <= limit})
report = {'schema': 1, 'baselineSourceCommit': '4c31f01b3cae07a2ae59e32fc8d7a1534b9bd161',
          'baselineSHA256': hashlib.sha256(baseline_path.read_bytes()).hexdigest(),
          'candidateAnalysisSHA256': hashlib.sha256(candidate_path.read_bytes()).hexdigest(),
          'checks': checks, 'checkCount': len(checks), 'passed': sum(c['passed'] for c in checks),
          'allPassed': all(c['passed'] for c in checks),
          'scope': 'Same eleven scalar fixtures, with independently sampled run-loop times. Compares measured geometric deviations, not pixels or display FPS. The native assertion suite and unchanged scalar analyzer apply separately.'}
output = candidate_path.parent / 'baseline-comparison.json'
assert not output.exists()
output.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
raise SystemExit(0 if report['allPassed'] else 1)
