from pathlib import Path
import json, math, sys
source=Path(sys.argv[1]).resolve();data=json.loads(source.read_text())
assert data['mode']=='controlled-clock' and data['testOnlyParentLayerClock'] is True and data['PNGWorkDuringScalarPass'] is False
checks=[];progress=[]
def check(name,passed,detail=None):checks.append({'name':name,'passed':bool(passed),'detail':detail})
def animations(event):return [a for layer in event['layers'] for a in layer['animations']]
def event(phase,name):return next(e for e in data['events'] if e['phase']==phase and e['event']==name)
def point_error(before,after,key,identity):
 a={p[identity]:p for p in before[key]};b={p[identity]:p for p in after[key]}
 if not a or a.keys()!=b.keys():return None
 return max(math.hypot(a[i]['x']-b[i]['x'],a[i]['y']-b[i]['y']) for i in a)
phases=list(dict.fromkeys(e['phase'] for e in data['events']))
for phase in phases:
 events=[e for e in data['events'] if e['phase']==phase]
 updates=[e for e in events if e['event']=='update' and any(a['key']=='history.stroke' for a in animations(e))]
 strokes=[next(a for a in animations(e) if a['key']=='history.stroke') for e in updates]
 expected=['CAKeyframeAnimation','CABasicAnimation'] if phase=='settled-axis-to-basic' else ['CABasicAnimation','CAKeyframeAnimation' if '-axis-' in phase else 'CABasicAnimation']
 check(phase+': unmodified production reaches expected branches',[a['animationClass'] for a in strokes]==expected)
 before=event(phase,'before-retarget');after=event(phase,'after-retarget-commit')
 check(phase+': synthetic parent clock frozen',all(any(layer['path']=='root' and layer['speed']==0 for layer in e['layers']) for e in [before,after]))
 if phase.startswith('basic-to-'):
  motions=[next(a for a in animations(e) if a['key'] in ['history.scroll','history.viewport']) for e in updates]
  initial=motions[0]['fromValue'];new=motions[1]
  captured=new['fromValue'] if new['key']=='history.scroll' else new['fromTransform'][2]
  actual=1-(captured-initial)/initial;requested=int(phase.rsplit('-',1)[1])/100
  row={'phase':phase,'requestedProgress':requested,'actualProductionCapturedProgress':actual,'absoluteError':abs(actual-requested),'initialMotionFromX':initial,'newMotionFromX':captured}
  progress.append(row)
  check(phase+': actual production capture matches exact controlled fraction',0<=actual<1 and abs(actual-requested)<=1e-5,row)
 else:
  check(phase+': after axis completion production selects basic',strokes[-1]['animationClass']=='CABasicAnimation')
 anchor=point_error(before,after,'projectedRetainedSamples','sampledAt')
 interior=point_error(before,after,'interiorAnchors','sampledAtMidpoint')
 check(phase+': retained raw anchors continuous',anchor is not None and anchor<=.05,{'maxErrorPoints':anchor})
 check(phase+': non-knot actual path interiors continuous',interior is not None and interior<=.05,{'maxErrorPoints':interior})
 heads=[before['headStroke'],after['headStroke']]
 head_error=math.dist(heads[0]['head'],heads[1]['head']) if all('head' in h for h in heads) else None
 check(phase+': visible endpoint continuous',head_error is not None and head_error<=.05,{'errorPoints':head_error})
 check(phase+': fixed stroke width and head stays on actual stroke',all(h.get('presentationLineWidth')==1.6 and h.get('deviationPoints',1)<=.25 for h in heads))
 check(phase+': final explicit lifecycle cleanup remains available',any(e['event']=='after-settle' for e in events))
check('all six exact fraction cases and settled axis boundary observed',len(phases)==7 and len(progress)==6)
report={'schema':1,'source':str(source),'scope':'SYNTHETIC deterministic native presentation test: only the test parent CALayer speed/timeOffset are controlled; production HistoryView is unmodified. Confirms retarget captures and non-knot/head continuity, independently of natural cadence. Does not measure wall-clock animation duration or display FPS.','checks':checks,'checkCount':len(checks),'passed':sum(c['passed'] for c in checks),'allPassed':all(c['passed'] for c in checks),'actualProgress':progress}
output=source.parent/'controlled-analysis.json';assert not output.exists();output.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2));raise SystemExit(0 if report['allPassed'] else 1)
