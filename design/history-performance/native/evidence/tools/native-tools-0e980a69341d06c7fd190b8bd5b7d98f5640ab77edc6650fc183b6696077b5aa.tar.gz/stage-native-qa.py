# This runner is extracted from a content-addressed archive before execution.
import hashlib,json,os,shutil,signal,subprocess,sys,tarfile,tempfile,time
from pathlib import Path
share=Path('/Volumes/My Shared Files/performance')
manifest=json.loads(sys.argv[1]);label=sys.argv[2]
entry=manifest.get('nativeRunner','run-axis-qa.sh');assert entry in ['run-axis-qa.sh','run-axis-capture-only.sh']
assert label.replace('-','').isalnum()
assert subprocess.check_output(['/usr/sbin/sysctl','-n','hw.model'],text=True).strip().startswith('VirtualMac')
project=Path.home()/'Project/Wattson-HistoryPerf-QA';project.mkdir(parents=True,exist_ok=True)
root=project/'.build/owned.noindex';root.mkdir(parents=True,exist_ok=True)
run=Path(tempfile.mkdtemp(prefix='run.',dir=root));child=None;status=1
signals=[signal.SIGHUP,signal.SIGINT,signal.SIGTERM]
def interrupted(number,frame):
 global status
 status=128+number
 raise SystemExit(status)
for number in signals:signal.signal(number,interrupted)
def unpack(archive, expected, dest, file_hashes=None):
 assert hashlib.sha256(archive.read_bytes()).hexdigest()==expected
 dest.mkdir(parents=True,exist_ok=True)
 with tarfile.open(archive,'r:gz') as t:
  for m in t.getmembers():
   p=Path(m.name);assert not p.is_absolute() and '..' not in p.parts and (m.isfile() or m.isdir())
   target=dest/p
   if m.isdir():target.mkdir(parents=True,exist_ok=True)
   else:
    target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(t.extractfile(m).read());target.chmod(m.mode)
 if file_hashes:
  actual={n:hashlib.sha256((dest/n).read_bytes()).hexdigest() for n in file_hashes}
  assert actual==file_hashes
try:
 source_archive=run/'source.tar.gz';shutil.copyfile(share/manifest['source']['archive'],source_archive)
 tools_archive=run/'tools.tar.gz';shutil.copyfile(share/manifest['tools']['archive'],tools_archive)
 source=run/'source';tools=run/'tools';results=run/'results'
 unpack(source_archive,manifest['source']['archiveSHA256'],source,manifest['source']['files'])
 unpack(tools_archive,manifest['tools']['archiveSHA256'],tools,manifest['tools']['files'])
 results.mkdir()
 provenance={'source':manifest['source'],'tools':manifest['tools'],'verifiedGuestLocalBeforeExecution':True,'guestRun':str(run),'label':label,'sourceState':'unmodified frozen production; independent native correctness and visual verification, not a timing benchmark'}
 (results/'provenance.json').write_text(json.dumps(provenance,indent=2)+'\n')
 blocked=signal.pthread_sigmask(signal.SIG_BLOCK,signals)
 try:
  env=dict(os.environ, WATTSON_HISTORY_SOURCE_ROOT=str(source), WATTSON_HISTORY_TOOLS_DIR=str(tools), WATTSON_HISTORY_RESULTS=str(results), WATTSON_HISTORY_SOURCE_COMMIT=manifest['source']['sourceCommit'])
  child=subprocess.Popen(['/usr/bin/python3',str(source/'scripts/lib/run_owned.py'),'--grace','300','--timeout','1800','--','/bin/bash',str(tools/entry)],env=env,start_new_session=True)
 finally:signal.pthread_sigmask(signal.SIG_SETMASK,blocked)
 status=child.wait(timeout=2100)
finally:
 # Evidence export may fail; owned scratch still must be removed. Preserve the
 # primary command/exception status and surface cleanup/export failures too.
 cleanup_errors=[]
 try:
  for number in signals:signal.signal(number,signal.SIG_IGN)
  if child is not None and child.poll() is None:
   os.killpg(child.pid,signal.SIGTERM)
   try:child.wait(timeout=90)
   except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait(timeout=10)
 except Exception as error:cleanup_errors.append(('child',repr(error)))
 try:
  if (run/'results').is_dir():
   archive=run/'results.tar.gz'
   with tarfile.open(archive,'w:gz') as t:t.add(run/'results',arcname='results')
   sha=hashlib.sha256(archive.read_bytes()).hexdigest();dest=share/'native-review'/('results-'+label+'-'+sha+'.tar.gz')
   assert not dest.exists();shutil.copyfile(archive,dest)
   record={'archive':'native-review/'+dest.name,'sha256':sha,'exitCode':status,'label':label}
   (share/'native-review'/('result-'+label+'.json')).write_text(json.dumps(record,indent=2)+'\n')
   print(json.dumps(record),flush=True)
 except Exception as error:cleanup_errors.append(('evidence-export',repr(error)))
 finally:
  try:shutil.rmtree(run)
  except Exception as error:cleanup_errors.append(('scratch',repr(error)))
 if cleanup_errors:
  for kind,error in cleanup_errors:print('NATIVE_QA_CLEANUP_FAILED '+kind+': '+error,file=sys.stderr)
  if status==0:status=1
raise SystemExit(status)
