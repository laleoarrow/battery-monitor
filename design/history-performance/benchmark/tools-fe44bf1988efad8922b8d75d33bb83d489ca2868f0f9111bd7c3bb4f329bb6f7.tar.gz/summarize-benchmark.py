import json,math,statistics,sys
from collections import defaultdict
from pathlib import Path
source=json.loads(Path(sys.argv[1]).read_text());groups=defaultdict(list)
for r in source['records']:
 assert r['visible'] and r['presentationBeforeUpdate'] and r['presentationVerified']
 groups[r['scenario']].append(r)
def quantile(x,p):
 x=sorted(x);i=(len(x)-1)*p;lo=math.floor(i);hi=math.ceil(i)
 return x[lo]+(x[hi]-x[lo])*(i-lo)
summary={'measurement':source['measurement'],'notFPS':True,'constructionCountingEnabled':source['countingEnabled'],'groups':{}}
for name,rows in groups.items():
 times=[x for r in rows for x in r['durationsMicroseconds']]
 round_medians=[statistics.median(r['durationsMicroseconds']) for r in rows]
 payloads={json.dumps(r['animationPayload'],sort_keys=True) for r in rows}
 counts={json.dumps(r['instrumentedCounts'],sort_keys=True) for r in rows}
 summary['groups'][name]={'rounds':len(rows),'calls':len(times),'microseconds':{'min':min(times),'median':statistics.median(times),'p90':quantile(times,.9),'p95':quantile(times,.95),'p99':quantile(times,.99),'max':max(times)},'roundMedianMicroseconds':{'min':min(round_medians),'median':statistics.median(round_medians),'p90':quantile(round_medians,.9),'p95':quantile(round_medians,.95),'p99':quantile(round_medians,.99),'max':max(round_medians)},'pooledCallsCorrelatedWithinRounds':True,'deterministicCounts':len(counts)==1,'constructionCounts':list(map(json.loads,sorted(counts))) if source['countingEnabled'] else None,'animationPayloadVariants':list(map(json.loads,sorted(payloads)))}
Path(sys.argv[2]).write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({k:v['microseconds'] for k,v in summary['groups'].items()},sort_keys=True))
