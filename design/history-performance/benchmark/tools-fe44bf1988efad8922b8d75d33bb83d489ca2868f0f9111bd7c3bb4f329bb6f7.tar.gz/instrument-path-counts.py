import difflib, hashlib, json, re, sys
from pathlib import Path
p=Path(sys.argv[1]);old=p.read_text();s=old
assert s.count('CGMutablePath()') >= 1
s=s.replace('CGMutablePath()', 'HistoryProfiling.path()').replace('CGPath(rect:', 'HistoryProfiling.rectPath(rect:')
injected={}
for name,field in [('paths','pathsCalls'),('fillPath','fillPathCalls'),('segments','decodedPaths')]:
 pattern=r'(^    private func '+name+r'\([^\n]*\{)'
 s,n=re.subn(pattern,lambda m:m.group(1)+'\n        HistoryProfiling.'+field+' += 1',s,flags=re.M)
 assert n <= 1
 injected[name]=n
p.write_text(s)
Path(sys.argv[2]).write_text(json.dumps({'purpose':'Deterministic construction counts only; do not use instrumented durations as production performance','originalSHA256':hashlib.sha256(old.encode()).hexdigest(),'derivedSHA256':hashlib.sha256(s.encode()).hexdigest(),'injectedHelpers':injected,'diff':''.join(difflib.unified_diff(old.splitlines(True),s.splitlines(True),fromfile='original/HistoryLayer.swift',tofile='counted/HistoryLayer.swift'))},indent=2)+'\n')
