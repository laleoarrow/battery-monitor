#!/bin/bash
set -euo pipefail
repo="${1:?frozen guest-local source}"
tools="${2:?frozen guest-local tools}"
results="${3:?explicit evidence output}"
count="${4:-64}"
mode="${5:-original}"
[[ "$mode" == original || "$mode" == counted ]]
source "$repo/scripts/lib/local_cleanup.sh"
wattson_cleanup_init
mkdir -p "$results" "$repo/.build/history-benchmark.noindex"
run="$(mktemp -d "$repo/.build/history-benchmark.noindex/run.XXXXXX")"
wattson_cleanup_add_dir "$run"
cd "$repo"
/usr/bin/sw_vers > "$results/system.txt"
wattson_run /usr/bin/xcrun swiftc --version > "$results/swift.txt"
instrumented=0
if [[ "$mode" == counted ]]; then
  instrumented=1
  mkdir -p "$run/source"
  cp Popover/HistoryLayer.swift "$run/source/HistoryLayer.swift"
  wattson_run /usr/bin/python3 "$tools/instrument-path-counts.py" "$run/source/HistoryLayer.swift" "$results/instrumentation.json"
  history_source="$run/source/HistoryLayer.swift"
else history_source="$repo/Popover/HistoryLayer.swift"; fi
app="$run/HistoryBenchmark.app"
bundle_id="com.leoarrow.wattson.historyperf.$(/usr/bin/uuidgen | /usr/bin/tr '[:upper:]' '[:lower:]')"
wattson_cleanup_add_app "$app"
wattson_cleanup_add_container "$bundle_id"
wattson_cleanup_add_defaults "$bundle_id"
wattson_cleanup_add_executable "$app/Contents/MacOS/HistoryBenchmark"
mkdir -p "$app/Contents/MacOS"
printf '%s\t%s\n' "$bundle_id" "$app" > "$results/owned-bundle.tsv"
cp "$tools/benchmark-history.swift" "$run/main.swift"
/usr/bin/shasum -a 256 Core/HistoryChart.swift "$history_source" "$run/main.swift" > "$results/inputs.sha256"
sources=(Core/*.swift MenuBar/*.swift)
for item in Popover/*.swift; do [[ "$item" == Popover/HistoryLayer.swift ]] || sources+=("$item"); done
sources+=("$history_source" "$run/main.swift")
# Match optimized native app compilation; no DEBUG-only hooks are enabled.
wattson_run /usr/bin/xcrun swiftc -O -whole-module-optimization -parse-as-library -swift-version 5 -warnings-as-errors -target arm64-apple-macos12.0 "${sources[@]}" -framework AppKit -framework CoreGraphics -framework IOKit -o "$app/Contents/MacOS/HistoryBenchmark" > "$results/build.log" 2>&1
cat > "$app/Contents/Info.plist" <<PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
<key>CFBundleIdentifier</key><string>$bundle_id</string>
<key>CFBundleName</key><string>HistoryBenchmark</string>
<key>CFBundleExecutable</key><string>HistoryBenchmark</string>
<key>CFBundlePackageType</key><string>APPL</string>
<key>LSUIElement</key><true/>
</dict></plist>
PLIST
wattson_run /usr/bin/codesign --force --sign - "$app" >> "$results/build.log" 2>&1
/usr/bin/shasum -a 256 "$app/Contents/MacOS/HistoryBenchmark" > "$results/executable.sha256"
wattson_run_timeout 290 /usr/bin/env WATTSON_HISTORY_INSTRUMENTED="$instrumented" WATTSON_FORCE_REDUCE_MOTION=0 WATTSON_FORCE_REDUCE_TRANSPARENCY=0 WATTSON_FORCE_INCREASE_CONTRAST=0 "$app/Contents/MacOS/HistoryBenchmark" "$results/benchmark.json" "$count" > "$results/run.log" 2> "$results/run.err"
[[ -s "$results/benchmark.json" ]]
wattson_run /usr/bin/python3 "$tools/summarize-benchmark.py" "$results/benchmark.json" "$results/summary.json"
printf 'HISTORY_BENCHMARK_PASSED %s %s\n' "$mode" "$count"
